# EDS - Database Documentation

**Server:** SQL-Server  
**Generated:** 2025-08-27 09:31:32  
**Size:** 994,440 MB used of 1,172,114 MB allocated

## Table of Contents
- [Database Overview](#database-overview)
- [Schemas](#schemas)
- [Tables](#tables)
- [Views](#views)
- [Stored Procedures](#stored-procedures)
- [Functions](#functions)
- [Relationships](#relationships)

## Database Overview

| Metric | Count |
|--------|-------|
| Schemas | 24 |
| Tables | 437 |
| Views | 474 |
| Stored Procedures | 395 |
| Functions | 232 |
| Total Rows | 1,333,137,419 |

## Schemas

| Schema Name | Principal |
|-------------|-----------|
| archive | dbo |
| db_accessadmin | db_accessadmin |
| db_backupoperator | db_backupoperator |
| db_datareader | db_datareader |
| db_datawriter | db_datawriter |
| db_ddladmin | db_ddladmin |
| db_denydatareader | db_denydatareader |
| db_denydatawriter | db_denydatawriter |
| db_owner | dbo |
| db_securityadmin | db_securityadmin |
| dbo | dbo |
| EDSIQEndUser | dbo |
| EDSIQJavaUser | EDSIQJavaUser |
| EDSIQPOPRINT | EDSIQPOPRINT |
| EDSIQVendorPOUser | EDSIQVendorPOUser |
| EDSIQWeb2 | EDSIQWeb2 |
| EDSIQWebUser | EDSIQWebUser |
| EDSWebRpts | EDSWebRpts |
| guest | guest |
| IUSR_SBSEDDATA | IUSR_SBSEDDATA |
| utility | dbo |
| VendorBids | VendorBids |
| VMS | dbo |
| XMLDevelop | XMLDevelop |


## Tables


### archive.allitems



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidHeaderId | int | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |
| ItemCode | varchar(50) | Yes | No |  |  |
| Description | varchar(2311) | Yes | No |  |  |
| UnitCode | varchar(20) | Yes | No |  |  |
| VendorItemCode | varchar(50) | Yes | No |  |  |
| Alternate | varchar(512) | Yes | No |  |  |
| BidPrice | money | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| BidItemId | int | Yes | No |  |  |
| CatalogId | int | Yes | No |  |  |
| CrossRefId | int | Yes | No |  |  |
| PricePlanId | int | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| PackedVendorItemCode | varchar(50) | Yes | No |  |  |
| ItemBidType | varchar(50) | Yes | No |  |  |
| TotalOrdered | int | Yes | No |  |  |
| TotalBid | int | Yes | No |  |  |
| SysId | int | No | No |  |  |









### archive.Approvals



**Rows:** 3,517,361

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ApprovalId | int | No | No |  |  |
| ApprovalById | int | Yes | No |  |  |
| Level | tinyint | Yes | No |  |  |
| StatusId | int | Yes | No |  |  |
| RequisitionId | int | Yes | No |  |  |
| ApprovalDate | datetime | Yes | No |  |  |
| ApproverId | int | Yes | No |  |  |
| rowguid | uniqueidentifier | No | No |  |  |









### archive.ApprovalsHistory



**Rows:** 447,389

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ApprovalId | int | No | No |  |  |
| ApprovalById | int | Yes | No |  |  |
| Level | tinyint | Yes | No |  |  |
| StatusId | int | Yes | No |  |  |
| RequisitionId | int | Yes | No |  |  |
| ApprovalDate | datetime | Yes | No |  |  |
| ApproverId | int | Yes | No |  |  |
| rowguid | uniqueidentifier | No | No |  |  |









### archive.Awards



**Rows:** 143,977

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| AwardId | int | No | No |  |  |
| Active | tinyint | Yes | No |  |  |
| BidId | int | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| PricePlanId | int | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| BidStartDate | datetime | Yes | No |  |  |
| BidEndDate | datetime | Yes | No |  |  |
| VendorBidNumber | varchar(50) | Yes | No |  |  |
| Description | varchar(511) | Yes | No |  |  |
| CatalogId | int | Yes | No |  |  |
| DiscountRate | decimal(9,5) | Yes | No |  |  |
| ItemsBid | int | Yes | No |  |  |
| AmountBid | money | Yes | No |  |  |
| BidDiscountRate | decimal(9,5) | Yes | No |  |  |
| StateContractDiscount | decimal(9,5) | Yes | No |  |  |
| UseGrossPrices | int | Yes | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| DateModified | datetime | Yes | No |  |  |
| BidImportId | int | Yes | No |  |  |
| rowguid | uniqueidentifier | No | No |  |  |









### archive.BatchDetail



**Rows:** 4,060,286

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BatchDetailId | int | No | No |  |  |
| Active | tinyint | Yes | No |  |  |
| BatchBookId | int | Yes | No |  |  |
| BatchId | int | No | No |  |  |
| RecordNumber | int | Yes | No |  |  |
| Type | char(1) | Yes | No |  |  |
| DistrictCode | char(2) | Yes | No |  |  |
| Category | char(1) | Yes | No |  |  |
| CometId | char(5) | Yes | No |  |  |
| BookAmount | char(10) | Yes | No |  |  |
| ItemCode | char(20) | Yes | No |  |  |
| Quantity | char(6) | Yes | No |  |  |
| OrigType | char(1) | Yes | No |  |  |
| OrigDistrictCode | char(2) | Yes | No |  |  |
| OrigCategory | char(1) | Yes | No |  |  |
| OrigCometCode | char(5) | Yes | No |  |  |
| OrigItemCode | char(15) | Yes | No |  |  |
| OrigQuantity | char(6) | Yes | No |  |  |
| ErrorField | tinyint | Yes | No |  |  |
| DistrictId | int | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| UserId | int | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |
| BidPrice | money | Yes | No |  |  |
| Qty | int | Yes | No |  |  |
| Total | money | Yes | No |  |  |
| DetailId | int | Yes | No |  |  |
| SourceId | int | Yes | No |  |  |
| Modified | datetime | Yes | No |  |  |
| ModifiedBy | int | Yes | No |  |  |
| PackedCode | varchar(16) | Yes | No |  |  |
| Location | char(1) | Yes | No |  |  |
| OrigBookAmount | char(10) | Yes | No |  |  |
| BatchFileName | varchar(16) | Yes | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| PreviousCategory | char(1) | Yes | No |  |  |
| PackComplete | tinyint | Yes | No |  |  |









### archive.BidHeaderCheckList



**Rows:** 4,521

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidHeaderCheckListId | int | No | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| BidderCheckListId | int | Yes | No |  |  |
| DisplaySequence | int | Yes | No |  |  |









### archive.BidHeaderDetail



**Rows:** 26,252,593

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidHeaderDetailId | bigint | No | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| DetailId | int | Yes | No |  |  |
| BidRequestItemId | int | Yes | No |  |  |
| Quantity | int | Yes | No |  |  |
| DateAdded | datetime | Yes | No |  |  |
| BidHeaderKey | int | Yes | No |  |  |









### archive.BidHeaderDocument



**Rows:** 11,787

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidHeaderDocumentId | int | No | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| BidDocumentId | int | Yes | No |  |  |
| DisplaySequence | int | Yes | No |  |  |









### archive.BidHeaderDocuments



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidHeaderDocumentId | int | No | No |  |  |
| BidHeaderId | int | No | No |  |  |
| DocumentDate | datetime | Yes | No |  |  |
| DocumentTitle | varchar(255) | No | No |  |  |
| DocumentFile | varchar(255) | Yes | No |  |  |
| DocumentData | text | Yes | No |  |  |
| DisplaySeq | int | Yes | No |  |  |









### archive.BidHeaders



**Rows:** 3,395

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidHeaderId | int | Yes | No |  |  |
| BidDate | datetime | Yes | No |  |  |
| BidAwardDate | datetime | Yes | No |  |  |
| EffectiveUntil | datetime | Yes | No |  |  |







**Indexes:**
- Idx_BidHeaders (NONCLUSTERED): BidHeaderId




### archive.BidImports



**Rows:** 42,011

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidImportId | int | No | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| Active | tinyint | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| BidItemDiscountRate | decimal(9,5) | Yes | No |  |  |
| CatalogId | int | Yes | No |  |  |
| CatalogDiscountRate | decimal(9,5) | Yes | No |  |  |
| VendorBidNumber | varchar(50) | Yes | No |  |  |
| ItemsBid | int | Yes | No |  |  |
| AmountBid | money | Yes | No |  |  |
| MinimumOrder | money | Yes | No |  |  |
| FreeDeliveryMinimum | money | Yes | No |  |  |
| Status | varchar(50) | Yes | No |  |  |
| Comments | varchar(1024) | Yes | No |  |  |
| DateModified | datetime | Yes | No |  |  |
| StateContractDiscount | decimal(9,5) | Yes | No |  |  |
| AdditionalHandlingAmount | money | Yes | No |  |  |
| FreeHandlingAmount | money | Yes | No |  |  |
| FreeHandlingStart | datetime | Yes | No |  |  |
| FreeHandlingEnd | datetime | Yes | No |  |  |
| UseVendorContactInfo | tinyint | Yes | No |  |  |
| ContactEmail | varchar(255) | Yes | No |  |  |
| ContactName | varchar(50) | Yes | No |  |  |
| ContactPhone | varchar(20) | Yes | No |  |  |
| ContactFax | varchar(20) | Yes | No |  |  |
| POVendorContactId | int | Yes | No |  |  |
| VendorBidId | int | Yes | No |  |  |
| BidVendorContactId | int | Yes | No |  |  |
| WebsiteLink | varchar(255) | Yes | No |  |  |
| CatalogDiscountComments | varchar(512) | Yes | No |  |  |
| BidHeaderKey | int | Yes | No |  |  |









### archive.BidMappedItems



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidMappedItemId | uniqueidentifier | No | No |  |  |
| BidHeaderId | int | No | No |  |  |
| OrigItemId | int | No | No |  |  |
| NewItemId | int | No | No |  |  |
| ReasonCode | varchar(20) | Yes | No |  |  |
| MapDate | datetime | No | No |  |  |









### archive.BidMSRPResults



**Rows:** 10,848

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidMSRPResultsId | int | No | No |  |  |
| Active | tinyint | Yes | No |  |  |
| BidHeaderId | int | No | No |  |  |
| BidImportId | int | No | No |  |  |
| ManufacturerId | int | Yes | No |  |  |
| DiscountRate | decimal(9,5) | Yes | No |  |  |
| Modified | datetime | No | No |  |  |
| DiscountRateString | char(10) | Yes | No |  |  |
| WriteInFlag | tinyint | Yes | No |  |  |
| WriteInManufacturer | varchar(100) | Yes | No |  |  |
| VendorNotes | varchar(1000) | Yes | No |  |  |
| BidRequestManufacturerId | int | Yes | No |  |  |
| WinningBidOverride | tinyint | Yes | No |  |  |
| PriceListTypeId | int | Yes | No |  |  |
| AuthorizationLetter | tinyint | Yes | No |  |  |
| SubmittedExcel | tinyint | Yes | No |  |  |
| ProductCatalog | tinyint | Yes | No |  |  |
| TotalAward | tinyint | Yes | No |  |  |
| VendorPriceFile | tinyint | Yes | No |  |  |
| TotalAwardDiscount | decimal(9,5) | Yes | No |  |  |
| TotalAwardString | varchar(20) | Yes | No |  |  |
| ExcelFileApproved | tinyint | Yes | No |  |  |
| BidHeaderKey | int | Yes | No |  |  |









### archive.BidReawards



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidReawardId | int | No | No |  |  |
| BidHeaderId | int | No | No |  |  |
| ReawardDate | datetime | No | No |  |  |
| EffectiveFrom | datetime | No | No |  |  |
| EffectiveUntil | datetime | No | No |  |  |
| Comments | varchar(4096) | Yes | No |  |  |









### archive.BidRequestItems



**Rows:** 5,704,577

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidRequestItemId | int | No | No |  |  |
| BidRequestItemId_OLD | int | Yes | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |
| BidRequest | int | Yes | No |  |  |
| Active | tinyint | Yes | No |  |  |
| RequisitionCount | int | Yes | No |  |  |
| Status | varchar(50) | Yes | No |  |  |
| Comments | varchar(1024) | Yes | No |  |  |
| BidRequestAmount | money | Yes | No |  |  |
| Checksum | int | Yes | No |  |  |
| MasterItemCodePtr | int | Yes | No |  |  |
| BidHeaderKey | int | Yes | No |  |  |
| ImageURL | varchar(300) | Yes | No |  |  |
| SDS_URL | varchar(300) | Yes | No |  |  |









### archive.BidRequestManufacturer



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidRequestManufacturerId | int | No | No |  |  |
| Active | tinyint | Yes | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| ManufacturerId | int | Yes | No |  |  |
| SequenceNumber | int | Yes | No |  |  |
| AllowAdditionalProductLines | tinyint | Yes | No |  |  |
| UseOptions | tinyint | Yes | No |  |  |
| BidHeaderKey | int | Yes | No |  |  |









### archive.BidRequestOptions



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidRequestOptionId | int | No | No |  |  |
| BidHeaderId | int | No | No |  |  |
| ManufacturerId | int | Yes | No |  |  |
| ManufacturerProductLineId | int | Yes | No |  |  |
| OptionId | int | Yes | No |  |  |
| BidRequestManufacturerId | int | Yes | No |  |  |
| BidRequestProductLineId | int | Yes | No |  |  |
| Name | varchar(50) | No | No |  |  |
| Weight | decimal(9,5) | Yes | No |  |  |









### archive.BidRequestPriceRanges



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidRequestPriceRangeId | int | No | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| BidRequestManufacturerId | int | Yes | No |  |  |
| BidRequestProductLineId | int | Yes | No |  |  |
| RangeBase | money | Yes | No |  |  |
| RangeWeight | decimal(9,5) | Yes | No |  |  |
| BidRequestMSRPOptionId | int | Yes | No |  |  |









### archive.BidResults



**Rows:** 30,585,282

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidResultsId | int | No | No |  |  |
| BidImportId | int | Yes | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| BidRequestItemId | int | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| DistrictId | int | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |
| ItemCode | varchar(50) | Yes | No |  |  |
| Units | varchar(16) | Yes | No |  |  |
| Alternate | varchar(512) | Yes | No |  |  |
| Quantity | int | Yes | No |  |  |
| ItemBidType | char(1) | Yes | No |  |  |
| UnitPrice | money | Yes | No |  |  |
| Cost | money | Yes | No |  |  |
| VendorItemCode | varchar(50) | Yes | No |  |  |
| QuantityBid | int | Yes | No |  |  |
| ItemsPerUnit | varchar(50) | Yes | No |  |  |
| UnitId | int | Yes | No |  |  |
| Status | varchar(51) | Yes | No |  |  |
| Comments | varchar(1024) | Yes | No |  |  |
| Active | int | Yes | No |  |  |
| PageNo | int | Yes | No |  |  |
| PackedVendorItemCode | varchar(50) | Yes | No |  |  |
| ModifiedDate | datetime | Yes | No |  |  |
| ModifiedSessionId | int | Yes | No |  |  |
| ModifiedBy | int | Yes | No |  |  |
| RTK_MSDSId | int | Yes | No |  |  |
| RTK_MSDSNotNeeded | tinyint | Yes | No |  |  |
| ContractNumber | varchar(50) | Yes | No |  |  |
| OriginalAwardedItem | tinyint | Yes | No |  |  |
| VOMId | int | Yes | No |  |  |
| AdditionalShipping | tinyint | Yes | No |  |  |
| ManufacturerBid | varchar(50) | Yes | No |  |  |
| ManufPartNoBid | varchar(50) | Yes | No |  |  |
| LinerGaugeMicrons | numeric(2,0) | Yes | No |  |  |
| LinerGaugeMil | numeric(3,2) | Yes | No |  |  |
| LinerCaseWeight | numeric(4,2) | Yes | No |  |  |
| LinerDimWidth | numeric(4,2) | Yes | No |  |  |
| LinerDimDepth | numeric(4,2) | Yes | No |  |  |
| LinerDimLength | numeric(4,2) | Yes | No |  |  |
| PackedManufPartNoBid | varchar(50) | Yes | No |  |  |
| BidHeaderKey | int | Yes | No |  |  |
| SDS_URL | varchar(300) | Yes | No |  |  |
| ImageURL | varchar(300) | Yes | No |  |  |
| UPC_ISBN | varchar(20) | Yes | No |  |  |
| UNSPSC | varchar(50) | Yes | No |  |  |









### archive.Bids



**Rows:** 172,256

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidId | int | No | No |  |  |
| Active | tinyint | Yes | No |  |  |
| CoopId | int | Yes | No |  |  |
| ClosingDate | datetime | Yes | No |  |  |
| OpeningDate | datetime | Yes | No |  |  |
| EffectiveFrom | datetime | Yes | No |  |  |
| EffectiveUntil | datetime | Yes | No |  |  |
| Name | varchar(255) | Yes | No |  |  |
| PricePlanId | int | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| BidDiscountRate | decimal(8,5) | Yes | No |  |  |
| VendorBidNumber | varchar(50) | Yes | No |  |  |
| DistrictId | int | Yes | No |  |  |
| ItemsBid | int | Yes | No |  |  |
| AmountBid | money | Yes | No |  |  |
| CatalogId | int | Yes | No |  |  |
| Description | varchar(511) | Yes | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| UseGrossPrices | int | Yes | No |  |  |
| BidImportId | int | Yes | No |  |  |
| DateModified | datetime | Yes | No |  |  |
| AdditionalHandlingAmount | money | Yes | No |  |  |
| FreeHandlingAmount | money | Yes | No |  |  |
| FreeHandlingStart | datetime | Yes | No |  |  |
| FreeHandlingEnd | datetime | Yes | No |  |  |
| WebsiteLink | varchar(255) | Yes | No |  |  |









### archive.BidTrades



**Rows:** 119

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidTradeId | int | No | No |  |  |
| BidHeaderId | int | No | No |  |  |
| TradeId | int | No | No |  |  |
| Title | varchar(255) | No | No |  |  |
| Specifications | varchar(MAX) | No | No |  |  |









### archive.Catalog



**Rows:** 2,422

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| CatalogId | int | No | Yes |  |  |









### archive.cxmlSession



**Rows:** 50,022

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| SessionId | int | No | No |  |  |
| payloadId | varchar(255) | Yes | No |  |  |
| buyerCookie | varchar(255) | Yes | No |  |  |
| BrowserFormPost | varchar(255) | Yes | No |  |  |
| fromDomain | varchar(255) | Yes | No |  |  |
| fromIdentity | varchar(255) | Yes | No |  |  |
| toDomain | varchar(255) | Yes | No |  |  |
| toIdentity | varchar(255) | Yes | No |  |  |
| senderDomain | varchar(255) | Yes | No |  |  |
| senderIdentity | varchar(255) | Yes | No |  |  |
| fromUserAgent | varchar(255) | Yes | No |  |  |
| OrigReqId | int | Yes | No |  |  |
| RequisitionId | int | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| Mode | int | Yes | No |  |  |
| BudgetAccountId | int | Yes | No |  |  |
| UserAccountId | int | Yes | No |  |  |
| AccountCode | varchar(50) | Yes | No |  |  |
| BudgetId | int | Yes | No |  |  |
| UniqueId | uniqueidentifier | Yes | No |  |  |









### archive.Detail



**Rows:** 25,480,018

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| DetailId | int | No | No |  |  |
| RequisitionId | int | Yes | No |  |  |
| CatalogId | int | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |
| AddendumItem | tinyint | Yes | No |  |  |
| ItemCode | varchar(50) | Yes | No |  |  |
| Quantity | int | Yes | No |  |  |
| LastYearsQuantity | int | Yes | No |  |  |
| Description | varchar(1024) | Yes | No |  |  |
| UnitId | int | Yes | No |  |  |
| UnitCode | varchar(20) | Yes | No |  |  |
| BidPrice | money | Yes | No |  |  |
| CatalogPrice | money | Yes | No |  |  |
| GrossPrice | money | Yes | No |  |  |
| DiscountRate | decimal(9,5) | Yes | No |  |  |
| CatalogPage | char(4) | Yes | No |  |  |
| PricePlanId | int | Yes | No |  |  |
| PriceId | int | Yes | No |  |  |
| AwardId | int | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| VendorItemCode | varchar(50) | Yes | No |  |  |
| Alternate | varchar(1024) | Yes | No |  |  |
| POId | int | Yes | No |  |  |
| BatchDetailId | int | Yes | No |  |  |
| Modified | datetime | Yes | No |  |  |
| ModifiedById | int | Yes | No |  |  |
| SourceId | int | Yes | No |  |  |
| SortSeq | varchar(64) | Yes | No |  |  |
| BidItemId | int | Yes | No |  |  |
| ExtraDescription | varchar(1024) | Yes | No |  |  |
| ReProc | tinyint | Yes | No |  |  |
| UseGrossPrices | tinyint | Yes | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| DistrictRequisitionNumber | varchar(50) | Yes | No |  |  |
| HeadingTitle | varchar(255) | Yes | No |  |  |
| Keyword | varchar(50) | Yes | No |  |  |
| SectionId | int | Yes | No |  |  |
| SectionName | varchar(255) | Yes | No |  |  |
| OriginalItemId | int | Yes | No |  |  |
| HeadingId | int | Yes | No |  |  |
| KeywordId | int | Yes | No |  |  |
| ItemMustBeBid | int | Yes | No |  |  |
| SessionId | int | Yes | No |  |  |
| Active | tinyint | Yes | No |  |  |
| RTK_MSDSId | int | Yes | No |  |  |
| AddedFromAddenda | datetime | Yes | No |  |  |
| LastAlteredSessionId | int | Yes | No |  |  |
| AdditionalShipping | tinyint | Yes | No |  |  |
| CrossRefId | int | Yes | No |  |  |
| ShippingCost | decimal(9,2) | Yes | No |  |  |
| ShippingQuantity | int | Yes | No |  |  |
| ShippingUpdated | datetime | Yes | No |  |  |









### archive.DetailHold



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| DetailId | int | No | No |  |  |
| RequisitionId | int | Yes | No |  |  |
| CatalogId | int | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |
| AddendumItem | tinyint | Yes | No |  |  |
| ItemCode | varchar(50) | Yes | No |  |  |
| Quantity | int | Yes | No |  |  |
| LastYearsQuantity | int | Yes | No |  |  |
| Description | varchar(1024) | Yes | No |  |  |
| UnitId | int | Yes | No |  |  |
| UnitCode | varchar(20) | Yes | No |  |  |
| BidPrice | money | Yes | No |  |  |
| CatalogPrice | money | Yes | No |  |  |
| GrossPrice | money | Yes | No |  |  |
| DiscountRate | decimal(9,5) | Yes | No |  |  |
| CatalogPage | char(4) | Yes | No |  |  |
| PricePlanId | int | Yes | No |  |  |
| PriceId | int | Yes | No |  |  |
| AwardId | int | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| VendorItemCode | varchar(50) | Yes | No |  |  |
| Alternate | varchar(1024) | Yes | No |  |  |
| POId | int | Yes | No |  |  |
| BatchDetailId | int | Yes | No |  |  |
| Modified | datetime | Yes | No |  |  |
| ModifiedById | int | Yes | No |  |  |
| SourceId | int | Yes | No |  |  |
| SortSeq | varchar(64) | Yes | No |  |  |
| BidItemId | int | Yes | No |  |  |
| ExtraDescription | varchar(1024) | Yes | No |  |  |
| ReProc | tinyint | Yes | No |  |  |
| UseGrossPrices | tinyint | Yes | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| DistrictRequisitionNumber | varchar(50) | Yes | No |  |  |
| HeadingTitle | varchar(255) | Yes | No |  |  |
| Keyword | varchar(50) | Yes | No |  |  |
| SectionId | int | Yes | No |  |  |
| SectionName | varchar(255) | Yes | No |  |  |
| OriginalItemId | int | Yes | No |  |  |
| HeadingId | int | Yes | No |  |  |
| KeywordId | int | Yes | No |  |  |
| ItemMustBeBid | int | Yes | No |  |  |
| SessionId | int | Yes | No |  |  |
| Active | tinyint | Yes | No |  |  |
| RTK_MSDSId | int | Yes | No |  |  |









### archive.DetailMatch



**Rows:** 1,499

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BudgetId | int | Yes | No |  |  |
| TotalRequisitionCost | money | Yes | No |  |  |
| DetailId | int | No | No |  |  |
| RequisitionId | int | Yes | No |  |  |
| CatalogId | int | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |
| AddendumItem | tinyint | Yes | No |  |  |
| ItemCode | varchar(50) | Yes | No |  |  |
| Quantity | int | Yes | No |  |  |
| LastYearsQuantity | int | Yes | No |  |  |
| Description | varchar(1024) | Yes | No |  |  |
| UnitId | int | Yes | No |  |  |
| UnitCode | varchar(20) | Yes | No |  |  |
| BidPrice | money | Yes | No |  |  |
| CatalogPrice | money | Yes | No |  |  |
| GrossPrice | money | Yes | No |  |  |
| DiscountRate | decimal(9,5) | Yes | No |  |  |
| CatalogPage | char(4) | Yes | No |  |  |
| PricePlanId | int | Yes | No |  |  |
| PriceId | int | Yes | No |  |  |
| AwardId | int | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| VendorItemCode | varchar(50) | Yes | No |  |  |
| Alternate | varchar(1024) | Yes | No |  |  |
| POId | int | Yes | No |  |  |
| BatchDetailId | int | Yes | No |  |  |
| Modified | datetime | Yes | No |  |  |
| ModifiedById | int | Yes | No |  |  |
| SourceId | int | Yes | No |  |  |
| SortSeq | varchar(64) | Yes | No |  |  |
| BidItemId | int | Yes | No |  |  |
| ExtraDescription | varchar(1024) | Yes | No |  |  |
| ReProc | tinyint | Yes | No |  |  |
| UseGrossPrices | tinyint | Yes | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| DistrictRequisitionNumber | varchar(50) | Yes | No |  |  |
| HeadingTitle | varchar(255) | Yes | No |  |  |
| Keyword | varchar(50) | Yes | No |  |  |
| SectionId | int | Yes | No |  |  |
| SectionName | varchar(255) | Yes | No |  |  |
| OriginalItemId | int | Yes | No |  |  |
| HeadingId | int | Yes | No |  |  |
| KeywordId | int | Yes | No |  |  |
| ItemMustBeBid | int | Yes | No |  |  |
| SessionId | int | Yes | No |  |  |
| Active | tinyint | Yes | No |  |  |
| RTK_MSDSId | int | Yes | No |  |  |
| AddedFromAddenda | datetime | Yes | No |  |  |
| LastAlteredSessionId | int | Yes | No |  |  |









### archive.DMSBidDocuments



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| Id | uniqueidentifier | No | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| BidNbr | varchar(MAX) | Yes | No |  |  |
| DocType | varchar(MAX) | Yes | No |  |  |
| DocId | uniqueidentifier | Yes | No |  |  |
| DistrictVisible | varchar(MAX) | Yes | No |  |  |
| PagesCaptured | int | Yes | No |  |  |
| FileName | varchar(1024) | Yes | No |  |  |









### archive.DMSVendorBidDocuments



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| Id | uniqueidentifier | No | No |  |  |
| VendorCode | varchar(10) | Yes | No |  |  |
| DistrictVisible | varchar(10) | Yes | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| BidNbr | varchar(20) | Yes | No |  |  |
| DocType | varchar(255) | Yes | No |  |  |
| ExpirationDate | varchar(30) | Yes | No |  |  |
| DocumentNumber | varchar(255) | Yes | No |  |  |
| DocId | uniqueidentifier | Yes | No |  |  |
| PagesCaptured | int | Yes | No |  |  |
| FileName | varchar(1024) | Yes | No |  |  |









### archive.FreezeItems



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| Id | uniqueidentifier | No | No |  |  |
| ItemId | int | No | No |  |  |
| CrossRefId | int | No | No |  |  |
| VendorId | int | No | No |  |  |
| VendorItemCode | varchar(50) | Yes | No |  |  |
| BidHeaderId | int | No | No |  |  |
| GrossPrice | money | Yes | No |  |  |









### archive.ItemContractPrices



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ICPId | int | No | No |  |  |
| ItemId | int | No | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| CrossRefId | int | Yes | No |  |  |
| Price | money | Yes | No |  |  |









### archive.OrderBooks



**Rows:** 692

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| OrderBookId | int | No | No |  |  |
| PricePlanDescription | varchar(255) | Yes | No |  |  |
| Category | varchar(255) | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| PricePlanId | int | Yes | No |  |  |
| AwardId | int | Yes | No |  |  |
| Type | char(1) | Yes | No |  |  |
| DistrictId | int | Yes | No |  |  |
| Markup | decimal(9,5) | Yes | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| OrderBookYear | int | Yes | No |  |  |
| OrderBookCreated | datetime | Yes | No |  |  |
| Active | int | Yes | No |  |  |
| MasterBook | int | Yes | No |  |  |
| MasterLetter | char(1) | Yes | No |  |  |
| UseParentCatalog | int | Yes | No |  |  |
| KeepZeroPages | int | Yes | No |  |  |









### archive.PO



**Rows:** 1,300,617

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| POId | int | No | No |  |  |
| RequisitionId | int | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| PONumber | varchar(24) | Yes | No |  |  |
| PODate | datetime | Yes | No |  |  |
| DatePrinted | datetime | Yes | No |  |  |
| DatePrintedDetail | datetime | Yes | No |  |  |
| DateExported | datetime | Yes | No |  |  |
| DateOrdered | datetime | Yes | No |  |  |
| DateReceived | datetime | Yes | No |  |  |
| Amount | money | Yes | No |  |  |
| ItemCount | int | Yes | No |  |  |
| AwardId | int | Yes | No |  |  |
| DiscountAmount | money | Yes | No |  |  |
| TotalGross | money | Yes | No |  |  |
| DiscountRate | decimal(9,5) | Yes | No |  |  |
| ShippingAmount | money | Yes | No |  |  |
| ExportedToVendor | datetime | Yes | No |  |  |
| UploadId | int | Yes | No |  |  |
| Cancelled | tinyint | Yes | No |  |  |
| POStatusID | int | Yes | No |  |  |
| rowguid | uniqueidentifier | No | No |  |  |









### archive.PODetailItems



**Rows:** 22,905,929

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| PODetailItemId | int | No | Yes |  |  |
| POId | int | Yes | No |  |  |
| DetailId | int | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |
| Quantity | int | Yes | No |  |  |
| BidItemId | int | Yes | No |  |  |
| BidPrice | money | Yes | No |  |  |
| GrossPrice | money | Yes | No |  |  |
| DiscountRate | decimal(9,5) | Yes | No |  |  |
| AwardId | int | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| VendorItemCode | varchar(50) | Yes | No |  |  |
| Alternate | varchar(1024) | Yes | No |  |  |
| ContractNumber | varchar(50) | Yes | No |  |  |
| rowguid | uniqueidentifier | No | No |  |  |









### archive.POTempDetails



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| POTempDetailID | int | No | No |  |  |
| POTempID | int | Yes | No |  |  |
| RequisitionID | int | No | No |  |  |
| VendorID | int | No | No |  |  |
| BidHeaderID | int | No | No |  |  |
| PONumber | varchar(50) | Yes | No |  |  |
| POPrefix | varchar(50) | Yes | No |  |  |
| POSuffix | varchar(50) | Yes | No |  |  |









### archive.Prices



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ItemId | int | No | No |  |  |
| PackedCode | varchar(50) | Yes | No |  |  |
| CrossRefId | int | Yes | No |  |  |
| CrossRefIdBid | int | Yes | No |  |  |
| BidPrice | decimal(34,13) | Yes | No |  |  |
| GrossPrice | money | Yes | No |  |  |
| CatalogPrice | money | Yes | No |  |  |
| AwardId | int | No | No |  |  |
| VendorId | int | No | No |  |  |
| PricePlanId | int | Yes | No |  |  |
| CatalogId | int | Yes | No |  |  |
| VendorItemCode | varchar(50) | Yes | No |  |  |
| ParentCatalogId | int | Yes | No |  |  |
| ItemCode | varchar(50) | Yes | No |  |  |
| Description | varchar(1024) | Yes | No |  |  |
| UnitId | int | Yes | No |  |  |
| UnitCode | varchar(20) | Yes | No |  |  |
| PriceId | uniqueidentifier | No | No |  |  |
| Page | char(4) | Yes | No |  |  |
| DiscountRate | decimal(9,5) | Yes | No |  |  |
| Name | varchar(50) | Yes | No |  |  |
| VendorName | varchar(50) | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| PackedItemCode | varchar(50) | Yes | No |  |  |
| BidItemId | int | Yes | No |  |  |
| Alternate | varchar(1024) | Yes | No |  |  |
| PackedVendorItemCode | varchar(255) | Yes | No |  |  |
| CatalogYear | char(2) | Yes | No |  |  |
| RedirectedItemId | int | Yes | No |  |  |
| BidHeaderId | int | Yes | No |  |  |









### archive.PricingConsolidatedOrderCounts



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| PCOCId | bigint | No | No |  |  |
| BidHeaderId | int | No | No |  |  |
| ItemId | int | No | No |  |  |
| OrderCount | int | No | No |  |  |









### archive.PricingMap



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| Id | uniqueidentifier | No | No |  |  |
| BidHeaderId | int | No | No |  |  |
| ItemId | int | No | No |  |  |
| MappedItemId | int | No | No |  |  |
| ItemCode | varchar(50) | Yes | No |  |  |
| PackedItemCode | varchar(50) | Yes | No |  |  |
| BidPrice | money | No | No |  |  |
| CatalogPrice | money | No | No |  |  |
| BidItemId | int | Yes | No |  |  |
| VendorId | int | No | No |  |  |
| VendorItemCode | varchar(50) | Yes | No |  |  |
| PackedVendorItemCode | varchar(50) | Yes | No |  |  |
| ManufacturerPartNumber | varchar(50) | Yes | No |  |  |
| PackedManufacturerPartNumber | varchar(50) | Yes | No |  |  |
| UnitId | int | No | No |  |  |
| UnitCode | varchar(16) | No | No |  |  |
| Alternate | varchar(512) | Yes | No |  |  |
| ItemDescription | varchar(1024) | Yes | No |  |  |
| SortSeq | varchar(64) | Yes | No |  |  |









### archive.PricingUpdate



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| PricingUpdateId | int | No | No |  |  |
| BidHeaderId | int | No | No |  |  |
| LastUpdated | datetime | Yes | No |  |  |









### archive.RequisitionChangeLog



**Rows:** 1,936,897

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| RequisitionChangeId | int | No | Yes |  |  |
| RequisitionId | int | No | No |  |  |
| OrigSchoolId | int | Yes | No |  |  |
| OrigUserId | int | Yes | No |  |  |
| OrigBudgetId | int | Yes | No |  |  |
| OrigBudgetAccountId | int | Yes | No |  |  |
| OrigUserAccountId | int | Yes | No |  |  |
| OrigCategoryId | int | Yes | No |  |  |
| OrigShippingId | int | Yes | No |  |  |
| OrigAttention | varchar(50) | Yes | No |  |  |
| OrigAccountCode | varchar(50) | Yes | No |  |  |
| OrigBidHeaderId | int | Yes | No |  |  |
| NewSchoolId | int | Yes | No |  |  |
| NewUserId | int | Yes | No |  |  |
| NewBudgetId | int | Yes | No |  |  |
| NewBudgetAccountId | int | Yes | No |  |  |
| NewUserAccountId | int | Yes | No |  |  |
| NewCategoryId | int | Yes | No |  |  |
| NewShippingId | int | Yes | No |  |  |
| NewAttention | varchar(50) | Yes | No |  |  |
| NewAccountCode | varchar(50) | Yes | No |  |  |
| NewBidHeaderId | int | Yes | No |  |  |
| UserId | int | Yes | No |  |  |
| SessionId | int | Yes | No |  |  |
| ChangeDate | datetime | Yes | No |  |  |









### archive.Requisitions



**Rows:** 1,433,904

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| RequisitionId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| RequisitionNumber | varchar(24) | Yes | No |  |  |
| SchoolId | int | Yes | No |  |  |
| UserId | int | Yes | No |  |  |
| BudgetId | int | Yes | No |  |  |
| BudgetAccountId | int | Yes | No |  |  |
| UserAccountId | int | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| ShippingId | int | Yes | No |  |  |
| Attention | varchar(50) | Yes | No |  |  |
| AccountCode | varchar(50) | Yes | No |  |  |
| DateEntered | datetime | Yes | No |  |  |
| ShippingPercent | decimal(9,5) | Yes | No |  |  |
| DiscountPercent | decimal(9,5) | Yes | No |  |  |
| ShippingCost | money | Yes | No |  |  |
| TotalItemsCost | money | Yes | No |  |  |
| TotalRequisitionCost | money | Yes | No |  |  |
| Comments | varchar(1023) | Yes | No |  |  |
| ApprovalRequired | tinyint | Yes | No |  |  |
| ApprovalId | int | Yes | No |  |  |
| ApprovalLevel | tinyint | Yes | No |  |  |
| StatusId | int | Yes | No |  |  |
| OrderDate | datetime | Yes | No |  |  |
| DateExported | datetime | Yes | No |  |  |
| BidId | int | Yes | No |  |  |
| BookId | int | Yes | No |  |  |
| SourceId | int | Yes | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| LastAlteredSessionId | int | Yes | No |  |  |
| DateUpdated | datetime | Yes | No |  |  |
| OrderType | tinyint | Yes | No |  |  |
| NotesCount | int | Yes | No |  |  |
| AddendaTotal | money | Yes | No |  |  |
| ApprovalCount | int | Yes | No |  |  |
| AdditionalFreight | tinyint | Yes | No |  |  |
| HistoryCount | int | Yes | No |  |  |
| POCount | int | Yes | No |  |  |
| LowPOCount | int | Yes | No |  |  |
| AdditionalShippingCost | money | Yes | No |  |  |









### archive.TMAwards



**Rows:** 29,335

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| TMAwardId | int | No | No |  |  |
| Active | tinyint | Yes | No |  |  |
| BidHeaderId | int | No | No |  |  |
| BidTradeCountyId | int | No | No |  |  |
| BidImportId | int | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| AwardType | varchar(50) | Yes | No |  |  |
| DateModified | datetime | Yes | No |  |  |
| AwardAmount | money | Yes | No |  |  |









### archive.UserAccounts



**Rows:** 2,704,140

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| UserAccountId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| AccountId | int | Yes | No |  |  |
| BudgetId | int | Yes | No |  |  |
| BudgetAccountId | int | Yes | No |  |  |
| UserId | int | Yes | No |  |  |
| AllocationAmount | money | Yes | No |  |  |
| AllocationAvailable | money | Yes | No |  |  |
| UseAllocations | tinyint | Yes | No |  |  |









### archive.UserAccountsUserAccountId_CrossMapping



**Rows:** 2,704,140

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| New_UserAccountId | int | No | Yes |  |  |
| Old_UserAccountId | int | Yes | No |  |  |









### archive.VendorDocRequest



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VendorDocRequestId | int | No | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| BidImportId | int | Yes | No |  |  |
| EmailAddress | varchar(4000) | Yes | No |  |  |
| Fax | varchar(20) | Yes | No |  |  |
| AddDate | datetime | Yes | No |  |  |
| SendDate | datetime | Yes | No |  |  |
| EmailAddress2 | varchar(255) | Yes | No |  |  |
| EmailCCAddress | varchar(255) | Yes | No |  |  |
| MessageContent | varchar(MAX) | Yes | No |  |  |
| MessageReceiptConfirmed | datetime | Yes | No |  |  |
| VendorDocRequestNotes | varchar(1000) | Yes | No |  |  |
| ContactName | varchar(4000) | Yes | No |  |  |









### archive.VendorDocRequestDetail



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VendorDocRequestDetailId | int | No | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| BidImportId | int | Yes | No |  |  |
| BidHeaderCheckListId | int | Yes | No |  |  |
| VendorDocRequestId | int | Yes | No |  |  |
| AddDate | datetime | Yes | No |  |  |
| SendDate | datetime | Yes | No |  |  |
| CommentsRejectReason | varchar(1024) | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| DistrictName | varchar(50) | Yes | No |  |  |
| ResolvedFlag | tinyint | Yes | No |  |  |









### archive.VendorQuery



**Rows:** 4,057

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VendorQueryId | int | No | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| BidImportId | int | Yes | No |  |  |
| EmailAddress | varchar(4000) | Yes | No |  |  |
| Fax | varchar(20) | Yes | No |  |  |
| AddDate | datetime | Yes | No |  |  |
| SendDate | datetime | Yes | No |  |  |
| EmailAddress2 | varchar(255) | Yes | No |  |  |
| EmailCCAddress | varchar(255) | Yes | No |  |  |
| MessageContent | varchar(MAX) | Yes | No |  |  |
| MessageReceiptConfirmed | datetime | Yes | No |  |  |
| VendorQueryNotes | varchar(1000) | Yes | No |  |  |
| ContactName | varchar(4000) | Yes | No |  |  |









### archive.VendorQueryDetail



**Rows:** 39,321

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VendorQueryDetailId | int | No | No |  |  |
| BidResultsId | int | Yes | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| BidImportId | int | Yes | No |  |  |
| VendorQueryId | int | Yes | No |  |  |
| AddDate | datetime | Yes | No |  |  |
| SendDate | datetime | Yes | No |  |  |
| ItemQuery | varchar(4000) | Yes | No |  |  |
| ItemQueryNotes | varchar(1000) | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| DistrictName | varchar(50) | Yes | No |  |  |
| ResolvedFlag | tinyint | Yes | No |  |  |
| CommonVendorQueryId | int | Yes | No |  |  |









### archive.VendorQueryMSRP



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VendorQueryMSRPId | int | No | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| BidImportId | int | Yes | No |  |  |
| EmailAddress | varchar(4000) | Yes | No |  |  |
| Fax | varchar(20) | Yes | No |  |  |
| AddDate | datetime | Yes | No |  |  |
| SendDate | datetime | Yes | No |  |  |
| EmailAddress2 | varchar(255) | Yes | No |  |  |
| EmailCCAddress | varchar(255) | Yes | No |  |  |
| MessageContent | varchar(MAX) | Yes | No |  |  |
| MessageReceiptConfirmed | datetime | Yes | No |  |  |
| VendorQueryMSRPNotes | varchar(1000) | Yes | No |  |  |
| ContactName | varchar(4000) | Yes | No |  |  |









### archive.VendorQueryMSRPDetail



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VendorQueryMSRPDetailId | int | No | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| BidImportId | int | Yes | No |  |  |
| VendorQueryMSRPId | int | Yes | No |  |  |
| AddDate | datetime | Yes | No |  |  |
| SendDate | datetime | Yes | No |  |  |
| MSRPQueryType | int | Yes | No |  |  |
| MSRPQuery | varchar(4000) | Yes | No |  |  |
| MSRPQueryManufacturers | varchar(MAX) | Yes | No |  |  |
| MSRPQueryNotes | varchar(1000) | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| ResolvedFlag | tinyint | Yes | No |  |  |
| AllowReply | tinyint | Yes | No |  |  |
| ManufacturerSelection | int | Yes | No |  |  |









### archive.VendorQueryTandM



**Rows:** 7

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VendorQueryTandMId | int | No | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| BidImportId | int | Yes | No |  |  |
| EmailAddress | varchar(4000) | Yes | No |  |  |
| Fax | varchar(20) | Yes | No |  |  |
| AddDate | datetime | Yes | No |  |  |
| SendDate | datetime | Yes | No |  |  |
| EmailAddress2 | varchar(255) | Yes | No |  |  |
| EmailCCAddress | varchar(255) | Yes | No |  |  |
| MessageContent | varchar(MAX) | Yes | No |  |  |
| MessageReceiptConfirmed | datetime | Yes | No |  |  |
| VendorQueryTandMNotes | varchar(1000) | Yes | No |  |  |
| ContactName | varchar(4000) | Yes | No |  |  |









### archive.VendorQueryTandMDetail



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VendorQueryTandMDetailId | int | No | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| BidImportId | int | Yes | No |  |  |
| VendorQueryTandMId | int | Yes | No |  |  |
| AddDate | datetime | Yes | No |  |  |
| SendDate | datetime | Yes | No |  |  |
| TandMQueryType | int | Yes | No |  |  |
| TandMQuery | varchar(4000) | Yes | No |  |  |
| TandMQueryCounties | varchar(1000) | Yes | No |  |  |
| TandMQueryNotes | varchar(1000) | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| ResolvedFlag | tinyint | Yes | No |  |  |









### dbo.AccountingDetail



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| AccountingDetailId | int | No | Yes |  |  |
| UserAccountId | int | Yes | No |  |  |
| DetailId | int | Yes | No |  |  |
| RequisitionId | int | Yes | No |  |  |
| Amount | money | Yes | No |  |  |



**Primary Key:** AccountingDetailId





**Indexes:**
- PK__AccountingDetail__7988E3C9 (CLUSTERED): AccountingDetailId




### dbo.AccountingFormats



**Rows:** 49

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| AccountingFormatId | int | No | Yes |  |  |
| Description | varchar(255) | Yes | No |  |  |
| FileLayoutId | int | Yes | No |  |  |
| MaxPODetailItems | int | Yes | No |  |  |
| LocationCodeRequired | tinyint | Yes | No |  |  |
| VendorBidNumberRequired | tinyint | Yes | No |  |  |
| VendorBidCommentsRequired | tinyint | Yes | No |  |  |
| UsersDistrictAccountingCodeRequired | tinyint | Yes | No |  |  |
| IncidentalOrdersSupported | tinyint | Yes | No |  |  |
| ShortName | varchar(50) | Yes | No |  |  |
| DetailedFormat | tinyint | Yes | No |  |  |
| ScriptURL | varchar(1024) | Yes | No |  |  |
| useFirstLast | tinyint | Yes | No |  |  |



**Primary Key:** AccountingFormatId





**Indexes:**
- PK_AccountingFormats (CLUSTERED): AccountingFormatId




### dbo.AccountingUserFields



**Rows:** 80

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| AccountingUserFieldId | int | No | Yes |  |  |
| AccountingFormatId | int | No | No |  |  |
| DistrictId | int | No | No |  |  |
| FieldPos | int | Yes | No |  |  |
| FieldName | varchar(50) | Yes | No |  |  |
| RequiredField | tinyint | Yes | No |  |  |



**Primary Key:** AccountingUserFieldId





**Indexes:**
- PK__Accounti__9EC55982690305A6 (CLUSTERED): AccountingUserFieldId




### dbo.Accounts



**Rows:** 108,041

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| AccountId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| DistrictId | int | Yes | No |  |  |
| SchoolId | int | Yes | No |  |  |
| Code | varchar(50) | Yes | No |  |  |
| Description | varchar(512) | Yes | No |  |  |



**Primary Key:** AccountId



**Foreign Keys:**
- DistrictId → dbo.District.DistrictId
- SchoolId → dbo.School.SchoolId




**Indexes:**
- PK_Accounts (CLUSTERED): AccountId
- _dta_index_Accounts_7_1035202788__K1_5 (NONCLUSTERED): Code, AccountId
- SK_AccountDistrict (NONCLUSTERED): DistrictId, Code
- SK_ActiveCode (NONCLUSTERED): Active, Code




### dbo.AccountSeparators



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| AccountSeparatorId | int | No | Yes |  |  |
| Description | varchar(50) | Yes | No |  |  |
| Code | char(1) | Yes | No |  |  |



**Primary Key:** AccountSeparatorId





**Indexes:**
- PK_AccountSeparators (CLUSTERED): AccountSeparatorId




### dbo.AddendumItems



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ItemId | int | No | No |  |  |
| ItemCode | varchar(15) | Yes | No |  |  |
| Description | varchar(255) | Yes | No |  |  |
| UnitId | int | Yes | No |  |  |
| UnitCode | varchar(20) | Yes | No |  |  |
| PriceId | int | Yes | No |  |  |
| CatalogPrice | decimal(9,2) | Yes | No |  |  |
| Page | int | Yes | No |  |  |
| BidPrice | decimal(9,2) | Yes | No |  |  |
| CatalogId | int | Yes | No |  |  |
| CatalogName | varchar(30) | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| VendorName | varchar(30) | Yes | No |  |  |
| DistrictId | int | Yes | No |  |  |
| ContractId | int | Yes | No |  |  |
| ContractNumber | varchar(20) | Yes | No |  |  |



**Primary Key:** ItemId





**Indexes:**
- PK_AddendumItems (CLUSTERED): ItemId




### dbo.additems



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ITEMID | int | No | No |  |  |
| ITEMCODE | varchar(15) | Yes | No |  |  |
| DESCRIPTION | varchar(255) | Yes | No |  |  |
| UNITID | int | Yes | No |  |  |
| PRICEID | int | Yes | No |  |  |
| CATALOGPRICE | decimal(9,2) | Yes | No |  |  |
| PAGE | int | Yes | No |  |  |
| BIDPRICE | decimal(9,2) | Yes | No |  |  |
| CATALOGID | int | Yes | No |  |  |
| CATEGORYID | int | Yes | No |  |  |
| VENDORID | int | Yes | No |  |  |
| DISTRICTID | int | Yes | No |  |  |
| CONTRACTID | int | Yes | No |  |  |
| CONTRACTNUMBER | varchar(20) | Yes | No |  |  |
| VENDORITEMCODE | varchar(20) | Yes | No |  |  |



**Primary Key:** ITEMID





**Indexes:**
- PK__additems__4AB81AF0 (CLUSTERED): ITEMID




### dbo.Alerts



**Rows:** 3

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| AlertID | int | No | Yes |  |  |
| DistrictID | int | Yes | No |  |  |
| DisplayStart | datetime | Yes | No |  |  |
| DisplayEnd | datetime | Yes | No |  |  |
| Message | varchar(MAX) | Yes | No |  |  |



**Primary Key:** AlertID





**Indexes:**
- PK__Alerts__EBB16AED20733621 (CLUSTERED): AlertID




### dbo.allitems



**Rows:** 6,276,768

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidHeaderId | int | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |
| ItemCode | varchar(50) | Yes | No |  |  |
| Description | varchar(2311) | Yes | No |  |  |
| UnitCode | varchar(20) | Yes | No |  |  |
| VendorItemCode | varchar(50) | Yes | No |  |  |
| Alternate | varchar(512) | Yes | No |  |  |
| BidPrice | money | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| BidItemId | int | Yes | No |  |  |
| CatalogId | int | Yes | No |  |  |
| CrossRefId | int | Yes | No |  |  |
| PricePlanId | int | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| PackedVendorItemCode | varchar(50) | Yes | No |  |  |
| ItemBidType | varchar(50) | Yes | No |  |  |
| TotalOrdered | int | Yes | No |  |  |
| TotalBid | int | Yes | No |  |  |
| SysId | int | No | Yes |  |  |









### dbo.AnswerTypes



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| AnswerTypeId | int | No | Yes |  |  |
| Description | varchar(50) | No | No |  |  |
| Mask | varchar(50) | Yes | No |  |  |
| RegExp | varchar(1024) | Yes | No |  |  |



**Primary Key:** AnswerTypeId





**Indexes:**
- PK__AnswerTy__4D81A3671812FA4A (CLUSTERED): AnswerTypeId




### dbo.ApprovalLevels



**Rows:** 9

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ApprovalLevelId | int | No | Yes |  |  |
| Description | varchar(50) | Yes | No |  |  |
| ApprovalLevel | tinyint | No | No |  |  |



**Primary Key:** ApprovalLevelId





**Indexes:**
- PK_ApprovalLevels (NONCLUSTERED): ApprovalLevelId
- PK_ApprovalLevelId (CLUSTERED): ApprovalLevelId
- SK_ApprovalLevel (NONCLUSTERED): ApprovalLevel




### dbo.Approvals



**Rows:** 7,777,792

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ApprovalId | int | No | Yes |  |  |
| ApprovalById | int | Yes | No |  |  |
| Level | tinyint | Yes | No |  |  |
| StatusId | int | Yes | No |  |  |
| RequisitionId | int | Yes | No |  |  |
| ApprovalDate | datetime | Yes | No |  |  |
| ApproverId | int | Yes | No |  |  |



**Primary Key:** ApprovalId





**Indexes:**
- PK_Approvals (CLUSTERED): ApprovalId
- SK_RequisitionId (NONCLUSTERED): RequisitionId
- SKI_RequisitionApprovaldate_ApprovalidStatusid (NONCLUSTERED): ApprovalId, StatusId, RequisitionId, ApprovalDate
- SKI_RequisitionStatusApprovalDate_Id (NONCLUSTERED): ApprovalId, RequisitionId, StatusId, ApprovalDate




### dbo.ApprovalsHistory



**Rows:** 330,784

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ApprovalId | int | No | No |  |  |
| ApprovalById | int | Yes | No |  |  |
| Level | tinyint | Yes | No |  |  |
| StatusId | int | Yes | No |  |  |
| RequisitionId | int | Yes | No |  |  |
| ApprovalDate | datetime | Yes | No |  |  |
| ApproverId | int | Yes | No |  |  |



**Primary Key:** ApprovalId





**Indexes:**
- PK_ApprovalsHistory (CLUSTERED): ApprovalId
- SK_Requisition (NONCLUSTERED): RequisitionId




### dbo.Audit



**Rows:** 2,568,656

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| AuditId | int | No | Yes |  |  |
| AuditDate | datetime | Yes | No | (getdate()) |  |
| AuditBy | int | Yes | No |  |  |
| AuditAction | int | Yes | No |  |  |
| AuditFile | varchar(50) | Yes | No |  |  |
| AuditRecord | int | Yes | No |  |  |
| AuditMessage | varchar(255) | Yes | No |  |  |



**Primary Key:** AuditId





**Indexes:**
- PK_Audit (CLUSTERED): AuditId




### dbo.Awardings



**Rows:** 10,585

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| AwardingId | int | No | Yes |  |  |
| BidHeaderId | int | No | No |  |  |
| StartTimestamp | datetime | No | No | (getdate()) |  |
| EndTimestamp | datetime | Yes | No |  |  |
| NotificationsCreated | bigint | Yes | No |  |  |
| NotificationsSent | datetime | Yes | No |  |  |



**Primary Key:** AwardingId





**Indexes:**
- PK__Awarding__F43393FB9B614318 (CLUSTERED): AwardingId




### dbo.Awards



**Rows:** 132,748

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| AwardId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| BidId | int | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| PricePlanId | int | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| BidStartDate | datetime | Yes | No |  |  |
| BidEndDate | datetime | Yes | No |  |  |
| VendorBidNumber | varchar(50) | Yes | No |  |  |
| Description | varchar(511) | Yes | No |  |  |
| CatalogId | int | Yes | No |  |  |
| DiscountRate | decimal(9,5) | Yes | No |  |  |
| ItemsBid | int | Yes | No |  |  |
| AmountBid | money | Yes | No |  |  |
| BidDiscountRate | decimal(9,5) | Yes | No |  |  |
| StateContractDiscount | decimal(9,5) | Yes | No |  |  |
| UseGrossPrices | int | Yes | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| DateModified | datetime | Yes | No |  |  |
| BidImportId | int | Yes | No |  |  |



**Primary Key:** AwardId





**Indexes:**
- PK_Bids (CLUSTERED): AwardId
- _dta_index_Awards_7_793105916__K4_K2_K18_9_17 (NONCLUSTERED): VendorBidNumber, UseGrossPrices, VendorId, Active, BidHeaderId
- _dta_index_Awards_9_352056340__K2_K1_K3 (NONCLUSTERED): Active, AwardId, BidId
- SK_Bid (NONCLUSTERED): BidId
- SK_BidActive (NONCLUSTERED): BidId, Active
- SK_BidHeader (NONCLUSTERED): BidHeaderId
- SK_VendorBidActive (NONCLUSTERED): VendorId, Active, BidHeaderId




### dbo.AwardsCatalogList



**Rows:** 80,727

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| AwardCatalogId | int | No | Yes |  |  |
| AwardId | int | Yes | No |  |  |
| CatalogId | int | Yes | No |  |  |
| DiscountRate | decimal(9,5) | Yes | No |  |  |
| DateModified | datetime | Yes | No |  |  |
| BidImportCatalogId | int | Yes | No |  |  |



**Primary Key:** AwardCatalogId





**Indexes:**
- PK__AwardsCatalogLis__583CFE97 (CLUSTERED): AwardCatalogId
- _dta_index_AwardsCatalogList_9_1464392286__K3_K2_K4 (NONCLUSTERED): CatalogId, AwardId, DiscountRate
- SK_Award (NONCLUSTERED): AwardId
- SK_AwardCatalog (NONCLUSTERED): AwardId, CatalogId




### dbo.AwardTypes



**Rows:** 2

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| AwardTypeId | int | No | Yes |  |  |
| Description | varchar(50) | No | No |  |  |



**Primary Key:** AwardTypeId





**Indexes:**
- PK__AwardTyp__0F1CCD9E79596900 (CLUSTERED): AwardTypeId




### dbo.BatchBook



**Rows:** 217,611

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BatchBookId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| BatchId | int | No | No |  |  |
| DistrictCode | char(2) | Yes | No |  |  |
| Category | char(1) | Yes | No |  |  |
| CometCode | char(5) | Yes | No |  |  |
| AccountCode | char(50) | Yes | No |  |  |
| DistrictId | int | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| UserId | int | Yes | No |  |  |
| BudgetId | int | Yes | No |  |  |
| AccountId | int | Yes | No |  |  |
| BudgetAccountId | int | Yes | No |  |  |
| UserAccountId | int | Yes | No |  |  |
| Records | int | Yes | No |  |  |
| InputAmount | money | Yes | No |  |  |
| CalcAmount | money | Yes | No |  |  |
| Errors | int | Yes | No |  |  |
| DuplicateOk | tinyint | Yes | No |  |  |
| DuplicateDetected | tinyint | Yes | No |  |  |
| RequisitionId | int | Yes | No |  |  |
| AmountOk | tinyint | Yes | No |  |  |



**Primary Key:** BatchBookId





**Indexes:**
- PK_BatchBook (CLUSTERED): BatchBookId
- SK_Batch (NONCLUSTERED): BatchId
- SK_DCCatCCBatch (NONCLUSTERED): DistrictCode, Category, CometCode, BatchId
- SK_DCU (NONCLUSTERED): DistrictId, CategoryId, UserId, Active
- SK_DistrictId (NONCLUSTERED): DistrictId, CategoryId




### dbo.BatchDetail



**Rows:** 5,020,036

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BatchDetailId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| BatchBookId | int | Yes | No |  |  |
| BatchId | int | No | No |  |  |
| RecordNumber | int | Yes | No |  |  |
| Type | char(1) | Yes | No |  |  |
| DistrictCode | char(2) | Yes | No |  |  |
| Category | char(1) | Yes | No |  |  |
| CometId | char(5) | Yes | No |  |  |
| BookAmount | char(10) | Yes | No |  |  |
| ItemCode | char(20) | Yes | No |  |  |
| Quantity | char(6) | Yes | No |  |  |
| OrigType | char(1) | Yes | No |  |  |
| OrigDistrictCode | char(2) | Yes | No |  |  |
| OrigCategory | char(1) | Yes | No |  |  |
| OrigCometCode | char(5) | Yes | No |  |  |
| OrigItemCode | char(15) | Yes | No |  |  |
| OrigQuantity | char(6) | Yes | No |  |  |
| ErrorField | tinyint | Yes | No |  |  |
| DistrictId | int | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| UserId | int | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |
| BidPrice | money | Yes | No |  |  |
| Qty | int | Yes | No |  |  |
| Total | money | Yes | No |  |  |
| DetailId | int | Yes | No |  |  |
| SourceId | int | Yes | No |  |  |
| Modified | datetime | Yes | No |  |  |
| ModifiedBy | int | Yes | No |  |  |
| PackedCode | varchar(16) | Yes | No |  |  |
| Location | char(1) | Yes | No |  |  |
| OrigBookAmount | char(10) | Yes | No |  |  |
| BatchFileName | varchar(16) | Yes | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| PreviousCategory | char(1) | Yes | No |  |  |
| PackComplete | tinyint | Yes | No |  |  |



**Primary Key:** BatchDetailId





**Indexes:**
- PK_BatchDetail (CLUSTERED): BatchDetailId
- SK_Batch (NONCLUSTERED): BatchId
- SK_BatchBook (NONCLUSTERED): BatchBookId
- SK_Category (NONCLUSTERED): Category, DistrictCode, CometId
- SK_ErrorCheck (NONCLUSTERED): BatchBookId, Active, ErrorField
- SK_PCCat (NONCLUSTERED): CategoryId, PackedCode
- SKI_Batch_DistrictCode (NONCLUSTERED): DistrictCode, BatchId
- SKI_BatchActiveCategory_ItemCode (NONCLUSTERED): ItemCode, BatchId, Active, CategoryId




### dbo.BatchDetailInserts



**Rows:** 1,176

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BatchDetailInsertId | uniqueidentifier | No | No | (newsequentialid()) |  |
| RequisitionId | int | No | No |  |  |
| ItemId | int | Yes | No |  |  |
| qty | int | Yes | No |  |  |
| BatchDetailId | int | No | No |  |  |
| SourceId | int | Yes | No |  |  |



**Primary Key:** BatchDetailInsertId





**Indexes:**
- PK_BatchDetailInserts (CLUSTERED): BatchDetailInsertId




### dbo.Batches



**Rows:** 14,507

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BatchId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| BatchDate | datetime | Yes | No |  |  |
| Imported | datetime | Yes | No |  |  |
| Converted | datetime | Yes | No |  |  |
| Records | int | Yes | No |  |  |
| ErrorCount | int | Yes | No |  |  |
| Amount | money | Yes | No |  |  |
| Type | char(1) | Yes | No |  |  |
| InputRecords | int | Yes | No |  |  |
| ImportedRecords | int | Yes | No |  |  |
| SourceId | int | Yes | No |  |  |
| Scheduled | datetime | Yes | No |  |  |
| Completed | datetime | Yes | No |  |  |
| Description | varchar(255) | Yes | No |  |  |
| Started | datetime | Yes | No |  |  |
| Loaded | datetime | Yes | No |  |  |



**Primary Key:** BatchId





**Indexes:**
- PK_ImportBatches (CLUSTERED): BatchId
- SK_Loaded (NONCLUSTERED): Loaded




### dbo.BidAnswers



**Rows:** 531,013

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidAnswerId | int | No | Yes |  |  |
| BidImportId | int | No | No |  |  |
| BidQuestionId | int | No | No |  |  |
| CountyId | int | No | No |  |  |
| BidTradeId | int | No | No |  |  |
| VendorBidTMAnswerId | int | Yes | No |  |  |



**Primary Key:** BidAnswerId





**Indexes:**
- PK__BidAnswe__7B1D995A4E6F0AFB (CLUSTERED): BidAnswerId
- SK_ImportTradeCounty_Question (NONCLUSTERED): BidQuestionId, BidImportId, BidTradeId, CountyId
- SK_QuestionImportTradeCounty (NONCLUSTERED): BidQuestionId, BidImportId, CountyId, BidTradeId
- SK_TradeCountyImport_Question (NONCLUSTERED): BidQuestionId, BidTradeId, CountyId, BidImportId




### dbo.BidAnswersJournal



**Rows:** 1,211,389

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidAnswerJournalId | int | No | Yes |  |  |
| BidAnswerId | int | No | No |  |  |
| SessionId | int | Yes | No |  |  |
| DateModified | datetime | No | No | (getdate()) |  |
| BidAnswer | varchar(512) | Yes | No |  |  |
| BidAnswerExtended | varchar(512) | Yes | No |  |  |
| VendorBidTMAnswerJournalId | int | Yes | No |  |  |



**Primary Key:** BidAnswerJournalId



**Foreign Keys:**
- BidAnswerId → dbo.BidAnswers.BidAnswerId




**Indexes:**
- PK__BidAnswe__8AD205EB523F9BDF (CLUSTERED): BidAnswerJournalId
- SK_BidAnswer (NONCLUSTERED): BidAnswerId, DateModified, BidAnswerJournalId




### dbo.BidCalendar



**Rows:** 1

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| CalendarId | int | No | Yes |  |  |
| DateAvailable | datetime | Yes | No |  |  |
| OpeningDate | datetime | Yes | No |  |  |
| Description | varchar(255) | Yes | No |  |  |
| CategoryName | varchar(255) | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| Comments | varchar(4096) | Yes | No |  |  |
| Status | varchar(255) | Yes | No |  |  |
| StateId | int | Yes | No |  |  |
| PricePlanId | int | Yes | No |  |  |
| TotalAwardMinimumDiscount | decimal(9,5) | Yes | No |  |  |
| AllowTotalAward | tinyint | Yes | No |  |  |



**Primary Key:** CalendarId





**Indexes:**
- PK__BidCalendar__6458BCB9 (CLUSTERED): CalendarId




### dbo.BidderCheckList



**Rows:** 138

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidderCheckListId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| CheckListText | varchar(100) | Yes | No |  |  |
| AdditionalInfoRTF | varchar(1000) | Yes | No |  |  |
| AdditionalInfoRTFText | varchar(1000) | Yes | No |  |  |
| DocumentName | varchar(50) | Yes | No |  |  |
| OptionalDocument | tinyint | Yes | No |  |  |
| OnFileEligible | tinyint | Yes | No |  |  |
| UploadEligible | tinyint | Yes | No |  |  |
| DocumentTypeId | int | Yes | No |  |  |
| ExpirationDateReqd | tinyint | Yes | No |  |  |
| DocNumberReqd | tinyint | Yes | No |  |  |
| DocNumberLabel | varchar(50) | Yes | No |  |  |



**Primary Key:** BidderCheckListId





**Indexes:**
- PK_BidderCheckList (CLUSTERED): BidderCheckListId
- SK_DocumentTypeBidderCheckListId (NONCLUSTERED): DocumentTypeId, BidderCheckListId




### dbo.BidderCheckListPkgDetail



**Rows:** 1,193

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidderCheckListPkgDetailId | int | No | Yes |  |  |
| BidderCheckListPkgHeaderId | int | Yes | No |  |  |
| BidderCheckListId | int | Yes | No |  |  |
| DisplaySequence | int | Yes | No |  |  |



**Primary Key:** BidderCheckListPkgDetailId





**Indexes:**
- PK_BidderCheckListPkgDetail (CLUSTERED): BidderCheckListPkgDetailId




### dbo.BidderCheckListPkgHeader



**Rows:** 56

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidderCheckListPkgHeaderId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| PackageName | varchar(80) | Yes | No |  |  |



**Primary Key:** BidderCheckListPkgHeaderId





**Indexes:**
- PK_CheckListPackageHeader (CLUSTERED): BidderCheckListPkgHeaderId




### dbo.BidDocument



**Rows:** 10,372

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidDocumentId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| DocumentTitle | varchar(80) | Yes | No |  |  |
| DocumentFilename | varchar(80) | Yes | No |  |  |
| DocumentType | varchar(50) | Yes | No |  |  |
| DocumentBody | text | Yes | No |  |  |



**Primary Key:** BidDocumentId





**Indexes:**
- PK_BidDocument (CLUSTERED): BidDocumentId




### dbo.BidDocumentTypes



**Rows:** 298

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidDocumentTypeId | int | No | Yes |  |  |
| BidType | int | Yes | No |  |  |
| Name | varchar(50) | No | No |  |  |
| Description | varchar(4096) | Yes | No |  |  |
| VendorSpecific | tinyint | Yes | No |  |  |
| State | char(2) | Yes | No |  |  |
| Sequence | int | Yes | No |  |  |
| DistrictVisible | tinyint | Yes | No |  |  |
| OnlyShowOne | tinyint | Yes | No |  |  |
| Grouping | varchar(50) | Yes | No |  |  |
| VendorUnique | tinyint | Yes | No |  |  |
| Expires | tinyint | Yes | No |  |  |



**Primary Key:** BidDocumentTypeId





**Indexes:**
- PK__BidDocum__DBABDC6F43326279 (CLUSTERED): BidDocumentTypeId
- SK_DocLookup (NONCLUSTERED): DistrictVisible, OnlyShowOne, BidType, Name, VendorSpecific




### dbo.BidHeaderCheckList



**Rows:** 106,557

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidHeaderCheckListId | int | No | Yes |  |  |
| BidHeaderId | int | Yes | No |  |  |
| BidderCheckListId | int | Yes | No |  |  |
| DisplaySequence | int | Yes | No |  |  |



**Primary Key:** BidHeaderCheckListId





**Indexes:**
- PK_BidHeaderCheckList (CLUSTERED): BidHeaderCheckListId
- SKI_BidHeaderBidderCheckListIdDisplaySeq_Id (NONCLUSTERED): BidHeaderCheckListId, BidHeaderId, BidderCheckListId, DisplaySequence




### dbo.BidHeaderDetail



**Rows:** 117,409,367

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidHeaderDetailId | bigint | No | Yes |  |  |
| BidHeaderId | int | Yes | No |  |  |
| DetailId | int | Yes | No |  |  |
| BidRequestItemId | int | Yes | No |  |  |
| Quantity | int | Yes | No |  |  |
| DateAdded | datetime | Yes | No | (getdate()) |  |
| BidHeaderKey | int | Yes | No |  |  |
| RequisitionId | int | Yes | No |  |  |
| id | uniqueidentifier | No | No | (newsequentialid()) |  |



**Primary Key:** BidHeaderDetailId





**Indexes:**
- PK_BidHeaderDetail (CLUSTERED): BidHeaderDetailId
- _dta_index_BidHeaderDetail_K2_K4_K1_K3 (NONCLUSTERED): BidHeaderId, BidRequestItemId, BidHeaderDetailId, DetailId
- _dta_index_BidHeaderDetail_K4_K1_K3 (NONCLUSTERED): BidRequestItemId, BidHeaderDetailId, DetailId
- IX_BidHeaderDetail_2 (NONCLUSTERED): BidHeaderId, DetailId
- SK_BidHeader_2 (NONCLUSTERED): BidHeaderId
- SK_Detail_2 (NONCLUSTERED): BidHeaderDetailId, BidHeaderId, DetailId
- UQ__BidHeade__3213E83E12D014FD (NONCLUSTERED): id




### dbo.BidHeaderDetail_Orig



**Rows:** 102,658,927

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidHeaderDetailId | bigint | No | Yes |  |  |
| BidHeaderId | int | Yes | No |  |  |
| DetailId | int | Yes | No |  |  |
| BidRequestItemId | int | Yes | No |  |  |
| Quantity | int | Yes | No |  |  |
| DateAdded | datetime | Yes | No | (getdate()) |  |
| BidHeaderKey | int | Yes | No |  |  |



**Primary Key:** BidHeaderDetailId





**Indexes:**
- PK_BidHeaderDetail_Orig (CLUSTERED): BidHeaderDetailId
- _dta_index_BidHeaderDetail_7_747201762__K2_K4_K1_K3 (NONCLUSTERED): BidHeaderId, BidRequestItemId, BidHeaderDetailId, DetailId
- _dta_index_BidHeaderDetail_7_747201762__K4_K1_K3 (NONCLUSTERED): BidRequestItemId, BidHeaderDetailId, DetailId
- IX_BidHeaderDetail (NONCLUSTERED): BidHeaderId, DetailId
- SK_BidHeader (NONCLUSTERED): BidHeaderId
- SK_Detail (NONCLUSTERED): BidHeaderDetailId, BidHeaderId, DetailId




### dbo.BidHeaderDocument



**Rows:** 155,004

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidHeaderDocumentId | int | No | Yes |  |  |
| BidHeaderId | int | Yes | No |  |  |
| BidDocumentId | int | Yes | No |  |  |
| DisplaySequence | int | Yes | No |  |  |



**Primary Key:** BidHeaderDocumentId





**Indexes:**
- PK_BidHeaderDocumentLinks (CLUSTERED): BidHeaderDocumentId




### dbo.BidHeaderDocuments



**Rows:** 1

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidHeaderDocumentId | int | No | Yes |  |  |
| BidHeaderId | int | No | No |  |  |
| DocumentDate | datetime | Yes | No |  |  |
| DocumentTitle | varchar(255) | No | No |  |  |
| DocumentFile | varchar(255) | Yes | No |  |  |
| DocumentData | text | Yes | No |  |  |
| DisplaySeq | int | Yes | No |  |  |



**Primary Key:** BidHeaderDocumentId





**Indexes:**
- PK__BidHeaderDocumen__5C8290C7 (CLUSTERED): BidHeaderDocumentId




### dbo.BidHeaders



**Rows:** 9,289

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidHeaderId | int | Yes | No |  |  |
| Active | tinyint | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| PricePlanId | int | Yes | No |  |  |
| DistrictId | int | Yes | No |  |  |
| BidDate | datetime | Yes | No |  |  |
| BidAwardDate | datetime | Yes | No |  |  |
| BidMessage | varchar(1024) | Yes | No |  |  |
| BidType | tinyint | Yes | No |  |  |
| PriceVarianceLevel | decimal(9,5) | Yes | No | ((2)) |  |
| MinimumPOAmount | money | Yes | No |  |  |
| Section | int | Yes | No |  |  |
| BudgetYearOption | tinyint | Yes | No |  |  |
| DateCreated | datetime | Yes | No | (getdate()) |  |
| EffectiveFrom | datetime | Yes | No |  |  |
| EffectiveUntil | datetime | Yes | No |  |  |
| Description | varchar(512) | Yes | No |  |  |
| ParentBidHeaderId | int | Yes | No |  |  |
| UpdateHold | int | Yes | No |  |  |
| ScheduledReaward | datetime | Yes | No |  |  |
| AllowTotalAward | tinyint | Yes | No |  |  |
| TotalAwardMinimumDiscount | decimal(9,5) | Yes | No |  |  |
| CalendarId | int | Yes | No |  |  |
| StateId | int | Yes | No |  |  |
| MarkAsOriginal | int | Yes | No |  |  |
| HostDistrictId | int | Yes | No |  |  |
| AwardMsg | varchar(1024) | Yes | No |  |  |
| AlertLink | varchar(255) | Yes | No |  |  |
| AlertMsg | varchar(4096) | Yes | No |  |  |
| BidManagerId | int | Yes | No |  |  |
| CompliantAlert | tinyint | Yes | No |  |  |
| HostAwardDate | datetime | Yes | No |  |  |
| AllowAdditionalManufacturers | tinyint | Yes | No |  |  |
| AllowAdditionalProductLines | tinyint | Yes | No |  |  |
| UseOptions | tinyint | Yes | No |  |  |
| BidHeaderKey | int | No | Yes |  |  |
| ImageURLRuleset | int | Yes | No |  |  |
| ReadyToUseDate | datetime | Yes | No |  |  |



**Primary Key:** BidHeaderKey





**Indexes:**
- PK_BidHeaders_1 (CLUSTERED): BidHeaderKey
- _dta_index_BidHeaders_12_2024706611__K9 (NONCLUSTERED): BidType
- _dta_index_BidHeaders_7_2024706611__K1_7_17 (NONCLUSTERED): BidAwardDate, Description, BidHeaderId
- _dta_index_BidHeaders_9_45243216__K2_K16_K15_K3_K4_K1 (NONCLUSTERED): Active, CategoryId, EffectiveUntil, EffectiveFrom, PricePlanId, BidHeaderId
- IX_BidHeaders (NONCLUSTERED): Active, BidType, BidHeaderId
- IX_BIdHeaders_BidHeaderId (NONCLUSTERED): BidHeaderId
- SK_BHPricePlan (NONCLUSTERED): BidAwardDate, Description, CategoryId, BidHeaderId, PricePlanId
- SK_BidGrouper (NONCLUSTERED): BidHeaderId, EffectiveFrom, EffectiveUntil, CategoryId, PricePlanId, BidAwardDate, BidType
- SK_BidHeaderEffective (NONCLUSTERED): BidHeaderId, Active, EffectiveFrom, EffectiveUntil
- SK_CatAwardDate (NONCLUSTERED): PricePlanId, CategoryId, Active, BidAwardDate
- SK_CatPPActive (NONCLUSTERED): EffectiveFrom, EffectiveUntil, BidDate, BidAwardDate, BidType, BidHeaderKey, BidHeaderId, CategoryId, PricePlanId, Active
- SK_CatPPAwardDate (NONCLUSTERED): CategoryId, PricePlanId, BidAwardDate
- SK_ParentBidHeaderId (NONCLUSTERED): ParentBidHeaderId
- SKI_ActiveFromUntil_etc (NONCLUSTERED): BidHeaderId, CategoryId, PricePlanId, DistrictId, BidType, ParentBidHeaderId, Active, EffectiveFrom, EffectiveUntil
- SKI_ActiveFromUntil_IdParent (NONCLUSTERED): BidHeaderId, ParentBidHeaderId, Active, EffectiveFrom, EffectiveUntil
- SKI_ActiveParentFromUntil_CatPPDisType (NONCLUSTERED): BidHeaderId, CategoryId, PricePlanId, DistrictId, BidType, Active, ParentBidHeaderId, EffectiveFrom, EffectiveUntil
- SKI_AwardDateActive_HeaderCatPPDistrictKey (NONCLUSTERED): BidHeaderId, CategoryId, PricePlanId, DistrictId, BidHeaderKey, BidAwardDate, Active
- SKI_BidHeaderId_TypeAlert (NONCLUSTERED): BidType, CompliantAlert, BidHeaderId
- SKI_Date (NONCLUSTERED): EffectiveFrom, EffectiveUntil, CategoryId, Active, BidHeaderId




### dbo.BidImportCatalogList



**Rows:** 32,309

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidImportCatalogId | int | No | Yes |  |  |
| BidImportId | int | Yes | No |  |  |
| CatalogId | int | Yes | No |  |  |
| DiscountRate | decimal(9,5) | Yes | No |  |  |
| DateModified | datetime | Yes | No |  |  |



**Primary Key:** BidImportCatalogId





**Indexes:**
- PK__BidImportCatalog__0D3AD6BB (CLUSTERED): BidImportCatalogId
- SKI_BidImportCatalog_Id (NONCLUSTERED): BidImportCatalogId, DiscountRate, BidImportId, CatalogId
- SKI_CatalogBidImport_DiscountRateId (NONCLUSTERED): BidImportCatalogId, DiscountRate, CatalogId, BidImportId




### dbo.BidImportCounties



**Rows:** 63,021

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidImportCountyId | int | No | Yes |  |  |
| BidImportId | int | No | No |  |  |
| BidTradeCountyId | int | No | No |  |  |
| Active | tinyint | Yes | No |  |  |
| DateModified | datetime | No | No | (getdate()) |  |
| Comments | varchar(4096) | Yes | No |  |  |



**Primary Key:** BidImportCountyId





**Indexes:**
- PK__BidImpor__C2DF818B7D29F9E4 (CLUSTERED): BidImportCountyId
- SKI_Active_BidImportIdBidTRadeCountyId (NONCLUSTERED): BidImportId, BidTradeCountyId, Active
- SKI_BidImportId_BidImportCountyIdBidTradeCountyId (NONCLUSTERED): BidImportCountyId, BidTradeCountyId, BidImportId
- SKI_BidTRadeCountyIdActive_BidImportId (NONCLUSTERED): BidImportId, BidTradeCountyId, Active




### dbo.BidImports



**Rows:** 53,521

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidImportId | int | No | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| Active | tinyint | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| BidItemDiscountRate | decimal(9,5) | Yes | No |  |  |
| CatalogId | int | Yes | No |  |  |
| CatalogDiscountRate | decimal(9,5) | Yes | No |  |  |
| VendorBidNumber | varchar(50) | Yes | No |  |  |
| ItemsBid | int | Yes | No |  |  |
| AmountBid | money | Yes | No |  |  |
| MinimumOrder | money | Yes | No |  |  |
| FreeDeliveryMinimum | money | Yes | No |  |  |
| Status | varchar(50) | Yes | No |  |  |
| Comments | varchar(1024) | Yes | No |  |  |
| DateModified | datetime | Yes | No |  |  |
| StateContractDiscount | decimal(9,5) | Yes | No |  |  |
| AdditionalHandlingAmount | money | Yes | No |  |  |
| FreeHandlingAmount | money | Yes | No |  |  |
| FreeHandlingStart | datetime | Yes | No |  |  |
| FreeHandlingEnd | datetime | Yes | No |  |  |
| UseVendorContactInfo | tinyint | Yes | No |  |  |
| ContactEmail | varchar(255) | Yes | No |  |  |
| ContactName | varchar(50) | Yes | No |  |  |
| ContactPhone | varchar(20) | Yes | No |  |  |
| ContactFax | varchar(20) | Yes | No |  |  |
| POVendorContactId | int | Yes | No |  |  |
| VendorBidId | int | Yes | No |  |  |
| BidVendorContactId | int | Yes | No |  |  |
| WebsiteLink | varchar(255) | Yes | No |  |  |
| CatalogDiscountComments | varchar(512) | Yes | No |  |  |
| BidHeaderKey | int | Yes | No |  |  |



**Primary Key:** BidImportId





**Indexes:**
- PK_BidImports (CLUSTERED): BidImportId
- _dta_index_BidImports_7_1640249494__K1_K4_K26_2_8 (NONCLUSTERED): BidHeaderId, VendorBidNumber, BidImportId, VendorId, POVendorContactId
- _dta_index_BidImports_7_475200793__K1 (NONCLUSTERED): BidImportId
- _dta_index_BidImports_7_475200793__K1_K3_K4_K2_5 (NONCLUSTERED): BidItemDiscountRate, BidImportId, Active, VendorId, BidHeaderId
- _dta_index_BidImports_7_475200793__K1_K4 (NONCLUSTERED): BidImportId, VendorId
- _dta_index_BidImports_7_475200793__K2_K1_K3_K4_5_9_10 (NONCLUSTERED): BidItemDiscountRate, ItemsBid, AmountBid, BidHeaderId, BidImportId, Active, VendorId
- _dta_index_BidImports_7_475200793__K2_K3_K4_K1_5 (NONCLUSTERED): BidItemDiscountRate, BidHeaderId, Active, VendorId, BidImportId
- _dta_index_BidImports_7_475200793__K3_K1_K2_K4_5_9_10 (NONCLUSTERED): BidItemDiscountRate, ItemsBid, AmountBid, Active, BidImportId, BidHeaderId, VendorId
- _dta_index_BidImports_7_475200793__K3_K2_K1_K4_5_9_10 (NONCLUSTERED): BidItemDiscountRate, ItemsBid, AmountBid, Active, BidHeaderId, BidImportId, VendorId
- SK_BidHeader (NONCLUSTERED): BidImportId, Active, VendorId, BidHeaderId
- SK_Vendor (NONCLUSTERED): BidImportId, BidHeaderId, VendorBidNumber, VendorId
- SKI_VendorImport_Header (NONCLUSTERED): BidHeaderId, Active, VendorId, BidImportId




### dbo.BidItems



**Rows:** 26,347,877

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidItemId | int | No | Yes |  |  |
| BidItemId_Old | int | Yes | No |  |  |
| BidId | int | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |
| Price | money | Yes | No |  |  |
| Alternate | varchar(512) | Yes | No |  |  |
| BidQuantity | int | Yes | No |  |  |
| BidRequest | int | Yes | No |  |  |
| AwardId | int | Yes | No |  |  |
| VendorItemCode | varchar(50) | Yes | No |  |  |
| CrossRefId | int | Yes | No |  |  |
| ItemBidType | varchar(32) | Yes | No |  |  |
| PackedItemCode | varchar(50) | Yes | No |  |  |
| PackedVendorItemCode | varchar(50) | Yes | No |  |  |
| DateUpdated | datetime | Yes | No |  |  |
| PageNo | int | Yes | No |  |  |
| RTK_MSDSId | int | Yes | No |  |  |
| BidResultsId | int | Yes | No |  |  |
| ContractNumber | varchar(50) | Yes | No |  |  |
| AdditionalShipping | tinyint | Yes | No |  |  |



**Primary Key:** BidItemId





**Indexes:**
- PK_BidItems2 (CLUSTERED): BidItemId
- _dta_index_BidItems_7_1321107797__K1_K2 (NONCLUSTERED): BidItemId, BidId
- _dta_index_BidItems_9_416056568__K2_K3_K6_K4_K10 (NONCLUSTERED): BidResultsId, BidId, ItemId, BidQuantity, Price, CrossRefId
- _dta_index_BidItems_9_416056568__K3_K2_K10_K1_K5_K9_K4 (NONCLUSTERED): ItemId, BidId, CrossRefId, BidItemId, Alternate, VendorItemCode, Price
- SK_BidPackedVendor (NONCLUSTERED): BidItemId, BidId, PackedVendorItemCode
- SK_ItemBid (NONCLUSTERED): BidItemId, Price, Alternate, VendorItemCode, CrossRefId, ItemId, BidId
- SK_Tune1 (NONCLUSTERED): ItemId, BidItemId, BidId, Price, Alternate, BidQuantity, AwardId, VendorItemCode
- SKI_BidResults_Bid_Item (NONCLUSTERED): BidId, ItemId, BidResultsId
- SKI_BidResults_BidItem (NONCLUSTERED): BidId, ItemId, BidResultsId
- ti_Crossref_BidItemId (NONCLUSTERED): BidItemId, CrossRefId




### dbo.BidItems_Old



**Rows:** 16,238,384

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidItemId | int | No | Yes |  |  |
| BidId | int | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |
| Price | money | Yes | No |  |  |
| Alternate | varchar(512) | Yes | No |  |  |
| BidQuantity | int | Yes | No |  |  |
| BidRequest | int | Yes | No |  |  |
| AwardId | int | Yes | No |  |  |
| VendorItemCode | varchar(50) | Yes | No |  |  |
| CrossRefId | int | Yes | No |  |  |
| ItemBidType | varchar(32) | Yes | No |  |  |
| PackedItemCode | varchar(50) | Yes | No |  |  |
| PackedVendorItemCode | varchar(50) | Yes | No |  |  |
| DateUpdated | datetime | Yes | No |  |  |
| PageNo | int | Yes | No |  |  |
| RTK_MSDSId | int | Yes | No |  |  |
| BidResultsId | int | Yes | No |  |  |
| ContractNumber | varchar(50) | Yes | No |  |  |
| AdditionalShipping | tinyint | Yes | No |  |  |



**Primary Key:** BidItemId





**Indexes:**
- PK_BidItems (CLUSTERED): BidItemId




### dbo.BidManagers



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidManagerId | int | No | Yes |  |  |
| Name | varchar(50) | Yes | No |  |  |
| UserId | int | Yes | No |  |  |
| Phone | varchar(20) | Yes | No |  |  |
| Email | varchar(255) | Yes | No |  |  |



**Primary Key:** BidManagerId





**Indexes:**
- PK__BidManag__D819B22B2B5AD8E8 (CLUSTERED): BidManagerId




### dbo.BidManufacturers



**Rows:** 245,952

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BMAId | int | No | Yes |  |  |
| BidId | int | No | No |  |  |
| ManufacturerId | int | No | No |  |  |
| DiscountRate | decimal(9,5) | Yes | No |  |  |
| Modified | datetime | No | No | (getdate()) |  |



**Primary Key:** BMAId





**Indexes:**
- PK__BidManuf__8D2BDD186E9E4570 (CLUSTERED): BMAId
- SKI_BidManufacturer_Discount (NONCLUSTERED): DiscountRate, BidId, ManufacturerId
- SKI_Manufacturer_BidDiscount (NONCLUSTERED): BidId, DiscountRate, ManufacturerId




### dbo.BidMappedItems



**Rows:** 1,459,725

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidMappedItemId | uniqueidentifier | No | No | (newid()) |  |
| BidHeaderId | int | No | No |  |  |
| OrigItemId | int | No | No |  |  |
| NewItemId | int | No | No |  |  |
| ReasonCode | varchar(20) | Yes | No |  |  |
| MapDate | datetime | No | No | (getdate()) |  |



**Primary Key:** BidMappedItemId





**Indexes:**
- PK__BidMappe__6B5A9CC727E67581 (CLUSTERED): BidMappedItemId
- SKI_BidHeader_OrigNew (NONCLUSTERED): OrigItemId, NewItemId, BidHeaderId
- SKI_BidHeaderReason_BidMappedItem (NONCLUSTERED): BidMappedItemId, BidHeaderId, ReasonCode




### dbo.BidMgrConfiguration



**Rows:** 1

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidMgrConfigurationId | int | No | Yes |  |  |
| CheckListHeaderRTF | varchar(5000) | Yes | No |  |  |



**Primary Key:** BidMgrConfigurationId





**Indexes:**
- PK_BidMgrConfiguration (CLUSTERED): BidMgrConfigurationId




### dbo.BidMgrTagFile



**Rows:** 4,070,339

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidMgrTagFileId | int | No | Yes |  |  |
| Usr | int | Yes | No |  |  |
| Tbl | int | Yes | No |  |  |
| Ptr | int | Yes | No |  |  |
| Val | char(10) | Yes | No |  |  |
| OrigVal | char(10) | Yes | No |  |  |



**Primary Key:** BidMgrTagFileId





**Indexes:**
- PK_BidMgrTagFile (CLUSTERED): BidMgrTagFileId
- SK_BidMgrTagFile_Usr_Tbl (NONCLUSTERED): Usr, Tbl
- SK_BidMgrTagFile_Usr_Tbl_Ptr (NONCLUSTERED): Usr, Tbl, Ptr
- SKI_Ptr_TagUsrTblVal (NONCLUSTERED): BidMgrTagFileId, Usr, Tbl, Val, Ptr




### dbo.BidMSRPResultPrices



**Rows:** 384,197

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidMSRPResultPricesId | int | No | Yes |  |  |
| BidMSRPResultsId | int | No | No |  |  |
| BidMSRPResultsProductLineId | int | Yes | No |  |  |
| Active | tinyint | Yes | No |  |  |
| BidRequestPriceRangeId | int | No | No |  |  |
| RangeBase | money | Yes | No |  |  |
| RangeWeight | decimal(9,5) | Yes | No |  |  |
| RangeValue | decimal(9,5) | Yes | No |  |  |



**Primary Key:** BidMSRPResultPricesId





**Indexes:**
- PK__BidMSRPR__6BDB670123093B9D (CLUSTERED): BidMSRPResultPricesId
- SKI_ProductLine_ (NONCLUSTERED): BidMSRPResultPricesId, BidMSRPResultsId, RangeWeight, BidMSRPResultsProductLineId




### dbo.BidMSRPResults



**Rows:** 38,098

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidMSRPResultsId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| BidHeaderId | int | No | No |  |  |
| BidImportId | int | No | No |  |  |
| ManufacturerId | int | Yes | No |  |  |
| DiscountRate | decimal(9,5) | Yes | No |  |  |
| Modified | datetime | No | No | (getdate()) |  |
| DiscountRateString | char(10) | Yes | No |  |  |
| WriteInFlag | tinyint | Yes | No |  |  |
| WriteInManufacturer | varchar(100) | Yes | No |  |  |
| VendorNotes | varchar(1000) | Yes | No |  |  |
| BidRequestManufacturerId | int | Yes | No |  |  |
| WinningBidOverride | tinyint | Yes | No |  |  |
| PriceListTypeId | int | Yes | No |  |  |
| AuthorizationLetter | tinyint | Yes | No |  |  |
| SubmittedExcel | tinyint | Yes | No |  |  |
| ProductCatalog | tinyint | Yes | No |  |  |
| TotalAward | tinyint | Yes | No |  |  |
| VendorPriceFile | tinyint | Yes | No |  |  |
| TotalAwardDiscount | decimal(9,5) | Yes | No |  |  |
| TotalAwardString | varchar(20) | Yes | No |  |  |
| ExcelFileApproved | tinyint | Yes | No |  |  |
| BidHeaderKey | int | Yes | No |  |  |



**Primary Key:** BidMSRPResultsId





**Indexes:**
- PK__BidMSRPR__0E57068669D99053 (CLUSTERED): BidMSRPResultsId
- SKI_BidHeaderManufacturer_Results (NONCLUSTERED): BidMSRPResultsId, Active, BidImportId, WinningBidOverride, TotalAward, BidHeaderId, ManufacturerId
- SKI_BidImportActive_BidHeader (NONCLUSTERED): BidMSRPResultsId, BidHeaderId, Active, BidImportId




### dbo.BidMSRPResultsProductLines



**Rows:** 100,869

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidMSRPResultsProductLineId | int | No | Yes |  |  |
| BidMSRPResultsId | int | No | No |  |  |
| Active | tinyint | Yes | No |  |  |
| BidRequestProductLineId | int | Yes | No |  |  |
| WriteInProductLineName | varchar(100) | Yes | No |  |  |
| BidRequestOptionId | int | Yes | No |  |  |
| MSRPOptionId | int | Yes | No |  |  |
| OptionName | varchar(50) | Yes | No |  |  |
| WriteInProductLineFlag | tinyint | Yes | No |  |  |
| Weight | decimal(9,5) | Yes | No |  |  |
| Modified | datetime | Yes | No |  |  |
| WeightedDiscount | decimal(9,5) | Yes | No |  |  |
| ManufacturerProductLineId | int | Yes | No |  |  |



**Primary Key:** BidMSRPResultsProductLineId





**Indexes:**
- PK_BidMSRPResultsProductLine (CLUSTERED): BidMSRPResultsProductLineId
- SKI_BidResults_ (NONCLUSTERED): BidMSRPResultsProductLineId, Active, MSRPOptionId, ManufacturerProductLineId, OptionName, BidMSRPResultsId




### dbo.BidPackage



**Rows:** 50

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidPackageId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| BidPackageName | varchar(80) | Yes | No |  |  |



**Primary Key:** BidPackageId





**Indexes:**
- PK_BidDocumentPackage (CLUSTERED): BidPackageId




### dbo.BidPackageDocument



**Rows:** 1,430

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidPackageDocumentId | int | No | Yes |  |  |
| BidPackageId | int | Yes | No |  |  |
| BidDocumentId | int | Yes | No |  |  |
| DisplaySequence | int | Yes | No |  |  |



**Primary Key:** BidPackageDocumentId





**Indexes:**
- PK_BidPackageDocument (CLUSTERED): BidPackageDocumentId




### dbo.BidProductLinePrices



**Rows:** 1,227,397

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidProductLinePriceId | int | No | Yes |  |  |
| BidProductLineId | int | No | No |  |  |
| RangeBase | money | Yes | No |  |  |
| DiscountRate | decimal(9,5) | Yes | No |  |  |
| Modified | datetime | No | No | (getdate()) |  |



**Primary Key:** BidProductLinePriceId





**Indexes:**
- PK__BidProductLinePrices (CLUSTERED): BidProductLinePriceId
- SKI_BidProductLinePrices (NONCLUSTERED): BidProductLinePriceId, DiscountRate, BidProductLineId, RangeBase
- SKI_BidProductLinePricesDesc (NONCLUSTERED): BidProductLinePriceId, DiscountRate, BidProductLineId, RangeBase




### dbo.BidProductLines



**Rows:** 264,942

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidProductLineId | int | No | Yes |  |  |
| BMAId | int | No | No |  |  |
| ManufacturerProductLineId | int | No | No |  |  |
| MSRPOptionId | int | No | No |  |  |
| DiscountRate | decimal(9,5) | Yes | No |  |  |
| Modified | datetime | No | No | (getdate()) |  |



**Primary Key:** BidProductLineId





**Indexes:**
- PK__BidProdu__B50DDCA01F360E8C (CLUSTERED): BidProductLineId




### dbo.BidQuestions



**Rows:** 22,500

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidQuestionId | int | No | Yes |  |  |
| BidTradeId | int | No | No |  |  |
| BidSection | varchar(255) | Yes | No |  |  |
| Sequence | int | Yes | No |  |  |
| QuestionPositionX | int | Yes | No |  |  |
| QuestionPositionY | int | Yes | No |  |  |
| QuestionHeight | int | Yes | No |  |  |
| QuestionWidth | int | Yes | No |  |  |
| QuestionText | varchar(MAX) | No | No |  |  |
| QuestionQty | int | Yes | No |  |  |
| QuestionUOMId | int | Yes | No |  |  |
| AnswerPositionX | int | Yes | No |  |  |
| AnswerPositionY | int | Yes | No |  |  |
| AnswerHeight | int | Yes | No |  |  |
| AnswerWidth | int | Yes | No |  |  |
| AnswerTypeId | int | Yes | No |  |  |
| AnswerTypeMask | varchar(50) | Yes | No |  |  |
| Weight | decimal(9,5) | Yes | No |  |  |
| Required | tinyint | Yes | No |  |  |
| ExtendCalculation | tinyint | Yes | No |  |  |
| ExtdCalcTypeId | int | Yes | No |  |  |
| ExtdCalcMask | varchar(50) | Yes | No |  |  |
| UseInCalculation | tinyint | Yes | No |  |  |
| OnChecklist | tinyint | Yes | No |  |  |
| CountyIdSpecific | int | Yes | No |  |  |
| BidEntryDisplayLabel | varchar(255) | Yes | No |  |  |



**Primary Key:** BidQuestionId



**Foreign Keys:**
- BidTradeId → dbo.BidTrades.BidTradeId




**Indexes:**
- PK__BidQuest__25F2DBFE1BE38B2E (CLUSTERED): BidQuestionId




### dbo.BidReawards



**Rows:** 523

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidReawardId | int | No | Yes |  |  |
| BidHeaderId | int | No | No |  |  |
| ReawardDate | datetime | No | No |  |  |
| EffectiveFrom | datetime | No | No |  |  |
| EffectiveUntil | datetime | No | No |  |  |
| Comments | varchar(4096) | Yes | No |  |  |



**Primary Key:** BidReawardId





**Indexes:**
- PK__BidReawa__14AE8FDE4B2C318A (CLUSTERED): BidReawardId




### dbo.BidRequestItemMergeActions



**Rows:** 35,539

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidRequestItemMergeActionsId | int | No | Yes |  |  |
| BidRequestItemId | int | Yes | No |  |  |
| DestinationBidRequestItemId | int | Yes | No |  |  |
| Merged | tinyint | Yes | No |  |  |



**Primary Key:** BidRequestItemMergeActionsId





**Indexes:**
- PK_BidRequestItemMergeHistory (CLUSTERED): BidRequestItemMergeActionsId




### dbo.BidRequestItemMergeActions_Orig



**Rows:** 27,168

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidRequestItemMergeActionsId | int | No | Yes |  |  |
| BidRequestItemId | int | Yes | No |  |  |
| DestinationBidRequestItemId | int | Yes | No |  |  |
| Merged | tinyint | Yes | No |  |  |



**Primary Key:** BidRequestItemMergeActionsId





**Indexes:**
- PK_BidRequestItemMergeHistory_Orig (CLUSTERED): BidRequestItemMergeActionsId




### dbo.BidRequestItemMergeActions_Saved_101521



**Rows:** 27,298

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidRequestItemMergeActionsId | int | No | Yes |  |  |
| BidRequestItemId | int | Yes | No |  |  |
| DestinationBidRequestItemId | int | Yes | No |  |  |
| Merged | tinyint | Yes | No |  |  |
| rowguid | uniqueidentifier | No | No |  |  |









### dbo.BidRequestItems



**Rows:** 26,996,332

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidRequestItemId | int | No | Yes |  |  |
| BidRequestItemId_OLD | int | Yes | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |
| BidRequest | int | Yes | No |  |  |
| Active | tinyint | Yes | No |  |  |
| RequisitionCount | int | Yes | No |  |  |
| Status | varchar(50) | Yes | No |  |  |
| Comments | varchar(1024) | Yes | No |  |  |
| BidRequestAmount | money | Yes | No |  |  |
| Checksum | int | Yes | No |  |  |
| MasterItemCodePtr | int | Yes | No |  |  |
| BidHeaderKey | int | Yes | No |  |  |
| ImageURL | varchar(300) | Yes | No |  |  |
| SDS_URL | varchar(300) | Yes | No |  |  |



**Primary Key:** BidRequestItemId





**Indexes:**
- PK_BidRequestItems (CLUSTERED): BidRequestItemId
- _dta_index_BidRequestItems_K2_K1_K5 (NONCLUSTERED): BidHeaderId, BidRequestItemId, Active
- _dta_index_BidRequestItems_K2_K5_K1_3_4_7_8 (NONCLUSTERED): ItemId, BidRequest, Status, Comments, BidHeaderId, Active, BidRequestItemId
- _dta_index_BidRequestItems_K2_K5_K1_K3 (NONCLUSTERED): BidHeaderId, Active, BidRequestItemId, ItemId
- IX_BidRequestItems_Old (NONCLUSTERED): BidRequestItemId_OLD
- SK_BidItem_2 (NONCLUSTERED): BidHeaderId, ItemId
- SK_ItemBidRequestHeader_2 (NONCLUSTERED): ItemId, BidHeaderId, BidRequest
- SKI_BidHeader_RequestItemItemQuantityActiveReqcount_2 (NONCLUSTERED): ItemId, BidRequest, Active, RequisitionCount, BidHeaderId, BidRequestItemId




### dbo.BidRequestItems_Orig



**Rows:** 25,521,585

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidRequestItemId | int | No | Yes |  |  |
| BidRequestItemId_OLD | int | Yes | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |
| BidRequest | int | Yes | No |  |  |
| Active | tinyint | Yes | No |  |  |
| RequisitionCount | int | Yes | No |  |  |
| Status | varchar(50) | Yes | No |  |  |
| Comments | varchar(1024) | Yes | No |  |  |
| BidRequestAmount | money | Yes | No |  |  |
| Checksum | int | Yes | No |  |  |
| MasterItemCodePtr | int | Yes | No |  |  |
| BidHeaderKey | int | Yes | No |  |  |
| ImageURL | varchar(300) | Yes | No |  |  |
| SDS_URL | varchar(300) | Yes | No |  |  |



**Primary Key:** BidRequestItemId





**Indexes:**
- PK_BidRequestItems_Orig (CLUSTERED): BidRequestItemId
- _dta_index_BidRequestItems_7_363200394__K2_K1_K5 (NONCLUSTERED): BidHeaderId, BidRequestItemId, Active
- _dta_index_BidRequestItems_7_363200394__K2_K5_K1_3_4_7_8 (NONCLUSTERED): ItemId, BidRequest, Status, Comments, BidHeaderId, Active, BidRequestItemId
- _dta_index_BidRequestItems_7_363200394__K2_K5_K1_K3 (NONCLUSTERED): BidHeaderId, Active, BidRequestItemId, ItemId
- IX_BidRequestItemID_OLD (NONCLUSTERED): BidRequestItemId_OLD
- SK_BidItem (NONCLUSTERED): BidHeaderId, ItemId
- SK_ItemBidRequestHeader (NONCLUSTERED): ItemId, BidHeaderId, BidRequest
- SKI_BidHeader_RequestItemItemQuantityActiveReqcount (NONCLUSTERED): ItemId, BidRequest, Active, RequisitionCount, BidHeaderId, BidRequestItemId




### dbo.BidRequestManufacturer



**Rows:** 94,012

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidRequestManufacturerId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| ManufacturerId | int | Yes | No |  |  |
| SequenceNumber | int | Yes | No |  |  |
| AllowAdditionalProductLines | tinyint | Yes | No |  |  |
| UseOptions | tinyint | Yes | No |  |  |
| BidHeaderKey | int | Yes | No |  |  |



**Primary Key:** BidRequestManufacturerId



**Foreign Keys:**
- BidHeaderId → dbo.BidHeaders.BidHeaderId




**Indexes:**
- PK_BidRequestManufacturer (CLUSTERED): BidRequestManufacturerId
- SKI_Manufact (NONCLUSTERED): BidRequestManufacturerId, Active, BidHeaderId, ManufacturerId




### dbo.BidRequestOptions



**Rows:** 381,049

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidRequestOptionId | int | No | Yes |  |  |
| BidHeaderId | int | No | No |  |  |
| ManufacturerId | int | Yes | No |  |  |
| ManufacturerProductLineId | int | Yes | No |  |  |
| OptionId | int | Yes | No |  |  |
| BidRequestManufacturerId | int | Yes | No |  |  |
| BidRequestProductLineId | int | Yes | No |  |  |
| Name | varchar(50) | No | No |  |  |
| Weight | decimal(9,5) | Yes | No |  |  |



**Primary Key:** BidRequestOptionId





**Indexes:**
- PK__BidReque__9B394ED17D189CDF (CLUSTERED): BidRequestOptionId
- SK_BRManufacturer_OptionProductName (NONCLUSTERED): OptionId, BidRequestProductLineId, Name, BidRequestManufacturerId
- SKI_ManufacturerProduct_OptionNameId (NONCLUSTERED): BidRequestOptionId, OptionId, Name, BidRequestProductLineId, BidRequestManufacturerId
- SKI_OptionProduct_ETC (NONCLUSTERED): OptionId, BidRequestProductLineId, BidRequestOptionId




### dbo.BidRequestPriceRanges



**Rows:** 1,713,245

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidRequestPriceRangeId | int | No | Yes |  |  |
| BidHeaderId | int | Yes | No |  |  |
| BidRequestManufacturerId | int | Yes | No |  |  |
| BidRequestProductLineId | int | Yes | No |  |  |
| RangeBase | money | Yes | No |  |  |
| RangeWeight | decimal(9,5) | Yes | No |  |  |
| BidRequestMSRPOptionId | int | Yes | No |  |  |



**Primary Key:** BidRequestPriceRangeId





**Indexes:**
- PK_BidRequestPriceRanges (CLUSTERED): BidRequestPriceRangeId
- SK_Lookups (NONCLUSTERED): BidHeaderId, BidRequestManufacturerId, BidRequestProductLineId, BidRequestMSRPOptionId, RangeBase, BidRequestPriceRangeId
- SKI_BidHeader_Etc (NONCLUSTERED): BidRequestPriceRangeId, BidRequestManufacturerId, BidRequestProductLineId, RangeBase, RangeWeight, BidRequestMSRPOptionId, BidHeaderId
- SKI_BRPR (NONCLUSTERED): BidRequestPriceRangeId, BidRequestProductLineId, BidRequestMSRPOptionId




### dbo.BidRequestProductLines



**Rows:** 158,929

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidRequestProductLineId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| BidRequestManufacturerId | int | No | No |  |  |
| ManufacturerProductLineId | int | Yes | No |  |  |
| UseOptions | tinyint | Yes | No |  |  |



**Primary Key:** BidRequestProductLineId





**Indexes:**
- PK__BidReque__D2B2584279480BFB (CLUSTERED): BidRequestProductLineId
- SKI_BidRequestManufacturer_ (NONCLUSTERED): BidRequestProductLineId, Active, ManufacturerProductLineId, BidRequestManufacturerId
- SKI_BidRequestProduct_ (NONCLUSTERED): BidRequestProductLineId, Active, ManufacturerProductLineId, BidRequestManufacturerId




### dbo.BidResponses



**Rows:** 1

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidResponseId | int | No | Yes |  |  |
| BidImportId | int | No | No |  |  |
| CountyId | int | No | No |  |  |
| BidQuestionId | int | No | No |  |  |
| BidAnswer | varchar(MAX) | Yes | No |  |  |



**Primary Key:** BidResponseId





**Indexes:**
- PK__BidRespo__4C059DB21FB41C12 (CLUSTERED): BidResponseId




### dbo.BidResultChanges



**Rows:** 18,229,521

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BRChangeId | int | No | Yes |  |  |
| BidResultsId | int | Yes | No |  |  |
| ChangeDate | datetime | Yes | No |  |  |
| PrevActive | int | Yes | No |  |  |
| PrevUnitPrice | money | Yes | No |  |  |
| NewActive | int | Yes | No |  |  |
| NewUnitPrice | money | Yes | No |  |  |
| PrevBidType | char(1) | Yes | No |  |  |
| NewBidType | char(1) | Yes | No |  |  |
| PrevComments | varchar(1024) | Yes | No |  |  |



**Primary Key:** BRChangeId





**Indexes:**
- PK__BidResultChanges__31783731 (CLUSTERED): BRChangeId




### dbo.BidResults



**Rows:** 31,981,902

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidResultsId | int | No | Yes |  |  |
| BidImportId | int | Yes | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| BidRequestItemId | int | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| DistrictId | int | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |
| ItemCode | varchar(50) | Yes | No |  |  |
| Units | varchar(16) | Yes | No |  |  |
| Alternate | varchar(512) | Yes | No |  |  |
| Quantity | int | Yes | No |  |  |
| ItemBidType | char(1) | Yes | No |  |  |
| UnitPrice | money | Yes | No |  |  |
| Cost | money | Yes | No |  |  |
| VendorItemCode | varchar(50) | Yes | No |  |  |
| QuantityBid | int | Yes | No |  |  |
| ItemsPerUnit | varchar(50) | Yes | No |  |  |
| UnitId | int | Yes | No |  |  |
| Status | varchar(51) | Yes | No |  |  |
| Comments | varchar(1024) | Yes | No |  |  |
| Active | int | Yes | No |  |  |
| PageNo | int | Yes | No |  |  |
| PackedVendorItemCode | varchar(50) | Yes | No |  |  |
| ModifiedDate | datetime | Yes | No |  |  |
| ModifiedSessionId | int | Yes | No |  |  |
| ModifiedBy | int | Yes | No |  |  |
| RTK_MSDSId | int | Yes | No |  |  |
| RTK_MSDSNotNeeded | tinyint | Yes | No |  |  |
| ContractNumber | varchar(50) | Yes | No |  |  |
| OriginalAwardedItem | tinyint | Yes | No |  |  |
| VOMId | int | Yes | No |  |  |
| AdditionalShipping | tinyint | Yes | No |  |  |
| ManufacturerBid | varchar(50) | Yes | No |  |  |
| ManufPartNoBid | varchar(50) | Yes | No |  |  |
| LinerGaugeMicrons | numeric(2,0) | Yes | No |  |  |
| LinerGaugeMil | numeric(3,2) | Yes | No |  |  |
| LinerCaseWeight | numeric(4,2) | Yes | No |  |  |
| LinerDimWidth | numeric(4,2) | Yes | No |  |  |
| LinerDimDepth | numeric(4,2) | Yes | No |  |  |
| LinerDimLength | numeric(4,2) | Yes | No |  |  |
| PackedManufPartNoBid | varchar(50) | Yes | No |  |  |
| BidHeaderKey | int | Yes | No |  |  |
| SDS_URL | varchar(300) | Yes | No |  |  |
| ImageURL | varchar(300) | Yes | No |  |  |
| UPC_ISBN | varchar(20) | Yes | No |  |  |
| UNSPSC | varchar(50) | Yes | No |  |  |
| UniqueItemNumber | varchar(50) | Yes | No |  |  |
| DigitallyDelivered | tinyint | Yes | No |  |  |
| MinimumOrderQuantity | int | Yes | No |  |  |
| PrescriptionRequired | bit | Yes | No |  |  |
| PerishableItem | bit | Yes | No |  |  |
| HashKey | varbinary(64) | Yes | No |  |  |
| ProductNames | varchar(4000) | Yes | No |  |  |
| TypeAheads | nvarchar(4000) | Yes | No |  |  |
| AIShortDesc | nvarchar(1024) | Yes | No |  |  |
| AIFullDesc | nvarchar(4000) | Yes | No |  |  |
| AIUNSPSC | varchar(20) | Yes | No |  |  |
| AIDate | datetime | Yes | No |  |  |



**Primary Key:** BidResultsId





**Indexes:**
- PK_BidResults (CLUSTERED): BidResultsId
- Ix_BidHeaderId_2 (NONCLUSTERED): BidHeaderId
- IX_BidResults_SDSURL_ItemId (NONCLUSTERED): SDS_URL, ItemId
- IX_SDS_URL (NONCLUSTERED): SDS_URL
- SK_BidRequestItem_2 (NONCLUSTERED): BidRequestItemId
- SK_HashKey (NONCLUSTERED): HashKey
- SK_ImportSDSRefSKI (NONCLUSTERED): BidImportId, SDS_URL
- SKI_AIDate_HashKey (NONCLUSTERED): HashKey, AIDate
- SKI_BidImportBidRequestItem_ActiveBidTypeBidResultsUnitPrice_2 (NONCLUSTERED): BidResultsId, DistrictId, Quantity, ItemBidType, UnitPrice, BidImportId, BidRequestItemId
- SKI_BidImportItemVOM_ItemBidTypeBidResults (NONCLUSTERED): BidResultsId, ItemBidType, BidImportId, ItemId, VOMId
- SKI_BidImportVIC_ItemImage (NONCLUSTERED): ItemId, ImageURL, BidImportId, VendorItemCode
- SKI_ItemId_Info (NONCLUSTERED): ItemCode, VendorItemCode, ManufacturerBid, ManufPartNoBid, SDS_URL, ItemId
- SKI_SDSRef_Import (NONCLUSTERED): BidImportId, SDS_URL
- SKI_SDSURL_Info (NONCLUSTERED): ItemId, ItemCode, VendorItemCode, ManufacturerBid, ManufPartNoBid, SDS_URL
- ski_VendorItemCodeImageURL_BidImportId (NONCLUSTERED): BidImportId, BidResultsId, VendorItemCode, ImageURL




### dbo.BidResults_Orig



**Rows:** 55,592,743

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidResultsId | int | No | Yes |  |  |
| BidImportId | int | Yes | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| BidRequestItemId | int | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| DistrictId | int | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |
| ItemCode | varchar(50) | Yes | No |  |  |
| Units | varchar(16) | Yes | No |  |  |
| Alternate | varchar(512) | Yes | No |  |  |
| Quantity | int | Yes | No |  |  |
| ItemBidType | char(1) | Yes | No |  |  |
| UnitPrice | money | Yes | No |  |  |
| Cost | money | Yes | No |  |  |
| VendorItemCode | varchar(50) | Yes | No |  |  |
| QuantityBid | int | Yes | No |  |  |
| ItemsPerUnit | varchar(50) | Yes | No |  |  |
| UnitId | int | Yes | No |  |  |
| Status | varchar(51) | Yes | No |  |  |
| Comments | varchar(1024) | Yes | No |  |  |
| Active | int | Yes | No |  |  |
| PageNo | int | Yes | No |  |  |
| PackedVendorItemCode | varchar(50) | Yes | No |  |  |
| ModifiedDate | datetime | Yes | No |  |  |
| ModifiedSessionId | int | Yes | No |  |  |
| ModifiedBy | int | Yes | No |  |  |
| RTK_MSDSId | int | Yes | No |  |  |
| RTK_MSDSNotNeeded | tinyint | Yes | No |  |  |
| ContractNumber | varchar(50) | Yes | No |  |  |
| OriginalAwardedItem | tinyint | Yes | No |  |  |
| VOMId | int | Yes | No |  |  |
| AdditionalShipping | tinyint | Yes | No |  |  |
| ManufacturerBid | varchar(50) | Yes | No |  |  |
| ManufPartNoBid | varchar(50) | Yes | No |  |  |
| LinerGaugeMicrons | numeric(2,0) | Yes | No |  |  |
| LinerGaugeMil | numeric(3,2) | Yes | No |  |  |
| LinerCaseWeight | numeric(4,2) | Yes | No |  |  |
| LinerDimWidth | numeric(4,2) | Yes | No |  |  |
| LinerDimDepth | numeric(4,2) | Yes | No |  |  |
| LinerDimLength | numeric(4,2) | Yes | No |  |  |
| PackedManufPartNoBid | varchar(50) | Yes | No |  |  |
| BidHeaderKey | int | Yes | No |  |  |
| SDS_URL | varchar(300) | Yes | No |  |  |
| ImageURL | varchar(300) | Yes | No |  |  |
| UPC_ISBN | varchar(20) | Yes | No |  |  |
| UNSPSC | varchar(50) | Yes | No |  |  |



**Primary Key:** BidResultsId





**Indexes:**
- PK_BidResults_Rebuilt_Orig (CLUSTERED): BidResultsId
- Ix_BidHeaderId (NONCLUSTERED): BidHeaderId
- SK_BidRequestItem (NONCLUSTERED): BidRequestItemId
- SKI_BidImportBidRequestItem_ActiveBidTypeBidResultsUnitPrice (NONCLUSTERED): BidResultsId, DistrictId, Quantity, ItemBidType, UnitPrice, BidImportId, BidRequestItemId




### dbo.BidResultsChangeLog



**Rows:** 238,949

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BRChangeLogId | int | No | Yes |  |  |
| ChangeDate | datetime | Yes | No |  |  |
| BidResultsId | int | Yes | No |  |  |
| SessionId | int | Yes | No |  |  |
| UserId | int | Yes | No |  |  |
| Reason | varchar(4096) | Yes | No |  |  |
| RequisitionId | int | Yes | No |  |  |
| DetailId | int | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |
| BidType | char(1) | Yes | No |  |  |
| NetPrice | money | Yes | No |  |  |
| VOMId | int | Yes | No |  |  |



**Primary Key:** BRChangeLogId





**Indexes:**
- PK__BidResultsChange__247341CE (CLUSTERED): BRChangeLogId




### dbo.Bids



**Rows:** 140,396

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| CoopId | int | Yes | No |  |  |
| ClosingDate | datetime | Yes | No |  |  |
| OpeningDate | datetime | Yes | No |  |  |
| EffectiveFrom | datetime | Yes | No |  |  |
| EffectiveUntil | datetime | Yes | No |  |  |
| Name | varchar(255) | Yes | No |  |  |
| PricePlanId | int | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| BidDiscountRate | decimal(8,5) | Yes | No |  |  |
| VendorBidNumber | varchar(50) | Yes | No |  |  |
| DistrictId | int | Yes | No |  | District Id for District Specific Bids |
| ItemsBid | int | Yes | No |  |  |
| AmountBid | money | Yes | No |  |  |
| CatalogId | int | Yes | No |  |  |
| Description | varchar(511) | Yes | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| UseGrossPrices | int | Yes | No |  |  |
| BidImportId | int | Yes | No |  |  |
| DateModified | datetime | Yes | No |  |  |
| AdditionalHandlingAmount | money | Yes | No |  |  |
| FreeHandlingAmount | money | Yes | No |  |  |
| FreeHandlingStart | datetime | Yes | No |  |  |
| FreeHandlingEnd | datetime | Yes | No |  |  |
| WebsiteLink | varchar(255) | Yes | No |  |  |



**Primary Key:** BidId





**Indexes:**
- PK_Bids_1 (CLUSTERED): BidId
- _dta_index_Bids_7_1785109450__K1_K11_K2_K19_K21 (NONCLUSTERED): BidId, VendorId, Active, BidHeaderId, BidImportId
- _dta_index_Bids_9_512056910__K1_K2_K19_K11_K12 (NONCLUSTERED): BidId, Active, BidHeaderId, VendorId, BidDiscountRate
- _dta_index_Bids_9_512056910__K19_K2_K1_K11 (NONCLUSTERED): BidHeaderId, Active, BidId, VendorId
- SK_ActiveHeaders (NONCLUSTERED): BidHeaderId, Active
- SK_BidHeader (NONCLUSTERED): BidHeaderId
- SK_BidHeaderActiveBidVendor (NONCLUSTERED): BidId, BidHeaderId, VendorId, Active
- SK_BidImport (NONCLUSTERED): BidId, BidImportId, VendorId
- SK_Vendor (NONCLUSTERED): BidId, BidImportId, VendorId
- SKI_Active_BidVendorBidDiscountRateBidHeader (NONCLUSTERED): BidId, VendorId, BidDiscountRate, BidHeaderId, Active
- SKI_Active_VendorBidheaderidBidImportid (NONCLUSTERED): VendorId, BidHeaderId, BidImportId, Active
- SKI_ActiveVendor_BidImport (NONCLUSTERED): BidHeaderId, BidImportId, Active, VendorId
- SKI_BidheaderActive_Bidid (NONCLUSTERED): BidId, BidHeaderId, Active, DateModified
- SKI_BidHeaderVendorActive_Bid (NONCLUSTERED): BidId, BidImportId, AdditionalHandlingAmount, FreeHandlingAmount, FreeHandlingStart, FreeHandlingEnd, BidHeaderId, VendorId, Active




### dbo.BidsCatalogList



**Rows:** 80,892

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidCatalogId | int | No | Yes |  |  |
| BidId | int | Yes | No |  |  |
| CatalogId | int | Yes | No |  |  |
| DiscountRate | decimal(9,5) | Yes | No |  |  |
| BidImportCatalogId | int | Yes | No |  |  |



**Primary Key:** BidCatalogId





**Indexes:**
- PK__BidsCatalogList__5A254709 (CLUSTERED): BidCatalogId
- _dta_index_BidsCatalogList_7_171199710__K3_K1_K2 (NONCLUSTERED): CatalogId, BidCatalogId, BidId
- SK_Bid (NONCLUSTERED): BidCatalogId, BidId
- SKI_Catalog_BidCatalogId (NONCLUSTERED): CatalogId




### dbo.BidTradeCounties



**Rows:** 40,330

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidTradeCountyId | int | No | Yes |  |  |
| BidTradeId | int | No | No |  |  |
| CountyId | int | No | No |  |  |



**Primary Key:** BidTradeCountyId





**Indexes:**
- PK__BidTrade__0909D2D914426966 (CLUSTERED): BidTradeCountyId
- SK_CountyTrade (NONCLUSTERED): BidTradeCountyId, CountyId, BidTradeId
- SK_TradeCounty (NONCLUSTERED): BidTradeId, CountyId




### dbo.BidTrades



**Rows:** 1,522

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidTradeId | int | No | Yes |  |  |
| BidHeaderId | int | No | No |  |  |
| TradeId | int | No | No |  |  |
| Title | varchar(255) | No | No |  |  |
| Specifications | varchar(MAX) | No | No |  |  |



**Primary Key:** BidTradeId





**Indexes:**
- PK__BidTrade__3200D0811071D882 (CLUSTERED): BidTradeId
- SK_BidHeaderId (NONCLUSTERED): BidTradeId, TradeId, Title, BidHeaderId




### dbo.BidTypes



**Rows:** 2

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidTypeId | int | No | Yes |  |  |
| Description | varchar(50) | No | No |  |  |



**Primary Key:** BidTypeId





**Indexes:**
- PK__BidTypes__332B7579 (CLUSTERED): BidTypeId




### dbo.BookTypes



**Rows:** 4

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BookTypeId | int | No | Yes |  |  |
| BookType | varchar(50) | No | No |  |  |



**Primary Key:** BookTypeId





**Indexes:**
- PK_BookTypes (CLUSTERED): BookTypeId




### dbo.BudgetAccounts



**Rows:** 1,337,048

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BudgetAccountId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| BudgetId | int | Yes | No |  |  |
| AccountId | int | Yes | No |  |  |
| BudgetAmount | money | Yes | No |  |  |
| AmountAvailable | money | Yes | No |  |  |
| UseAllocations | tinyint | Yes | No |  |  |



**Primary Key:** BudgetAccountId



**Foreign Keys:**
- AccountId → dbo.Accounts.AccountId
- BudgetId → dbo.Budgets.BudgetId




**Indexes:**
- PK_BudgetAccounts (CLUSTERED): BudgetAccountId
- _dta_index_BudgetAccounts_7_11199140__K1_4 (NONCLUSTERED): AccountId, BudgetAccountId
- SK_ActiveAccount (NONCLUSTERED): Active, AccountId
- SK_BAUseAllocations (NONCLUSTERED): UseAllocations, BudgetAccountId
- SK_Budget (NONCLUSTERED): BudgetId, Active
- SK_UseAllocationsBA (NONCLUSTERED): UseAllocations, BudgetAccountId
- SKI_Account_BudgetaccountActive (NONCLUSTERED): BudgetAccountId, Active, AccountId




### dbo.Budgets



**Rows:** 15,553

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BudgetId | int | No | Yes |  |  |
| DistrictId | int | Yes | No |  |  |
| Active | tinyint | Yes | No |  |  |
| Name | varchar(30) | Yes | No |  |  |
| StartDate | datetime | Yes | No |  |  |
| EndDate | datetime | Yes | No |  |  |
| VisibleFrom | datetime | Yes | No |  |  |
| VisibleUntil | datetime | Yes | No |  |  |
| AnnualCutoff | datetime | Yes | No |  |  |
| EditFrom | datetime | Yes | No |  |  |
| EditUntil | datetime | Yes | No |  |  |
| EarlyAccess | datetime | Yes | No |  |  |



**Primary Key:** BudgetId



**Foreign Keys:**
- DistrictId → dbo.District.DistrictId




**Indexes:**
- PK_Budgets (CLUSTERED): BudgetId
- _dta_index_Budgets_7_2030682332__K3_K2_K1_4_5_6 (NONCLUSTERED): Name, StartDate, EndDate, Active, DistrictId, BudgetId
- SK_BudgetDistrict (NONCLUSTERED): Active, Name, StartDate, EndDate, VisibleFrom, VisibleUntil, AnnualCutoff, EditFrom, EditUntil, EarlyAccess, BudgetId, DistrictId
- SK_District (NONCLUSTERED): DistrictId
- SK_DistrictDate (NONCLUSTERED): DistrictId, EndDate, StartDate
- SKI_Active_BudgetDistrictNameFromUntil (NONCLUSTERED): BudgetId, DistrictId, Name, VisibleFrom, VisibleUntil, Active




### dbo.CalDistricts



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| CalDistrictId | int | No | Yes |  |  |
| CalendarId | int | Yes | No |  |  |
| DistrictId | int | Yes | No |  |  |



**Primary Key:** CalDistrictId





**Indexes:**
- PK__CalDistricts__6641052B (CLUSTERED): CalDistrictId




### dbo.CalendarDates



**Rows:** 2,152

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| CalendarDateId | int | No | Yes |  |  |
| CalendarId | int | No | No |  |  |
| Description | varchar(50) | Yes | No |  |  |
| Date1 | datetime | No | No |  |  |
| Date2 | datetime | Yes | No |  |  |
| Date3 | datetime | Yes | No |  |  |
| Date4 | datetime | Yes | No |  |  |



**Primary Key:** CalendarDateId





**Indexes:**
- PK__Calendar__D3AE10E05AE9F079 (CLUSTERED): CalendarDateId




### dbo.CalendarIB



**Rows:** 640

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| CalendarIBId | int | No | Yes |  |  |
| CalendarId | int | No | No |  |  |
| IBTypeId | int | No | No |  |  |
| ScheduleId | int | No | No |  |  |
| CalendarTypeId | int | No | No |  |  |



**Primary Key:** CalendarIBId





**Indexes:**
- PK__Calendar__AAF83A2A665BA325 (CLUSTERED): CalendarIBId




### dbo.CalendarItems



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| CalendarItemId | int | No | No |  |  |
| Active | tinyint | Yes | No |  |  |
| LinkId | int | Yes | No |  |  |
| LinkType | char(1) | Yes | No |  |  |
| Description | varchar(50) | Yes | No |  |  |
| ScheduledEventDate | datetime | Yes | No |  |  |
| ActualEventDate | datetime | Yes | No |  |  |



**Primary Key:** CalendarItemId





**Indexes:**
- PK_CalendarItems (CLUSTERED): CalendarItemId




### dbo.Calendars



**Rows:** 282

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| CalendarId | int | No | Yes |  |  |
| Active | tinyint | No | No |  |  |
| BudgetYear | int | No | No |  |  |
| ScheduleId | int | No | No |  |  |
| CalendarTypeId | int | No | No |  |  |
| Description | varchar(50) | No | No |  |  |
| HeaderText | varchar(8000) | Yes | No |  |  |
| FooterText | varchar(8000) | Yes | No |  |  |
| HeaderTextHTML | varchar(4096) | Yes | No |  |  |
| FooterTextHTML | varchar(4096) | Yes | No |  |  |



**Primary Key:** CalendarId





**Indexes:**
- PK__Calendar__53CFC44D628B1241 (CLUSTERED): CalendarId




### dbo.CalendarTypes



**Rows:** 2

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| CalendarTypeId | int | No | Yes |  |  |
| Description | varchar(50) | No | No |  |  |
| DateCount | int | No | No |  |  |
| TimeSpace1to2 | int | Yes | No |  |  |
| TimeSpace2to3 | int | Yes | No |  |  |
| TimeSpace3to4 | int | Yes | No |  |  |



**Primary Key:** CalendarTypeId





**Indexes:**
- PK__Calendar__024C0F7C5348CEB1 (CLUSTERED): CalendarTypeId




### dbo.Carolina Living Items



**Rows:** 2,017

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| inventorynumber | nvarchar(255) | No | No |  |  |
| Description | nvarchar(255) | Yes | No |  |  |



**Primary Key:** inventorynumber





**Indexes:**
- PK_Carolina Living Items (CLUSTERED): inventorynumber




### dbo.Catalog



**Rows:** 3,832

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| CatalogId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| Name | varchar(50) | Yes | No |  |  |
| DisplayedVendorName | varchar(50) | Yes | No |  |  |
| ImportFormat | tinyint | Yes | No |  |  |
| Prefix | varchar(10) | Yes | No |  |  |
| NextNumber | int | Yes | No |  |  |
| VendorFormat | int | Yes | No |  |  |
| Description | varchar(255) | Yes | No |  |  |
| CrossRefLetter | char(1) | Yes | No |  |  |
| DropSeq | varchar(16) | Yes | No |  |  |
| CatalogYear | char(2) | Yes | No |  |  |
| EffectiveFrom | datetime | Yes | No |  |  |
| EffectiveUntil | datetime | Yes | No |  |  |
| CreateDate | datetime | Yes | No |  |  |
| PostDate | datetime | Yes | No |  |  |
| WebDesc | varchar(50) | Yes | No |  |  |
| WebLink | varchar(255) | Yes | No |  |  |
| NotValidForOB | tinyint | Yes | No |  |  |
| AlertMsg | varchar(1024) | Yes | No |  |  |
| BeginDefault | datetime | Yes | No |  |  |
| PackExp | varchar(1024) | Yes | No |  |  |
| PackReplace | varchar(1024) | Yes | No |  |  |
| Index | int | Yes | No |  |  |
| Page1 | int | Yes | No |  |  |
| MaxPage | int | Yes | No |  |  |
| PDFAvailable | tinyint | Yes | No |  |  |
| pdfDirectory | varchar(1024) | Yes | No |  |  |
| BasePath | varchar(255) | Yes | No |  |  |
| BaseCatalogId | int | Yes | No |  |  |



**Primary Key:** CatalogId



**Foreign Keys:**
- CategoryId → dbo.Category.CategoryId
- VendorId → dbo.Vendors.VendorId




**Indexes:**
- PK_Catalog (CLUSTERED): CatalogId
- SK_ActiveVendorPost (NONCLUSTERED): Active, VendorId, PostDate
- SKI_CategoryActiveYear_IdVendorName (NONCLUSTERED): CatalogId, VendorId, Name, DisplayedVendorName, CategoryId, Active, CatalogYear
- SKI_VendorCategoryActiveYearCatalog_Name (NONCLUSTERED): Name, VendorId, CategoryId, Active, CatalogYear, CatalogId




### dbo.CatalogImportFields



**Rows:** 15

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| CatalogImportFieldId | int | No | Yes |  |  |
| CatalogImportId | int | No | No |  |  |
| SequenceId | int | Yes | No |  |  |
| Name | varchar(50) | No | No |  |  |
| Optional | tinyint | Yes | No |  |  |



**Primary Key:** CatalogImportFieldId





**Indexes:**
- PK__CatalogI__DDA8F6524AD38441 (CLUSTERED): CatalogImportFieldId




### dbo.CatalogImportMap



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| CatalogImportMapId | int | No | Yes |  |  |
| CatalogId | int | No | No |  |  |
| CatalogImportFieldId | int | No | No |  |  |
| ImportIndex | int | No | No |  |  |
| ImportRegExp | varchar(1024) | Yes | No |  |  |



**Primary Key:** CatalogImportMapId





**Indexes:**
- PK__CatalogI__3420EF794EA41525 (CLUSTERED): CatalogImportMapId




### dbo.CatalogPricing



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| CPId | int | No | Yes |  |  |
| CrossRefId | int | No | No |  |  |
| ACLId | int | No | No |  |  |
| AwardId | int | No | No |  |  |
| BidId | int | No | No |  |  |
| NetPrice | money | Yes | No |  |  |



**Primary Key:** CPId





**Indexes:**
- PK__CatalogP__F5B22BC60E9E9EA9 (CLUSTERED): CPId




### dbo.CatalogRequest



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| CatalogRequestId | int | No | Yes |  |  |
| VendorId | int | Yes | No |  |  |
| EmailAddress | varchar(255) | Yes | No |  |  |
| Fax | varchar(20) | Yes | No |  |  |
| AddDate | datetime | Yes | No |  |  |
| SendDate | datetime | Yes | No |  |  |
| EmailAddress2 | varchar(255) | Yes | No |  |  |
| EmailCCAddress | varchar(255) | Yes | No |  |  |
| MessageContent | varchar(MAX) | Yes | No |  |  |
| MessageReceiptConfirmed | datetime | Yes | No |  |  |
| CatalogRequestNotes | varchar(1000) | Yes | No |  |  |
| ContactName | varchar(255) | Yes | No |  |  |



**Primary Key:** CatalogRequestId





**Indexes:**
- PK_CatalogRequest (CLUSTERED): CatalogRequestId




### dbo.CatalogRequestDetail



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| CatalogRequestDetailId | int | No | Yes |  |  |
| CatalogRequestId | int | Yes | No |  |  |
| AddDate | datetime | Yes | No |  |  |
| SendDate | datetime | Yes | No |  |  |
| CatalogRequestType | int | Yes | No |  |  |
| CatalogRequestMsg | varchar(4000) | Yes | No |  |  |
| CatalogRequestNotes | varchar(1000) | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| ResolvedFlag | tinyint | Yes | No |  |  |



**Primary Key:** CatalogRequestDetailId



**Foreign Keys:**
- CatalogRequestId → dbo.CatalogRequest.CatalogRequestId




**Indexes:**
- PK_CatalogRequestDetail (CLUSTERED): CatalogRequestDetailId




### dbo.CatalogRequestStatus



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| CatalogRequestStatusId | int | No | Yes |  |  |
| CatalogRequestId | int | Yes | No |  |  |
| StatusId | int | Yes | No |  |  |
| StatusDate | datetime | Yes | No |  |  |
| FollowUpDate | datetime | Yes | No |  |  |



**Primary Key:** CatalogRequestStatusId



**Foreign Keys:**
- CatalogRequestId → dbo.CatalogRequest.CatalogRequestId




**Indexes:**
- PK_CatalogRequestStatus (CLUSTERED): CatalogRequestStatusId




### dbo.CatalogText



**Rows:** 112,799

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| CatalogTextId | int | No | Yes |  |  |
| CatalogId | int | No | No |  |  |
| PageNbr | int | No | No |  |  |
| BaseFileName | varchar(255) | No | No |  |  |
| TextData | nvarchar(MAX) | Yes | No |  |  |



**Primary Key:** CatalogTextId





**Indexes:**
- PK__CatalogT__D89517CF03D6F773 (CLUSTERED): CatalogTextId
- SKI_CatalogId_PageText (NONCLUSTERED): PageNbr, TextData, CatalogId




### dbo.CatalogTextParts



**Rows:** 17,179,537

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| CatalogTextPartId | int | No | Yes |  |  |
| CatalogTextId | int | No | No |  |  |
| BaseOffset | int | Yes | No |  |  |
| TextPart | varchar(4096) | Yes | No |  |  |



**Primary Key:** CatalogTextPartId





**Indexes:**
- PK__CatalogT__3489609851EE58DE (CLUSTERED): CatalogTextPartId
- SKI_CatalogTextId_OffsetPart (NONCLUSTERED): BaseOffset, TextPart, CatalogTextId




### dbo.Category



**Rows:** 133

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| CategoryId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| CategoryNumber | int | Yes | No |  |  |
| Name | varchar(50) | Yes | No |  |  |
| EDSId | int | Yes | No |  |  |
| Prefix | varchar(10) | Yes | No |  |  |
| NextNumber | int | Yes | No |  |  |
| AllowAddenda | int | Yes | No |  |  |
| HeadingTitle | varchar(32) | Yes | No |  |  |
| ExtraTitle | varchar(128) | Yes | No |  |  |
| KeywordExamples | varchar(50) | Yes | No |  |  |
| OnSavingsReport | int | Yes | No |  |  |
| Code | varchar(16) | Yes | No |  |  |
| Type | int | Yes | No |  |  |
| BreakOnHeadingChange | int | Yes | No |  |  |
| MasterBookCopies | int | Yes | No |  |  |
| Grouping | varchar(50) | Yes | No |  |  |
| AppendBidMessage | tinyint | Yes | No |  |  |
| DefaultHeadingID | int | Yes | No |  |  |
| AvgDiscountFactor | decimal(9,5) | Yes | No | ((0.6)) |  |
| useCatalogViewer | tinyint | Yes | No |  |  |
| RTKLocation | varchar(50) | Yes | No |  |  |
| Description | varchar(2048) | Yes | No |  |  |
| Priority | tinyint | Yes | No |  |  |



**Primary Key:** CategoryId





**Indexes:**
- PK_Category (CLUSTERED): CategoryId
- SK_Active (NONCLUSTERED): Active
- SK_CategoryType (NONCLUSTERED): Type, CategoryId
- SK_EDS (NONCLUSTERED): EDSId
- SK_Name (NONCLUSTERED): Name
- SKI_Category_NameExtraTitle (NONCLUSTERED): Name, ExtraTitle, CategoryId




### dbo.CatList



**Rows:** 155,059

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| CategoryName | varchar(50) | Yes | No |  |  |
| PriceplanCode | varchar(20) | Yes | No |  |  |
| DistrictName | varchar(50) | Yes | No |  |  |
| SchoolName | varchar(50) | Yes | No |  |  |
| SchoolAddress | varchar(30) | Yes | No |  |  |
| SchoolCity | varchar(25) | Yes | No |  |  |
| SchoolState | varchar(2) | Yes | No |  |  |
| SchoolZip | varchar(10) | Yes | No |  |  |
| Attention | varchar(50) | Yes | No |  |  |
| UserNumber | int | Yes | No |  |  |









### dbo.CertificateAuthority



**Rows:** 1

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| CertificateAuthorityId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| StateId | int | No | No |  |  |
| CertificateName | varchar(50) | No | No |  |  |
| CertificatesExpire | tinyint | Yes | No |  |  |
| ExpireInMonths | int | Yes | No |  |  |



**Primary Key:** CertificateAuthorityId





**Indexes:**
- PK__Certific__38B8FA6C28296682 (CLUSTERED): CertificateAuthorityId




### dbo.ChargeTypes



**Rows:** 14

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ChargeTypeId | int | No | Yes |  |  |
| Active | int | Yes | No |  |  |
| Description | varchar(50) | Yes | No |  |  |
| RTK | int | Yes | No |  |  |
| Frequency | int | Yes | No |  |  |
| Repeats | int | Yes | No |  |  |
| FrequencyData | varchar(50) | Yes | No |  |  |
| AccountingChargeCode | varchar(50) | Yes | No |  |  |
| LM | tinyint | Yes | No |  |  |



**Primary Key:** ChargeTypeId





**Indexes:**
- PK__ChargeTypes__31272A29 (CLUSTERED): ChargeTypeId




### dbo.CommonMSRPVendorQuery



**Rows:** 4

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| CommonMSRPVendorQueryId | int | No | Yes |  |  |
| CategoryIdSpecific | int | Yes | No |  |  |
| CommonQuestion | varchar(500) | Yes | No |  |  |
| GroupFilter | varchar(50) | Yes | No |  |  |
| AllowReply | tinyint | Yes | No |  |  |
| ManufacturerSelection | int | Yes | No |  |  |









### dbo.CommonTandMVendorQuery



**Rows:** 22

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| CommonTandMVendorQueryId | int | No | Yes |  |  |
| CategoryIdSpecific | int | Yes | No |  |  |
| CommonQuestion | varchar(500) | Yes | No |  |  |
| GroupFilter | varchar(50) | Yes | No |  |  |









### dbo.CommonVendorQuery



**Rows:** 43

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| CommonVendorQueryId | int | No | Yes |  |  |
| CategoryIdSpecific | int | Yes | No |  |  |
| CommonQuestion | varchar(1000) | Yes | No |  |  |









### dbo.CommonVendorQueryAnswer



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| CommonVendorQueryAnswerId | int | No | Yes |  |  |
| CommonVendorQueryId | int | Yes | No |  |  |
| SeqNumber | tinyint | Yes | No |  |  |
| AnswerText | varchar(100) | Yes | No |  |  |
| AnswerAction | int | Yes | No |  |  |



**Primary Key:** CommonVendorQueryAnswerId





**Indexes:**
- PK__CommonVe__5BDEDA942A8A3EB4 (CLUSTERED): CommonVendorQueryAnswerId




### dbo.ContractTypes



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ContractId | int | No | No |  |  |
| ContractType | varchar(20) | Yes | No |  |  |
| NumberRequired | tinyint | Yes | No |  |  |



**Primary Key:** ContractId





**Indexes:**
- PK_ContractTypes (CLUSTERED): ContractId




### dbo.Control



**Rows:** 1

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ControlId | int | No | Yes |  |  |
| LastPriceUpdateStart | datetime | Yes | No |  |  |
| LastPriceUpdateEnd | datetime | Yes | No |  |  |
| ControlYear | int | Yes | No |  |  |
| RTKBaseYear | int | Yes | No |  |  |
| BillingYear | int | Yes | No |  |  |



**Primary Key:** ControlId





**Indexes:**
- PK__Control__77B5A9F0 (CLUSTERED): ControlId




### dbo.Coops



**Rows:** 20

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| CoopId | int | No | No |  |  |
| Active | tinyint | Yes | No |  |  |
| Code | char(2) | Yes | No |  |  |
| Name | varchar(50) | Yes | No |  |  |



**Primary Key:** CoopId





**Indexes:**
- PK_Coops (CLUSTERED): CoopId




### dbo.CopyRequests



**Rows:** 23,246

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| CopyRequestId | int | No | Yes |  |  |
| RSId | int | No | No |  |  |
| SessionId | int | No | No |  |  |
| StartTime | datetime | Yes | No |  |  |
| EndTime | datetime | Yes | No |  |  |
| Requested | datetime | Yes | No |  |  |



**Primary Key:** CopyRequestId





**Indexes:**
- PK__CopyRequests__4CB63D52 (CLUSTERED): CopyRequestId




### dbo.Counties



**Rows:** 77

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| CountyId | int | No | Yes |  |  |
| State | char(2) | No | No |  |  |
| Name | varchar(50) | No | No |  |  |
| StateId | int | Yes | No |  |  |



**Primary Key:** CountyId





**Indexes:**
- PK__Counties__71CC8A7A (CLUSTERED): CountyId
- SK_StateIDName (NONCLUSTERED): Name, StateId
- SK_StateName (NONCLUSTERED): State, Name




### dbo.CoverView



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| DistrictId | int | No | No |  |  |
| DistrictCode | varchar(2) | Yes | No |  |  |
| DistrictName | varchar(50) | Yes | No |  |  |
| DistrictAddress1 | varchar(30) | Yes | No |  |  |
| DistrictAddress2 | varchar(30) | Yes | No |  |  |
| DistrictAddress3 | varchar(30) | Yes | No |  |  |
| DistrictCity | varchar(25) | Yes | No |  |  |
| DistrictState | varchar(2) | Yes | No |  |  |
| DistrictZipcode | varchar(10) | Yes | No |  |  |
| SchoolId | int | Yes | No |  |  |
| SchoolName | varchar(50) | Yes | No |  |  |
| SchoolAddress1 | varchar(30) | Yes | No |  |  |
| SchoolAddress2 | varchar(30) | Yes | No |  |  |
| SchoolAddress3 | varchar(30) | Yes | No |  |  |
| SchoolCity | varchar(25) | Yes | No |  |  |
| SchoolState | varchar(2) | Yes | No |  |  |
| SchoolZipcode | varchar(10) | Yes | No |  |  |
| UserId | int | Yes | No |  |  |
| UserName | varchar(50) | Yes | No |  |  |
| CometId | int | Yes | No |  |  |
| AccountCode | varchar(50) | Yes | No |  |  |
| AccountCount | int | Yes | No |  |  |
| BudgetStartDate | datetime | Yes | No |  |  |
| BudgetEndDate | datetime | Yes | No |  |  |
| ItemCount | int | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| OrderBookId | int | Yes | No |  |  |
| CategoryDescription | varchar(255) | Yes | No |  |  |
| PricePlanDescription | varchar(255) | Yes | No |  |  |
| UsesBooklet | int | Yes | No |  |  |
| UsesOnline | int | Yes | No |  |  |
| RepMsg | varchar(512) | Yes | No |  |  |
| IBTypeId | int | Yes | No |  |  |
| BookType | varchar(50) | Yes | No |  |  |
| ScheduleGroup | varchar(50) | Yes | No |  |  |
| StateName | varchar(50) | Yes | No |  |  |
| CoverViewId | uniqueidentifier | No | No | (newsequentialid()) |  |



**Primary Key:** CoverViewId





**Indexes:**
- PK_CoverView (CLUSTERED): CoverViewId




### dbo.CrossRefs



**Rows:** 141,341,255

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| CrossRefId | int | No | Yes |  |  |
| CrossRefId_Old | int | Yes | No |  |  |
| Active | tinyint | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |
| VendorItemCode | varchar(50) | Yes | No |  |  |
| CatalogId | int | Yes | No |  |  |
| CatalogPrice | money | Yes | No |  |  |
| Page | char(4) | Yes | No |  |  |
| CatalogYear | char(2) | Yes | No |  |  |
| CrossRefLocation | char(1) | Yes | No |  |  |
| PackedCode | varchar(50) | Yes | No | ('([dbo].[uf_PackCode]([VendorItemCode]))') |  |
| Manufacturor | varchar(50) | Yes | No |  |  |
| ManufacturorPartNumber | varchar(50) | Yes | No |  |  |
| DateDeactivated | datetime | Yes | No |  |  |
| DateUpdated | datetime | Yes | No | (getdate()) |  |
| GrossPrice | money | Yes | No |  |  |
| DoNotDiscount | int | Yes | No |  |  |
| RTK_MSDSId | int | Yes | No |  |  |
| RTK_MSDSNotNeeded | tinyint | Yes | No |  |  |
| ReplacementCrossRefId | int | Yes | No |  |  |
| AdditionalShipping | tinyint | Yes | No |  |  |
| FullDescription | varchar(4096) | Yes | No |  |  |
| UOM | varchar(20) | Yes | No |  |  |
| MatchKey | varchar(150) | Yes | No |  |  |
| ManufacturerId | int | Yes | No |  |  |
| ProductLine | varchar(50) | Yes | No |  |  |
| ManufacturerProductLineId | int | Yes | No |  |  |
| ItemsPerUnit | varchar(30) | Yes | No |  |  |
| MSDSFlag | tinyint | Yes | No |  |  |
| MSDSRef | varchar(255) | Yes | No |  |  |
| Heading | varchar(50) | Yes | No |  |  |
| UniqueItemNumber | varchar(50) | Yes | No |  |  |
| ShortDescription | varchar(512) | Yes | No |  |  |
| keyword | varchar(1024) | Yes | No |  |  |
| ImageURL | varchar(1024) | Yes | No |  |  |
| UPC_ISBN | varchar(20) | Yes | No |  |  |
| UNSPSC | varchar(20) | Yes | No |  |  |
| ImageId | bigint | Yes | No |  |  |
| PerishableItem | bit | Yes | No | ((0)) |  |
| PrescriptionRequired | bit | Yes | No | ((0)) |  |
| DigitallyDelivered | tinyint | Yes | No |  |  |
| MinimumOrderQuantity | int | Yes | No |  |  |
| HashKey | varbinary(64) | Yes | No |  |  |
| ProductNames | nvarchar(4000) | Yes | No |  |  |
| TypeAheads | nvarchar(4000) | Yes | No |  |  |
| AIShortDesc | nvarchar(1024) | Yes | No |  |  |
| AIFullDesc | nvarchar(4000) | Yes | No |  |  |
| AIUNSPSC | varchar(20) | Yes | No |  |  |
| AIDate | datetime | Yes | No |  |  |



**Primary Key:** CrossRefId





**Indexes:**
- PK_CrossRefs2 (CLUSTERED): CrossRefId
- _dta_index_CrossRefs_12_389628481__K3_K1_K12 (NONCLUSTERED): ItemId, CrossRefId, ManufacturorPartNumber
- _dta_index_CrossRefs_7_389628481__K1_K2_K3_K5_K6_21 (NONCLUSTERED): AdditionalShipping, CrossRefId, Active, ItemId, CatalogId, CatalogPrice
- _dta_index_CrossRefs_7_389628481__K2_K3_K5_K1_K6 (NONCLUSTERED): Active, ItemId, CatalogId, CrossRefId, CatalogPrice
- _dta_index_CrossRefs_9_457768688__K1_K6_K7 (NONCLUSTERED): CrossRefId, CatalogPrice, Page
- _dta_index_CrossRefs_9_457768688__K2_K3_K1_K5_K6_K7_K4_K15_K16 (NONCLUSTERED): Active, ItemId, CrossRefId, CatalogId, CatalogPrice, Page, VendorItemCode, GrossPrice, DoNotDiscount
- CrossRefs_MinimumOrderQuantity_index (NONCLUSTERED): MinimumOrderQuantity
- IX_CrossRefs_MSDSRef_ItemId (NONCLUSTERED): MSDSRef, ItemId, Active
- SK_ActiveCatalogSDSRef (NONCLUSTERED): Active, CatalogId, MSDSRef
- SK_AIDate (NONCLUSTERED): AIDate
- SK_CatalogActiveLastUpdated (NONCLUSTERED): Active, CatalogId, DateUpdated
- SK_CatItem (NONCLUSTERED): CatalogId, ItemId, Active
- SK_Item (NONCLUSTERED): CrossRefId, ItemId
- SKI_ActiveSDSRef_Catalog (NONCLUSTERED): CatalogId, ItemId, VendorItemCode, Manufacturor, ManufacturorPartNumber, ImageURL, Active, MSDSRef
- SKI_AIDate_KashKey (NONCLUSTERED): HashKey, AIDate
- ski_CatActiveManufacturerPartNumber_VICUPCSDManUnique (NONCLUSTERED): VendorItemCode, UPC_ISBN, ShortDescription, Manufacturor, UniqueItemNumber, CatalogId, Active, ManufacturorPartNumber
- SKI_CrossRef_ (NONCLUSTERED): Active, ItemId, VendorItemCode, CatalogId, Page, PackedCode, CrossRefId
- SKI_HashKey_CrossRefId (NONCLUSTERED): CrossRefId, Manufacturor, ManufacturorPartNumber, FullDescription, ShortDescription, HashKey, CatalogId, Active
- SKI_ImageURLCatalogActive_VendorItemCodeUnique (NONCLUSTERED): CrossRefId, VendorItemCode, UniqueItemNumber, ImageURL, CatalogId, Active
- SKI_ItemActive_Etc (NONCLUSTERED): CrossRefId, VendorItemCode, Page, PackedCode, CatalogYear, GrossPrice, CatalogPrice, DoNotDiscount, ItemId, Active, CatalogId
- SKI_PackedCatalogActive_Item (NONCLUSTERED): CrossRefId, ItemId, PackedCode, CatalogId, Active
- SKI_PackedItem_Page (NONCLUSTERED): Page, CatalogYear, Manufacturor, ManufacturorPartNumber, GrossPrice, DoNotDiscount, PackedCode, Active, ItemId, CatalogId
- SKI_UniqueCatalog_ImageURLId (NONCLUSTERED): ImageURL, CrossRefId, Active, UniqueItemNumber, CatalogId
- ski_VICCatalogActive_DateUpdatedCrossRefIdImageURL (NONCLUSTERED): DateUpdated, CrossRefId, ImageURL, VendorItemCode, CatalogId, Active




### dbo.CSCommands



**Rows:** 16

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| CSCommandId | int | No | Yes |  |  |
| ShortDesc | varchar(50) | No | No |  |  |
| FullDescription | varchar(1024) | Yes | No |  |  |
| Command | varchar(255) | No | No |  |  |
| Target | varchar(255) | Yes | No |  |  |
| SecurityRoleId | int | Yes | No |  |  |



**Primary Key:** CSCommandId





**Indexes:**
- PK__CSComman__4EE1C29071B84738 (CLUSTERED): CSCommandId




### dbo.CSMessageFiles



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| CSMessageFileID | int | No | Yes |  |  |
| CSMessageID | int | No | No |  |  |
| CSFileName | varchar(255) | No | No |  |  |
| CSFile | varbinary(MAX) | No | No |  |  |



**Primary Key:** CSMessageFileID





**Indexes:**
- PK__CSMessag__D10EA1397F6BDA51 (CLUSTERED): CSMessageFileID




### dbo.CSMessages



**Rows:** 11,382

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| CSMessageID | int | No | Yes |  |  |
| UserID | int | No | No |  |  |
| CSMessage | varchar(MAX) | Yes | No |  |  |



**Primary Key:** CSMessageID





**Indexes:**
- PK__CSMessag__B3A813227B9B496D (CLUSTERED): CSMessageID




### dbo.CSRep



**Rows:** 45

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| CSRepId | int | No | Yes |  |  |
| Name | varchar(30) | Yes | No |  |  |
| ID | char(2) | Yes | No |  |  |
| UserId | int | Yes | No |  |  |
| Phone | varchar(20) | Yes | No |  |  |
| EMail | varchar(128) | Yes | No |  |  |



**Primary Key:** CSRepId





**Indexes:**
- PK_CSRep (CLUSTERED): CSRepId
- SK_User (NONCLUSTERED): UserId




### dbo.CXmlSession



**Rows:** 63,228

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| SessionId | int | No | No |  |  |
| payloadId | varchar(255) | Yes | No |  |  |
| buyerCookie | varchar(255) | Yes | No |  |  |
| BrowserFormPost | varchar(255) | Yes | No |  |  |
| fromDomain | varchar(255) | Yes | No |  |  |
| fromIdentity | varchar(255) | Yes | No |  |  |
| toDomain | varchar(255) | Yes | No |  |  |
| toIdentity | varchar(255) | Yes | No |  |  |
| senderDomain | varchar(255) | Yes | No |  |  |
| senderIdentity | varchar(255) | Yes | No |  |  |
| fromUserAgent | varchar(255) | Yes | No |  |  |
| OrigReqId | int | Yes | No |  |  |
| RequisitionId | int | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| Mode | int | Yes | No |  |  |
| BudgetAccountId | int | Yes | No |  |  |
| UserAccountId | int | Yes | No |  |  |
| AccountCode | varchar(50) | Yes | No |  |  |
| BudgetId | int | Yes | No |  |  |
| UniqueId | uniqueidentifier | Yes | No | (newid()) |  |



**Primary Key:** SessionId





**Indexes:**
- PK__CXmlSession__4AB2BD59 (CLUSTERED): SessionId




### dbo.dchtest



**Rows:** 1,192

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| POId | int | No | No |  |  |
| PONumber | varchar(24) | Yes | No |  |  |
| ItemCount | int | Yes | No |  |  |
| Amount | money | Yes | No |  |  |
| BudgetName | varchar(30) | Yes | No |  |  |
| RequisitionNumber | varchar(24) | Yes | No |  |  |
| AccountCode | varchar(50) | Yes | No |  |  |
| Attention | varchar(50) | Yes | No |  |  |
| CometId | int | Yes | No |  |  |
| DistrictCode | varchar(4) | Yes | No |  |  |
| DistrictName | varchar(50) | Yes | No |  |  |
| DistrictNameAddress | varchar(237) | Yes | No |  |  |
| SchoolName | varchar(50) | Yes | No |  |  |
| SchoolNameAddress | varchar(189) | Yes | No |  |  |
| VendorCode | varchar(16) | Yes | No |  |  |
| VendorPhone | varchar(25) | Yes | No |  |  |
| DistrictVendorCode | varchar(20) | Yes | No |  |  |
| VendorName | varchar(50) | Yes | No |  |  |
| VendorNameAddress | varchar(249) | Yes | No |  |  |
| PODate | datetime | Yes | No |  |  |
| DatePrinted | datetime | Yes | No |  |  |
| DatePrintedDetail | datetime | Yes | No |  |  |
| DateExported | datetime | Yes | No |  |  |
| DistrictId | int | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| BudgetId | int | Yes | No |  |  |
| AccountId | int | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| UserId | int | Yes | No |  |  |
| SchoolId | int | No | No |  |  |
| VendorBidNumber | varchar(50) | Yes | No |  |  |
| VendorBidComments | varchar(540) | Yes | No |  |  |
| CategoryCode | char(1) | Yes | No |  |  |
| CategoryName | varchar(50) | Yes | No |  |  |
| DiscountRate | decimal(9,5) | Yes | No |  |  |
| DiscountAmount | money | Yes | No |  |  |
| TotalGross | money | Yes | No |  |  |
| LocationCode | varchar(32) | No | No |  |  |
| ShippingAmount | money | Yes | No |  |  |
| ShippingPercentage | decimal(9,5) | Yes | No |  |  |
| ShippingNameAddress | varchar(189) | Yes | No |  |  |
| DistrictAddress1 | varchar(30) | Yes | No |  |  |
| DistrictAddress2 | varchar(30) | Yes | No |  |  |
| DistrictAddress3 | varchar(30) | Yes | No |  |  |
| DistrictCity | varchar(25) | Yes | No |  |  |
| DistrictState | varchar(2) | Yes | No |  |  |
| DistrictZipcode | varchar(10) | Yes | No |  |  |
| SchoolAddress1 | varchar(30) | Yes | No |  |  |
| SchoolAddress2 | varchar(30) | Yes | No |  |  |
| SchoolAddress3 | varchar(30) | Yes | No |  |  |
| SchoolCity | varchar(25) | Yes | No |  |  |
| SchoolState | varchar(2) | Yes | No |  |  |
| SchoolZipcode | varchar(10) | Yes | No |  |  |
| VendorsAddress1 | varchar(50) | Yes | No |  |  |
| VendorsAddress2 | varchar(50) | Yes | No |  |  |
| VendorsAddress3 | varchar(50) | Yes | No |  |  |
| VendorsCity | varchar(50) | Yes | No |  |  |
| VendorsState | varchar(2) | Yes | No |  |  |
| VendorsZipcode | varchar(10) | Yes | No |  |  |
| ShipLocationsAddress1 | varchar(30) | Yes | No |  |  |
| ShipLocationsAddress2 | varchar(30) | Yes | No |  |  |
| ShipLocationsAddress3 | varchar(30) | Yes | No |  |  |
| ShipLocationsCity | varchar(25) | Yes | No |  |  |
| ShipLocationsState | varchar(2) | Yes | No |  |  |
| ShipLocationsZipcode | varchar(10) | Yes | No |  |  |
| ShipLocationsName | varchar(50) | Yes | No |  |  |
| DistrictMessage | varchar(4096) | Yes | No |  |  |
| BidDate | datetime | Yes | No |  |  |
| UsersDistrictAcctgCode | varchar(20) | Yes | No |  |  |
| AwardsBidHeaderId | int | Yes | No |  |  |
| ExportedToVendor | datetime | Yes | No |  |  |









### dbo.DebugMsgs



**Rows:** 19,698,831

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| SysId | bigint | No | Yes |  |  |
| LogDate | datetime | Yes | No | (getdate()) |  |
| Msg | varchar(1024) | Yes | No |  |  |



**Primary Key:** SysId





**Indexes:**
- PK_DebugMsgs1 (CLUSTERED): SysId
- Idx_LogDate (NONCLUSTERED): LogDate




### dbo.DebugMsgs_Orig



**Rows:** 5,211,696

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| sysid | int | No | Yes |  |  |
| LogDate | datetime | Yes | No | (getdate()) |  |
| Msg | varchar(1024) | Yes | No |  |  |



**Primary Key:** sysid





**Indexes:**
- PK_DebugMsgs (CLUSTERED): sysid




### dbo.Detail



**Rows:** 30,433,415

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| DetailId | int | No | Yes |  |  |
| RequisitionId | int | Yes | No |  |  |
| CatalogId | int | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |
| AddendumItem | tinyint | Yes | No |  |  |
| ItemCode | varchar(50) | Yes | No |  |  |
| Quantity | int | Yes | No |  |  |
| LastYearsQuantity | int | Yes | No |  |  |
| Description | varchar(1024) | Yes | No |  |  |
| UnitId | int | Yes | No |  |  |
| UnitCode | varchar(20) | Yes | No |  |  |
| BidPrice | money | Yes | No |  |  |
| CatalogPrice | money | Yes | No |  |  |
| GrossPrice | money | Yes | No |  |  |
| DiscountRate | decimal(9,5) | Yes | No |  |  |
| CatalogPage | char(4) | Yes | No |  |  |
| PricePlanId | int | Yes | No |  |  |
| PriceId | int | Yes | No |  |  |
| AwardId | int | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| VendorItemCode | varchar(50) | Yes | No |  |  |
| Alternate | varchar(1024) | Yes | No |  |  |
| POId | int | Yes | No |  |  |
| BatchDetailId | int | Yes | No |  |  |
| Modified | datetime | Yes | No |  |  |
| ModifiedById | int | Yes | No |  |  |
| SourceId | int | Yes | No |  |  |
| SortSeq | varchar(64) | Yes | No |  |  |
| BidItemId | int | Yes | No |  |  |
| ExtraDescription | varchar(1024) | Yes | No |  |  |
| ReProc | tinyint | Yes | No |  |  |
| UseGrossPrices | tinyint | Yes | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| DistrictRequisitionNumber | varchar(50) | Yes | No |  |  |
| HeadingTitle | varchar(255) | Yes | No |  |  |
| Keyword | varchar(50) | Yes | No |  |  |
| SectionId | int | Yes | No |  |  |
| SectionName | varchar(255) | Yes | No |  |  |
| OriginalItemId | int | Yes | No |  |  |
| HeadingId | int | Yes | No |  |  |
| KeywordId | int | Yes | No |  |  |
| ItemMustBeBid | int | Yes | No |  |  |
| SessionId | int | Yes | No |  |  |
| Active | tinyint | Yes | No |  |  |
| RTK_MSDSId | int | Yes | No |  |  |
| AddedFromAddenda | datetime | Yes | No |  |  |
| LastAlteredSessionId | int | Yes | No |  |  |
| AdditionalShipping | tinyint | Yes | No |  |  |
| CrossRefId | int | Yes | No |  |  |
| ShippingCost | decimal(9,2) | Yes | No |  |  |
| ShippingQuantity | int | Yes | No |  |  |
| ShippingUpdated | datetime | Yes | No |  |  |
| PerishableItem | bit | Yes | No | ((0)) |  |
| DeliveryDate | date | Yes | No |  |  |
| PrescriptionRequired | bit | Yes | No | ((0)) |  |
| DoctorsName | varchar(100) | Yes | No | ('') |  |
| DEANumber | varchar(9) | Yes | No | ('') |  |
| Email | varchar(255) | Yes | No |  |  |
| DigitallyDelivered | tinyint | Yes | No |  |  |
| DigitallyDeliveredEmail | varchar(255) | Yes | No |  |  |
| MinimumOrderQuantity | int | Yes | No |  |  |



**Primary Key:** DetailId





**Indexes:**
- PK_Detail (CLUSTERED): DetailId
- _dta_index_Detail_7_581629165__K1_K2_7 (NONCLUSTERED): Quantity, DetailId, RequisitionId
- _dta_index_Detail_7_581629165__K1_K2_K4_29_30 (NONCLUSTERED): BidItemId, ExtraDescription, DetailId, RequisitionId, ItemId
- _dta_index_Detail_9_16055143__K2_K4_K7 (NONCLUSTERED): RequisitionId, ItemId, Quantity
- Detail_ItemId_index (NONCLUSTERED): ItemId
- IX_Detail_RequisitionId_ItemId (NONCLUSTERED): RequisitionId, ItemId, CrossRefId
- SK_BHOnly (NONCLUSTERED): BidHeaderId
- SK_DetailReq (NONCLUSTERED): DetailId, RequisitionId
- SK_ItemReq (NONCLUSTERED): ItemId, RequisitionId
- SK_ReqItem (NONCLUSTERED): ExtraDescription, OriginalItemId, RequisitionId, ItemId, DetailId
- SK_ReqSortSeq (NONCLUSTERED): RequisitionId, SortSeq
- SK_Requisition (NONCLUSTERED): RequisitionId
- SKI_BidItem_QuantityDetailReq (NONCLUSTERED): Quantity, DetailId, RequisitionId, BidItemId
- SKI_CrossRef_BidItemId (NONCLUSTERED): BidItemId, CrossRefId
- SKI_Detail_RequisitionItem (NONCLUSTERED): RequisitionId, ItemId, BidItemId, ExtraDescription, SortSeq, DetailId
- SKI_MustBeBid_DetailReqItemPrice (NONCLUSTERED): DetailId, RequisitionId, ItemId, BidPrice, AwardId, VendorId, BidItemId, BidHeaderId, ItemMustBeBid
- SKI_Requisition_QuantityBidPriceVendorBidHeader (NONCLUSTERED): Quantity, BidPrice, VendorId, BidHeaderId, DetailId, ItemId, BidItemId, ItemMustBeBid, AddedFromAddenda, RequisitionId
- ti_CrossRef_Detail (NONCLUSTERED): DetailId, CrossRefId




### dbo.DetailChangeLog



**Rows:** 2,924,927

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| DetailChangeId | int | No | Yes |  |  |
| DetailId | int | No | No |  |  |
| RequisitionId | int | No | No |  |  |
| ItemId | int | No | No |  |  |
| OrigQty | int | Yes | No |  |  |
| NewQty | int | Yes | No |  |  |
| OrigBidPrice | money | Yes | No |  |  |
| NewBidPrice | money | Yes | No |  |  |
| OrigBidItemId | int | Yes | No |  |  |
| NewBidItemId | int | Yes | No |  |  |
| UserId | int | Yes | No |  |  |
| SessionId | int | Yes | No |  |  |
| ChangeDate | datetime | Yes | No |  |  |
| OrigVendorId | int | Yes | No |  |  |
| NewVendorId | int | Yes | No |  |  |
| BRChangeLogId | int | Yes | No |  |  |



**Primary Key:** DetailChangeId





**Indexes:**
- PK__DetailChangeLog__265B8A40 (CLUSTERED): DetailChangeId
- SK_Detail (NONCLUSTERED): DetailId
- SK_DetailOldNewQty (NONCLUSTERED): DetailId, OrigQty, NewQty
- SK_Item (NONCLUSTERED): ItemId
- SK_Requisition (NONCLUSTERED): RequisitionId
- SK_User (NONCLUSTERED): UserId




### dbo.DetailChanges



**Rows:** 26,502,061

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| DetailChangeId | int | No | Yes |  |  |
| DetailId | int | Yes | No |  |  |
| ChangeDate | datetime | Yes | No |  |  |
| OrigQty | int | Yes | No |  |  |
| NewQty | int | Yes | No |  |  |
| RequisitionId | int | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |
| BidPrice | money | Yes | No |  |  |
| BidItemId | int | Yes | No |  |  |



**Primary Key:** DetailChangeId





**Indexes:**
- PK__DetailChanges__2F8FEEBF (CLUSTERED): DetailChangeId
- SK_Detail (NONCLUSTERED): DetailId
- SK_DetailOldNewQtyDate (NONCLUSTERED): DetailId, OrigQty, NewQty, ChangeDate
- SK_Requisition (NONCLUSTERED): RequisitionId




### dbo.DetailHold



**Rows:** 1

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| DetailId | int | No | Yes |  |  |
| RequisitionId | int | Yes | No |  |  |
| CatalogId | int | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |
| AddendumItem | tinyint | Yes | No |  |  |
| ItemCode | varchar(50) | Yes | No |  |  |
| Quantity | int | Yes | No |  |  |
| LastYearsQuantity | int | Yes | No |  |  |
| Description | varchar(1024) | Yes | No |  |  |
| UnitId | int | Yes | No |  |  |
| UnitCode | varchar(20) | Yes | No |  |  |
| BidPrice | money | Yes | No |  |  |
| CatalogPrice | money | Yes | No |  |  |
| GrossPrice | money | Yes | No |  |  |
| DiscountRate | decimal(9,5) | Yes | No |  |  |
| CatalogPage | char(4) | Yes | No |  |  |
| PricePlanId | int | Yes | No |  |  |
| PriceId | int | Yes | No |  |  |
| AwardId | int | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| VendorItemCode | varchar(50) | Yes | No |  |  |
| Alternate | varchar(1024) | Yes | No |  |  |
| POId | int | Yes | No |  |  |
| BatchDetailId | int | Yes | No |  |  |
| Modified | datetime | Yes | No |  |  |
| ModifiedById | int | Yes | No |  |  |
| SourceId | int | Yes | No |  |  |
| SortSeq | varchar(64) | Yes | No |  |  |
| BidItemId | int | Yes | No |  |  |
| ExtraDescription | varchar(1024) | Yes | No |  |  |
| ReProc | tinyint | Yes | No |  |  |
| UseGrossPrices | tinyint | Yes | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| DistrictRequisitionNumber | varchar(50) | Yes | No |  |  |
| HeadingTitle | varchar(255) | Yes | No |  |  |
| Keyword | varchar(50) | Yes | No |  |  |
| SectionId | int | Yes | No |  |  |
| SectionName | varchar(255) | Yes | No |  |  |
| OriginalItemId | int | Yes | No |  |  |
| HeadingId | int | Yes | No |  |  |
| KeywordId | int | Yes | No |  |  |
| ItemMustBeBid | int | Yes | No |  |  |
| SessionId | int | Yes | No |  |  |
| Active | tinyint | Yes | No |  |  |
| RTK_MSDSId | int | Yes | No |  |  |









### dbo.DetailMatch



**Rows:** 103,534

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BudgetId | int | Yes | No |  |  |
| TotalRequisitionCost | money | Yes | No |  |  |
| DetailId | int | No | No |  |  |
| RequisitionId | int | Yes | No |  |  |
| CatalogId | int | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |
| AddendumItem | tinyint | Yes | No |  |  |
| ItemCode | varchar(50) | Yes | No |  |  |
| Quantity | int | Yes | No |  |  |
| LastYearsQuantity | int | Yes | No |  |  |
| Description | varchar(1024) | Yes | No |  |  |
| UnitId | int | Yes | No |  |  |
| UnitCode | varchar(20) | Yes | No |  |  |
| BidPrice | money | Yes | No |  |  |
| CatalogPrice | money | Yes | No |  |  |
| GrossPrice | money | Yes | No |  |  |
| DiscountRate | decimal(9,5) | Yes | No |  |  |
| CatalogPage | char(4) | Yes | No |  |  |
| PricePlanId | int | Yes | No |  |  |
| PriceId | int | Yes | No |  |  |
| AwardId | int | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| VendorItemCode | varchar(50) | Yes | No |  |  |
| Alternate | varchar(1024) | Yes | No |  |  |
| POId | int | Yes | No |  |  |
| BatchDetailId | int | Yes | No |  |  |
| Modified | datetime | Yes | No |  |  |
| ModifiedById | int | Yes | No |  |  |
| SourceId | int | Yes | No |  |  |
| SortSeq | varchar(64) | Yes | No |  |  |
| BidItemId | int | Yes | No |  |  |
| ExtraDescription | varchar(1024) | Yes | No |  |  |
| ReProc | tinyint | Yes | No |  |  |
| UseGrossPrices | tinyint | Yes | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| DistrictRequisitionNumber | varchar(50) | Yes | No |  |  |
| HeadingTitle | varchar(255) | Yes | No |  |  |
| Keyword | varchar(50) | Yes | No |  |  |
| SectionId | int | Yes | No |  |  |
| SectionName | varchar(255) | Yes | No |  |  |
| OriginalItemId | int | Yes | No |  |  |
| HeadingId | int | Yes | No |  |  |
| KeywordId | int | Yes | No |  |  |
| ItemMustBeBid | int | Yes | No |  |  |
| SessionId | int | Yes | No |  |  |
| Active | tinyint | Yes | No |  |  |
| RTK_MSDSId | int | Yes | No |  |  |
| AddedFromAddenda | datetime | Yes | No |  |  |
| LastAlteredSessionId | int | Yes | No |  |  |









### dbo.DetailNotifications



**Rows:** 2,549,321

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| DetailNotificationId | bigint | No | Yes |  |  |
| DetailId | bigint | No | No |  |  |
| NotificationId | bigint | Yes | No |  |  |
| DateCreated | datetime | No | No | (getdate()) |  |
| OrigItemId | bigint | Yes | No |  |  |
| NewItemId | bigint | Yes | No |  |  |
| OrigVendorId | bigint | Yes | No |  |  |
| NewVendorId | bigint | Yes | No |  |  |
| OrigBidPrice | decimal(11,5) | Yes | No |  |  |
| NewBidPrice | decimal(11,5) | Yes | No |  |  |



**Primary Key:** DetailNotificationId





**Indexes:**
- PK__DetailNo__B32A2B6002470E89 (CLUSTERED): DetailNotificationId
- SKI_DetailDate_Etal (NONCLUSTERED): DetailNotificationId, NotificationId, OrigItemId, NewItemId, OrigVendorId, NewVendorId, OrigBidPrice, NewBidPrice, DetailId, DateCreated
- SKI_DetailDateNewVendorOrigVendor_Id (NONCLUSTERED): DetailNotificationId, OrigItemId, NewItemId, OrigBidPrice, NewBidPrice, DetailId, DateCreated, OrigVendorId, NewVendorId
- SKI_Notification_DetailId (NONCLUSTERED): DetailId, DetailNotificationId, DateCreated, OrigItemId, NewItemId, OrigVendorId, NewVendorId, OrigBidPrice, NewBidPrice, NotificationId




### dbo.DetailUploads



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| DetailUploadId | bigint | No | Yes |  |  |
| DetailId | bigint | Yes | No |  |  |
| Description | varchar(50) | Yes | No |  |  |
| ClientFileName | varchar(300) | Yes | No |  |  |
| ClientDateTime | datetime2 | Yes | No |  |  |
| ClientSize | bigint | Yes | No |  |  |
| DateUploaded | datetime2 | No | No | (getdate()) |  |
| DocId | uniqueidentifier | Yes | No | (newid()) |  |
| DocType | varchar(50) | Yes | No |  |  |
| DocData | varbinary(MAX) | Yes | No |  |  |



**Primary Key:** DetailUploadId





**Indexes:**
- PK__DetailUp__CA367AE1FDEFCFEB (CLUSTERED): DetailUploadId




### dbo.District



**Rows:** 958

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| DistrictId | int | No | Yes |  |  |
| DistrictCode | varchar(4) | Yes | No |  |  |
| Active | tinyint | Yes | No |  |  |
| Name | varchar(50) | Yes | No |  |  |
| Address1 | varchar(30) | Yes | No |  |  |
| Address2 | varchar(30) | Yes | No |  |  |
| Address3 | varchar(30) | Yes | No |  |  |
| City | varchar(25) | Yes | No |  |  |
| State | varchar(2) | Yes | No |  |  |
| Zipcode | varchar(10) | Yes | No |  |  |
| RequiredApprovalLevel | tinyint | Yes | No |  |  |
| POsBySchool | tinyint | Yes | No |  |  |
| ReqsBySchool | tinyint | Yes | No |  |  |
| SuppressPONumber | tinyint | Yes | No |  |  |
| CSRepId | int | Yes | No |  |  |
| POConsolidation | char(1) | Yes | No |  |  |
| CoopId | int | Yes | No |  |  |
| BillingAddressId | int | Yes | No |  |  |
| ShippingAddressId | int | Yes | No |  |  |
| NextCometId | int | Yes | No |  |  |
| PhoneNumber | varchar(20) | Yes | No |  |  |
| Fax | varchar(20) | Yes | No |  |  |
| EMail | varchar(255) | Yes | No |  |  |
| BAName | varchar(50) | Yes | No |  |  |
| UseGrossPrices | tinyint | Yes | No |  |  |
| POLayoutId | int | Yes | No |  |  |
| AccountingFormatId | int | Yes | No |  |  |
| TextbookPercentage | decimal(9,5) | Yes | No |  |  |
| NoBooklets | tinyint | Yes | No |  |  |
| RequireAccounts | tinyint | Yes | No |  |  |
| CurrentBudgetOnly | tinyint | Yes | No |  |  |
| DistrictTypeId | int | Yes | No |  |  |
| AccountSeparator | char(1) | Yes | No |  |  |
| EnableLogins | tinyint | Yes | No |  |  |
| County | varchar(50) | Yes | No |  |  |
| DRsbySchool | int | Yes | No |  |  |
| RightToKnow | int | Yes | No |  |  |
| RTK | int | Yes | No |  |  |
| AllowPasswordChanges | tinyint | Yes | No |  |  |
| ScheduleId | int | Yes | No |  |  |
| DisableLogins | tinyint | Yes | No |  |  |
| LocalPOLayoutId | int | Yes | No |  |  |
| POUploadEmail | varchar(255) | Yes | No |  |  |
| ContactName | varchar(50) | Yes | No |  |  |
| ContactPhone | varchar(20) | Yes | No |  |  |
| ParentDistrictId | int | Yes | No |  |  |
| NoAdvises | tinyint | Yes | No |  |  |
| TimeAndMaterialBids | tinyint | Yes | No |  |  |
| MinimumPO | money | Yes | No | ((25)) |  |
| AccountingDistrictCode | varchar(50) | Yes | No |  |  |
| StateId | int | Yes | No |  |  |
| FixedPOMsg | varchar(500) | Yes | No |  |  |
| UseEDSVendorCodes | tinyint | Yes | No |  |  |
| AccountingSystemOptions | varchar(255) | Yes | No |  |  |
| CooperativeBids | tinyint | Yes | No |  |  |
| AllowIncidentalOrdering | tinyint | Yes | No |  |  |
| AllowUserMaintenance | tinyint | Yes | No |  |  |
| PrintBidAs | tinyint | Yes | No |  |  |
| AnnualPOGenerationMethod | varchar(10) | Yes | No |  |  |
| IncidentalPOGenerationMethod | varchar(10) | Yes | No |  |  |
| SuppressPrintSchedule | tinyint | Yes | No |  |  |
| MinimumPOAmount | money | Yes | No |  |  |
| EnableRTKOnline | int | Yes | No |  |  |
| onlineOrderbook | tinyint | Yes | No |  |  |
| AllowElectronicPOs | int | Yes | No |  |  |
| NotificationType | int | Yes | No |  |  |
| DoNotShipCatalogs | tinyint | Yes | No |  |  |
| usesActualPONumber | tinyint | Yes | No |  |  |
| HidefromDistrictLists | tinyint | Yes | No |  |  |
| AllowSmallPOs | tinyint | Yes | No |  |  |
| AllowBringForwardReqs | tinyint | Yes | No |  |  |



**Primary Key:** DistrictId





**Indexes:**
- PK_District (CLUSTERED): DistrictId
- _dta_index_District_7_1582680736__K1_4 (NONCLUSTERED): Name, DistrictId
- _dta_index_District_7_605438543__K1_2_4_5_6_7_8_9_10_12_21_22_53 (NONCLUSTERED): DistrictCode, Name, Address1, Address2, Address3, UseEDSVendorCodes, City, State, Zipcode, POsBySchool, PhoneNumber, Fax, DistrictId
- SK_CSRep (NONCLUSTERED): CSRepId
- SK_DistrictCode (NONCLUSTERED): DistrictCode
- SK_DistrictIdActiveCountyStateDC (NONCLUSTERED): DistrictId, Active, County, State, DistrictCode
- SK_POSchool (NONCLUSTERED): POsBySchool




### dbo.DistrictCategories



**Rows:** 123,080

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| DistrictCategoryId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| DistrictId | int | Yes | No |  |  |
| Title | varchar(50) | Yes | No |  |  |
| Charge | money | Yes | No |  |  |
| AllowAddenda | tinyint | Yes | No |  |  |
| AllowIncidentals | tinyint | Yes | No |  |  |
| OrderBookTypeId | int | Yes | No |  |  |
| BidItemsOnly | bit | Yes | No |  |  |
| EarlyAccess | tinyint | Yes | No |  |  |
| RTKLocation | varchar(50) | Yes | No |  |  |
| AllowBudgetBooks | tinyint | Yes | No |  |  |
| AllowOrderBooks | tinyint | Yes | No |  |  |
| Description | varchar(2048) | Yes | No |  |  |
| Priority | tinyint | Yes | No |  |  |



**Primary Key:** DistrictCategoryId





**Indexes:**
- PK_DistrictCategories (CLUSTERED): DistrictCategoryId
- _dta_index_DistrictCategories_7_1550680622__K4_K3_K1_5 (NONCLUSTERED): Title, DistrictId, CategoryId, DistrictCategoryId
- _dta_index_DistrictCategories_9_763149764__K3_K4_K9 (NONCLUSTERED): CategoryId, DistrictId, AllowAddenda
- SK_Category (NONCLUSTERED): CategoryId
- SK_DistrictCategory (NONCLUSTERED): DistrictId, CategoryId
- SK_DKAAllow (NONCLUSTERED): AllowAddenda, DistrictId, CategoryId, Active
- SKI_ActiveCategory_District (NONCLUSTERED): DistrictId, Active, CategoryId
- SKI_DistrictCategory_Active (NONCLUSTERED): DistrictCategoryId, Active, Title, AllowAddenda, AllowIncidentals, OrderBookTypeId, BidItemsOnly, DistrictId, CategoryId




### dbo.DistrictCategoryTitles



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| DistrictCategoryTitleId | int | No | Yes |  |  |
| DistrictId | int | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| Title | varchar(50) | Yes | No |  |  |



**Primary Key:** DistrictCategoryTitleId





**Indexes:**
- PK__DistrictCategory__7266E4EE (CLUSTERED): DistrictCategoryTitleId




### dbo.DistrictCharges



**Rows:** 20,773

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| DistrictChargeId | int | No | Yes |  |  |
| DistrictId | int | No | No |  |  |
| Active | int | Yes | No |  |  |
| ChargeDate | datetime | Yes | No |  |  |
| ChargeTypeId | int | Yes | No |  |  |
| Amount | money | Yes | No |  |  |
| DateUpdated | datetime | Yes | No |  |  |
| Invoiced | datetime | Yes | No |  |  |
| Frequency | int | Yes | No |  |  |
| Repeats | int | Yes | No |  |  |
| FrequencyData | varchar(50) | Yes | No |  |  |
| BudgetId | int | Yes | No |  |  |
| Comments | varchar(512) | Yes | No |  |  |



**Primary Key:** DistrictChargeId





**Indexes:**
- PK__DistrictCharges__330F729B (CLUSTERED): DistrictChargeId




### dbo.DistrictChargesNotes



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| DistrictChargeNoteId | uniqueidentifier | No | No | (newid()) |  |
| DistrictId | int | No | No |  |  |
| BudgetId | int | No | No |  |  |
| NoteDate | datetime | No | No | (getdate()) |  |
| Comments | varchar(4096) | Yes | No |  |  |



**Primary Key:** DistrictChargeNoteId





**Indexes:**
- PK__District__ABAFBCC17B56E6FB (CLUSTERED): DistrictChargeNoteId




### dbo.DistrictContacts



**Rows:** 3,777

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| DistrictContactId | int | No | Yes |  |  |
| DistrictId | int | No | No |  |  |
| DistrictContactTypeId | int | No | No |  |  |
| SalutationId | int | Yes | No |  |  |
| FirstName | varchar(50) | Yes | No |  |  |
| MiddleName | varchar(50) | Yes | No |  |  |
| LastName | varchar(50) | Yes | No |  |  |
| Suffix | varchar(20) | Yes | No |  |  |
| Phone | varchar(20) | Yes | No |  |  |
| Fax | varchar(20) | Yes | No |  |  |
| eMail | varchar(255) | Yes | No |  |  |
| ShippingId | int | Yes | No |  |  |
| Address1 | varchar(50) | Yes | No |  |  |
| Address2 | varchar(50) | Yes | No |  |  |
| City | varchar(50) | Yes | No |  |  |
| State | char(2) | Yes | No |  |  |
| Zipcode | varchar(10) | Yes | No |  |  |
| FullName | varchar(174) | Yes | No |  |  |



**Primary Key:** DistrictContactId





**Indexes:**
- PK__District__DEBBC8B95C331A6D (CLUSTERED): DistrictContactId
- SK_DistrictContacttype (NONCLUSTERED): DistrictId, DistrictContactTypeId




### dbo.DistrictContactTypes



**Rows:** 7

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| DistrictContactTypeId | int | No | Yes |  |  |
| Description | varchar(50) | No | No |  |  |



**Primary Key:** DistrictContactTypeId





**Indexes:**
- PK__District__D7F61BD758628989 (CLUSTERED): DistrictContactTypeId




### dbo.DistrictContinuances



**Rows:** 13,304

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| Id | uniqueidentifier | No | No | (newid()) |  |
| DistrictId | int | No | No |  |  |
| BudgetId | int | No | No |  |  |
| Email | varchar(255) | Yes | No |  |  |
| Status | char(1) | Yes | No | ('P') |  |
| SignedBy | varchar(255) | Yes | No |  |  |
| Comments | varchar(4096) | Yes | No |  |  |
| Sent | datetime | No | No | (getdate()) |  |
| Received | datetime | Yes | No |  |  |
| SavingsBudgetId | int | Yes | No |  |  |



**Primary Key:** Id





**Indexes:**
- PK__District__3214EC073BD65497 (CLUSTERED): Id




### dbo.DistrictNotes



**Rows:** 66

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| DistrictNotesId | int | No | Yes |  |  |
| DistrictId | int | Yes | No |  |  |
| NoteTitle | varchar(80) | Yes | No |  |  |
| NoteType | char(1) | Yes | No |  |  |
| Note | varchar(4000) | Yes | No |  |  |
| DateOfNote | datetime | Yes | No |  |  |



**Primary Key:** DistrictNotesId





**Indexes:**
- PK_DistrictNotes (CLUSTERED): DistrictNotesId




### dbo.DistrictNotifications



**Rows:** 5,947

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| DistrictNotificationId | int | No | Yes |  |  |
| DistrictId | int | No | No |  |  |
| NotificationType | varchar(50) | No | No |  |  |
| CategoryId | int | Yes | No |  |  |
| UserId | int | Yes | No |  |  |
| Method | varchar(50) | Yes | No |  |  |
| NotifyList | varchar(255) | Yes | No |  |  |
| OtherNotify | varchar(4096) | Yes | No |  |  |
| Modified | datetime | Yes | No | (getdate()) |  |



**Primary Key:** DistrictNotificationId





**Indexes:**
- PK__District__89A5C1BB4AB835BD (CLUSTERED): DistrictNotificationId




### dbo.DistrictPP



**Rows:** 9,186

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| DistrictPPId | int | No | Yes |  |  |
| DistrictId | int | Yes | No |  |  |
| PricePlanId | int | Yes | No |  |  |



**Primary Key:** DistrictPPId



**Foreign Keys:**
- PricePlanId → dbo.PricePlans.PricePlanId




**Indexes:**
- PK_DistrictPP (CLUSTERED): DistrictPPId
- SK_DistrictId (NONCLUSTERED): DistrictId
- SK_DistrictPP (NONCLUSTERED): DistrictId, PricePlanId
- SK_PPDistrict (NONCLUSTERED): PricePlanId, DistrictId




### dbo.DistrictProposedCharges



**Rows:** 10,307

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| Id | uniqueidentifier | No | No | (newid()) |  |
| DistrictId | int | No | No |  |  |
| BudgetId | int | No | No |  |  |
| ChargeTypeId | int | No | No |  |  |
| DateUpdated | datetime | Yes | No |  |  |
| DateApplied | datetime | Yes | No |  |  |
| Amount | money | Yes | No |  |  |
| PreviousAmount | money | Yes | No |  |  |
| PreviousBudgetId | int | Yes | No |  |  |
| ChangePercentage | decimal(11,5) | Yes | No |  |  |
| Action | char(1) | Yes | No |  |  |
| Frequency | int | Yes | No |  |  |
| FrequencyData | varchar(50) | Yes | No |  |  |









### dbo.DistrictReports



**Rows:** 11

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| DistrictReportId | int | No | Yes |  |  |
| Level | int | Yes | No |  |  |
| Group | varchar(50) | Yes | No |  |  |
| ReportName | varchar(50) | No | No |  |  |
| ScriptURL | varchar(1024) | Yes | No |  |  |



**Primary Key:** DistrictReportId





**Indexes:**
- PK__District__CF9EF8CE03D372A6 (CLUSTERED): DistrictReportId




### dbo.DistrictTypes



**Rows:** 6

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| DistrictTypeId | int | No | Yes |  |  |
| Description | varchar(64) | Yes | No |  |  |
| UsesOnline | tinyint | Yes | No |  |  |
| UsesBooklet | tinyint | Yes | No |  |  |
| UsePriorYearReqs | tinyint | Yes | No |  |  |
| VerifySBSOnline | tinyint | Yes | No |  |  |



**Primary Key:** DistrictTypeId





**Indexes:**
- PK_DistrictTypes (CLUSTERED): DistrictTypeId




### dbo.DistrictVendor



**Rows:** 315,272

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| DistrictVendorId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| DistrictId | int | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| Value | varchar(20) | Yes | No |  |  |
| VendorsAccountCode | varchar(50) | Yes | No |  |  |



**Primary Key:** DistrictVendorId



**Foreign Keys:**
- DistrictId → dbo.District.DistrictId
- VendorId → dbo.Vendors.VendorId




**Indexes:**
- PK_DistrictVendor (CLUSTERED): DistrictVendorId
- SK_District (NONCLUSTERED): DistrictId
- SK_DistrictVendor (NONCLUSTERED): DistrictVendorId, VendorsAccountCode, DistrictId, VendorId
- SKI_District_DistrictvendorVendorValueVAC (NONCLUSTERED): DistrictVendorId, Value, VendorsAccountCode, DistrictId, VendorId, Active




### dbo.DMSBidDocuments



**Rows:** 28,029

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| Id | uniqueidentifier | No | No | (newid()) |  |
| BidHeaderId | int | Yes | No |  |  |
| BidNbr | varchar(MAX) | Yes | No |  |  |
| DocType | varchar(MAX) | Yes | No |  |  |
| DocId | uniqueidentifier | Yes | No |  |  |
| DistrictVisible | varchar(MAX) | Yes | No |  |  |
| PagesCaptured | int | Yes | No |  |  |
| FileName | varchar(1024) | Yes | No |  |  |



**Primary Key:** Id





**Indexes:**
- PK_DMSBidDocuments (CLUSTERED): Id




### dbo.DMSSDSDocuments



**Rows:** 602

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| Id | uniqueidentifier | No | No | (newid()) |  |
| MSDSId | int | No | No |  |  |
| DocId | uniqueidentifier | No | No |  |  |
| PagesCaptured | int | Yes | No |  |  |
| DocName | varchar(1024) | Yes | No |  |  |



**Primary Key:** Id





**Indexes:**
- PK__DMSSDSDo__3214EC07C9C46946 (CLUSTERED): Id
- SKI_MSDS_IDDoc (NONCLUSTERED): Id, MSDSId, DocId




### dbo.DMSVendorBidDocuments



**Rows:** 709,509

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| Id | uniqueidentifier | No | No | (newid()) |  |
| VendorCode | varchar(10) | Yes | No |  |  |
| DistrictVisible | varchar(10) | Yes | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| BidNbr | varchar(20) | Yes | No |  |  |
| DocType | varchar(255) | Yes | No |  |  |
| ExpirationDate | varchar(30) | Yes | No |  |  |
| DocumentNumber | varchar(255) | Yes | No |  |  |
| DocId | uniqueidentifier | Yes | No |  |  |
| PagesCaptured | int | Yes | No |  |  |
| FileName | varchar(1024) | Yes | No |  |  |



**Primary Key:** Id





**Indexes:**
- PK_DMSVendorBidDocuments (CLUSTERED): Id
- SKI_BidHeaderVendorCodeDocType_Id (NONCLUSTERED): Id, BidHeaderId, VendorCode, DocType




### dbo.DMSVendorDocuments



**Rows:** 6,485

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| Id | uniqueidentifier | No | No | (newid()) |  |
| VendorCode | varchar(10) | Yes | No |  |  |
| DistrictVisible | varchar(10) | Yes | No |  |  |
| DocType | varchar(255) | Yes | No |  |  |
| ExpirationDate | varchar(30) | Yes | No |  |  |
| DocumentNumber | varchar(255) | Yes | No |  |  |
| DocId | uniqueidentifier | Yes | No |  |  |
| PagesCaptured | int | Yes | No |  |  |
| FileName | varchar(1024) | Yes | No |  |  |



**Primary Key:** Id





**Indexes:**
- PK_DMSVendorDocuments (CLUSTERED): Id




### dbo.dtproperties



**Rows:** 42

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| id | int | No | Yes |  |  |
| objectid | int | Yes | No |  |  |
| property | varchar(64) | No | No |  |  |
| value | varchar(255) | Yes | No |  |  |
| uvalue | nvarchar(255) | Yes | No |  |  |
| lvalue | image | Yes | No |  |  |
| version | int | No | No | (0) |  |



**Primary Key:** id, property





**Indexes:**
- pk_dtproperties (CLUSTERED): id, property




### dbo.EmailBlast



**Rows:** 16,118

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| EmailBlastId | int | No | Yes |  |  |
| BlastName | varchar(100) | Yes | No |  |  |
| BlastDescription | varchar(2000) | Yes | No |  |  |
| BlastHTML | varchar(8000) | Yes | No |  |  |
| SQLStmt | varchar(8000) | Yes | No |  |  |
| ReportWhereClause | varchar(8000) | Yes | No |  |  |
| SentDate | datetime | Yes | No |  |  |
| EmailFrom | varchar(500) | Yes | No |  |  |
| EmailCC | varchar(500) | Yes | No |  |  |
| EmailBCC | varchar(500) | Yes | No |  |  |
| EmailSubject | varchar(250) | Yes | No |  |  |
| ReadReceipt | tinyint | Yes | No |  |  |
| HighPriority | tinyint | Yes | No |  |  |
| AddressFromRep | tinyint | Yes | No |  |  |
| Attachments | varchar(2000) | Yes | No |  |  |
| UseDefaultReadReceiptEmail | tinyint | Yes | No |  |  |
| ReadReceiptEmail | varchar(500) | Yes | No |  |  |
| BlastVar1 | varchar(250) | Yes | No |  |  |
| BlastVar2 | varchar(250) | Yes | No |  |  |
| Reference1Id | int | Yes | No |  |  |
| Reference2Id | int | Yes | No |  |  |
| VarDataSQL | varchar(8000) | Yes | No |  |  |



**Primary Key:** EmailBlastId





**Indexes:**
- PK_EmailBlast (CLUSTERED): EmailBlastId




### dbo.EmailBlastAddresses08132012



**Rows:** 271

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| EmailAddress | nvarchar(255) | Yes | No |  |  |









### dbo.EmailBlastCopy



**Rows:** 3

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| EmailBlastId | int | No | Yes |  |  |
| BlastName | varchar(50) | Yes | No |  |  |
| BlastDescription | varchar(2000) | Yes | No |  |  |
| BlastHTML | varchar(MAX) | Yes | No |  |  |
| SQLStmt | varchar(8000) | Yes | No |  |  |
| ReportWhereClause | varchar(8000) | Yes | No |  |  |
| SentDate | datetime | Yes | No |  |  |
| EmailFrom | varchar(500) | Yes | No |  |  |
| EmailCC | varchar(500) | Yes | No |  |  |
| EmailBCC | varchar(500) | Yes | No |  |  |
| EmailSubject | varchar(80) | Yes | No |  |  |
| ReadReceipt | tinyint | Yes | No |  |  |
| HighPriority | tinyint | Yes | No |  |  |
| AddressFromRep | tinyint | Yes | No |  |  |
| Attachments | varchar(2000) | Yes | No |  |  |
| UseDefaultReadReceiptEmail | tinyint | Yes | No |  |  |
| ReadReceiptEmail | varchar(500) | Yes | No |  |  |



**Primary Key:** EmailBlastId





**Indexes:**
- PK_EmailBlastCopy (CLUSTERED): EmailBlastId




### dbo.EmailBlastLog



**Rows:** 1,389,491

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| EmailBlastLogId | int | No | Yes |  |  |
| EmailBlastId | int | Yes | No |  |  |
| PrimaryRecipient | varchar(50) | Yes | No |  |  |
| ContactFullName | varchar(100) | Yes | No |  |  |
| EmailSentTo | varchar(500) | Yes | No |  |  |
| EmailFrom | varchar(500) | Yes | No |  |  |
| EmailCC | varchar(500) | Yes | No |  |  |
| EmailBCC | varchar(500) | Yes | No |  |  |
| SendDate | datetime | Yes | No |  |  |
| XMLData | varchar(8000) | Yes | No |  |  |
| Attachment | varchar(1000) | Yes | No |  |  |
| PrimaryRecipientId | int | Yes | No |  |  |



**Primary Key:** EmailBlastLogId





**Indexes:**
- PK_EmailBlastLog (CLUSTERED): EmailBlastLogId




### dbo.FreezeItems



**Rows:** 15,435

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| Id | uniqueidentifier | No | No | (newid()) |  |
| ItemId | int | No | No |  |  |
| CrossRefId | int | No | No |  |  |
| VendorId | int | No | No |  |  |
| VendorItemCode | varchar(50) | Yes | No |  |  |
| BidHeaderId | int | No | No |  |  |
| GrossPrice | money | Yes | No |  |  |



**Primary Key:** Id





**Indexes:**
- PK__FreezeIt__3214EC074D34D55C (CLUSTERED): Id
- SKI_BidHeaderItemVendor_Etc (NONCLUSTERED): Id, CrossRefId, VendorItemCode, GrossPrice, BidHeaderId, ItemId, VendorId
- ti_Crossref_Id (NONCLUSTERED): Id, CrossRefId




### dbo.FreezeItems2015



**Rows:** 100,517

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| DistrictName | varchar(50) | Yes | No |  |  |
| BudgetName | varchar(30) | Yes | No |  |  |
| SchoolName | varchar(50) | Yes | No |  |  |
| CometId | int | Yes | No |  |  |
| Attention | varchar(50) | Yes | No |  |  |
| RequisitionNumber | varchar(24) | Yes | No |  |  |
| ItemCode | varchar(50) | Yes | No |  |  |
| VendorItemCode | varchar(50) | Yes | No |  |  |
| Quantity | int | Yes | No |  |  |
| BidPrice | money | Yes | No |  |  |
| Extended | money | Yes | No |  |  |
| OrigVendorItemCode | varchar(50) | Yes | No |  |  |
| OrigBidPrice | money | Yes | No |  |  |
| OrigExtended | money | Yes | No |  |  |
| Description | varchar(1024) | Yes | No |  |  |
| Status | varchar(255) | Yes | No |  |  |
| UseAllocations | tinyint | No | No |  |  |
| AllocationAvailable | money | No | No |  |  |
| DetailId | int | No | No |  |  |
| RequisitionId | int | No | No |  |  |
| VendorId | int | Yes | No |  |  |
| AwardId | int | Yes | No |  |  |
| CatalogId | int | Yes | No |  |  |
| CatalogPrice | money | Yes | No |  |  |
| OrigVendorId | int | Yes | No |  |  |
| OrigAwardId | int | Yes | No |  |  |
| OrigCatalogId | int | Yes | No |  |  |
| OrigCatalogPrice | money | Yes | No |  |  |







**Indexes:**
- SKI_Detail_Etc (NONCLUSTERED): OrigVendorItemCode, OrigBidPrice, OrigVendorId, OrigAwardId, OrigCatalogId, OrigCatalogPrice, DetailId




### dbo.HeaderWorkItems



**Rows:** 491,824

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| OBDWorkId | int | No | Yes |  |  |
| ItemId | int | No | No |  |  |









### dbo.Headings



**Rows:** 164,211

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| HeadingId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| Code | varchar(16) | Yes | No |  |  |
| ExpandAll | tinyint | Yes | No |  |  |
| Title | varchar(255) | Yes | No |  |  |
| Description | varchar(4096) | Yes | No |  |  |
| DistrictId | int | Yes | No |  |  |
| DateCreated | datetime | Yes | No | (getdate()) |  |
| DateUpdated | datetime | Yes | No |  |  |



**Primary Key:** HeadingId





**Indexes:**
- PK_Headings (CLUSTERED): HeadingId
- _dta_index_Headings_7_1374679995__K1_K2_6 (NONCLUSTERED): Title, HeadingId, Active
- _dta_index_Headings_7_1374679995__K2_K1_6 (NONCLUSTERED): Title, Active, HeadingId
- SK_ActiveCategoryTitleDistrict (NONCLUSTERED): Active, CategoryId, Title, DistrictId
- SKI_ExpandAll_Heading (NONCLUSTERED): HeadingId, ExpandAll
- SKI_HeadingId_Title (NONCLUSTERED): Title, HeadingId




### dbo.HolidayCalendar



**Rows:** 29

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| Year | int | No | No |  |  |
| Month | int | No | No |  |  |
| Holidays | varchar(100) | Yes | No | ('') |  |



**Primary Key:** Year, Month





**Indexes:**
- HolidayCalendar_pk (CLUSTERED): Year, Month
- HolidayCalendar_Year_Month_index (NONCLUSTERED): Year, Month




### dbo.HolidayCalendarVendor



**Rows:** 7

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| Year | int | No | No |  |  |
| Month | int | No | No |  |  |
| Holidays | varchar(100) | Yes | No | ('') |  |
| VendorId | int | No | No | ((0)) |  |



**Primary Key:** Year, Month, VendorId





**Indexes:**
- HolidayCalendarVendor_pk (CLUSTERED): Year, Month, VendorId
- HolidayCalendarVendor_Year_Month_index (NONCLUSTERED): Year, Month, VendorId




### dbo.ImageErrors



**Rows:** 26,727

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| imageErrorId | bigint | No | Yes |  |  |
| imageURL | varchar(2048) | No | No |  |  |
| error | varchar(MAX) | Yes | No |  |  |
| logDate | datetime | No | No | (getdate()) |  |



**Primary Key:** imageErrorId





**Indexes:**
- PK__ImageErr__FE6831C29F922480 (CLUSTERED): imageErrorId
- NonClusteredIndex-20210628-091606 (NONCLUSTERED): error, logDate, imageURL, imageErrorId




### dbo.ImageLog



**Rows:** 1,788,706

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| imageLogId | bigint | No | Yes |  |  |
| imageId | bigint | Yes | No |  |  |
| imageURL | varchar(2048) | Yes | No |  |  |
| imageActualURL | varchar(2048) | Yes | No |  |  |
| statusCode | int | Yes | No |  |  |
| statusText | varchar(512) | Yes | No |  |  |
| contentType | varchar(50) | Yes | No |  |  |
| headers | varchar(MAX) | Yes | No |  |  |
| testDate | datetime | Yes | No | (getdate()) |  |
| writeStatus | int | Yes | No |  |  |
| writeDate | datetime | Yes | No |  |  |



**Primary Key:** imageLogId





**Indexes:**
- PK__ImageLog (CLUSTERED): imageLogId
- NonClusteredIndex-20250321-091731 (NONCLUSTERED): imageLogId, imageId, imageURL, writeStatus, writeDate




### dbo.Images



**Rows:** 1,736,177

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| imageId | bigint | No | Yes |  |  |
| imageURL | varchar(768) | Yes | No |  |  |
| imageActualURL | varchar(768) | Yes | No |  |  |
| imagePath | varchar(512) | Yes | No |  |  |
| imageResized | varchar(512) | Yes | No |  |  |
| imageThumbnail | varchar(512) | Yes | No |  |  |
| pHash | char(64) | Yes | No |  |  |
| bipHash | bigint | Yes | No |  |  |
| imageSize | int | Yes | No |  |  |
| imageFormat | varchar(20) | Yes | No |  |  |
| width | int | Yes | No |  |  |
| height | int | Yes | No |  |  |
| imageSpace | varchar(20) | Yes | No |  |  |
| channels | int | Yes | No |  |  |
| depth | varchar(20) | Yes | No |  |  |
| density | int | Yes | No |  |  |
| dateLoaded | datetime | Yes | No | (getdate()) |  |
| dateChecked | datetime | Yes | No | (getdate()) |  |
| dateDeleted | datetime | Yes | No |  |  |



**Primary Key:** imageId





**Indexes:**
- PK__Images__336E9B55906715A9 (CLUSTERED): imageId
- DPA_RECIDX_416 (NONCLUSTERED): pHash, imageSize, imageFormat
- SK_URLLoaded (NONCLUSTERED): imageURL, dateLoaded




### dbo.ImportCatalogDetail



**Rows:** 17,262

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ImportCatalogDetailId | int | No | Yes |  |  |
| ImportCatalogHeaderId | int | Yes | No |  |  |
| ImportInfoType | int | Yes | No |  |  |
| ImportInfoDesc | varchar(1000) | Yes | No |  |  |
| ImportInfoValue | int | Yes | No |  |  |
| ImportDateTime | datetime | Yes | No |  |  |



**Primary Key:** ImportCatalogDetailId





**Indexes:**
- PK_ImportCatalogDetail (CLUSTERED): ImportCatalogDetailId




### dbo.ImportCatalogHeader



**Rows:** 2,756

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ImportCatalogHeaderId | int | No | Yes |  |  |
| CatalogId | int | Yes | No |  |  |
| ImportDateStart | datetime | Yes | No |  |  |
| ImportDateComplete | datetime | Yes | No |  |  |



**Primary Key:** ImportCatalogHeaderId





**Indexes:**
- PK_ImportCatalogHeader (CLUSTERED): ImportCatalogHeaderId




### dbo.ImportDetail



**Rows:** 882,935

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ImportDetailId | int | No | Yes |  |  |
| ImportId | int | Yes | No |  |  |
| ImportData | varchar(512) | Yes | No |  |  |



**Primary Key:** ImportDetailId





**Indexes:**
- PK_ImportDetail (CLUSTERED): ImportDetailId




### dbo.ImportMessages



**Rows:** 5,500

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| MessageId | int | No | Yes |  |  |
| ProcessId | int | No | No |  |  |
| MsgDate | datetime | Yes | No |  |  |
| Message | varchar(512) | Yes | No |  |  |



**Primary Key:** MessageId





**Indexes:**
- PK_ImportMessages (CLUSTERED): MessageId




### dbo.ImportProcesses



**Rows:** 754

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ProcessId | int | No | Yes |  |  |
| ImportId | int | No | No |  |  |
| ProcessDate | datetime | Yes | No |  |  |



**Primary Key:** ProcessId





**Indexes:**
- PK_Processes (CLUSTERED): ProcessId




### dbo.Imports



**Rows:** 301

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ImportId | int | No | Yes |  |  |
| ImportType | tinyint | Yes | No |  |  |
| ImportDate | datetime | Yes | No |  |  |
| Comments | varchar(255) | Yes | No |  |  |
| Records | int | Yes | No |  |  |
| ErrorCount | int | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| CatalogId1 | int | Yes | No |  |  |
| CatalogId2 | int | Yes | No |  |  |
| CatalogId3 | int | Yes | No |  |  |
| CatalogId4 | int | Yes | No |  |  |
| CatalogId5 | int | Yes | No |  |  |
| CatalogId6 | int | Yes | No |  |  |
| PricePlanId | int | Yes | No |  |  |



**Primary Key:** ImportId





**Indexes:**
- PK_Imports (CLUSTERED): ImportId




### dbo.InstructionBookContents



**Rows:** 31

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| IBCId | int | No | Yes |  |  |
| IBTypeId | int | No | No |  |  |
| DistrictId | int | Yes | No |  |  |
| Priority | int | Yes | No |  |  |
| Title | varchar(255) | Yes | No |  |  |
| TitleInTOC | tinyint | Yes | No |  |  |
| Body | varchar(4096) | Yes | No |  |  |
| HeaderAttributes | int | Yes | No |  |  |
| HTMLBody | varchar(MAX) | Yes | No |  |  |
| SubReportName | varchar(1024) | Yes | No |  |  |



**Primary Key:** IBCId





**Indexes:**
- PK__Instruct__9001CA154AB388B0 (CLUSTERED): IBCId




### dbo.InstructionBookTypes



**Rows:** 6

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| IBTypeId | int | No | Yes |  |  |
| Description | varchar(50) | No | No |  |  |
| ShowInAllBooks | tinyint | Yes | No |  |  |



**Primary Key:** IBTypeId





**Indexes:**
- PK__Instruct__E64A5E1636AC9003 (CLUSTERED): IBTypeId




### dbo.Instructions



**Rows:** 7

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| InstructionId | int | No | Yes |  |  |
| SectionName | varchar(50) | Yes | No |  |  |
| Heading | varchar(255) | Yes | No |  |  |
| Body | varchar(8000) | Yes | No |  |  |



**Primary Key:** InstructionId





**Indexes:**
- PK__Instruct__CE06947129C65AB9 (CLUSTERED): InstructionId




### dbo.Invoices



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| InvoiceId | int | No | Yes |  |  |
| DistrictId | int | No | No |  |  |
| InvoiceTypeId | int | No | No |  |  |
| InvoiceDate | datetime | No | No |  |  |
| DueDate | datetime | Yes | No |  |  |
| Amount | money | Yes | No |  |  |
| Comments | varchar(4096) | Yes | No |  |  |



**Primary Key:** InvoiceId





**Indexes:**
- PK__Invoices__1F247CCC (CLUSTERED): InvoiceId




### dbo.InvoiceTypes



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| InvoiceTypeId | int | No | Yes |  |  |
| Frequency | int | Yes | No |  |  |
| DueDays | int | Yes | No |  |  |
| Description | varchar(50) | No | No |  |  |



**Primary Key:** InvoiceTypeId





**Indexes:**
- PK__InvoiceTypes__1D3C345A (CLUSTERED): InvoiceTypeId




### dbo.IPQueue



**Rows:** 5,038

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| IPQueueId | int | No | Yes |  |  |
| Queue | varchar(50) | No | No |  |  |
| Email | varchar(255) | Yes | No |  |  |
| SingleFile | tinyint | Yes | No |  |  |
| ToUser | tinyint | Yes | No |  |  |
| Requested | datetime | No | No | (getdate()) |  |
| Started | datetime | Yes | No |  |  |
| Completed | datetime | Yes | No |  |  |
| Status | varchar(255) | Yes | No |  |  |



**Primary Key:** IPQueueId





**Indexes:**
- PK__IPQueue__4EC586B738FC4C6D (CLUSTERED): IPQueueId




### dbo.IPQueueUsers



**Rows:** 489,217

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| IPQueueUserId | int | No | Yes |  |  |
| IPQueueId | int | No | No |  |  |
| UserId | int | No | No |  |  |
| Requested | datetime | No | No | (getdate()) |  |
| Started | datetime | Yes | No |  |  |
| Completed | datetime | Yes | No |  |  |
| Status | varchar(255) | Yes | No |  |  |



**Primary Key:** IPQueueUserId





**Indexes:**
- PK__IPQueueU__5793EB133CCCDD51 (CLUSTERED): IPQueueUserId




### dbo.ItemContractPrices



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ICPId | int | No | Yes |  |  |
| ItemId | int | No | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| CrossRefId | int | Yes | No |  |  |
| Price | money | Yes | No |  |  |



**Primary Key:** ICPId





**Indexes:**
- PK__ItemCont__9F03B0683B0730CC (CLUSTERED): ICPId




### dbo.ItemDocuments



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ItemDocumentId | bigint | No | Yes |  |  |
| ItemId | int | No | No |  |  |
| Description | varchar(255) | Yes | No |  |  |
| FileName | varchar(255) | Yes | No |  |  |
| DocumentType | varchar(10) | Yes | No |  |  |
| DocumentSize | bigint | Yes | No |  |  |
| DocumentDate | datetime | Yes | No |  |  |
| DateUploaded | datetime | No | No | (getdate()) |  |
| DocumentId | uniqueidentifier | No | No | (newid()) |  |
| DocumentData | varbinary(MAX) | Yes | No |  |  |



**Primary Key:** ItemDocumentId





**Indexes:**
- PK__ItemDocu__2D6D2FEFEB03F9C0 (CLUSTERED): ItemDocumentId




### dbo.Items



**Rows:** 28,856,944

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ItemId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| ItemCode | varchar(50) | Yes | No |  |  |
| Description | varchar(512) | Yes | No |  |  |
| UnitId | int | Yes | No |  |  |
| ParentCatalogId | int | Yes | No |  |  |
| HeadingId | int | Yes | No |  |  |
| RTK | tinyint | Yes | No |  |  |
| SortSeq | varchar(64) | Yes | No |  |  |
| EditionId | int | Yes | No |  |  |
| CopyrightYear | int | Yes | No |  |  |
| PackedCode | varchar(50) | Yes | No | ('([dbo].[uf_PackCode]([ItemCode]))') |  |
| DateDeactivated | datetime | Yes | No |  |  |
| DistrictId | int | Yes | No |  |  |
| BrandName | varchar(50) | Yes | No |  |  |
| ManufacturorNumber | varchar(50) | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| VendorPartNumber | varchar(50) | Yes | No |  |  |
| ItemsPerUnit | varchar(50) | Yes | No |  |  |
| ListPrice | money | Yes | No |  |  |
| ExtraDetail | varchar(1024) | Yes | No |  |  |
| ShortDescription | varchar(60) | Yes | No |  |  |
| KeywordId | int | Yes | No |  |  |
| AlternateItemCode | varchar(50) | Yes | No |  |  |
| SectionId | int | Yes | No |  |  |
| UOMDivisor | int | Yes | No |  |  |
| RedirectedItemId | int | Yes | No |  |  |
| ListPriceSource | int | Yes | No |  |  |
| FullDescription | varchar(1536) | Yes | No |  |  |
| CrossRefText | varchar(768) | Yes | No |  |  |
| StandardItem | tinyint | Yes | No |  |  |
| BidderToSupplyVendor | tinyint | Yes | No |  |  |
| BidderToSupplyVendorPartNbr | tinyint | Yes | No |  |  |
| ManufacturerId | int | Yes | No |  |  |
| VendorToSupplyManufacturer | tinyint | Yes | No |  |  |
| ProductLineId | int | Yes | No |  |  |
| HeadingKeywordId | bigint | Yes | No |  |  |



**Primary Key:** ItemId





**Indexes:**
- PK_Items (CLUSTERED): ItemId
- _dta_index_Items_12_1509632471__K1_K6_K15_K8_K24_5_10 (NONCLUSTERED): Description, SortSeq, ItemId, UnitId, DistrictId, HeadingId, KeywordId
- _dta_index_Items_7_1509632471__K1_K24_K6_K15_K18_K11_K7_K3_K8_4_5_10_12_16_17_19_20_22 (NONCLUSTERED): ItemCode, Description, SortSeq, CopyrightYear, BrandName, ManufacturorNumber, VendorPartNumber, ItemsPerUnit, ExtraDetail, ItemId, KeywordId, UnitId, DistrictId, VendorId, EditionId, ParentCatalogId, CategoryId, HeadingId
- DPA_RECIDX_18 (NONCLUSTERED): CategoryId, VendorId
- SK_CategoryPackedcode_ItemIdActiveItemCodeDescUnitParentHeadingRTKSortDist (NONCLUSTERED): ItemId, Active, ItemCode, Description, UnitId, ParentCatalogId, HeadingId, RTK, SortSeq, DistrictId, CategoryId, PackedCode
- SK_CategoryUnit (NONCLUSTERED): CategoryId, UnitId
- SK_Heading (NONCLUSTERED): ItemId, HeadingId
- SK_ItemActiveDistrict (NONCLUSTERED): ItemId, Active, DistrictId
- SK_ItemCodeCategory (NONCLUSTERED): ItemCode, CategoryId
- SK_ItemHeading (NONCLUSTERED): ItemId, HeadingId, Active
- SK_ItemItemCodeCategory (NONCLUSTERED): ItemId, ItemCode, CategoryId
- SKI_ActiveCategory_Heading (NONCLUSTERED): HeadingId, Active, CategoryId
- SKI_ActiveHeading_ItemItemcodeDescrUnitSortseq (NONCLUSTERED): ItemId, ItemCode, Description, UnitId, SortSeq, DistrictId, ListPrice, Active, HeadingId
- ski_CategoryDistrictActive_Heading (NONCLUSTERED): HeadingId, ItemId, CategoryId, DistrictId, Active
- SKI_HeadingActiveCategoryDistrict_Item (NONCLUSTERED): ItemId, HeadingId, Active, CategoryId, DistrictId
- SKI_Item_CategoryHeadingKeywordItemCodeUnit (NONCLUSTERED): CategoryId, ItemCode, UnitId, HeadingId, KeywordId, ItemId
- SKI_ItemCategoryActive_HeadingKeyword (NONCLUSTERED): HeadingId, KeywordId, DistrictId, ItemId, CategoryId, Active
- SKI_ItemCode (NONCLUSTERED): SortSeq, ItemCode




### dbo.ItemUpdates



**Rows:** 198,886

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ItemUpdateId | int | No | Yes |  |  |
| ItemId | int | Yes | No |  |  |
| Reason | varchar(50) | Yes | No |  |  |
| UpdateField | varchar(50) | Yes | No |  |  |
| Action | int | Yes | No |  |  |



**Primary Key:** ItemUpdateId





**Indexes:**
- PK_ItemUpdates (CLUSTERED): ItemUpdateId




### dbo.jSessions



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| jSessionId | int | No | Yes |  |  |
| SessionId | int | No | No |  |  |
| jSession | varchar(255) | No | No |  |  |
| StartTime | datetime | No | No | (getdate()) |  |
| EndTime | datetime | Yes | No |  |  |
| IPAddress | varchar(50) | Yes | No |  |  |



**Primary Key:** jSessionId





**Indexes:**
- PK__jSession__DD84209B32A6F4F5 (CLUSTERED): jSessionId




### dbo.Keywords



**Rows:** 25,261

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| KeywordId | int | No | Yes |  |  |
| Active | int | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| HeadingId | int | Yes | No |  |  |
| DistrictId | int | Yes | No |  |  |
| Keyword | varchar(50) | Yes | No |  |  |
| DateCreated | datetime | Yes | No | (getdate()) |  |
| DateUpdated | datetime | Yes | No |  |  |



**Primary Key:** KeywordId





**Indexes:**
- PK_Keywords (CLUSTERED): KeywordId
- _dta_index_Keywords_7_1246679539__K1_6 (NONCLUSTERED): Keyword, KeywordId
- _dta_index_Keywords_7_1246679539__K2_K1_6 (NONCLUSTERED): Keyword, Active, KeywordId
- SK_Category (NONCLUSTERED): CategoryId
- SK_Heading (NONCLUSTERED): HeadingId
- SKI_KeywordHeadingDistrictActive_KeywordId (NONCLUSTERED): KeywordId, CategoryId, Keyword, HeadingId, DistrictId, Active
- SKI_KeywordId_Keyword (NONCLUSTERED): Keyword, KeywordId




### dbo.Ledger



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| LedgerId | int | No | Yes |  |  |
| TransactionTypeId | int | No | No |  |  |
| Amount | money | Yes | No |  |  |
| TransactionDate | datetime | No | No |  |  |
| DueDate | datetime | Yes | No |  |  |
| DatePosted | datetime | No | No |  |  |
| PostedBy | int | Yes | No |  |  |
| DistrictId | int | Yes | No |  |  |
| Credit | tinyint | Yes | No |  |  |
| Comment | varchar(4096) | Yes | No |  |  |



**Primary Key:** LedgerId





**Indexes:**
- PK__Ledger__1D072A30 (CLUSTERED): LedgerId




### dbo.LL_RepArea



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| Ref | int | No | No |  |  |
| ReportType | varchar(50) | Yes | No |  |  |
| TemplateType | varchar(1) | Yes | No |  |  |



**Primary Key:** Ref





**Indexes:**
- PK_LL_RepArea (CLUSTERED): Ref




### dbo.LL_RepLay



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| Ref | int | No | No |  |  |
| Description | varchar(60) | Yes | No |  |  |
| AreaRef | int | Yes | No |  |  |
| FileName | varchar(80) | Yes | No |  |  |
| FactoryDefault | tinyint | Yes | No |  |  |
| Type | varchar(5) | Yes | No |  |  |



**Primary Key:** Ref





**Indexes:**
- PK_LL_RepLay (CLUSTERED): Ref




### dbo.ManufacturerProductLines



**Rows:** 13,904

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ManufacturerProductLineId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| ManufacturerId | int | No | No |  |  |
| Name | varchar(100) | No | No |  |  |
| UseOptions | tinyint | Yes | No |  |  |



**Primary Key:** ManufacturerProductLineId





**Indexes:**
- PK__Manufact__4837625B00E92DC3 (CLUSTERED): ManufacturerProductLineId




### dbo.Manufacturers



**Rows:** 8,703

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ManufacturerId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| CategoryId | int | No | No |  |  |
| Name | varchar(100) | No | No |  |  |
| WebsiteLink | varchar(255) | Yes | No |  |  |
| AllowAdditionalProductLines | tinyint | Yes | No |  |  |
| UseOptions | tinyint | Yes | No |  |  |



**Primary Key:** ManufacturerId





**Indexes:**
- PK__Manufact__357E5CC16608FF6F (CLUSTERED): ManufacturerId




### dbo.MappedItems



**Rows:** 2

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| MappedItemId | int | No | Yes |  |  |
| OrigItemId | int | No | No |  |  |
| NewItemId | int | No | No |  |  |
| MapDate | datetime | No | No | (getdate()) |  |



**Primary Key:** MappedItemId





**Indexes:**
- PK__MappedIt__64ED12E457E92F51 (CLUSTERED): MappedItemId
- SK_Map (NONCLUSTERED): NewItemId, OrigItemId




### dbo.Menus



**Rows:** 4

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| MenuId | int | No | Yes |  |  |
| ParentId | int | Yes | No |  |  |
| Name | varchar(50) | Yes | No |  |  |
| Description | varchar(255) | Yes | No |  |  |
| URL | varchar(1024) | Yes | No |  |  |
| RequiredLevel | int | Yes | No |  |  |
| SortSeq | int | Yes | No |  |  |



**Primary Key:** MenuId





**Indexes:**
- PK__Menus__C99ED23062C01C6B (CLUSTERED): MenuId




### dbo.Messages



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| MessageId | int | No | No |  |  |
| Active | tinyint | Yes | No |  |  |
| Code | varchar(20) | Yes | No |  |  |
| Comments | varchar(1023) | Yes | No |  |  |



**Primary Key:** MessageId





**Indexes:**
- PK_Messages (CLUSTERED): MessageId




### dbo.Months



**Rows:** 12

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| MonthId | int | No | No |  |  |
| MonthName | varchar(50) | No | No |  |  |
| Abbrev | char(3) | No | No |  |  |



**Primary Key:** MonthId





**Indexes:**
- PK__MonthNam__9FA83FA626129C39 (CLUSTERED): MonthId




### dbo.MSDS



**Rows:** 58,726

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| MSDSId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| CurrentVersionMSDSId | int | Yes | No |  |  |
| AlternateDescription | varchar(60) | Yes | No |  |  |
| ContentCentralMSDSDocId | varchar(36) | Yes | No |  |  |



**Primary Key:** MSDSId





**Indexes:**
- PK_MSDS (CLUSTERED): MSDSId
- SKI_CurrentVersion_DocId (NONCLUSTERED): MSDSId, ContentCentralMSDSDocId, CurrentVersionMSDSId




### dbo.MSDSDetail



**Rows:** 138,516

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| MSDSDetailID | int | No | Yes |  |  |
| MSDSID | int | Yes | No |  |  |
| SeqNum | int | Yes | No |  |  |
| RTK_CASFileId | int | Yes | No |  |  |
| MixturePercent | decimal(9,5) | Yes | No |  |  |
| LegacyCASRegNo | varchar(12) | Yes | No |  |  |
| MixturePercentCode | char(2) | Yes | No |  |  |



**Primary Key:** MSDSDetailID



**Foreign Keys:**
- MSDSID → dbo.MSDS.MSDSId




**Indexes:**
- PK_MSDSDetail (CLUSTERED): MSDSDetailID
- SKI_MSDSCAS_Id (NONCLUSTERED): MSDSDetailID, MSDSID, RTK_CASFileId




### dbo.MSRPExcelExport



**Rows:** 563

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| MSRPExcelExportId | int | No | Yes |  |  |
| ManufacturerName | varchar(50) | Yes | No |  |  |
| ProductLine | varchar(50) | Yes | No |  |  |
| OptionName | varchar(50) | Yes | No |  |  |
| ManufWebsite | varchar(255) | Yes | No |  |  |
| RangeBase1 | varchar(50) | Yes | No |  |  |
| RangeWeight1 | varchar(50) | Yes | No |  |  |
| RangeBase2 | varchar(50) | Yes | No |  |  |
| RangeWeight2 | varchar(50) | Yes | No |  |  |
| RangeBase3 | varchar(50) | Yes | No |  |  |
| RangeWeight3 | varchar(50) | Yes | No |  |  |
| RangeBase4 | varchar(50) | Yes | No |  |  |
| RangeWeight4 | varchar(50) | Yes | No |  |  |
| RangeBase5 | varchar(50) | Yes | No |  |  |
| RangeWeight5 | varchar(50) | Yes | No |  |  |
| RangeBase6 | varchar(50) | Yes | No |  |  |
| RangeWeight6 | varchar(50) | Yes | No |  |  |



**Primary Key:** MSRPExcelExportId





**Indexes:**
- PK_MSRPExcelExport (CLUSTERED): MSRPExcelExportId




### dbo.MSRPExcelImport



**Rows:** 76,315

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| MSRPExcelImportId | int | No | Yes |  |  |
| BidNumber | int | Yes | No |  |  |
| SeqNumber | int | Yes | No |  |  |
| Manufacturer | varchar(100) | Yes | No |  |  |
| ProductLineGroup | varchar(100) | Yes | No |  |  |
| DeliveryOption | varchar(50) | Yes | No |  |  |
| ManufWebsite | varchar(255) | Yes | No |  |  |
| Base1 | money | Yes | No |  |  |
| Weight1 | decimal(9,5) | Yes | No |  |  |
| Base2 | money | Yes | No |  |  |
| Weight2 | decimal(9,5) | Yes | No |  |  |
| Base3 | money | Yes | No |  |  |
| Weight3 | decimal(9,5) | Yes | No |  |  |
| Base4 | money | Yes | No |  |  |
| Weight4 | decimal(9,5) | Yes | No |  |  |
| Base5 | money | Yes | No |  |  |
| Weight5 | decimal(9,5) | Yes | No |  |  |
| Base6 | money | Yes | No |  |  |
| Weight6 | decimal(9,5) | Yes | No |  |  |
| Base7 | money | Yes | No |  |  |
| Weight7 | decimal(9,5) | Yes | No |  |  |
| Base8 | money | Yes | No |  |  |
| Weight8 | decimal(9,5) | Yes | No |  |  |
| Base9 | money | Yes | No |  |  |
| Weight9 | decimal(9,5) | Yes | No |  |  |
| Base10 | money | Yes | No |  |  |
| Weight10 | decimal(9,5) | Yes | No |  |  |



**Primary Key:** MSRPExcelImportId





**Indexes:**
- PK_MSRPExcelImport (CLUSTERED): MSRPExcelImportId




### dbo.MSRPOptions



**Rows:** 12

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| MSRPOptionId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| MSRPOptionName | varchar(50) | No | No |  |  |



**Primary Key:** MSRPOptionId





**Indexes:**
- PK__MSRPOpti__FBF27A777BA25A27 (CLUSTERED): MSRPOptionId
- SKI_Name_OptionId (NONCLUSTERED): MSRPOptionId, Active, MSRPOptionName




### dbo.NextNumber



**Rows:** 24,004

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| NextNumberId | int | No | Yes |  |  |
| DistrictId | int | Yes | No |  |  |
| SchoolId | int | Yes | No |  |  |
| BudgetId | int | Yes | No |  |  |
| IdType | char(1) | Yes | No |  |  |
| Prefix | varchar(20) | Yes | No |  |  |
| Suffix | varchar(20) | Yes | No |  |  |
| NextNumber | int | Yes | No |  |  |
| SuppressLZ | tinyint | Yes | No |  |  |
| NumberLength | tinyint | Yes | No |  |  |
| FFMessage | varchar(4096) | Yes | No |  |  |
| EndNumber | int | Yes | No |  |  |
| ActualNumber | tinyint | Yes | No |  |  |



**Primary Key:** NextNumberId





**Indexes:**
- PK_ReqPONext (CLUSTERED): NextNumberId
- _dta_index_NextNumber_7_1182679311__K4_K5_3_11 (NONCLUSTERED): SchoolId, FFMessage, BudgetId, IdType
- IX_NextNumber_Composite (NONCLUSTERED): Prefix, Suffix, NextNumber, DistrictId, SchoolId, BudgetId, IdType
- SK_BIS (NONCLUSTERED): BudgetId, IdType, SchoolId
- SK_IDType (NONCLUSTERED): IdType




### dbo.NotificationOptions



**Rows:** 4

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| NotificationOptionId | int | No | Yes |  |  |
| Name | varchar(50) | No | No |  |  |



**Primary Key:** NotificationOptionId





**Indexes:**
- PK__Notifica__EC3B5DF0BADE7CE9 (CLUSTERED): NotificationOptionId




### dbo.Notifications



**Rows:** 720

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| NotificationId | bigint | No | Yes |  |  |
| UserId | bigint | No | No |  |  |
| Email | varchar(300) | No | No |  |  |
| DateSent | datetime | Yes | No |  |  |
| NotificationType | varchar(50) | Yes | No |  |  |
| EmailBlastId | int | Yes | No |  |  |
| EmailHTMLTable | varchar(MAX) | Yes | No |  |  |







**Indexes:**
- PK_Notifications (CLUSTERED): NotificationId




### dbo.OBPrices



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ItemId | int | No | No |  |  |
| PackedCode | varchar(50) | Yes | No |  |  |
| CrossRefId | int | Yes | No |  |  |
| CrossRefIdBid | int | Yes | No |  |  |
| BidPrice | money | Yes | No |  |  |
| GrossPrice | money | Yes | No |  |  |
| CatalogPrice | money | Yes | No |  |  |
| AwardId | int | No | No |  |  |
| VendorId | int | No | No |  |  |
| PricePlanId | int | Yes | No |  |  |
| CatalogId | int | Yes | No |  |  |
| VendorItemCode | varchar(50) | Yes | No |  |  |
| ParentCatalogId | int | Yes | No |  |  |
| ItemCode | varchar(50) | Yes | No |  |  |
| Description | varchar(1024) | Yes | No |  |  |
| UnitId | int | Yes | No |  |  |
| UnitCode | varchar(20) | Yes | No |  |  |
| PriceId | int | Yes | No |  |  |
| Page | char(4) | Yes | No |  |  |
| DiscountRate | decimal(9,5) | Yes | No |  |  |
| Name | varchar(50) | Yes | No |  |  |
| VendorName | varchar(50) | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| PackedItemCode | varchar(50) | Yes | No |  |  |
| BidItemId | int | Yes | No |  |  |
| Alternate | varchar(1024) | Yes | No |  |  |
| PackedVendorItemCode | varchar(255) | Yes | No |  |  |
| CatalogYear | char(2) | Yes | No |  |  |







**Indexes:**
- SK_Award (NONCLUSTERED): AwardId
- SK_BidItem (NONCLUSTERED): BidItemId
- SK_Category (NONCLUSTERED): CategoryId
- SK_Item (NONCLUSTERED): ItemId
- SK_PPCat (NONCLUSTERED): PricePlanId, CategoryId
- SK_PricePlan (NONCLUSTERED): PricePlanId
- SK_Vendor (NONCLUSTERED): VendorId




### dbo.OBView



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| OBDWorkId | int | No | Yes |  |  |
| Title | varchar(255) | Yes | No |  |  |
| HeadingDescription | varchar(4096) | Yes | No |  |  |
| ItemCode | varchar(32) | Yes | No |  |  |
| ItemDescription | varchar(1024) | Yes | No |  |  |
| UnitCode | varchar(10) | Yes | No |  |  |
| BidPrice | money | Yes | No |  |  |
| PricePlanDescription | varchar(255) | Yes | No |  |  |
| CatalogPage | varchar(4) | Yes | No |  |  |
| CatalogYear | char(2) | Yes | No |  |  |
| VendorCode | varchar(16) | Yes | No |  |  |
| VendorName | varchar(255) | Yes | No |  |  |
| VendorItemCode | varchar(32) | Yes | No |  |  |
| Alternate | varchar(1024) | Yes | No |  |  |
| Category | varchar(255) | Yes | No |  |  |
| TotalQuantity | int | Yes | No |  |  |
| TotalRequisitions | int | Yes | No |  |  |
| DistrictUsed | int | Yes | No |  |  |
| ExpandAll | tinyint | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |
| HeadingId | int | Yes | No |  |  |
| BidItemId | int | Yes | No |  |  |
| Weight | int | Yes | No |  |  |
| SortSeq | varchar(64) | Yes | No |  |  |
| LYQty | int | Yes | No |  |  |
| MustKeep | int | Yes | No |  |  |
| GrossPrice | money | Yes | No |  |  |
| BidDiscountRate | decimal(9,5) | Yes | No |  |  |
| CatalogDiscountRate | decimal(9,5) | Yes | No |  |  |
| Compliant | tinyint | Yes | No |  |  |



**Primary Key:** OBDWorkId





**Indexes:**
- PK__OBView__744F2D60 (CLUSTERED): OBDWorkId




### dbo.Options



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| OptionId | int | No | No |  |  |
| Active | tinyint | Yes | No |  |  |
| Name | varchar(30) | Yes | No |  |  |
| OptionType | varchar(40) | Yes | No |  |  |



**Primary Key:** OptionId





**Indexes:**
- PK_Options (CLUSTERED): OptionId




### dbo.OptionsLink



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| OptionLinkId | int | No | No |  |  |
| OptionId | int | Yes | No |  |  |
| LinkId | int | Yes | No |  |  |
| Value | varchar(255) | Yes | No |  |  |



**Primary Key:** OptionLinkId





**Indexes:**
- PK_OptionsLink (CLUSTERED): OptionLinkId




### dbo.OrderBookAlwaysAdd



**Rows:** 9

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| OBAAId | int | No | Yes |  |  |
| CategoryId | int | Yes | No |  |  |
| ItemCode | varchar(32) | Yes | No |  |  |



**Primary Key:** OBAAId





**Indexes:**
- PK_OrderBookAlwaysAdd (CLUSTERED): OBAAId




### dbo.OrderBookDetail



**Rows:** 36,990,046

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| OrderBookDetailId | int | No | Yes |  |  |
| OrderBookId | int | Yes | No |  |  |
| Active | tinyint | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |
| BidItemId | int | Yes | No |  |  |
| Weight | int | Yes | No |  |  |
| BasePrice | money | Yes | No |  |  |
| CatalogId | int | Yes | No |  |  |
| CrossRefId | int | Yes | No |  |  |
| BidPrice | money | Yes | No |  |  |
| GrossPrice | money | Yes | No |  |  |
| CatalogPrice | money | Yes | No |  |  |
| DiscountRate | decimal(9,5) | Yes | No |  |  |
| CatalogPage | varchar(4) | Yes | No |  |  |
| CatalogYear | varchar(2) | Yes | No |  |  |
| VendorCode | varchar(16) | Yes | No |  |  |
| VendorName | varchar(255) | Yes | No |  |  |
| VendorItemCode | varchar(50) | Yes | No |  |  |
| Alternate | varchar(1024) | Yes | No |  |  |
| AwardId | int | Yes | No |  |  |
| ParentAwardId | int | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |



**Primary Key:** OrderBookDetailId





**Indexes:**
- PK_OrderBookDetail (CLUSTERED): OrderBookDetailId
- SKI_OrderBook_Item (NONCLUSTERED): ItemId, OrderBookId
- ti_CrossRef_OrderBookDetailId (NONCLUSTERED): OrderBookDetailId, CrossRefId




### dbo.OrderBookDetailOld



**Rows:** 187,630,151

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| OrderBookDetailId | int | No | Yes |  |  |
| OrderBookId | int | Yes | No |  |  |
| Active | tinyint | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |
| BidItemId | int | Yes | No |  |  |
| Weight | int | Yes | No |  |  |
| BasePrice | money | Yes | No |  |  |
| CatalogId | int | Yes | No |  |  |
| CrossRefId | int | Yes | No |  |  |
| BidPrice | money | Yes | No |  |  |
| GrossPrice | money | Yes | No |  |  |
| CatalogPrice | money | Yes | No |  |  |
| DiscountRate | decimal(9,5) | Yes | No |  |  |
| CatalogPage | varchar(4) | Yes | No |  |  |
| CatalogYear | varchar(2) | Yes | No |  |  |
| VendorCode | varchar(16) | Yes | No |  |  |
| VendorName | varchar(255) | Yes | No |  |  |
| VendorItemCode | varchar(50) | Yes | No |  |  |
| Alternate | varchar(1024) | Yes | No |  |  |
| AwardId | int | Yes | No |  |  |
| ParentAwardId | int | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |



**Primary Key:** OrderBookDetailId





**Indexes:**
- PK_OrderBookDetailOld (CLUSTERED): OrderBookDetailId
- SK_IPKey1 (NONCLUSTERED): OrderBookDetailId, ItemId, BidItemId, Weight, CatalogId, CrossRefId, BidPrice, CatalogPage, CatalogYear, VendorCode, VendorName, VendorItemCode, AwardId, OrderBookId, Active
- SK_OrderBook (NONCLUSTERED): OrderBookId
- SK_OrderBookItem (NONCLUSTERED): OrderBookDetailId, BidItemId, OrderBookId, ItemId
- SKI_OrderBook_OBDetailVendorCodeNameId (NONCLUSTERED): OrderBookDetailId, VendorCode, VendorName, VendorId, OrderBookId




### dbo.OrderBookLog



**Rows:** 474,243

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| OrderBookLogId | int | No | Yes |  |  |
| Printed | datetime | Yes | No |  |  |
| OrderBookId | int | Yes | No |  |  |
| DistrictId | int | Yes | No |  |  |
| SchoolId | int | Yes | No |  |  |
| UserId | int | Yes | No |  |  |
| ItemsPrinted | int | Yes | No |  |  |
| PagesPrinted | int | Yes | No |  |  |
| Device | varchar(255) | Yes | No |  |  |



**Primary Key:** OrderBookLogId





**Indexes:**
- PK__OrderBookLog__3528CC84 (CLUSTERED): OrderBookLogId




### dbo.OrderBooks



**Rows:** 29,920

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| OrderBookId | int | No | Yes |  |  |
| PricePlanDescription | varchar(255) | Yes | No |  |  |
| Category | varchar(255) | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| PricePlanId | int | Yes | No |  |  |
| AwardId | int | Yes | No |  |  |
| Type | char(1) | Yes | No |  |  |
| DistrictId | int | Yes | No |  |  |
| Markup | decimal(9,5) | Yes | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| OrderBookYear | int | Yes | No |  |  |
| OrderBookCreated | datetime | Yes | No |  |  |
| Active | int | Yes | No |  |  |
| MasterBook | int | Yes | No |  |  |
| MasterLetter | char(1) | Yes | No |  |  |
| UseParentCatalog | int | Yes | No |  |  |
| KeepZeroPages | int | Yes | No |  |  |



**Primary Key:** OrderBookId





**Indexes:**
- PK_OrderBooks (CLUSTERED): OrderBookId




### dbo.OrderBookTypes



**Rows:** 12

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| OrderBookTypeId | int | No | Yes |  |  |
| Description | varchar(255) | Yes | No |  |  |
| PrintMode | int | Yes | No |  |  |
| UseOnlineFormat | tinyint | Yes | No |  |  |



**Primary Key:** OrderBookTypeId





**Indexes:**
- PK__OrderBookTypes__7405149D (CLUSTERED): OrderBookTypeId




### dbo.Payments



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| PaymentId | int | No | Yes |  |  |
| DistrictId | int | No | No |  |  |
| InvoiceId | int | Yes | No |  |  |
| PaymentTypeId | int | No | No |  |  |
| PaymentDate | datetime | No | No |  |  |
| Amount | money | Yes | No |  |  |
| Comments | varchar(4096) | Yes | No |  |  |



**Primary Key:** PaymentId





**Indexes:**
- PK__Payments__22F50DB0 (CLUSTERED): PaymentId




### dbo.PaymentTypes



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| PaymentTypeId | int | No | Yes |  |  |
| Description | varchar(50) | No | No |  |  |



**Primary Key:** PaymentTypeId





**Indexes:**
- PK__PaymentTypes__210CC53E (CLUSTERED): PaymentTypeId




### dbo.PendingApprovals



**Rows:** 542,030

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| SysId | int | No | Yes |  |  |
| SessionId | int | Yes | No |  |  |
| SchoolId | int | Yes | No |  |  |
| UserId | int | Yes | No |  |  |
| RequisitionId | int | Yes | No |  |  |
| BudgetId | int | Yes | No |  |  |
| AccountId | int | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| StatusId | int | Yes | No |  |  |
| Amount | money | Yes | No |  |  |
| ApprovalLevel | tinyint | Yes | No |  |  |
| ApprovalDate | datetime | Yes | No |  |  |
| LastApprovalId | int | Yes | No |  |  |
| NextApproverId | int | Yes | No |  |  |
| LastApproverId | int | Yes | No |  |  |



**Primary Key:** SysId





**Indexes:**
- PK_PendingApprovals (CLUSTERED): SysId
- SK_LastApproval (NONCLUSTERED): LastApprovalId
- SK_SessionId (NONCLUSTERED): SessionId
- SK_SessionNextApproverStatus (NONCLUSTERED): SessionId, NextApproverId, StatusId
- SK_SessionRequisition (NONCLUSTERED): SessionId, RequisitionId




### dbo.PO



**Rows:** 2,455,005

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| POId | int | No | Yes |  |  |
| RequisitionId | int | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| PONumber | varchar(24) | Yes | No |  |  |
| PODate | datetime | Yes | No |  |  |
| DatePrinted | datetime | Yes | No |  |  |
| DatePrintedDetail | datetime | Yes | No |  |  |
| DateExported | datetime | Yes | No |  |  |
| DateOrdered | datetime | Yes | No |  |  |
| DateReceived | datetime | Yes | No |  |  |
| Amount | money | Yes | No |  |  |
| ItemCount | int | Yes | No |  |  |
| AwardId | int | Yes | No |  |  |
| DiscountAmount | money | Yes | No |  |  |
| TotalGross | money | Yes | No |  |  |
| DiscountRate | decimal(9,5) | Yes | No |  |  |
| ShippingAmount | money | Yes | No |  |  |
| ExportedToVendor | datetime | Yes | No |  |  |
| UploadId | int | Yes | No |  |  |
| Cancelled | tinyint | Yes | No |  |  |
| POStatusID | int | Yes | No |  |  |
| isActualNumber | tinyint | Yes | No |  |  |
| ePOSuppressed | tinyint | Yes | No |  |  |



**Primary Key:** POId



**Foreign Keys:**
- RequisitionId → dbo.Requisitions.RequisitionId
- VendorId → dbo.Vendors.VendorId




**Indexes:**
- PK_PO (CLUSTERED): POId
- _dta_index_PO_7_1070678912__K2_K1_K3_4_5_6_7_8_11_12_14_15_16_17_18 (NONCLUSTERED): PONumber, PODate, DatePrinted, DatePrintedDetail, DateExported, Amount, ItemCount, DiscountAmount, TotalGross, DiscountRate, ShippingAmount, ExportedToVendor, RequisitionId, POId, VendorId
- _dta_index_PO_7_1070678912__K3_K2_K19_K21 (NONCLUSTERED): VendorId, RequisitionId, UploadId, Cancelled
- SK__Vendor_ReqPONumber (NONCLUSTERED): POId, RequisitionId, PONumber, VendorId
- SK_Requisition (NONCLUSTERED): RequisitionId
- SK_ReqVen1 (NONCLUSTERED): RequisitionId, VendorId, POId, PONumber, PODate, DatePrinted, DatePrintedDetail, DateExported, Amount, ItemCount, DiscountAmount, TotalGross, DiscountRate, ShippingAmount
- SKI_Vendor_ReqUploadCancelled (NONCLUSTERED): RequisitionId, UploadId, Cancelled, VendorId




### dbo.PODetailItems



**Rows:** 24,290,269

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| PODetailItemId | int | No | Yes |  |  |
| POId | int | Yes | No |  |  |
| DetailId | int | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |
| Quantity | int | Yes | No |  |  |
| BidItemId | int | Yes | No |  |  |
| BidPrice | money | Yes | No |  |  |
| GrossPrice | money | Yes | No |  |  |
| DiscountRate | decimal(9,5) | Yes | No |  |  |
| AwardId | int | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| VendorItemCode | varchar(50) | Yes | No |  |  |
| Alternate | varchar(1024) | Yes | No |  |  |
| ContractNumber | varchar(50) | Yes | No |  |  |



**Primary Key:** PODetailItemId



**Foreign Keys:**
- DetailId → dbo.Detail.DetailId
- POId → dbo.PO.POId




**Indexes:**
- PK_PODetailItems (CLUSTERED): PODetailItemId
- SK_Detail (NONCLUSTERED): DetailId
- SK_PO (NONCLUSTERED): POId
- SKI_POVendor_Detail (NONCLUSTERED): DetailId, POId, VendorId
- SKI_POVendorDetailBidItem_Award (NONCLUSTERED): AwardId, POId, VendorId, DetailId, BidItemId




### dbo.POIDTable



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| POIDID | int | No | Yes |  |  |
| POID | int | No | No |  |  |
| DateCreated | datetime | Yes | No | (getdate()) |  |



**Primary Key:** POIDID





**Indexes:**
- PK__POIDTabl__9899C8AA58B78F44 (CLUSTERED): POIDID




### dbo.POLayoutDetail



**Rows:** 6,841

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| POLayoutDetailId | int | No | Yes |  |  |
| POLayoutId | int | No | No |  |  |
| POLayoutFieldId | int | Yes | No |  |  |
| VerticalPos | int | Yes | No |  |  |
| HorizontalPos | int | Yes | No |  |  |
| MaxWidth | int | Yes | No |  |  |
| MaxHeight | int | Yes | No |  |  |
| WrapAround | tinyint | Yes | No |  |  |
| Literal | varchar(512) | Yes | No |  |  |
| PrintWhen | tinyint | Yes | No |  |  |
| Image | varbinary(MAX) | Yes | No |  |  |



**Primary Key:** POLayoutDetailId





**Indexes:**
- PK_POLayoutDetail (CLUSTERED): POLayoutDetailId




### dbo.POLayoutFields



**Rows:** 56

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| POLayoutFieldId | int | No | Yes |  |  |
| POLayoutField | varchar(50) | Yes | No |  |  |
| POLayoutSource | varchar(4096) | Yes | No |  |  |
| POLayoutFieldType | tinyint | Yes | No |  |  |
| DetailField | tinyint | Yes | No |  |  |



**Primary Key:** POLayoutFieldId





**Indexes:**
- PK_POLayoutFields (CLUSTERED): POLayoutFieldId




### dbo.POLayouts



**Rows:** 630

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| POLayoutId | int | No | Yes |  |  |
| Name | varchar(50) | Yes | No |  |  |
| FormLength | int | Yes | No |  |  |
| FormWidth | int | Yes | No |  |  |
| ContinuousFeed | tinyint | Yes | No |  |  |
| Copies | int | Yes | No |  |  |
| FormType | int | Yes | No |  |  |



**Primary Key:** POLayoutId





**Indexes:**
- PK_POLayouts (CLUSTERED): POLayoutId




### dbo.POPageSummary



**Rows:** 73,456

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| POPageId | uniqueidentifier | No | No | (newsequentialid()) |  |
| DistrictId | int | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| POId | int | No | No |  |  |
| LineCount | int | Yes | No |  |  |
| PageCount | int | No | No |  |  |



**Primary Key:** POPageId





**Indexes:**
- PK_POPageSummary (CLUSTERED): POPageId




### dbo.POPrintTaggedPOFile



**Rows:** 120,930

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| RSID | int | Yes | No |  |  |
| DISTRICTID | int | Yes | No |  |  |
| PONUMBER | varchar(24) | Yes | No |  |  |
| POID | int | Yes | No |  |  |
| POOrderSeq | int | Yes | No |  |  |
| AccountId | int | Yes | No |  |  |
| AwardsBidHeaderId | int | Yes | No |  |  |
| BudgetName | varchar(30) | Yes | No |  |  |
| BudgetId | int | Yes | No |  |  |
| SysId | int | No | Yes |  |  |



**Primary Key:** SysId





**Indexes:**
- PK_POPrintTaggedPOFile (CLUSTERED): SysId
- SK_RSDistrictPOOrder (NONCLUSTERED): PONUMBER, AccountId, AwardsBidHeaderId, BudgetId, RSID, DISTRICTID, POOrderSeq
- TPF_BYRSID (NONCLUSTERED): RSID




### dbo.POQueue



**Rows:** 26,028

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| POQueueId | int | No | Yes |  |  |
| UserId | int | No | No |  |  |
| VendorId | int | No | No |  |  |
| SessionId | int | No | No |  |  |
| RequestDate | datetime | No | No | (getdate()) |  |
| SendStarted | datetime | Yes | No |  |  |
| SendEnded | datetime | Yes | No |  |  |
| SendAddress | varchar(512) | Yes | No |  |  |
| SendStatus | varchar(50) | Yes | No |  |  |
| EarliestDeliveryDate | date | Yes | No |  |  |
| RequestedDeliveryDate | date | Yes | No |  |  |
| OrderComments | varchar(4096) | Yes | No |  |  |



**Primary Key:** POQueueId





**Indexes:**
- PK__POQueue__91383C3E79617699 (CLUSTERED): POQueueId
- SK_QueueRequestDate (NONCLUSTERED): POQueueId, RequestDate




### dbo.POQueueItems



**Rows:** 396,069

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| POQueueItemId | int | No | Yes |  |  |
| POQueueId | int | No | No |  |  |
| POId | int | No | No |  |  |
| SendStarted | datetime | Yes | No |  |  |
| SendEnded | datetime | Yes | No |  |  |
| SendStatus | varchar(255) | Yes | No |  |  |
| PayloadId | varchar(255) | Yes | No |  |  |



**Primary Key:** POQueueItemId





**Indexes:**
- PK__POQueueI__1E7B80021701E1C0 (CLUSTERED): POQueueItemId
- SKI_POIdPOQueue_Started (NONCLUSTERED): SendStarted, POId, POQueueId
- SKI_Queue_Id (NONCLUSTERED): POQueueItemId, POQueueId




### dbo.POStatus



**Rows:** 403,736

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| POStatusId | int | No | Yes |  |  |
| POId | int | No | No |  |  |
| StatusDate | datetime | No | No | (getdate()) |  |
| StatusId | int | No | No |  |  |
| UserId | int | Yes | No |  |  |
| Comments | varchar(512) | Yes | No |  |  |



**Primary Key:** POStatusId





**Indexes:**
- PK__POStatus__DE88A18037256B49 (CLUSTERED): POStatusId
- SKI_PO_Status (NONCLUSTERED): StatusId, UserId, POId, StatusDate




### dbo.POStatusTable



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| POStatusID | int | No | Yes |  |  |
| StatusName | varchar(50) | Yes | No |  |  |



**Primary Key:** POStatusID





**Indexes:**
- PK__POStatus__F880A40749754BB4 (CLUSTERED): POStatusID




### dbo.PostCatalogDetail



**Rows:** 38,319

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| PostCatalogDetailId | int | No | Yes |  |  |
| PostCatalogHeaderId | int | Yes | No |  |  |
| PostInfoType | int | Yes | No |  |  |
| PostInfoDesc | varchar(100) | Yes | No |  |  |
| PostInfoValue | int | Yes | No |  |  |
| PostDateTime | datetime | Yes | No |  |  |



**Primary Key:** PostCatalogDetailId





**Indexes:**
- PK_PostCatalogDetail (CLUSTERED): PostCatalogDetailId




### dbo.PostCatalogHeader



**Rows:** 3,262

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| PostCatalogHeaderId | int | No | Yes |  |  |
| CatalogId | int | Yes | No |  |  |
| PostDateStart | datetime | Yes | No |  |  |
| PostDateComplete | datetime | Yes | No |  |  |



**Primary Key:** PostCatalogHeaderId





**Indexes:**
- PK_PostCatalogHeader (CLUSTERED): PostCatalogHeaderId




### dbo.POTemp



**Rows:** 37

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| POTempID | int | No | Yes |  |  |
| SessionID | int | No | No |  |  |









### dbo.POTempDetails



**Rows:** 4,014

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| POTempDetailID | int | No | Yes |  |  |
| POTempID | int | Yes | No |  |  |
| RequisitionID | int | No | No |  |  |
| VendorID | int | No | No |  |  |
| BidHeaderID | int | No | No |  |  |
| PONumber | varchar(50) | Yes | No |  |  |
| POPrefix | varchar(50) | Yes | No |  |  |
| POSuffix | varchar(50) | Yes | No |  |  |









### dbo.PPCatalogs



**Rows:** 1,660

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| PPCatalogId | int | No | Yes |  |  |
| PricePlanId | int | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| CatalogId | int | Yes | No |  |  |
| DiscountRate | decimal(5,2) | Yes | No |  |  |
| AwardId | int | Yes | No |  |  |



**Primary Key:** PPCatalogId





**Indexes:**
- PK_PPCatalogs (CLUSTERED): PPCatalogId
- SK_Cat (NONCLUSTERED): CategoryId
- SK_CatalogId (NONCLUSTERED): CatalogId
- SK_PPCat (NONCLUSTERED): PricePlanId, CategoryId, CatalogId
- SK_PricePlan (NONCLUSTERED): PricePlanId




### dbo.PPCategory



**Rows:** 1,453

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| PPCategoryId | int | No | Yes |  |  |
| PricePlanId | int | No | No |  |  |
| CategoryId | int | No | No |  |  |
| AllowAddenda | int | Yes | No |  |  |



**Primary Key:** PPCategoryId





**Indexes:**
- PK__CategoryPP__5E7FE7D2 (CLUSTERED): PPCategoryId
- SK_Category (NONCLUSTERED): CategoryId
- SK_PPCat (NONCLUSTERED): PricePlanId, CategoryId




### dbo.PriceHolds



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| PriceHoldId | int | No | Yes |  |  |
| DetailId | int | No | No |  |  |
| BidPrice | money | Yes | No |  |  |
| Quantity | int | Yes | No |  |  |



**Primary Key:** PriceHoldId





**Indexes:**
- PK__PriceHol__CC37109B40E005B3 (CLUSTERED): PriceHoldId




### dbo.PriceListTypes



**Rows:** 2

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| PriceListTypeId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| Name | varchar(50) | No | No |  |  |



**Primary Key:** PriceListTypeId





**Indexes:**
- PK__PriceLis__1D8486F504B9BEA7 (CLUSTERED): PriceListTypeId




### dbo.PricePlans



**Rows:** 584

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| PricePlanId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| Code | varchar(20) | Yes | No |  |  |
| Description | varchar(255) | Yes | No |  |  |
| LastAltered | datetime | Yes | No |  |  |
| LastUpdated | datetime | Yes | No |  |  |
| stateid | int | Yes | No |  |  |



**Primary Key:** PricePlanId





**Indexes:**
- PK_PricePlans (CLUSTERED): PricePlanId




### dbo.PriceRanges



**Rows:** 120,619

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| PriceRangeId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| CategoryId | int | No | No |  |  |
| ManufacturerId | int | Yes | No |  |  |
| ManufacturerProductLineId | int | Yes | No |  |  |
| RangeBase | money | Yes | No |  |  |
| RangeWeight | decimal(9,5) | Yes | No |  |  |
| MSRPOptionId | int | Yes | No |  |  |



**Primary Key:** PriceRangeId





**Indexes:**
- PK__PriceRan__B8A301DF1F38AAB9 (CLUSTERED): PriceRangeId




### dbo.Prices



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ItemId | int | No | No |  |  |
| PackedCode | varchar(50) | Yes | No |  |  |
| CrossRefId | int | Yes | No |  |  |
| CrossRefIdBid | int | Yes | No |  |  |
| BidPrice | decimal(34,13) | Yes | No |  |  |
| GrossPrice | money | Yes | No |  |  |
| CatalogPrice | money | Yes | No |  |  |
| AwardId | int | No | No |  |  |
| VendorId | int | No | No |  |  |
| PricePlanId | int | Yes | No |  |  |
| CatalogId | int | Yes | No |  |  |
| VendorItemCode | varchar(50) | Yes | No |  |  |
| ParentCatalogId | int | Yes | No |  |  |
| ItemCode | varchar(50) | Yes | No |  |  |
| Description | varchar(1024) | Yes | No |  |  |
| UnitId | int | Yes | No |  |  |
| UnitCode | varchar(20) | Yes | No |  |  |
| PriceId | uniqueidentifier | No | No | (newid()) |  |
| Page | char(4) | Yes | No |  |  |
| DiscountRate | decimal(9,5) | Yes | No |  |  |
| Name | varchar(50) | Yes | No |  |  |
| VendorName | varchar(50) | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| PackedItemCode | varchar(50) | Yes | No |  |  |
| BidItemId | int | Yes | No |  |  |
| Alternate | varchar(1024) | Yes | No |  |  |
| PackedVendorItemCode | varchar(255) | Yes | No |  |  |
| CatalogYear | char(2) | Yes | No |  |  |
| RedirectedItemId | int | Yes | No |  |  |
| BidHeaderId | int | Yes | No |  |  |



**Primary Key:** PriceId



**Foreign Keys:**
- BidItemId → dbo.BidItems_Old.BidItemId




**Indexes:**
- PK_Prices (CLUSTERED): PriceId




### dbo.PricingAddenda



**Rows:** 203,535

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| PricingAddendaId | bigint | No | Yes |  |  |
| CrossRefId | int | Yes | No |  |  |
| CatalogId | int | Yes | No |  |  |
| HeadingId | int | Yes | No |  |  |
| KeywordId | int | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| DistrictId | int | Yes | No |  |  |
| HeadingKeywordId | bigint | Yes | No |  |  |
| ListPrice | money | Yes | No |  |  |
| LastBidPrice | money | Yes | No |  |  |
| CatalogPrice | money | Yes | No |  |  |
| CatalogPage | char(4) | Yes | No |  |  |
| AwardId | int | Yes | No |  |  |
| BidType | tinyint | Yes | No |  |  |
| ItemBidType | varchar(32) | Yes | No |  |  |
| UnitId | int | Yes | No |  |  |
| Unitcode | varchar(20) | Yes | No |  |  |
| SortSeq | varchar(64) | Yes | No |  |  |
| FullDescription | varchar(4096) | Yes | No |  |  |
| PackedItemCode | varchar(50) | Yes | No |  |  |
| ItemCode | varchar(50) | Yes | No |  |  |
| VendorItemCode | varchar(50) | Yes | No |  |  |
| Manufacturer | varchar(50) | Yes | No |  |  |
| ManufacturerPartNumber | varchar(50) | Yes | No |  |  |
| ItemHeading | varchar(255) | Yes | No |  |  |
| ItemKeyword | varchar(50) | Yes | No |  |  |
| AllStringFields | varchar(6000) | Yes | No |  |  |



**Primary Key:** PricingAddendaId





**Indexes:**
- PK_PricingAddenda (CLUSTERED): PricingAddendaId
- SKI_CategoryHeadingKeywordDistrict_Id (NONCLUSTERED): PricingAddendaId, CategoryId, HeadingId, KeywordId, DistrictId
- ti_CrossRef_PricingAddendaId (NONCLUSTERED): PricingAddendaId, CrossRefId




### dbo.PricingConsolidatedOrderCounts



**Rows:** 401,387

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| PCOCId | bigint | No | Yes |  |  |
| BidHeaderId | int | No | No |  |  |
| ItemId | int | No | No |  |  |
| OrderCount | int | No | No |  |  |



**Primary Key:** PCOCId





**Indexes:**
- PK__PricingC__720259A0ACB8C0D2 (CLUSTERED): PCOCId
- SK_BidHeaderIdItemId (NONCLUSTERED): BidHeaderId, ItemId




### dbo.PricingMap



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| Id | uniqueidentifier | No | No | (newid()) |  |
| BidHeaderId | int | No | No |  |  |
| ItemId | int | No | No |  |  |
| MappedItemId | int | No | No |  |  |
| ItemCode | varchar(50) | Yes | No |  |  |
| PackedItemCode | varchar(50) | Yes | No |  |  |
| BidPrice | money | No | No |  |  |
| CatalogPrice | money | No | No |  |  |
| BidItemId | int | Yes | No |  |  |
| VendorId | int | No | No |  |  |
| VendorItemCode | varchar(50) | Yes | No |  |  |
| PackedVendorItemCode | varchar(50) | Yes | No |  |  |
| ManufacturerPartNumber | varchar(50) | Yes | No |  |  |
| PackedManufacturerPartNumber | varchar(50) | Yes | No |  |  |
| UnitId | int | No | No |  |  |
| UnitCode | varchar(16) | No | No |  |  |
| Alternate | varchar(512) | Yes | No |  |  |
| ItemDescription | varchar(1024) | Yes | No |  |  |
| SortSeq | varchar(64) | Yes | No |  |  |



**Primary Key:** Id





**Indexes:**
- PK__PricingM__3214EC0777224648 (CLUSTERED): Id




### dbo.PricingUpdate



**Rows:** 58,556

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| PricingUpdateId | int | No | Yes |  |  |
| BidHeaderId | int | No | No |  |  |
| LastUpdated | datetime | Yes | No |  |  |



**Primary Key:** PricingUpdateId





**Indexes:**
- PK__PricingU__40D9B4ECDC40BD26 (CLUSTERED): PricingUpdateId




### dbo.PrintDocuments



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| PrintDocumentId | int | No | Yes |  |  |
| Created | datetime | Yes | No | (getdate()) |  |
| Printed | datetime | Yes | No |  |  |
| RequestedBy | int | Yes | No |  |  |
| DistrictId | int | Yes | No |  |  |
| SchoolId | int | Yes | No |  |  |
| UserId | int | Yes | No |  |  |
| DocumentName | varchar(50) | Yes | No |  |  |
| DocumentType | varchar(50) | Yes | No |  |  |
| DocumentLength | int | Yes | No |  |  |
| DocumentPages | int | Yes | No |  |  |
| DocumentBody | varbinary(MAX) | Yes | No |  |  |



**Primary Key:** PrintDocumentId





**Indexes:**
- PK__PrintDoc__D48DBA3968C69B45 (CLUSTERED): PrintDocumentId




### dbo.Printers



**Rows:** 15

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| PrinterId | int | No | Yes |  |  |
| Name | varchar(50) | Yes | No |  |  |
| PrintPrefix | varchar(255) | Yes | No |  |  |
| PrintSuffix | varchar(255) | Yes | No |  |  |
| PrinterType | varchar(50) | Yes | No |  |  |
| PrintQueue | varchar(255) | Yes | No |  |  |



**Primary Key:** PrinterId





**Indexes:**
- PK_Printers (CLUSTERED): PrinterId




### dbo.ProjectTasks



**Rows:** 14

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ProjectTasksId | int | No | Yes |  |  |
| TaskSeqNum | int | Yes | No |  |  |
| TaskDescription | varchar(60) | Yes | No |  |  |
| PreReqSeqNum | int | Yes | No |  |  |
| OnlineTask | tinyint | Yes | No |  |  |
| BookletTask | tinyint | Yes | No |  |  |



**Primary Key:** ProjectTasksId





**Indexes:**
- PK_ProjectTasks (CLUSTERED): ProjectTasksId
- SK_Seq (NONCLUSTERED): TaskSeqNum




### dbo.QuestionnaireResponses



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| qrid | int | No | Yes |  |  |
| districtid | int | No | No |  |  |
| userid | int | No | No |  |  |
| qr1 | varchar(500) | Yes | No |  |  |
| qr2 | varchar(500) | Yes | No |  |  |
| qr3 | varchar(500) | Yes | No |  |  |
| qr4 | varchar(500) | Yes | No |  |  |
| qr5 | varchar(500) | Yes | No |  |  |
| qr6 | varchar(500) | Yes | No |  |  |
| qr7 | varchar(500) | Yes | No |  |  |
| qr8 | varchar(500) | Yes | No |  |  |
| qr9 | varchar(500) | Yes | No |  |  |
| qr10 | varchar(500) | Yes | No |  |  |
| qActionDate | datetime | No | No |  |  |



**Primary Key:** qrid





**Indexes:**
- PK_QuestionnaireResponses (CLUSTERED): qrid




### dbo.Rates



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| RateId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| ServiceId | int | No | No |  |  |
| BidId | int | No | No |  |  |
| BidQuantity | decimal(9,5) | No | No |  |  |
| RateTypeId | tinyint | No | No |  |  |
| RateUnitId | int | No | No |  |  |
| Rate | decimal(9,5) | Yes | No |  |  |
| BidCost | decimal(11,5) | Yes | No |  |  |
| Comments | text | Yes | No |  |  |



**Primary Key:** RateId





**Indexes:**
- PK__Rates__58A7CF5C1768EED4 (CLUSTERED): RateId




### dbo.RateTypes



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| RateTypeId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| Description | varchar(50) | No | No |  |  |



**Primary Key:** RateTypeId





**Indexes:**
- PK__RateType__B06796C80FC7CD0C (CLUSTERED): RateTypeId




### dbo.RateUnits



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| RateUnitId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| Description | varchar(50) | Yes | No |  |  |



**Primary Key:** RateUnitId





**Indexes:**
- PK__RateUnit__1AC7298A13985DF0 (CLUSTERED): RateUnitId




### dbo.Receiving



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ReceivingId | int | No | No |  |  |
| POId | int | Yes | No |  |  |
| DetailId | int | Yes | No |  |  |
| Quantity | int | Yes | No |  |  |
| DateReceived | datetime | Yes | No |  |  |
| Comments | varchar(1023) | Yes | No |  |  |



**Primary Key:** ReceivingId





**Indexes:**
- PK_Receiving (CLUSTERED): ReceivingId




### dbo.ReportSession



**Rows:** 5,182,125

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| RSId | int | No | Yes |  |  |
| RSData | varchar(4096) | Yes | No |  |  |
| ReportStarted | datetime | Yes | No |  |  |
| ReportEnded | datetime | Yes | No |  |  |
| ReportProcessorId | int | Yes | No |  |  |
| ReportOption | int | Yes | No |  |  |
| ReportRequestedBy | varchar(50) | Yes | No |  |  |
| ReportFile | varchar(255) | Yes | No |  |  |
| LastPrinted | datetime | Yes | No |  |  |
| PrintPages | int | Yes | No |  |  |
| PrintCopies | int | Yes | No |  |  |



**Primary Key:** RSId





**Indexes:**
- PK_ReportSession (CLUSTERED): RSId




### dbo.ReportSessionLinks



**Rows:** 51,472,536

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| RSLId | int | No | Yes |  |  |
| RSId | int | Yes | No |  |  |
| IntId | int | Yes | No |  |  |
| AuxId | int | Yes | No |  |  |



**Primary Key:** RSLId





**Indexes:**
- PK_ReportSessionLinks (CLUSTERED): RSLId
- RS_RSLink (NONCLUSTERED): RSId, IntId




### dbo.ReqAudit



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ReqAuditId | int | No | Yes |  |  |
| RequisitionId | int | Yes | No |  |  |
| DetailId | int | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |
| FieldName | varchar(50) | Yes | No |  |  |
| PreviousValue | varchar(255) | Yes | No |  |  |
| NewValue | varchar(255) | Yes | No |  |  |



**Primary Key:** ReqAuditId





**Indexes:**
- PK_ReqAudit (CLUSTERED): ReqAuditId




### dbo.RequisitionChangeLog



**Rows:** 1,938,483

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| RequisitionChangeId | int | No | Yes |  |  |
| RequisitionId | int | No | No |  |  |
| OrigSchoolId | int | Yes | No |  |  |
| OrigUserId | int | Yes | No |  |  |
| OrigBudgetId | int | Yes | No |  |  |
| OrigBudgetAccountId | int | Yes | No |  |  |
| OrigUserAccountId | int | Yes | No |  |  |
| OrigCategoryId | int | Yes | No |  |  |
| OrigShippingId | int | Yes | No |  |  |
| OrigAttention | varchar(50) | Yes | No |  |  |
| OrigAccountCode | varchar(50) | Yes | No |  |  |
| OrigBidHeaderId | int | Yes | No |  |  |
| NewSchoolId | int | Yes | No |  |  |
| NewUserId | int | Yes | No |  |  |
| NewBudgetId | int | Yes | No |  |  |
| NewBudgetAccountId | int | Yes | No |  |  |
| NewUserAccountId | int | Yes | No |  |  |
| NewCategoryId | int | Yes | No |  |  |
| NewShippingId | int | Yes | No |  |  |
| NewAttention | varchar(50) | Yes | No |  |  |
| NewAccountCode | varchar(50) | Yes | No |  |  |
| NewBidHeaderId | int | Yes | No |  |  |
| UserId | int | Yes | No |  |  |
| SessionId | int | Yes | No |  |  |
| ChangeDate | datetime | Yes | No |  |  |



**Primary Key:** RequisitionChangeId





**Indexes:**
- PK__RequisitionChang__2843D2B2 (CLUSTERED): RequisitionChangeId




### dbo.RequisitionNoteEmails



**Rows:** 15,931

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| RequisitionNoteEmailID | int | No | Yes |  |  |
| RequisitionNoteID | int | No | No |  |  |
| UserID | int | No | No |  |  |



**Primary Key:** RequisitionNoteEmailID





**Indexes:**
- PK__Requisit__234DFCF713193B03 (CLUSTERED): RequisitionNoteEmailID




### dbo.RequisitionNotes



**Rows:** 24,347

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| RequisitionNoteID | int | No | Yes |  |  |
| RequisitionID | int | No | No |  |  |
| Note | varchar(MAX) | Yes | No |  |  |
| CreateDate | datetime | No | No |  |  |
| CreatedByUserID | int | No | No |  |  |



**Primary Key:** RequisitionNoteID





**Indexes:**
- PK__Requisit__4A9C7A5E0F48AA1F (CLUSTERED): RequisitionNoteID
- SK_RequisitionId (NONCLUSTERED): RequisitionID




### dbo.Requisitions



**Rows:** 2,035,106

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| RequisitionId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| RequisitionNumber | varchar(24) | Yes | No |  |  |
| SchoolId | int | Yes | No |  |  |
| UserId | int | Yes | No |  |  |
| BudgetId | int | Yes | No |  |  |
| BudgetAccountId | int | Yes | No |  |  |
| UserAccountId | int | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| ShippingId | int | Yes | No |  |  |
| Attention | varchar(50) | Yes | No |  |  |
| AccountCode | varchar(50) | Yes | No |  |  |
| DateEntered | datetime | Yes | No |  |  |
| ShippingPercent | decimal(9,5) | Yes | No |  |  |
| DiscountPercent | decimal(9,5) | Yes | No |  |  |
| ShippingCost | money | Yes | No |  |  |
| TotalItemsCost | money | Yes | No |  |  |
| TotalRequisitionCost | money | Yes | No |  |  |
| Comments | varchar(1023) | Yes | No |  |  |
| ApprovalRequired | tinyint | Yes | No |  |  |
| ApprovalId | int | Yes | No |  |  |
| ApprovalLevel | tinyint | Yes | No |  |  |
| StatusId | int | Yes | No |  |  |
| OrderDate | datetime | Yes | No |  |  |
| DateExported | datetime | Yes | No |  |  |
| BidId | int | Yes | No |  |  |
| BookId | int | Yes | No |  |  |
| SourceId | int | Yes | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| LastAlteredSessionId | int | Yes | No |  |  |
| DateUpdated | datetime | Yes | No | (getdate()) |  |
| OrderType | tinyint | Yes | No |  |  |
| NotesCount | int | Yes | No |  |  |
| AddendaTotal | money | Yes | No |  |  |
| ApprovalCount | int | Yes | No |  |  |
| AdditionalFreight | tinyint | Yes | No |  |  |
| HistoryCount | int | Yes | No |  |  |
| POCount | int | Yes | No |  |  |
| LowPOCount | int | Yes | No |  |  |
| AdditionalShippingCost | money | Yes | No |  |  |



**Primary Key:** RequisitionId



**Foreign Keys:**
- BudgetId → dbo.Budgets.BudgetId
- CategoryId → dbo.Category.CategoryId




**Indexes:**
- PK_Requisitions (CLUSTERED): RequisitionId
- _dta_index_Requisitions_7_354152357__K4_K1_K6_K10_K5_K9_K7_K29_K8_3_11 (NONCLUSTERED): RequisitionNumber, Attention, SchoolId, RequisitionId, BudgetId, ShippingId, UserId, CategoryId, BudgetAccountId, BidHeaderId, UserAccountId
- Requisitions9 (NONCLUSTERED): UserAccountId
- SK_BidHeader (NONCLUSTERED): BidHeaderId
- SK_Budget (NONCLUSTERED): RequisitionId, BidHeaderId, BudgetId
- SK_BudgetAccount (NONCLUSTERED): BudgetAccountId
- SK_BudgetUser (NONCLUSTERED): BudgetId, UserId
- SK_CatBudget (NONCLUSTERED): CategoryId, BudgetId
- SK_Category (NONCLUSTERED): CategoryId
- SK_CatSchool (NONCLUSTERED): CategoryId, SchoolId
- SK_ReqBudget (NONCLUSTERED): RequisitionNumber, BudgetAccountId, UserAccountId, CategoryId, ShippingId, Attention, BidHeaderId, RequisitionId, BudgetId
- SK_RUBBaCSRnAAc (NONCLUSTERED): RequisitionId, UserId, BudgetId, BudgetAccountId, CategoryId, ShippingId, RequisitionNumber, Attention, AccountCode
- SK_SchoolId (NONCLUSTERED): SchoolId
- SK_User (NONCLUSTERED): BudgetId, CategoryId, UserId
- SKI_BudgetAccountShippingUserSchool_ReqNbr (NONCLUSTERED): RequisitionNumber, BudgetAccountId, ShippingId, UserId, SchoolId
- SKI_BudgetCategory_Etc (NONCLUSTERED): RequisitionNumber, SchoolId, UserId, BudgetAccountId, UserAccountId, ShippingId, Attention, BidHeaderId, BudgetId, CategoryId, RequisitionId
- SKI_CategoryEntered_UserBudgetBid (NONCLUSTERED): UserId, BudgetId, BidHeaderId, CategoryId, DateEntered
- SKI_UserAccount_Req (NONCLUSTERED): SchoolId, UserId, BudgetId, BudgetAccountId, CategoryId, ShippingId, DateEntered, BidHeaderId, OrderType, UserAccountId, RequisitionId




### dbo.ResetPasswordTracking



**Rows:** 76,042

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| UserIds | varchar(255) | No | No |  |  |
| SchoolId | int | No | No |  |  |
| DistrictId | int | No | No |  |  |
| Email | varchar(255) | Yes | No |  |  |
| ResetPasswordCode | varchar(8) | Yes | No |  |  |
| Action | varchar(100) | Yes | No |  |  |
| InsertAt | datetime | Yes | No | (getdate()) |  |
| ErrorMsg | varchar(MAX) | Yes | No |  |  |
| Description | varchar(MAX) | Yes | No |  |  |







**Indexes:**
- IX_ResetPasswordTracking_ResetCode (NONCLUSTERED): UserIds, SchoolId, DistrictId, Email, ResetPasswordCode




### dbo.Rights



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| RightsId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| Code | varchar(255) | Yes | No |  |  |
| Description | varchar(255) | Yes | No |  |  |



**Primary Key:** RightsId





**Indexes:**
- PK_Rights (CLUSTERED): RightsId




### dbo.RightsLink



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| RightsLinkId | int | No | Yes |  |  |
| RightsId | int | Yes | No |  |  |
| LinkId | int | Yes | No |  |  |
| Value | varchar(255) | Yes | No |  |  |



**Primary Key:** RightsLinkId





**Indexes:**
- PK_RightsLink (CLUSTERED): RightsLinkId




### dbo.RTK_2010NJHSL



**Rows:** 3,322

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| Substance Number | nvarchar(255) | Yes | No |  |  |
| Common Name | nvarchar(255) | Yes | No |  |  |
| Chemical Name | nvarchar(255) | Yes | No |  |  |
| CAS Number | nvarchar(255) | Yes | No |  |  |
| DOT Number | nvarchar(255) | Yes | No |  |  |
| SHHS List | nvarchar(255) | Yes | No |  |  |
| synonym | nvarchar(255) | Yes | No |  |  |
| Source 1 | nvarchar(255) | Yes | No |  |  |
| CA | nvarchar(255) | Yes | No |  |  |
| CO | nvarchar(255) | Yes | No |  |  |
| MU | nvarchar(255) | Yes | No |  |  |
| TE | nvarchar(255) | Yes | No |  |  |
| F4 | nvarchar(255) | Yes | No |  |  |
| F3 | nvarchar(255) | Yes | No |  |  |
| F2 | nvarchar(255) | Yes | No |  |  |
| R4 | nvarchar(255) | Yes | No |  |  |
| R3 | nvarchar(255) | Yes | No |  |  |
| R2 | nvarchar(255) | Yes | No |  |  |
| R1 | nvarchar(255) | Yes | No |  |  |
| Source 2 | nvarchar(255) | Yes | No |  |  |
| Source 3 | nvarchar(255) | Yes | No |  |  |
| Source 4 | nvarchar(255) | Yes | No |  |  |
| Source 5 | nvarchar(255) | Yes | No |  |  |
| Source 6 | nvarchar(255) | Yes | No |  |  |
| Source 7 | nvarchar(255) | Yes | No |  |  |
| Source 8 | nvarchar(255) | Yes | No |  |  |
| Source 14 | nvarchar(255) | Yes | No |  |  |
| Source 15 | nvarchar(255) | Yes | No |  |  |
| Source 17 | nvarchar(255) | Yes | No |  |  |
| Source 18 | nvarchar(255) | Yes | No |  |  |
| Source 19 | nvarchar(255) | Yes | No |  |  |
| Source 20 | nvarchar(255) | Yes | No |  |  |
| Source 21 | nvarchar(255) | Yes | No |  |  |
| Source 22 | nvarchar(255) | Yes | No |  |  |
| non prefix | nvarchar(255) | Yes | No |  |  |









### dbo.RTK_CASFile



**Rows:** 7,881

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| RTK_CASFileId | int | No | Yes |  |  |
| CASRegNo | varchar(11) | No | No |  |  |
| CASChemicalName | varchar(50) | Yes | No |  |  |
| DOT_Id | char(4) | Yes | No |  |  |
| SubstanceNo | char(4) | Yes | No |  |  |
| TradeSecretNo | varchar(20) | Yes | No |  |  |
| LegacyCASRegNo | varchar(12) | Yes | No |  |  |
| CompoundContaining | varchar(11) | Yes | No |  |  |
| SpecialHealthHazard | tinyint | Yes | No |  |  |
| Carcinogen | tinyint | Yes | No |  |  |
| Mutagen | tinyint | Yes | No |  |  |
| Teratogen | tinyint | Yes | No |  |  |
| Corrosive | tinyint | Yes | No |  |  |
| F4_Flammable4th | tinyint | Yes | No |  |  |
| F3_Flammable3rd | tinyint | Yes | No |  |  |
| R4_Reactive4th | tinyint | Yes | No |  |  |
| R3_Reactive3rd | tinyint | Yes | No |  |  |
| R2_Reactive2nd | tinyint | Yes | No |  |  |
| SpecialHealthHazardCodes | varchar(30) | Yes | No |  |  |



**Primary Key:** RTK_CASFileId





**Indexes:**
- PK_RTK_CASFile (CLUSTERED): RTK_CASFileId




### dbo.RTK_ContainerCodes



**Rows:** 21

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ContainerCodesID | int | No | Yes |  |  |
| ContainerCode | char(2) | No | No |  |  |
| ContainerAltCode | char(2) | Yes | No |  |  |
| ContainerDesc | varchar(30) | Yes | No |  |  |



**Primary Key:** ContainerCodesID





**Indexes:**
- PK_RTK_ContainerCodes (CLUSTERED): ContainerCodesID




### dbo.RTK_Documents



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| RTKDocumentId | uniqueidentifier | No | No | (newid()) |  |
| DistrictId | int | No | No |  |  |
| FacilityId | int | Yes | No |  |  |
| SchoolId | int | Yes | No |  |  |
| UserId | int | Yes | No |  |  |
| DocumentId | uniqueidentifier | No | No |  |  |
| Description | varchar(1024) | No | No |  |  |
| ValidFrom | datetime | Yes | No |  |  |
| ValidUntil | datetime | Yes | No |  |  |
| Created | datetime | No | No | (getdate()) |  |
| Updated | datetime | Yes | No |  |  |
| Deleted | datetime | Yes | No |  |  |



**Primary Key:** RTKDocumentId





**Indexes:**
- PK__RTK_Docu__D61B7C4C075678D3 (CLUSTERED): RTKDocumentId




### dbo.RTK_FactSheets



**Rows:** 2,459

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| RTKFactSheetId | uniqueidentifier | No | No | (newid()) |  |
| SubstanceNumber | int | No | No |  |  |
| CommonName | varchar(255) | No | No |  |  |
| ChemicalName | varchar(255) | No | No |  |  |
| CASNumber | varchar(20) | Yes | No |  |  |
| DOTNumber | varchar(10) | Yes | No |  |  |
| HazardCodes | varchar(50) | Yes | No |  |  |
| Created | datetime | No | No | (getdate()) |  |
| Updated | datetime | No | No | (getdate()) |  |
| Deleted | datetime | Yes | No |  |  |



**Primary Key:** RTKFactSheetId





**Indexes:**
- PK__RTK_Fact__C8B2BFBC12C82B7F (CLUSTERED): RTKFactSheetId




### dbo.RTK_HealthHazardCodes



**Rows:** 9

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| HealthHazardCodesID | int | No | Yes |  |  |
| HealthHazardCode | char(2) | No | No |  |  |
| Description | varchar(30) | Yes | No |  |  |



**Primary Key:** HealthHazardCodesID





**Indexes:**
- PK_RTK_HealthHazardCodes (CLUSTERED): HealthHazardCodesID




### dbo.RTK_Inventories



**Rows:** 658

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| RTK_InventoryId | int | No | Yes |  |  |
| RTK_SiteId | int | No | No |  |  |
| RTK_InventoryDate | date | Yes | No |  |  |
| RTK_InventoryYear | int | Yes | No |  |  |
| RTK_InventoryBy | varchar(255) | Yes | No |  |  |
| RTK_InventoryNotes | varchar(MAX) | Yes | No |  |  |



**Primary Key:** RTK_InventoryId





**Indexes:**
- PK__RTK_Inve__A3434811D0E797E1 (CLUSTERED): RTK_InventoryId




### dbo.RTK_InventoryRangeCodes



**Rows:** 12

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| InventoryRangeCodesID | int | No | Yes |  |  |
| RangeCode | char(2) | No | No |  |  |
| BegRange | int | Yes | No |  |  |
| EndRange | int | Yes | No |  |  |
| Description | varchar(25) | Yes | No |  |  |



**Primary Key:** InventoryRangeCodesID





**Indexes:**
- PK_RTK_InventoryRangeCodes (CLUSTERED): InventoryRangeCodesID




### dbo.RTK_Items



**Rows:** 64,627

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| RTK_ItemsId | int | No | Yes |  |  |
| CategoryId | int | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |
| LegacyCometCode | varchar(16) | Yes | No |  |  |
| AlternateDesc | varchar(60) | Yes | No |  |  |
| CaseCount | int | Yes | No |  |  |
| MeasurePct | decimal(9,5) | Yes | No |  |  |
| ContainerCodesId | int | Yes | No |  |  |
| UOMCodesId | int | Yes | No |  |  |
| OtherContainerDesc | varchar(20) | Yes | No |  |  |
| LegacyCometDesc | varchar(60) | Yes | No |  |  |
| MSDSId | int | Yes | No |  |  |
| ItemCode | varchar(50) | Yes | No |  |  |
| RTK_PurposeId | int | Yes | No |  |  |
| Manufacturer | varchar(50) | Yes | No |  |  |



**Primary Key:** RTK_ItemsId





**Indexes:**
- PK_RTK_ItemsId (CLUSTERED): RTK_ItemsId
- KeyLegacyCometCode (NONCLUSTERED): LegacyCometCode
- SK_CategoryItem (NONCLUSTERED): CategoryId, ItemId
- SKI_Item_Codes (NONCLUSTERED): RTK_ItemsId, ContainerCodesId, UOMCodesId, MSDSId, ItemId
- SKI_MSDS_ItemId (NONCLUSTERED): RTK_ItemsId, ItemId, MSDSId
- SKI_MSDSCategory_Item (NONCLUSTERED): RTK_ItemsId, MSDSId, CategoryId
- SKI_MSDSItemCode_Id (NONCLUSTERED): RTK_ItemsId, MSDSId, ItemCode




### dbo.RTK_LegacyDistrictCodesMap



**Rows:** 78

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| RTK_DistrictCodesMapId | int | No | Yes |  |  |
| Legacy_DistrictCode | char(2) | No | No |  |  |
| SQL_DistrictCode | char(2) | No | No |  |  |
| DistrictId | int | No | No |  |  |



**Primary Key:** RTK_DistrictCodesMapId





**Indexes:**
- PK_RTK_LegacyDistrictCodesMap (CLUSTERED): RTK_DistrictCodesMapId




### dbo.RTK_LegacySchoolFile



**Rows:** 6,766

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| LegacySchoolFileId | int | No | Yes |  |  |
| LegacyDistrictCode | char(2) | Yes | No |  |  |
| LegacySchoolCode | char(5) | Yes | No |  |  |
| SchoolName | varchar(30) | Yes | No |  |  |
| SchoolAddr | varchar(30) | Yes | No |  |  |
| CityStZip | varchar(30) | Yes | No |  |  |
| NJEIN | varchar(20) | Yes | No |  |  |
| ExposedEmployees | int | Yes | No |  |  |
| DistrictId | int | Yes | No |  |  |
| RTK_SitesId | int | Yes | No |  |  |



**Primary Key:** LegacySchoolFileId





**Indexes:**
- PK_LegacySchoolFile (CLUSTERED): LegacySchoolFileId




### dbo.RTK_MixtureCodes



**Rows:** 11

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| MixtureCodesID | int | No | Yes |  |  |
| MixtureCode | char(2) | No | No |  |  |
| Description | varchar(12) | Yes | No |  |  |



**Primary Key:** MixtureCodesID





**Indexes:**
- PK_RTK_MixtureCodes (CLUSTERED): MixtureCodesID




### dbo.RTK_MSDSDetail



**Rows:** 151,665

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| RTK_MSDSDetailID | int | No | Yes |  |  |
| RTK_ItemsID | int | Yes | No |  |  |
| SeqNum | int | Yes | No |  |  |
| RTK_CASFileId | int | Yes | No |  |  |
| MixturePercent | decimal(9,5) | Yes | No |  |  |
| LegacyCASRegNo | varchar(12) | Yes | No |  |  |
| MixturePercentCode | char(2) | Yes | No |  |  |



**Primary Key:** RTK_MSDSDetailID





**Indexes:**
- PK_RTK_MSDSDetail (CLUSTERED): RTK_MSDSDetailID
- IX_RTK_MSDSDetail (NONCLUSTERED): RTK_MSDSDetailID
- IX_RTK_MSDSDetail_1 (NONCLUSTERED): RTK_ItemsID, RTK_MSDSDetailID




### dbo.RTK_Purposes



**Rows:** 35

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| RTK_PurposeID | int | No | Yes |  |  |
| Description | varchar(50) | No | No |  |  |



**Primary Key:** RTK_PurposeID





**Indexes:**
- PK__RTK_Purp__3213E83F0B50C8C2 (CLUSTERED): RTK_PurposeID




### dbo.RTK_ReportItems



**Rows:** 1,006,046

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| RTK_ReportItemsId | int | No | Yes |  |  |
| Year | int | Yes | No |  |  |
| DistrictId | int | Yes | No |  |  |
| RTK_SitesId | int | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |
| Quantity | int | Yes | No |  |  |
| LegacyLocnCode | char(5) | Yes | No |  |  |
| LegacyCometItemCode | char(8) | Yes | No |  |  |
| DetailId | int | Yes | No |  |  |
| ManuallyEntered | int | Yes | No |  |  |
| ExactLocationOnSite | varchar(50) | Yes | No |  |  |
| MSDSId | int | Yes | No |  |  |
| RTK_ItemsId | int | Yes | No |  |  |



**Primary Key:** RTK_ReportItemsId





**Indexes:**
- PK_RTK_ReportItems (CLUSTERED): RTK_ReportItemsId
- IX_RTK_ReportItems_byDistrictId (NONCLUSTERED): DistrictId
- IX_RTK_ReportItems_byItemId (NONCLUSTERED): ItemId
- IX_RTK_ReportItems_byYear (NONCLUSTERED): RTK_ReportItemsId, ItemId, Year
- SKI_ItemSiteYear_Id (NONCLUSTERED): RTK_ReportItemsId, ItemId, RTK_SitesId, Year
- SKI_ItemYear_DistrictSite (NONCLUSTERED): DistrictId, RTK_SitesId, RTK_ItemsId, Year
- SKI_MSDS_ItemId (NONCLUSTERED): RTK_ReportItemsId, ItemId, MSDSId
- SKI_Year_All (NONCLUSTERED): RTK_ReportItemsId, ItemId, CategoryId, Quantity, ExactLocationOnSite, MSDSId, RTK_ItemsId, Year, DistrictId, RTK_SitesId




### dbo.RTK_Sites



**Rows:** 823

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| RTK_SitesId | int | No | Yes |  |  |
| Active | int | Yes | No |  |  |
| DistrictId | int | Yes | No |  |  |
| NJEIN | varchar(20) | Yes | No |  |  |
| ExposedEmployeesCount | int | Yes | No |  |  |
| CoMunCode | varchar(5) | Yes | No |  |  |
| FacilityName | varchar(50) | Yes | No |  |  |
| MailingAddress1 | varchar(100) | Yes | No |  |  |
| MailingAddress2 | varchar(100) | Yes | No |  |  |
| MailingAddress3 | varchar(100) | Yes | No |  |  |
| MailingAddress4 | varchar(100) | Yes | No |  |  |
| FacilityLocation1 | varchar(100) | Yes | No |  |  |
| FacilityLocation2 | varchar(100) | Yes | No |  |  |
| FacilityLocation3 | varchar(100) | Yes | No |  |  |
| FacilityLocation4 | varchar(100) | Yes | No |  |  |
| ChemicalInventoryStatus | tinyint | Yes | No |  |  |
| FacilityEmergencyContact | varchar(100) | Yes | No |  |  |
| EmergencyPhone | varchar(50) | Yes | No |  |  |
| ResponsibleOfficial | varchar(100) | Yes | No |  |  |
| TitleResponsibleOfficial | varchar(100) | Yes | No |  |  |
| EmailResponsibleOfficial | varchar(200) | Yes | No |  |  |
| PhoneResponsibleOfficial | varchar(50) | Yes | No |  |  |



**Primary Key:** RTK_SitesId





**Indexes:**
- PK_RTK_Sites (CLUSTERED): RTK_SitesId




### dbo.RTK_Surveys



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| RTKSurveyId | uniqueidentifier | No | No | (newid()) |  |
| DistrictId | int | No | No |  |  |
| SchoolId | int | Yes | No |  |  |
| FacilityId | int | Yes | No |  |  |
| FacilityNumber | varchar(20) | Yes | No |  |  |
| FacilityName | varchar(50) | Yes | No |  |  |
| ReportYear | int | No | No |  |  |
| DocumentId | uniqueidentifier | No | No |  |  |
| Description | varchar(1024) | No | No |  |  |
| ValidFrom | datetime | Yes | No |  |  |
| ValidUntil | datetime | Yes | No |  |  |
| Created | datetime | No | No | (getdate()) |  |
| Updated | datetime | Yes | No |  |  |
| Deleted | datetime | Yes | No |  |  |



**Primary Key:** RTKSurveyId





**Indexes:**
- PK__RTK_Surv__4E40C4ED188104D5 (CLUSTERED): RTKSurveyId




### dbo.RTK_Training



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| RTKTrainingId | uniqueidentifier | No | No | (newid()) |  |
| DistrictId | int | No | No |  |  |
| FacilityId | int | Yes | No |  |  |
| SchoolId | int | Yes | No |  |  |
| UserId | int | Yes | No |  |  |
| DocumentId | uniqueidentifier | Yes | No |  |  |
| Description | varchar(1024) | No | No |  |  |
| ValidFrom | datetime | Yes | No |  |  |
| ValidUntil | datetime | Yes | No |  |  |
| Created | datetime | No | No | (getdate()) |  |
| Updated | datetime | Yes | No |  |  |
| Deleted | datetime | Yes | No |  |  |



**Primary Key:** RTKTrainingId





**Indexes:**
- PK__RTK_Trai__AE6AAE51019D9F7D (CLUSTERED): RTKTrainingId




### dbo.RTK_UOMCodes



**Rows:** 3

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| UOMCodesID | int | No | Yes |  |  |
| UOMCode | char(1) | No | No |  |  |
| Description | varchar(20) | Yes | No |  |  |



**Primary Key:** UOMCodesID





**Indexes:**
- PK_RTK_UOMCodes (CLUSTERED): UOMCodesID




### dbo.RTK_VendorLinks



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| RTKVendorLinkId | uniqueidentifier | No | No | (newid()) |  |
| VendorId | int | No | No |  |  |
| VendorName | varchar(50) | No | No |  |  |
| Description | varchar(4096) | Yes | No |  |  |
| Link | varchar(1024) | Yes | No |  |  |
| Created | datetime | No | No | (getdate()) |  |
| Updated | datetime | Yes | No |  |  |
| Deleted | datetime | Yes | No |  |  |



**Primary Key:** RTKVendorLinkId





**Indexes:**
- PK__RTK_Vend__724EEC6A0D0F5229 (CLUSTERED): RTKVendorLinkId




### dbo.SafetyDataSheets



**Rows:** 94,729

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| SafetyDataSheetId | bigint | No | Yes |  |  |
| SDSURL | varchar(512) | No | No |  |  |
| Seq | bigint | Yes | No |  |  |
| Created | datetime | No | No | (getdate()) |  |
| Updated | datetime | Yes | No |  |  |
| Deleted | datetime | Yes | No |  |  |



**Primary Key:** SafetyDataSheetId





**Indexes:**
- PK__SafetyDa__C9A3658F59DFE532 (CLUSTERED): SafetyDataSheetId
- SK_URL (NONCLUSTERED): SDSURL




### dbo.Salutations



**Rows:** 5

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| SalutationId | int | No | Yes |  |  |
| Title | varchar(20) | No | No |  |  |



**Primary Key:** SalutationId





**Indexes:**
- PK__Salutati__562AE14F0EBE9A3A (CLUSTERED): SalutationId




### dbo.SaxDups



**Rows:** 31,171

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BidHeaderId | int | No | No |  |  |
| PackedCode | varchar(255) | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |









### dbo.SaxNotifications



**Rows:** 78

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| RepName | varchar(30) | Yes | No |  |  |
| DistrictName | varchar(50) | Yes | No |  |  |
| BudgetName | varchar(30) | Yes | No |  |  |
| SchoolName | varchar(50) | Yes | No |  |  |
| CometId | int | Yes | No |  |  |
| UserId | int | No | No |  |  |
| EMail | varchar(255) | Yes | No |  |  |
| Attention | varchar(50) | Yes | No |  |  |
| RequisitionNumber | varchar(24) | Yes | No |  |  |
| ItemCode | varchar(50) | Yes | No |  |  |
| VendorItemCode | varchar(50) | Yes | No |  |  |
| Quantity | int | Yes | No |  |  |
| Description | varchar(1024) | Yes | No |  |  |
| BidPrice | money | Yes | No |  |  |
| RequestedVendorItemCode | varchar(50) | Yes | No |  |  |
| RequestedDescription | varchar(1156) | Yes | No |  |  |









### dbo.ScanEvents



**Rows:** 383,566

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ScanEventId | int | No | Yes |  |  |
| ScanJobId | int | No | No |  |  |
| EventStamp | datetime | No | No | (getdate()) |  |
| SourceFile | varchar(512) | No | No |  |  |
| IndexData | varchar(MAX) | Yes | No |  |  |
| EventStatus | varchar(255) | Yes | No |  |  |



**Primary Key:** ScanEventId





**Indexes:**
- PK__ScanEven__316CC94A551BCD8E (CLUSTERED): ScanEventId




### dbo.ScanJobs



**Rows:** 3

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ScanJobId | int | No | Yes |  |  |
| CaptureName | varchar(50) | No | No |  |  |
| CabinetName | varchar(50) | No | No |  |  |
| SourceFolder | varchar(512) | No | No |  |  |
| SplitFolder | varchar(512) | No | No |  |  |
| ProcessedFolder | varchar(512) | Yes | No |  |  |
| RejectedFolder | varchar(512) | Yes | No |  |  |
| CCCaptureJobId | uniqueidentifier | Yes | No |  |  |
| CatalogName | varchar(50) | Yes | No |  |  |



**Primary Key:** ScanJobId





**Indexes:**
- PK__ScanJobs__8A1E9DAD341935C8 (CLUSTERED): ScanJobId




### dbo.ScannerZones



**Rows:** 10

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ScannerZoneId | int | No | Yes |  |  |
| ScanJobId | int | No | No |  |  |
| DocTypeFieldRecognitionZoneId | uniqueidentifier | No | No |  |  |
| LeftPosition | decimal(7,2) | No | No |  |  |
| TopPosition | decimal(7,2) | No | No |  |  |
| Width | decimal(7,2) | No | No |  |  |
| Height | decimal(7,2) | No | No |  |  |
| HorizontalTolerance | decimal(7,2) | No | No |  |  |
| VerticalTolerance | decimal(7,2) | No | No |  |  |



**Primary Key:** ScannerZoneId





**Indexes:**
- PK__ScannerZ__57E358B33E936515 (CLUSTERED): ScannerZoneId




### dbo.ScheduledTask



**Rows:** 12

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| TaskId | int | No | Yes |  |  |
| TaskName | nvarchar(255) | No | No |  |  |
| Description | nvarchar(MAX) | Yes | No |  |  |
| ScheduleExpression | nvarchar(255) | No | No |  |  |
| TaskType | nvarchar(50) | No | No |  |  |
| Status | nvarchar(50) | No | No | ('Pending') |  |
| LastRunTime | datetime | Yes | No |  |  |
| NextRunTime | datetime | Yes | No |  |  |
| MaxRetries | int | No | No | ((3)) |  |
| CurrentRetries | int | No | No | ((0)) |  |
| CreatedBy | nvarchar(100) | No | No |  |  |
| CreatedAt | datetime | No | No | (getdate()) |  |
| UpdatedBy | nvarchar(100) | Yes | No |  |  |
| UpdatedAt | datetime | Yes | No |  |  |



**Primary Key:** TaskId





**Indexes:**
- PK__Schedule__7C6949B192A05F7B (CLUSTERED): TaskId




### dbo.ScheduleTypes



**Rows:** 10

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ScheduleId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| Name | varchar(50) | Yes | No |  |  |
| StateId | int | Yes | No |  |  |



**Primary Key:** ScheduleId





**Indexes:**
- PK__ScheduleTypes__1348B5CC (CLUSTERED): ScheduleId




### dbo.School



**Rows:** 6,542

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| SchoolId | int | No | Yes |  |  |
| DistrictId | int | Yes | No |  |  |
| Active | tinyint | Yes | No |  |  |
| Name | varchar(50) | Yes | No |  |  |
| Address1 | varchar(30) | Yes | No |  |  |
| Address2 | varchar(30) | Yes | No |  |  |
| Address3 | varchar(30) | Yes | No |  |  |
| City | varchar(25) | Yes | No |  |  |
| State | varchar(2) | Yes | No |  |  |
| Zipcode | varchar(10) | Yes | No |  |  |
| BillingId | int | Yes | No |  |  |
| ShippingId | int | Yes | No |  |  |
| PhoneNumber | varchar(20) | Yes | No |  |  |
| Fax | varchar(20) | Yes | No |  |  |
| EMail | varchar(255) | Yes | No |  |  |
| LocationCode | varchar(32) | Yes | No |  |  |
| AddressId | int | Yes | No |  |  |



**Primary Key:** SchoolId



**Foreign Keys:**
- DistrictId → dbo.District.DistrictId




**Indexes:**
- PK_School (CLUSTERED): SchoolId
- _dta_index_School_7_510676917__K2_K1_4_5_6_7_8_9_10 (NONCLUSTERED): Name, Address1, Address2, Address3, City, State, Zipcode, DistrictId, SchoolId
- SK_District (NONCLUSTERED): DistrictId
- SKI_Active_School (NONCLUSTERED): SchoolId, Active




### dbo.SDS_Rpt_Bridge



**Rows:** 98

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| SessionId | int | No | No |  |  |
| ItemId | int | No | No |  |  |
| SDSDoc | varchar(500) | No | No |  |  |







**Indexes:**
- IX_SDS_Rpt_Bridge (CLUSTERED): SessionId




### dbo.SDSDocs



**Rows:** 161,387

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| Id | uniqueidentifier | No | No | (newid()) |  |
| ItemId | int | No | No |  |  |
| CrossRefId | int | Yes | No |  |  |
| MSDSId | int | Yes | No |  |  |
| OrigURL | varchar(1024) | Yes | No |  |  |
| DateLoaded | datetime | Yes | No | (getdate()) |  |
| DateChecked | datetime | Yes | No | (getdate()) |  |
| Checksum | bigint | Yes | No |  |  |
| DocType | varchar(50) | Yes | No |  |  |
| Document | varbinary(MAX) | Yes | No |  |  |
| Description | varchar(255) | Yes | No |  |  |
| Manufacturer | varchar(255) | Yes | No |  |  |



**Primary Key:** Id





**Indexes:**
- PK__SDSDocs__3214EC07599E86FE (CLUSTERED): Id
- SKI_Item_Id (NONCLUSTERED): Id, ItemId
- SKI_MSDS_ItemId (NONCLUSTERED): Id, ItemId, MSDSId
- ti_CrossRef_Id (NONCLUSTERED): Id, CrossRefId




### dbo.SDSErrors



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| sdsErrorId | bigint | No | Yes |  |  |
| sdsURL | varchar(512) | Yes | No |  |  |
| error | varchar(MAX) | Yes | No |  |  |
| logDate | datetime | Yes | No | (getdate()) |  |



**Primary Key:** sdsErrorId





**Indexes:**
- PK__SDSError__1FC45DBB3D51DD76 (CLUSTERED): sdsErrorId




### dbo.SDSLog



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| sdsLogId | bigint | No | Yes |  |  |
| sdsURL | varchar(512) | Yes | No |  |  |
| statusCode | int | Yes | No |  |  |
| statusText | varchar(512) | Yes | No |  |  |
| contentType | varchar(50) | Yes | No |  |  |
| headers | varchar(MAX) | Yes | No |  |  |
| testDate | datetime | Yes | No | (getdate()) |  |
| writeStatus | int | Yes | No |  |  |
| writeDate | datetime | Yes | No |  |  |



**Primary Key:** sdsLogId





**Indexes:**
- PK__SDSLog__BE04475849B83273 (CLUSTERED): sdsLogId




### dbo.SDSResults



**Rows:** 116,893

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| SDSResultsId | int | No | Yes |  |  |
| SafetyDataSheetId | int | No | No |  |  |
| SDSURL | varchar(512) | Yes | No |  |  |
| SDSCacheURL | varchar(512) | Yes | No |  |  |
| DocumentType | varchar(128) | Yes | No |  |  |
| DocumentURL | varchar(512) | Yes | No |  |  |
| ValidCache | bit | Yes | No |  |  |
| ValidSDSUrl | bit | Yes | No |  |  |
| ValidDocumentURL | bit | Yes | No |  |  |
| ValidElasticText | bit | Yes | No |  |  |
| SDSCacheError | varchar(1024) | Yes | No |  |  |
| SDSURLError | varchar(1024) | Yes | No |  |  |
| DocumentURLError | varchar(1024) | Yes | No |  |  |
| ElasticError | varchar(1024) | Yes | No |  |  |



**Primary Key:** SDSResultsId





**Indexes:**
- PK__SDSResul__FAB2B42F07B89792 (CLUSTERED): SDSResultsId




### dbo.SDSs



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| sdsId | bigint | No | Yes |  |  |
| sdsURL | varchar(512) | Yes | No |  |  |
| sdsPath | varchar(512) | Yes | No |  |  |
| sdsHash | bigint | Yes | No |  |  |
| dateLoaded | datetime | Yes | No | (getdate()) |  |
| dateChecked | datetime | Yes | No | (getdate()) |  |
| dateDeleted | datetime | Yes | No |  |  |



**Primary Key:** sdsId





**Indexes:**
- PK__SDSs__27BDF69229E64697 (CLUSTERED): sdsId




### dbo.SDSSyncStatus



**Rows:** 26,483

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| SafetyDataSheetId | int | No | No |  |  |
| TotalItems | int | Yes | No |  |  |
| TotalRequisitions | int | Yes | No |  |  |
| SyncedItems | int | No | No | ((0)) |  |
| SyncedRequisitions | int | No | No | ((0)) |  |
| SyncStatus | varchar(50) | No | No | ('New') |  |
| CreatedAt | datetime | No | No | (getdate()) |  |
| UpdatedAt | datetime | Yes | No |  |  |
| LastSyncedAt | datetime | Yes | No |  |  |
| ItemSyncStatus | varchar(50) | Yes | No |  | Queueing, Syncing |
| RequisitionSyncStatus | varchar(50) | Yes | No |  |  |
| StartSyncAt | datetime | Yes | No |  |  |
| EndSyncAt | datetime | Yes | No |  |  |



**Primary Key:** SafetyDataSheetId





**Indexes:**
- PK__SDSSyncS__C9A3658FEE1B713F (CLUSTERED): SafetyDataSheetId
- IX_SDSSyncStatus_LastSyncedAt (NONCLUSTERED): LastSyncedAt
- IX_SDSSyncStatus_SyncStatus (NONCLUSTERED): SyncStatus




### dbo.SearchKeywords



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| SearchKeywordId | uniqueidentifier | No | No | (newid()) |  |
| ItemId | int | No | No |  |  |
| CrossRefId | int | No | No |  |  |
| Keyword | varchar(50) | Yes | No |  |  |



**Primary Key:** SearchKeywordId





**Indexes:**
- PK__SearchKe__3F57263943E68087 (CLUSTERED): SearchKeywordId




### dbo.SearchSets



**Rows:** 43,370

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| SSId | int | No | Yes |  |  |
| SessionId | int | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| CatalogId | int | Yes | No |  |  |
| SearchBy | int | Yes | No |  |  |
| SearchStart | varchar(255) | Yes | No |  |  |
| SearchEnd | varchar(255) | Yes | No |  |  |



**Primary Key:** SSId





**Indexes:**
- PK_SearchSets (CLUSTERED): SSId
- SK_Session (NONCLUSTERED): SessionId




### dbo.Sections



**Rows:** 18

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| SectionId | int | No | Yes |  |  |
| CategoryId | int | Yes | No |  |  |
| Description | varchar(50) | Yes | No |  |  |



**Primary Key:** SectionId





**Indexes:**
- PK__Sections__744F2D60 (CLUSTERED): SectionId
- SK_Category (NONCLUSTERED): CategoryId




### dbo.SecurityKeys



**Rows:** 13

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| SecurityKeyID | int | No | Yes |  |  |
| KeyName | varchar(100) | No | No |  |  |
| KeyDescription | varchar(255) | Yes | No |  |  |



**Primary Key:** SecurityKeyID





**Indexes:**
- PK__Security__405262811466F737 (CLUSTERED): SecurityKeyID




### dbo.SecurityRoleKeys



**Rows:** 64

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| SecurityRoleKeyID | int | No | Yes |  |  |
| SecurityKeyID | int | Yes | No |  |  |
| SecurityRoleID | int | Yes | No |  |  |



**Primary Key:** SecurityRoleKeyID





**Indexes:**
- PK__Security__ABE2F2671837881B (CLUSTERED): SecurityRoleKeyID




### dbo.SecurityRoles



**Rows:** 5

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| SecurityRoleId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| Name | varchar(50) | No | No |  |  |



**Primary Key:** SecurityRoleId





**Indexes:**
- PK__Security__F829C791160AB647 (CLUSTERED): SecurityRoleId




### dbo.SecurityRoleUsers



**Rows:** 351,013

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| SecurityRoleUserId | int | No | Yes |  |  |
| SecurityRoleId | int | No | No |  |  |
| UserId | int | No | No |  |  |



**Primary Key:** SecurityRoleUserId





**Indexes:**
- PK__Security__E7F0D603703A131A (CLUSTERED): SecurityRoleUserId
- SKI_UserId_UserRoleIdRoleId (NONCLUSTERED): SecurityRoleUserId, SecurityRoleId, UserId




### dbo.Services



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ServiceId | int | No | Yes |  |  |
| ParentId | int | Yes | No |  |  |
| TradeId | int | Yes | No |  |  |
| Active | tinyint | Yes | No |  |  |
| Description | varchar(50) | Yes | No |  |  |
| BidQuantity | decimal(9,5) | No | No |  |  |
| RateTypeId | tinyint | No | No |  |  |
| RateUnitId | int | No | No |  |  |
| Comments | text | Yes | No |  |  |



**Primary Key:** ServiceId





**Indexes:**
- PK__Services__C51BB00A0BF73C28 (CLUSTERED): ServiceId




### dbo.SessionCmds



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| SessionCmdId | int | No | Yes |  |  |
| SessionId | int | No | No |  |  |
| EventDate | datetime | Yes | No | (getdate()) |  |
| Command | varchar(4096) | Yes | No |  |  |



**Primary Key:** SessionCmdId





**Indexes:**
- PK__SessionC__D4B6857B1F942081 (CLUSTERED): SessionCmdId




### dbo.SessionTable



**Rows:** 12,228,892

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| SessionId | int | No | Yes |  |  |
| DistrictId | int | Yes | No |  |  |
| SchoolId | int | Yes | No |  |  |
| UserId | int | No | No |  |  |
| RequisitionId | int | Yes | No |  |  |
| POId | int | Yes | No |  |  |
| BudgetId | int | Yes | No |  |  |
| ReqMode | int | Yes | No |  |  |
| OrderBy | int | Yes | No |  |  |
| CatalogId | int | Yes | No |  |  |
| Mode | int | Yes | No |  |  |
| SessionStart | datetime | Yes | No | (getdate()) |  |
| SessionEnd | datetime | Yes | No |  |  |
| SessionLast | datetime | Yes | No |  |  |
| CSRepId | int | Yes | No |  |  |
| RepUserId | int | Yes | No |  |  |
| ApprovalLevel | tinyint | Yes | No |  |  |
| Attention | varchar(50) | Yes | No |  |  |
| ResolutionX | int | Yes | No |  |  |
| ResolutionY | int | Yes | No |  |  |
| TabSelected | varchar(32) | Yes | No |  |  |
| ReloadPage | tinyint | Yes | No |  |  |
| TempUserId | int | Yes | No |  |  |
| CurrentBudgetId | int | Yes | No |  |  |
| NextBudgetId | int | Yes | No |  |  |
| AllowIncidentals | tinyint | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |



**Primary Key:** SessionId





**Indexes:**
- PK_SessionTable (CLUSTERED): SessionId
- IX_SessionTable_SessionId (NONCLUSTERED): DistrictId, SchoolId, UserId, BudgetId, CurrentBudgetId, NextBudgetId, SessionId
- SK_Budget (NONCLUSTERED): BudgetId
- SKI_DistrictEnd_UserRepLevel (NONCLUSTERED): UserId, CSRepId, ApprovalLevel, DistrictId, SessionEnd




### dbo.ShipLocations



**Rows:** 6,828

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ShippingId | int | No | Yes |  |  |
| DistrictId | int | Yes | No |  |  |
| Active | tinyint | Yes | No |  |  |
| Name | varchar(50) | Yes | No |  |  |
| Address1 | varchar(30) | Yes | No |  |  |
| Address2 | varchar(30) | Yes | No |  |  |
| Address3 | varchar(30) | Yes | No |  |  |
| City | varchar(25) | Yes | No |  |  |
| State | varchar(2) | Yes | No |  |  |
| ZipCode | varchar(10) | Yes | No |  |  |
| Phone | varchar(20) | Yes | No |  |  |
| Fax | varchar(14) | Yes | No |  |  |
| EMail | varchar(255) | Yes | No |  |  |
| LocationCode | varchar(32) | Yes | No |  |  |
| RTK_SitesId | int | Yes | No |  |  |



**Primary Key:** ShippingId





**Indexes:**
- PK_ShipLocations (CLUSTERED): ShippingId
- _dta_index_ShipLocations_7_1576757070__K1_4_5_6_7_8_9_10_14 (NONCLUSTERED): Name, Address1, Address2, Address3, City, State, ZipCode, LocationCode, ShippingId
- SK_District (NONCLUSTERED): DistrictId




### dbo.ShippingCosts



**Rows:** 902

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ShippingCostId | int | No | Yes |  |  |
| DetailId | int | No | No |  |  |
| RequisitionId | int | No | No |  |  |
| ShippingRequestId | int | Yes | No |  |  |
| DateUpdated | datetime | No | No | (getdate()) |  |
| Quantity | int | Yes | No |  |  |
| Cost | decimal(9,2) | Yes | No |  |  |
| UpdatedBy | varchar(50) | Yes | No |  |  |



**Primary Key:** ShippingCostId





**Indexes:**
- PK__Shipping__AB3F978E04C3C730 (CLUSTERED): ShippingCostId
- SK_ShippingRequestId (NONCLUSTERED): ShippingRequestId




### dbo.ShippingRequests



**Rows:** 597

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ShippingRequestId | int | No | Yes |  |  |
| ShippingRequestUniqueId | uniqueidentifier | No | No | (newid()) |  |
| RequisitionId | int | No | No |  |  |
| VendorId | int | No | No |  |  |
| EmailAddresses | varchar(4096) | No | No |  |  |
| Comments | varchar(4096) | Yes | No |  |  |
| RequestSent | datetime | No | No | (getdate()) |  |
| RequestCompleted | datetime | Yes | No |  |  |
| CompletedBy | varchar(50) | Yes | No |  |  |
| RequestStatus | varchar(50) | Yes | No |  |  |
| loadingDock | tinyint | Yes | No |  |  |



**Primary Key:** ShippingRequestId





**Indexes:**
- PK__Shipping__4DDC37ED82F7C8BD (CLUSTERED): ShippingRequestId




### dbo.ShippingVendor



**Rows:** 37,197

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| ShippingVendorId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| VendorId | int | No | No |  |  |
| ShippingId | int | No | No |  |  |
| ShippingCode | varchar(50) | Yes | No |  |  |



**Primary Key:** ShippingVendorId





**Indexes:**
- PK__Shipping__F29A100E04561A60 (CLUSTERED): ShippingVendorId
- SKI_VendorId_Code (NONCLUSTERED): ShippingCode, VendorId, ShippingId




### dbo.SSOLoginTracking



**Rows:** 97,775

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| SSOProvider | varchar(50) | No | No |  |  |
| Email | varchar(255) | Yes | No |  |  |
| Action | varchar(100) | Yes | No |  |  |
| InsertAt | datetime | Yes | No | (getdate()) |  |
| ErrorMsg | varchar(255) | Yes | No |  |  |
| Description | varchar(MAX) | Yes | No |  |  |







**Indexes:**
- IX_SSOLoginTracking_ResetCode (NONCLUSTERED): Email, SSOProvider, Action




### dbo.States



**Rows:** 3

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| StateId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| Name | varchar(50) | Yes | No |  |  |
| code | char(2) | Yes | No |  |  |



**Primary Key:** StateId





**Indexes:**
- PK_States (CLUSTERED): StateId




### dbo.StatusTable



**Rows:** 52

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| StatusId | int | No | Yes |  |  |
| StatusCode | char(1) | Yes | No |  |  |
| Name | varchar(50) | Yes | No |  |  |
| RequiredLevel | tinyint | Yes | No |  |  |
| OptionValue | int | Yes | No |  |  |
| UserVisibilityLevel | int | Yes | No |  |  |
| IsPrint | bit | Yes | No |  |  |
| ScriptURL | varchar(1024) | Yes | No |  |  |



**Primary Key:** StatusId





**Indexes:**
- PK_StatusTable (CLUSTERED): StatusId
- SK_Name (NONCLUSTERED): Name
- SK_OptionValue (NONCLUSTERED): OptionValue
- SK_RequiredLevel (NONCLUSTERED): RequiredLevel
- SK_StatusCode (NONCLUSTERED): StatusCode




### dbo.Sulphite



**Rows:** 49

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| SulphiteId | int | No | Yes |  |  |
| VendorItemCode | varchar(50) | No | No |  |  |
| ItemCode | varchar(50) | No | No |  |  |
| ItemId | int | Yes | No |  |  |
| Z2Exclude | tinyint | Yes | No |  |  |



**Primary Key:** SulphiteId





**Indexes:**
- PK__Sulphite__677FE68D64B095AA (CLUSTERED): SulphiteId




### dbo.SulphiteDetail



**Rows:** 6,280

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| DetailId | int | No | No |  |  |
| vendorItemCode | varchar(50) | Yes | No |  |  |
| ItemCode | varchar(50) | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |









### dbo.SulphiteImport



**Rows:** 49

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| Cascade item number | nvarchar(255) | Yes | No |  |  |
| Description | nvarchar(255) | Yes | No |  |  |
| Ed Data code number | nvarchar(255) | Yes | No |  |  |
| Suggested alternate | nvarchar(255) | Yes | No |  |  |
| ED-DATA item code | nvarchar(255) | Yes | No |  |  |









### dbo.SulphiteUsers



**Rows:** 1,209

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| SulphiteUserId | int | No | Yes |  |  |
| UserId | int | No | No |  |  |



**Primary Key:** SulphiteUserId





**Indexes:**
- PK__Sulphite__6D55B3EA13F94E2C (CLUSTERED): SulphiteUserId




### dbo.Suppression


**Description:** List of recipients that you do not want to send emails to


**Rows:** 3,769

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| Id | int | No | Yes |  |  |
| Email | varchar(100) | Yes | No |  |  |
| Type | varchar(50) | Yes | No |  |  |
| District | varchar(100) | Yes | No |  |  |
| Locator | varchar(200) | Yes | No |  |  |
| Phone | varchar(20) | Yes | No |  |  |
| Reason | varchar(300) | Yes | No |  |  |
| Handled | bit | Yes | No | ((1)) |  |
| CreatedAt | datetime | Yes | No | (getdate()) |  |
| UpdatedAt | datetime | Yes | No |  |  |
| CreatedBy | int | Yes | No | ((0)) |  |
| UpdatedBy | int | Yes | No | ((0)) |  |
| BelongsTo | varchar(50) | Yes | No |  |  |
| SuppressionType | varchar(50) | Yes | No |  |  |
| SuppressionAt | datetime | Yes | No |  |  |



**Primary Key:** Id





**Indexes:**
- PK__Suppress__3214EC079C958FED (CLUSTERED): Id
- Suppression_uindex (NONCLUSTERED): Email, SuppressionType




### dbo.sysdiagrams



**Rows:** 9

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| name | sysname | No | No |  |  |
| principal_id | int | No | No |  |  |
| diagram_id | int | No | Yes |  |  |
| version | int | Yes | No |  |  |
| definition | varbinary(MAX) | Yes | No |  |  |



**Primary Key:** diagram_id





**Indexes:**
- PK__sysdiagr__C2B05B616A96485D (CLUSTERED): diagram_id
- UK_principal_name (NONCLUSTERED): principal_id, name




### dbo.TableOfContents



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| TCId | int | No | Yes |  |  |
| Title | varchar(255) | Yes | No |  |  |
| PageNbr | int | Yes | No |  |  |
| OrderBookId | int | Yes | No |  |  |



**Primary Key:** TCId





**Indexes:**
- PK_TableOfContents (CLUSTERED): TCId




### dbo.TagFile_



**Rows:** 6,235

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| Usr | int | Yes | No |  |  |
| Tbl | int | Yes | No |  |  |
| Ptr | int | Yes | No |  |  |
| Val | char(10) | Yes | No |  |  |









### dbo.TAGFILEP



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| USR | int | No | No |  |  |
| TBL | smallint | No | No |  |  |
| POS | char(256) | No | No |  |  |
| VAL | char(10) | Yes | No |  |  |



**Primary Key:** USR, TBL, POS





**Indexes:**
- PK__TAGFILEP__47DBAE45 (CLUSTERED): USR, TBL, POS




### dbo.TagFilePos_



**Rows:** 2,259

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| Usr | int | Yes | No |  |  |
| Tbl | int | Yes | No |  |  |
| Pos | char(256) | Yes | No |  |  |
| Val | char(10) | Yes | No |  |  |









### dbo.TagSet_



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| Tbl | int | Yes | No |  |  |
| Usr | int | Yes | No |  |  |
| Source | char(50) | Yes | No |  |  |
| Date | int | Yes | No |  |  |
| Count | int | Yes | No |  |  |
| Description | char(250) | Yes | No |  |  |









### dbo.TaskEvent



**Rows:** 122,102

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| TaskEventId | int | No | Yes |  |  |
| ProjectTaskId | int | Yes | No |  |  |
| EventDate | datetime | Yes | No |  |  |
| BidDate | datetime | Yes | No |  |  |
| DistrictId | int | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| UserId | int | Yes | No |  |  |
| ValueField | varchar(20) | Yes | No |  |  |



**Primary Key:** TaskEventId





**Indexes:**
- PK_TaskEvent (CLUSTERED): TaskEventId




### dbo.TaskSchedule



**Rows:** 1,544,400

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| TaskScheduleId | int | No | Yes |  |  |
| ProjectTasksId | int | No | No |  |  |
| TaskSeqNum | int | No | No |  |  |
| StartDateOrig | datetime | Yes | No |  |  |
| EndDateOrig | datetime | Yes | No |  |  |
| StartDateProjected | datetime | Yes | No |  |  |
| EndDateProjected | datetime | Yes | No |  |  |
| StartDateActual | datetime | Yes | No |  |  |
| EndDateActual | datetime | Yes | No |  |  |
| BidCycleDate | datetime | Yes | No |  |  |
| DistrictId | int | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| UserId | int | Yes | No |  |  |
| PricePlanId | int | Yes | No |  |  |
| SessionId | int | Yes | No |  |  |



**Primary Key:** TaskScheduleId





**Indexes:**
- PK_TaskSchedule (CLUSTERED): TaskScheduleId
- SK_ProjectTasks (NONCLUSTERED): ProjectTasksId
- SKI_CategoryDistrictCycle_PricePlan (NONCLUSTERED): TaskScheduleId, PricePlanId, StartDateActual, ProjectTasksId, CategoryId, DistrictId, BidCycleDate




### dbo.TempIrvingtonWincap



**Rows:** 860

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| Approver | nvarchar(255) | Yes | No |  |  |
| Rqst ID | nvarchar(255) | Yes | No |  |  |
| F3 | nvarchar(255) | Yes | No |  |  |
| Description | nvarchar(255) | Yes | No |  |  |
| Employee ID | nvarchar(255) | Yes | No |  |  |
| Req ID | nvarchar(255) | Yes | No |  |  |
| F7 | nvarchar(255) | Yes | No |  |  |
| F8 | nvarchar(255) | Yes | No |  |  |
| F9 | nvarchar(255) | Yes | No |  |  |
| Building | nvarchar(255) | Yes | No |  |  |
| F11 | nvarchar(255) | Yes | No |  |  |
| Dept for Apprvl | nvarchar(255) | Yes | No |  |  |
| Position (Linked)e | nvarchar(255) | Yes | No |  |  |
| HR Location | nvarchar(255) | Yes | No |  |  |
| Grade/Level | nvarchar(255) | Yes | No |  |  |
| Supervisor | nvarchar(255) | Yes | No |  |  |
| Default Fund | nvarchar(255) | Yes | No |  |  |
| Default Budgetcode | nvarchar(255) | Yes | No |  |  |
| Invoice Address | nvarchar(255) | Yes | No |  |  |
| F20 | nvarchar(255) | Yes | No |  |  |
| Shipping Address | nvarchar(255) | Yes | No |  |  |
| Stock Request Ship To | nvarchar(255) | Yes | No |  |  |
| F23 | nvarchar(255) | Yes | No |  |  |
| F24 | nvarchar(255) | Yes | No |  |  |
| Email | nvarchar(255) | Yes | No |  |  |
| EOL | nvarchar(255) | Yes | No |  |  |









### dbo.TM_UOM



**Rows:** 77

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| TM_UOMId | int | No | Yes |  |  |
| Description | varchar(50) | No | No |  |  |



**Primary Key:** TM_UOMId





**Indexes:**
- PK__TM_UOM__330FAB5B0CA1479E (CLUSTERED): TM_UOMId




### dbo.TMAwards



**Rows:** 87,889

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| TMAwardId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| BidHeaderId | int | No | No |  |  |
| BidTradeCountyId | int | No | No |  |  |
| BidImportId | int | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| AwardType | varchar(50) | Yes | No |  |  |
| DateModified | datetime | Yes | No | (getdate()) |  |
| AwardAmount | money | Yes | No |  |  |



**Primary Key:** TMAwardId





**Indexes:**
- PK__TMAwards__D13C98351130F291 (CLUSTERED): TMAwardId
- SK_BidTradeCounty (NONCLUSTERED): BidImportId, VendorId, BidHeaderId, BidTradeCountyId, Active, AwardAmount




### dbo.TMImport



**Rows:** 3,114

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| TMImportId | int | No | Yes |  |  |
| State | char(2) | No | No |  |  |
| County | varchar(50) | No | No |  |  |
| Package | varchar(50) | No | No |  |  |
| Level | int | No | No |  |  |
| VendorName | varchar(255) | No | No |  |  |
| TradeId | int | Yes | No |  |  |



**Primary Key:** TMImportId





**Indexes:**
- PK__TMImport__C8E74C496C34780C (CLUSTERED): TMImportId




### dbo.TMImport1



**Rows:** 1,885

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| TMImportId | int | No | Yes |  |  |
| State | char(2) | No | No |  |  |
| County | varchar(50) | No | No |  |  |
| Package | varchar(50) | No | No |  |  |
| Level | int | No | No |  |  |
| VendorName | varchar(255) | No | No |  |  |
| TradeId | int | Yes | No |  |  |









### dbo.TMImport2



**Rows:** 147

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| TMImportId | int | No | Yes |  |  |
| State | char(2) | No | No |  |  |
| County | varchar(50) | No | No |  |  |
| Package | varchar(50) | No | No |  |  |
| Level | int | No | No |  |  |
| VendorName | varchar(255) | No | No |  |  |
| TradeId | int | Yes | No |  |  |









### dbo.TMImport3



**Rows:** 833

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| TMImportId | int | No | Yes |  |  |
| State | char(2) | No | No |  |  |
| County | varchar(50) | No | No |  |  |
| Package | varchar(50) | No | No |  |  |
| Level | int | No | No |  |  |
| VendorName | varchar(255) | No | No |  |  |
| TradeId | int | Yes | No |  |  |









### dbo.TMImport5



**Rows:** 2,889

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| TMImportId | int | No | Yes |  |  |
| State | char(2) | No | No |  |  |
| County | varchar(50) | No | No |  |  |
| Package | varchar(50) | No | No |  |  |
| Level | int | No | No |  |  |
| VendorName | varchar(255) | No | No |  |  |
| TradeId | int | Yes | No |  |  |









### dbo.TMImport6



**Rows:** 2,134

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| TMImportId | int | No | Yes |  |  |
| State | char(2) | No | No |  |  |
| County | varchar(50) | No | No |  |  |
| Package | varchar(50) | No | No |  |  |
| Level | int | No | No |  |  |
| VendorName | varchar(255) | No | No |  |  |
| TradeId | int | Yes | No |  |  |









### dbo.TmpLog



**Rows:** 461

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| TmpLogID | int | No | Yes |  |  |
| LogDateTime | datetime | Yes | No | (getdate()) |  |









### dbo.TmpTaskSchedule



**Rows:** 4,884

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| TmpTaskScheduleId | int | No | Yes |  |  |
| SessionId | int | No | No |  |  |
| ProjectTasksId | int | No | No |  |  |
| TaskSeqNum | int | Yes | No |  |  |
| TaskDescription | varchar(60) | Yes | No |  |  |
| StartDate | datetime | Yes | No |  |  |
| EndDate | datetime | Yes | No |  |  |



**Primary Key:** TmpTaskScheduleId





**Indexes:**
- PK_TmpTaskSchedule (CLUSTERED): TmpTaskScheduleId




### dbo.TMSurvey



**Rows:** 796

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| TMSurveyId | int | No | Yes |  |  |
| DistrictId | int | No | No |  |  |
| Submitter | varchar(255) | Yes | No |  |  |
| Title | varchar(255) | Yes | No |  |  |
| Email | varchar(255) | Yes | No |  |  |
| Started | datetime | Yes | No |  |  |
| Finished | datetime | Yes | No |  |  |
| CountyId | int | Yes | No |  |  |



**Primary Key:** TMSurveyId





**Indexes:**
- PK__TMSurvey__3514BEAE5921A398 (CLUSTERED): TMSurveyId




### dbo.TMSurveyNewTrades



**Rows:** 89

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| TMSurveyNewTradeId | int | No | Yes |  |  |
| TMSurveyId | int | No | No |  |  |
| TradeName | varchar(255) | Yes | No |  |  |
| TradeDescription | varchar(MAX) | Yes | No |  |  |



**Primary Key:** TMSurveyNewTradeId





**Indexes:**
- PK__TMSurvey__24912C0360C2C560 (CLUSTERED): TMSurveyNewTradeId




### dbo.TMSurveyNewVendors



**Rows:** 186

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| TMSurveyNewVendorId | int | No | Yes |  |  |
| TMSurveyId | int | No | No |  |  |
| TradeName | varchar(50) | Yes | No |  |  |
| VendorName | varchar(50) | Yes | No |  |  |
| Address1 | varchar(50) | Yes | No |  |  |
| Address2 | varchar(50) | Yes | No |  |  |
| City | varchar(50) | Yes | No |  |  |
| State | char(2) | Yes | No |  |  |
| Zipcode | varchar(10) | Yes | No |  |  |
| ContactName | varchar(50) | Yes | No |  |  |
| EMail | varchar(255) | Yes | No |  |  |
| Phone | varchar(20) | Yes | No |  |  |
| Fax | varchar(20) | Yes | No |  |  |



**Primary Key:** TMSurveyNewVendorId





**Indexes:**
- PK__TMSurvey__00123ED364935644 (CLUSTERED): TMSurveyNewVendorId




### dbo.TMSurveyResults



**Rows:** 89,650

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| TMSurveyResultId | int | No | Yes |  |  |
| TMSurveyId | int | No | No |  |  |
| TMVendorId | int | No | No |  |  |
| BidTradeCountyId | int | Yes | No |  |  |
| Rating | int | Yes | No |  |  |
| Comments | varchar(MAX) | Yes | No |  |  |
| Updated | datetime | Yes | No |  |  |



**Primary Key:** TMSurveyResultId





**Indexes:**
- PK__TMSurvey__99EA30475CF2347C (CLUSTERED): TMSurveyResultId
- SK_Survey_VendorBTCRateComments (NONCLUSTERED): TMVendorId, BidTradeCountyId, Rating, Comments, TMSurveyId




### dbo.TMVendors



**Rows:** 16,173

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| TMVendorId | int | No | Yes |  |  |
| TMYear | int | No | No |  |  |
| VendorId | int | Yes | No |  |  |
| VendorName | varchar(50) | Yes | No |  |  |
| TradeId | int | No | No |  |  |
| CountyId | int | No | No |  |  |
| Sequence | int | Yes | No |  |  |
| BidTradeId | int | Yes | No |  |  |



**Primary Key:** TMVendorId





**Indexes:**
- PK__TMVendor__7C1EB3C7555112B4 (CLUSTERED): TMVendorId




### dbo.TopUOM



**Rows:** 4,579

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| TopUOMId | int | No | Yes |  |  |
| CategoryId | int | Yes | No |  |  |
| UnitId | int | Yes | No |  |  |



**Primary Key:** TopUOMId





**Indexes:**
- PK_TopUOM (CLUSTERED): TopUOMId
- SK_CatUnit (NONCLUSTERED): CategoryId, UnitId




### dbo.Trades



**Rows:** 107

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| TradeId | int | No | Yes |  |  |
| ParentId | int | Yes | No |  |  |
| Active | tinyint | Yes | No |  |  |
| Description | varchar(255) | Yes | No |  |  |
| Comments | text | Yes | No |  |  |
| PackageNumber | int | Yes | No |  |  |



**Primary Key:** TradeId





**Indexes:**
- PK__Trades__3028BB5B0826AB44 (CLUSTERED): TradeId




### dbo.TransactionLog_HISTORY



**Rows:** 99,019,937

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| SysId | uniqueidentifier | No | No |  |  |
| RequestStart | datetime2 | No | No |  |  |
| RequestEnd | datetime2 | Yes | No |  |  |
| SessionId | varchar(64) | Yes | No |  |  |
| TargetServer | varchar(64) | Yes | No |  |  |
| URL | varchar(2014) | Yes | No |  |  |
| Headers | varchar(MAX) | Yes | No |  |  |
| Content | varchar(MAX) | Yes | No |  |  |
| Method | varchar(50) | Yes | No |  |  |
| Protocol | varchar(255) | Yes | No |  |  |



**Primary Key:** SysId





**Indexes:**
- PK__Transact__EB33B1C2BA5D0C0D (CLUSTERED): SysId
- ski_RequestStart_Session (NONCLUSTERED): SessionId, SysId, RequestStart
- SKI_SessionRequestStart (NONCLUSTERED): SysId, SessionId, RequestStart




### dbo.TransactionLogCF



**Rows:** 25,335,821

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| SysId | uniqueidentifier | No | No | (newid()) |  |
| RequestStart | datetime2 | Yes | No | (sysdatetime()) |  |
| RequestEnd | datetime2 | Yes | No |  |  |
| SessionId | varchar(64) | Yes | No |  |  |
| TargetServer | varchar(64) | Yes | No |  |  |
| URL | varchar(2014) | Yes | No |  |  |
| Headers | varchar(MAX) | Yes | No |  |  |
| Content | varchar(MAX) | Yes | No |  |  |
| Method | varchar(50) | Yes | No |  |  |
| Protocol | varchar(255) | Yes | No |  |  |



**Primary Key:** SysId





**Indexes:**
- PK__Transact__EB33B1C261E2A3C5 (CLUSTERED): SysId
- SKI_RequestStart_SessionHeadersSysId (NONCLUSTERED): SysId, SessionId, Headers, RequestStart
- SKI_SessionRequestStart_HeadersSysId (NONCLUSTERED): SysId, Headers, SessionId, RequestStart




### dbo.TransactionTypes



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| TransactionTypeId | int | No | Yes |  |  |
| Description | varchar(255) | No | No |  |  |
| Credit | tinyint | Yes | No |  |  |



**Primary Key:** TransactionTypeId





**Indexes:**
- PK__TransactionTypes__1EEF72A2 (CLUSTERED): TransactionTypeId




### dbo.TransmitLog



**Rows:** 131,864

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| TransmitId | uniqueidentifier | No | No | (newid()) |  |
| DateStamp | datetime2 | Yes | No | (getdate()) |  |
| RequestURL | varchar(1024) | Yes | No |  |  |
| RequestParams | varchar(2048) | Yes | No |  |  |
| RequestData | varchar(MAX) | Yes | No |  |  |



**Primary Key:** TransmitId





**Indexes:**
- PK__Transmit__63FDBAB3BAF604AA (CLUSTERED): TransmitId




### dbo.Units



**Rows:** 11,217

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| UnitId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| Code | varchar(20) | Yes | No |  |  |



**Primary Key:** UnitId





**Indexes:**
- PK_Units (CLUSTERED): UnitId
- _dta_index_Units_7_334676290__K1_3 (NONCLUSTERED): Code, UnitId
- SK_Code (NONCLUSTERED): Code
- SKI_UnitId_Code (NONCLUSTERED): Code, UnitId




### dbo.UNSPSCs



**Rows:** 50,317

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| UNSPSCId | int | No | No |  |  |
| Code | varchar(10) | No | No |  |  |
| Description | varchar(255) | No | No |  |  |



**Primary Key:** UNSPSCId





**Indexes:**
- PK__UNSPSCs__C2A3FEE54B5BDC5F (CLUSTERED): UNSPSCId




### dbo.UnsubscriptionEmail



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| Id | int | No | Yes |  |  |
| Email | varchar(255) | Yes | No |  |  |
| CreatedAt | datetime | Yes | No | (getdate()) |  |



**Primary Key:** Id





**Indexes:**
- PK_UnsubscriptionEmail (CLUSTERED): Id
- UnsubscriptionEmail_uindex (NONCLUSTERED): Email




### dbo.UserAccounts



**Rows:** 3,186,342

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| UserAccountId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| AccountId | int | Yes | No |  |  |
| BudgetId | int | Yes | No |  |  |
| BudgetAccountId | int | Yes | No |  |  |
| UserId | int | Yes | No |  |  |
| AllocationAmount | money | Yes | No |  |  |
| AllocationAvailable | money | Yes | No |  |  |
| UseAllocations | tinyint | Yes | No |  |  |



**Primary Key:** UserAccountId



**Foreign Keys:**
- AccountId → dbo.Accounts.AccountId
- BudgetAccountId → dbo.BudgetAccounts.BudgetAccountId
- BudgetId → dbo.Budgets.BudgetId




**Indexes:**
- PK_UserAccounts (CLUSTERED): UserAccountId
- SK_BA (NONCLUSTERED): BudgetAccountId
- SK_BudgetAccount (NONCLUSTERED): Active, BudgetAccountId
- SK_UAUseAllocations (NONCLUSTERED): UseAllocations, UserAccountId
- SK_User (NONCLUSTERED): UserId, Active
- SK_UserAccount (NONCLUSTERED): AccountId, UserId
- SKI_UserBudgetActive_Account (NONCLUSTERED): AccountId, UserId, BudgetId, Active
- UserAccounts34 (NONCLUSTERED): BudgetId, Active, AccountId, UserId




### dbo.UserAdminLog



**Rows:** 6,466

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| logID | int | No | Yes |  |  |
| submituserid | int | No | No |  |  |
| targetuserid | int | Yes | No |  |  |
| action | varchar(50) | No | No |  |  |
| commitString | nvarchar(MAX) | Yes | No |  |  |
| actionDate | datetime | No | No |  |  |



**Primary Key:** logID





**Indexes:**
- PK_UserAdminLog (CLUSTERED): logID




### dbo.UserCategory



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| UserCategoryId | int | No | Yes |  |  |
| UserId | int | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |



**Primary Key:** UserCategoryId





**Indexes:**
- PK_UserCategory (CLUSTERED): UserCategoryId




### dbo.UserImports



**Rows:** 328

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| School | nvarchar(255) | Yes | No |  |  |
| User # | nvarchar(255) | Yes | No |  |  |
| Attention | nvarchar(255) | Yes | No |  |  |
| Approval Level (Teacher/Principal/BA) | nvarchar(255) | Yes | No |  |  |
| Approver User # | nvarchar(255) | Yes | No |  |  |
| Account Code | nvarchar(255) | Yes | No |  |  |
| Amount | float(53) | Yes | No |  |  |
| SysId | int | No | Yes |  |  |









### dbo.Users



**Rows:** 335,194

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| UserId | int | No | Yes |  |  |
| DistrictId | int | Yes | No |  |  |
| SchoolId | int | Yes | No |  |  |
| ShippingId | int | Yes | No |  |  |
| Active | tinyint | Yes | No |  |  |
| UserName | varchar(50) | Yes | No |  |  |
| Password | varchar(100) | Yes | No |  |  |
| Attention | varchar(50) | Yes | No |  |  |
| ApprovalLevel | tinyint | Yes | No |  |  |
| CometId | int | Yes | No |  |  |
| DisableNewRequisition | tinyint | Yes | No |  |  |
| DistrictAcctgCode | varchar(20) | Yes | No |  |  |
| ApproverId | int | Yes | No |  |  |
| NewRequisitionButton | int | Yes | No |  |  |
| AllowIncidentals | tinyint | Yes | No |  |  |
| AllowVendorChanges | tinyint | Yes | No |  |  |
| AllowShipToChanges | tinyint | Yes | No |  |  |
| AllowTM | tinyint | Yes | No |  |  |
| Email | varchar(255) | Yes | No |  |  |
| SecurityRoleId | int | Yes | No |  |  |
| Use20 | tinyint | Yes | No |  |  |
| FirstName | varchar(20) | Yes | No |  |  |
| LastName | varchar(30) | Yes | No |  |  |
| allowMSRP | tinyint | Yes | No |  |  |
| EmailByPassDate | date | Yes | No |  |  |
| AllowExport | bit | Yes | No |  |  |
| HasAdminAccess | bit | Yes | No |  |  |
| AllowAddenda | bit | Yes | No |  |  |
| UseCF | int | Yes | No |  |  |
| IBTypeId | int | Yes | No |  |  |
| AllowAccountCodeMgmt | tinyint | Yes | No |  |  |
| AllowEarlyAccess | tinyint | Yes | No |  |  |
| POAccess | int | Yes | No |  |  |
| NotificationType | int | Yes | No |  |  |
| PasswordOld | varchar(100) | Yes | No |  |  |
| SSOID | varchar(255) | Yes | No |  |  |
| SSOProvider | varchar(50) | Yes | No |  |  |
| ResetPasswordCode | varchar(8) | Yes | No |  |  |
| ResetPasswordCodeExpiration | datetime | Yes | No |  |  |
| AllowVendorCodeMaintenance | tinyint | Yes | No |  |  |
| PositionData | nvarchar(4000) | Yes | No |  |  |



**Primary Key:** UserId





**Indexes:**
- PK_Users (CLUSTERED): UserId
- _dta_index_Users_7_658802521__K1_10_12 (NONCLUSTERED): CometId, DistrictAcctgCode, UserId
- SK_Approver (NONCLUSTERED): ApproverId
- SK_CometId (NONCLUSTERED): CometId
- SKI_DistrictActive_UserSchoolApprovallevelCometApprover (NONCLUSTERED): UserId, SchoolId, ApprovalLevel, CometId, ApproverId, DistrictId, Active
- SKI_SchoolActive_AttentionLevelComet (NONCLUSTERED): Attention, ApprovalLevel, CometId, SchoolId, Active
- SKI_SchoolUser_CometDistrictAcctCode (NONCLUSTERED): CometId, DistrictAcctgCode, SchoolId, UserId
- SKI_User_SchoolCometAcctg (NONCLUSTERED): SchoolId, CometId, DistrictAcctgCode, UserId




### dbo.UserTrees



**Rows:** 56,920

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| utid | int | No | Yes |  |  |
| DistrictId | int | Yes | No |  |  |
| UserId | int | Yes | No |  |  |
| ApproverId | int | Yes | No |  |  |
| ApprovalLevel | int | Yes | No |  |  |
| Level | int | Yes | No |  |  |
| Status | int | Yes | No |  |  |
| SortKey | varchar(512) | Yes | No |  |  |



**Primary Key:** utid





**Indexes:**
- PK_UserTrees (CLUSTERED): utid




### dbo.VendorCatalogNote



**Rows:** 11

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VendorCatalogNoteId | int | No | Yes |  |  |
| VendorId | int | Yes | No |  |  |
| CatalogId | int | Yes | No |  |  |
| NoteTitle | varchar(80) | Yes | No |  |  |
| Note | varchar(4000) | Yes | No |  |  |
| NoteDateTime | datetime | Yes | No |  |  |



**Primary Key:** VendorCatalogNoteId





**Indexes:**
- PK_VendorCatalogNote (CLUSTERED): VendorCatalogNoteId




### dbo.VendorCategory



**Rows:** 6,740

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VCId | int | No | Yes |  |  |
| VendorId | int | Yes | No |  |  |
| CategoryId | int | Yes | No |  |  |
| VendorName | varchar(50) | Yes | No |  |  |
| WebLink | varchar(512) | Yes | No |  |  |



**Primary Key:** VCId





**Indexes:**
- PK_VendorCategory (CLUSTERED): VCId
- SK_Category (NONCLUSTERED): CategoryId
- SK_Vendor (NONCLUSTERED): VendorId
- SKI_VendorCategory_Name (NONCLUSTERED): VCId, VendorName, WebLink, VendorId, CategoryId




### dbo.VendorCategoryPP



**Rows:** 17,273

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VCPId | int | No | Yes |  |  |
| VendorId | int | No | No |  |  |
| CategoryId | int | No | No |  |  |
| DistrictId | int | Yes | No |  |  |
| PricePlanId | int | Yes | No |  |  |



**Primary Key:** VCPId





**Indexes:**
- PK__VendorCategoryPP__2B8A53B1 (CLUSTERED): VCPId
- SK_VendorId (NONCLUSTERED): VendorId




### dbo.VendorCertificates



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VendorCertificateId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| VendorId | int | No | No |  |  |
| CertificateAuthorityId | int | No | No |  |  |
| Certificate | varchar(50) | Yes | No |  |  |
| DateOfIssuance | datetime | Yes | No |  |  |
| ExpirationDate | datetime | Yes | No |  |  |



**Primary Key:** VendorCertificateId





**Indexes:**
- PK__VendorCe__6273C2F02BF9F766 (CLUSTERED): VendorCertificateId




### dbo.VendorContacts



**Rows:** 23,116

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VendorContactId | int | No | Yes |  |  |
| VendorId | int | No | No |  |  |
| Active | tinyint | Yes | No |  |  |
| SalutationId | int | Yes | No |  |  |
| FirstName | varchar(50) | Yes | No |  |  |
| LastName | varchar(50) | Yes | No |  |  |
| Suffix | varchar(20) | Yes | No |  |  |
| Address1 | varchar(50) | Yes | No |  |  |
| Address2 | varchar(50) | Yes | No |  |  |
| City | varchar(50) | Yes | No |  |  |
| State | char(2) | Yes | No |  |  |
| Zipcode | varchar(10) | Yes | No |  |  |
| Phone | varchar(25) | Yes | No |  |  |
| Fax | varchar(20) | Yes | No |  |  |
| EMail | varchar(255) | Yes | No |  |  |
| Comments | varchar(1024) | Yes | No |  |  |
| Password | varchar(50) | Yes | No |  |  |
| LastModified | datetime | Yes | No |  |  |
| BidContact | tinyint | Yes | No |  |  |
| POContact | tinyint | Yes | No |  |  |
| FullName | varchar(150) | Yes | No |  |  |
| FreightContact | tinyint | Yes | No |  |  |
| CSContact | tinyint | Yes | No |  |  |
| ARContact | tinyint | Yes | No |  |  |



**Primary Key:** VendorContactId





**Indexes:**
- PK__VendorCo__A4D440DD7E883271 (CLUSTERED): VendorContactId
- _dta_index_VendorContacts_7_183372118__K2_K1_8_9_10_11_12_13 (NONCLUSTERED): Address1, Address2, City, State, Zipcode, Phone, VendorId, VendorContactId
- _dta_index_VendorContacts_7_183372118__K3_K2_K1_K20 (NONCLUSTERED): Active, VendorId, VendorContactId, POContact
- SKI_Vendor_All (NONCLUSTERED): VendorContactId, Active, SalutationId, FirstName, LastName, Suffix, Address1, Address2, City, State, Zipcode, Phone, Fax, EMail, BidContact, POContact, FullName, VendorId
- SKI_Vendor_VendorcontactidActiveBidcontactPocontact (NONCLUSTERED): BidContact, VendorId, Active, POContact, VendorContactId




### dbo.VendorDeliveryRule



**Rows:** 1

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VendorDeliveryRuleId | int | No | Yes |  |  |
| Name | varchar(50) | Yes | No | ('') |  |
| Description | varchar(500) | Yes | No | ('') |  |
| DeliveryDays | varchar(100) | Yes | No | ('') |  |
| DeliveryTime | int | Yes | No |  |  |
| AllowGapDay | bit | Yes | No | ((0)) |  |









### dbo.VendorDocRequest



**Rows:** 14

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VendorDocRequestId | int | No | Yes |  |  |
| BidHeaderId | int | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| BidImportId | int | Yes | No |  |  |
| EmailAddress | varchar(4000) | Yes | No |  |  |
| Fax | varchar(20) | Yes | No |  |  |
| AddDate | datetime | Yes | No |  |  |
| SendDate | datetime | Yes | No |  |  |
| EmailAddress2 | varchar(255) | Yes | No |  |  |
| EmailCCAddress | varchar(255) | Yes | No |  |  |
| MessageContent | varchar(MAX) | Yes | No |  |  |
| MessageReceiptConfirmed | datetime | Yes | No |  |  |
| VendorDocRequestNotes | varchar(1000) | Yes | No |  |  |
| ContactName | varchar(4000) | Yes | No |  |  |



**Primary Key:** VendorDocRequestId





**Indexes:**
- PK_VendorDocRequest (CLUSTERED): VendorDocRequestId




### dbo.VendorDocRequestDetail



**Rows:** 52

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VendorDocRequestDetailId | int | No | Yes |  |  |
| BidHeaderId | int | Yes | No |  |  |
| BidImportId | int | Yes | No |  |  |
| BidHeaderCheckListId | int | Yes | No |  |  |
| VendorDocRequestId | int | Yes | No |  |  |
| AddDate | datetime | Yes | No |  |  |
| SendDate | datetime | Yes | No |  |  |
| CommentsRejectReason | varchar(1024) | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| DistrictName | varchar(50) | Yes | No |  |  |
| ResolvedFlag | tinyint | Yes | No |  |  |



**Primary Key:** VendorDocRequestDetailId





**Indexes:**
- PK_VendorDocRequestDetail (CLUSTERED): VendorDocRequestDetailId




### dbo.VendorDocRequestStatus



**Rows:** 14

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VendorDocRequestStatusId | int | No | Yes |  |  |
| VendorDocRequestId | int | Yes | No |  |  |
| StatusId | int | Yes | No |  |  |
| StatusDate | datetime | Yes | No |  |  |
| FollowUpDate | datetime | Yes | No |  |  |



**Primary Key:** VendorDocRequestStatusId





**Indexes:**
- PK_VendorDocRequestStatus (NONCLUSTERED): VendorDocRequestStatusId




### dbo.VendorLocations



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VendorLocationId | int | No | Yes |  |  |
| ShippingId | int | No | No |  |  |
| VendorId | int | No | No |  |  |
| LocationCode | varchar(50) | Yes | No |  |  |



**Primary Key:** VendorLocationId





**Indexes:**
- PK__VendorLocations__55F8BC25 (CLUSTERED): VendorLocationId




### dbo.VendorLogoDisplays



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VendorLogoDisplayID | int | No | Yes |  |  |
| Sequence | int | No | No |  |  |
| VendorID | int | No | No |  |  |



**Primary Key:** VendorLogoDisplayID





**Indexes:**
- PK__VendorLo__68EBDD4F7211DF33 (CLUSTERED): VendorLogoDisplayID




### dbo.VendorOrders



**Rows:** 1,766

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VendorOrderId | int | No | Yes |  |  |
| VendorId | int | No | No |  |  |
| POId | int | No | No |  |  |
| LastUpdated | datetime | Yes | No |  |  |
| VendorData | nvarchar(MAX) | Yes | No |  |  |
| VendorStatus | varchar(MAX) | Yes | No |  |  |



**Primary Key:** VendorOrderId





**Indexes:**
- PK__VendorOr__477DCB3BB41239CE (CLUSTERED): VendorOrderId




### dbo.VendorOverrideMessages



**Rows:** 5

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VOMId | int | No | Yes |  |  |
| Message | varchar(50) | No | No |  |  |
| RequiredLevel | int | Yes | No |  |  |



**Primary Key:** VOMId





**Indexes:**
- PK__VendorOverrideMe__01D73E63 (CLUSTERED): VOMId




### dbo.VendorPOtags



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| SysId | uniqueidentifier | No | No | (newsequentialid()) |  |
| SessionId | int | No | No |  |  |
| ScreenId | varchar(50) | No | No |  |  |
| TagId | int | No | No |  |  |
| Tagged | tinyint | Yes | No |  |  |







**Indexes:**
- MSmerge_index_2044234733 (NONCLUSTERED): SysId




### dbo.VendorQuery



**Rows:** 11,462

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VendorQueryId | int | No | Yes |  |  |
| BidHeaderId | int | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| BidImportId | int | Yes | No |  |  |
| EmailAddress | varchar(4000) | Yes | No |  |  |
| Fax | varchar(20) | Yes | No |  |  |
| AddDate | datetime | Yes | No |  |  |
| SendDate | datetime | Yes | No |  |  |
| EmailAddress2 | varchar(255) | Yes | No |  |  |
| EmailCCAddress | varchar(255) | Yes | No |  |  |
| MessageContent | varchar(MAX) | Yes | No |  |  |
| MessageReceiptConfirmed | datetime | Yes | No |  |  |
| VendorQueryNotes | varchar(1000) | Yes | No |  |  |
| ContactName | varchar(4000) | Yes | No |  |  |



**Primary Key:** VendorQueryId





**Indexes:**
- PK_VendorQuery (CLUSTERED): VendorQueryId
- SKI_Bidheader_QueryVendor (NONCLUSTERED): VendorQueryId, VendorId, BidHeaderId




### dbo.VendorQueryDetail



**Rows:** 127,686

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VendorQueryDetailId | int | No | Yes |  |  |
| BidResultsId | int | Yes | No |  |  |
| BidHeaderId | int | Yes | No |  |  |
| BidImportId | int | Yes | No |  |  |
| VendorQueryId | int | Yes | No |  |  |
| AddDate | datetime | Yes | No |  |  |
| SendDate | datetime | Yes | No |  |  |
| ItemQuery | varchar(4000) | Yes | No |  |  |
| ItemQueryNotes | varchar(1000) | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| DistrictName | varchar(50) | Yes | No |  |  |
| ResolvedFlag | tinyint | Yes | No |  |  |
| CommonVendorQueryId | int | Yes | No |  |  |



**Primary Key:** VendorQueryDetailId





**Indexes:**
- PK_VendorQueryDetail (CLUSTERED): VendorQueryDetailId
- SK_VendorQueryId (NONCLUSTERED): VendorQueryId




### dbo.VendorQueryMSRP



**Rows:** 140

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VendorQueryMSRPId | int | No | Yes |  |  |
| BidHeaderId | int | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| BidImportId | int | Yes | No |  |  |
| EmailAddress | varchar(4000) | Yes | No |  |  |
| Fax | varchar(20) | Yes | No |  |  |
| AddDate | datetime | Yes | No |  |  |
| SendDate | datetime | Yes | No |  |  |
| EmailAddress2 | varchar(255) | Yes | No |  |  |
| EmailCCAddress | varchar(255) | Yes | No |  |  |
| MessageContent | varchar(MAX) | Yes | No |  |  |
| MessageReceiptConfirmed | datetime | Yes | No |  |  |
| VendorQueryMSRPNotes | varchar(1000) | Yes | No |  |  |
| ContactName | varchar(4000) | Yes | No |  |  |



**Primary Key:** VendorQueryMSRPId





**Indexes:**
- PK_VendorQueryMSRP (CLUSTERED): VendorQueryMSRPId




### dbo.VendorQueryMSRPDetail



**Rows:** 2

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VendorQueryMSRPDetailId | int | No | Yes |  |  |
| BidHeaderId | int | Yes | No |  |  |
| BidImportId | int | Yes | No |  |  |
| VendorQueryMSRPId | int | Yes | No |  |  |
| AddDate | datetime | Yes | No |  |  |
| SendDate | datetime | Yes | No |  |  |
| MSRPQueryType | int | Yes | No |  |  |
| MSRPQuery | varchar(4000) | Yes | No |  |  |
| MSRPQueryManufacturers | varchar(MAX) | Yes | No |  |  |
| MSRPQueryNotes | varchar(1000) | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| ResolvedFlag | tinyint | Yes | No |  |  |
| AllowReply | tinyint | Yes | No |  |  |
| ManufacturerSelection | int | Yes | No |  |  |



**Primary Key:** VendorQueryMSRPDetailId



**Foreign Keys:**
- VendorQueryMSRPId → dbo.VendorQueryMSRP.VendorQueryMSRPId




**Indexes:**
- PK_VendorQueryMSRPDetail (CLUSTERED): VendorQueryMSRPDetailId




### dbo.VendorQueryMSRPStatus



**Rows:** 2

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VendorQueryMSRPStatusId | int | No | Yes |  |  |
| VendorQueryMSRPId | int | Yes | No |  |  |
| StatusId | int | Yes | No |  |  |
| StatusDate | datetime | Yes | No |  |  |
| FollowUpDate | datetime | Yes | No |  |  |



**Primary Key:** VendorQueryMSRPStatusId



**Foreign Keys:**
- VendorQueryMSRPId → dbo.VendorQueryMSRP.VendorQueryMSRPId




**Indexes:**
- PK_VendorQueryMSRPStatus (CLUSTERED): VendorQueryMSRPStatusId




### dbo.VendorQueryStatus



**Rows:** 30,025

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VendorQueryStatusId | int | No | Yes |  |  |
| VendorQueryId | int | Yes | No |  |  |
| StatusId | int | Yes | No |  |  |
| StatusDate | datetime | Yes | No |  |  |
| FollowUpDate | datetime | Yes | No |  |  |



**Primary Key:** VendorQueryStatusId





**Indexes:**
- PK_VendorQueryStatus (NONCLUSTERED): VendorQueryStatusId
- IX_VendorQueryStatus (NONCLUSTERED): VendorQueryId




### dbo.VendorQueryTandM



**Rows:** 1,815

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VendorQueryTandMId | int | No | Yes |  |  |
| BidHeaderId | int | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| BidImportId | int | Yes | No |  |  |
| EmailAddress | varchar(4000) | Yes | No |  |  |
| Fax | varchar(20) | Yes | No |  |  |
| AddDate | datetime | Yes | No |  |  |
| SendDate | datetime | Yes | No |  |  |
| EmailAddress2 | varchar(255) | Yes | No |  |  |
| EmailCCAddress | varchar(255) | Yes | No |  |  |
| MessageContent | varchar(MAX) | Yes | No |  |  |
| MessageReceiptConfirmed | datetime | Yes | No |  |  |
| VendorQueryTandMNotes | varchar(1000) | Yes | No |  |  |
| ContactName | varchar(4000) | Yes | No |  |  |



**Primary Key:** VendorQueryTandMId





**Indexes:**
- PK_VendorQueryTandM (CLUSTERED): VendorQueryTandMId




### dbo.VendorQueryTandMDetail



**Rows:** 1,011

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VendorQueryTandMDetailId | int | No | Yes |  |  |
| BidHeaderId | int | Yes | No |  |  |
| BidImportId | int | Yes | No |  |  |
| VendorQueryTandMId | int | Yes | No |  |  |
| AddDate | datetime | Yes | No |  |  |
| SendDate | datetime | Yes | No |  |  |
| TandMQueryType | int | Yes | No |  |  |
| TandMQuery | varchar(4000) | Yes | No |  |  |
| TandMQueryCounties | varchar(1000) | Yes | No |  |  |
| TandMQueryNotes | varchar(1000) | Yes | No |  |  |
| VendorId | int | Yes | No |  |  |
| ResolvedFlag | tinyint | Yes | No |  |  |



**Primary Key:** VendorQueryTandMDetailId



**Foreign Keys:**
- VendorQueryTandMId → dbo.VendorQueryTandM.VendorQueryTandMId




**Indexes:**
- PK_VendorQueryTandMDetail (CLUSTERED): VendorQueryTandMDetailId




### dbo.VendorQueryTandMStatus



**Rows:** 1,537

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VendorQueryTandMStatusId | int | No | Yes |  |  |
| VendorQueryTandMId | int | Yes | No |  |  |
| StatusId | int | Yes | No |  |  |
| StatusDate | datetime | Yes | No |  |  |
| FollowUpDate | datetime | Yes | No |  |  |



**Primary Key:** VendorQueryTandMStatusId



**Foreign Keys:**
- VendorQueryTandMId → dbo.VendorQueryTandM.VendorQueryTandMId




**Indexes:**
- PK_VendorQueryTandMStatus (CLUSTERED): VendorQueryTandMStatusId




### dbo.Vendors



**Rows:** 18,794

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VendorId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| Code | varchar(16) | Yes | No |  |  |
| Name | varchar(50) | Yes | No |  |  |
| Address1 | varchar(50) | Yes | No |  |  |
| Address2 | varchar(50) | Yes | No |  |  |
| Address3 | varchar(50) | Yes | No |  |  |
| City | varchar(25) | Yes | No |  |  |
| State | varchar(2) | Yes | No |  |  |
| ZipCode | varchar(10) | Yes | No |  |  |
| Phone | varchar(20) | Yes | No |  |  |
| Fax | varchar(20) | Yes | No |  |  |
| EMail | varchar(255) | Yes | No |  |  |
| UseGrossPrices | tinyint | Yes | No |  |  |
| ShippingPercentage | decimal(9,5) | Yes | No |  |  |
| DistrictId | int | Yes | No |  |  |
| Password | varchar(50) | Yes | No |  |  |
| HostURL | varchar(255) | Yes | No |  |  |
| HostPort | int | Yes | No |  |  |
| HostDirectory | varchar(255) | Yes | No |  |  |
| HostUserName | varchar(255) | Yes | No |  |  |
| HostPassword | varchar(255) | Yes | No |  |  |
| UploadEMailList | varchar(4096) | Yes | No |  |  |
| UploadType | int | Yes | No |  |  |
| BusinessUnit | varchar(17) | Yes | No |  |  |
| POPassword | varchar(50) | Yes | No |  |  |
| cXMLAddress | varchar(255) | Yes | No |  |  |
| VendorLogo | varbinary(MAX) | Yes | No |  |  |
| cXMLFromDomain | varchar(50) | Yes | No |  |  |
| cXMLFromIdentity | varchar(50) | Yes | No |  |  |
| cXMLToDomain | varchar(50) | Yes | No |  |  |
| cXMLToIdentity | varchar(50) | Yes | No |  |  |
| cXMLSenderDomain | varchar(50) | Yes | No |  |  |
| cXMLSenderIdentity | varchar(50) | Yes | No |  |  |
| cXMLSenderSharedSecret | varchar(50) | Yes | No |  |  |
| AllowElectronicPOs | int | Yes | No |  |  |
| VendorDeliveryRuleId | int | Yes | No | ((1)) |  |



**Primary Key:** VendorId





**Indexes:**
- PK_Vendors (CLUSTERED): VendorId
- _dta_index_Vendors_7_1906157886__K1_3 (NONCLUSTERED): Code, VendorId
- _dta_index_Vendors_7_1906157886__K1_3_4 (NONCLUSTERED): Code, Name, VendorId
- _dta_index_Vendors_7_1906157886__K1_4 (NONCLUSTERED): Name, VendorId
- _dta_index_Vendors_7_279372460__K1_3_4_5_6_7_8_9_10_11_15_24 (NONCLUSTERED): Code, Name, Address1, Address2, Address3, City, State, ZipCode, Phone, ShippingPercentage, UploadType, VendorId
- _dta_index_Vendors_9_752057765__K1_K4 (NONCLUSTERED): VendorId, Name
- _dta_stat_279372460_18 (NONCLUSTERED): HostURL
- SK_ActiveName (NONCLUSTERED): Active, Name
- SK_Code (NONCLUSTERED): Code
- SKI_ActiveCode_Vendor (NONCLUSTERED): VendorId, Active, Code




### dbo.VendorSessions



**Rows:** 10,613

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VendorSessionId | int | No | Yes |  |  |
| VendorId | int | No | No |  |  |
| UserName | varchar(50) | Yes | No |  |  |
| jSession | varchar(255) | Yes | No |  |  |
| StartTime | datetime | Yes | No |  |  |
| EndTime | datetime | Yes | No |  |  |
| IPAddress | varchar(50) | Yes | No |  |  |
| VPORegistrationId | int | Yes | No |  |  |



**Primary Key:** VendorSessionId





**Indexes:**
- PK_VendorSessions (CLUSTERED): VendorSessionId
- SK_jSessionPK (NONCLUSTERED): jSession, VendorSessionId




### dbo.VendorUploads



**Rows:** 1,529,628

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| UploadId | int | No | Yes |  |  |
| FileName | varchar(255) | Yes | No |  |  |
| DateCreated | datetime | Yes | No |  |  |
| DateUploaded | datetime | Yes | No |  |  |
| Status | varchar(255) | Yes | No |  |  |
| cxmlsessionid | int | Yes | No |  |  |
| poid | int | Yes | No |  |  |
| PayloadID | varchar(255) | Yes | No |  |  |



**Primary Key:** UploadId





**Indexes:**
- PK__VendorUploads__4C813328 (CLUSTERED): UploadId
- SK_PO (NONCLUSTERED): poid




### dbo.VPOLoginAttempts



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VPOLoginAttemptId | int | No | Yes |  |  |
| VPOUserCode | varchar(50) | No | No |  |  |
| VPORegistrationId | int | Yes | No |  |  |
| VPOEventDate | datetime | No | No | (getdate()) |  |
| IPAddress | varchar(50) | Yes | No |  |  |
| LoginStatus | int | No | No | ((2)) |  |



**Primary Key:** VPOLoginAttemptId





**Indexes:**
- PK__VPOLogin__DE43609E57D879A4 (CLUSTERED): VPOLoginAttemptId




### dbo.VPORegistrations



**Rows:** 6

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VPORegistrationId | int | No | Yes |  |  |
| Active | tinyint | Yes | No |  |  |
| VPOUserCode | varchar(50) | No | No |  |  |
| VPOPassword | varchar(50) | No | No |  |  |
| VPOLastChange | datetime | No | No | (getdate()) |  |
| VPOEMail | varchar(255) | Yes | No |  |  |
| VPOName | varchar(50) | Yes | No |  |  |
| VPOPhone | varchar(50) | Yes | No |  |  |
| VPOAllowedRetries | int | No | No | ((5)) |  |
| VPOParentId | int | Yes | No |  |  |
| VPOCanCreateUser | tinyint | Yes | No |  |  |



**Primary Key:** VPORegistrationId





**Indexes:**
- PK__VPORegis__811068474D5AEB31 (CLUSTERED): VPORegistrationId




### dbo.VPOVendorLinks



**Rows:** 10

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| VPOVendorLinkId | int | No | Yes |  |  |
| VPORegistrationId | int | No | No |  |  |
| VendorId | int | No | No |  |  |
| LastChange | datetime | No | No | (getdate()) |  |



**Primary Key:** VPOVendorLinkId





**Indexes:**
- PK__VPOVendo__8C21AD725313C487 (CLUSTERED): VPOVendorLinkId
- IX_VPOVendorLinks (NONCLUSTERED): VPORegistrationId, VendorId




### dbo.WizHelpFile



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| Id | int | Yes | No |  |  |
| Proc | varchar(64) | Yes | No |  |  |
| Field | varchar(64) | Yes | No |  |  |
| HelpText | char(1024) | Yes | No |  |  |









### dbo.YearlyTotals



**Rows:** 9,985

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| BudgetId | int | No | No |  |  |
| Name | varchar(30) | Yes | No |  |  |
| DistrictId | int | Yes | No |  |  |
| DistrictName | varchar(189) | Yes | No |  |  |
| TotalBidCost | money | Yes | No |  |  |
| TotalCatalogCost | numeric(38,6) | Yes | No |  |  |
| TotalStateContractCost | numeric(38,6) | Yes | No |  |  |
| StateContractDiscount | decimal(13,9) | Yes | No |  |  |
| OverallSavings | numeric(38,6) | Yes | No |  |  |
| OverallDiscount | numeric(38,6) | Yes | No |  |  |
| IncludedCatalogCost | numeric(38,6) | Yes | No |  |  |
| IncludedBidCost | money | Yes | No |  |  |
| ExcludedCatalogCost | numeric(38,6) | Yes | No |  |  |
| ExcludedBidCost | money | Yes | No |  |  |
| IncludedSavings | numeric(38,6) | Yes | No |  |  |
| ExcludedSavings | numeric(38,6) | Yes | No |  |  |
| IncludedDiscount | numeric(38,6) | Yes | No |  |  |
| ExcludedDiscount | numeric(38,6) | Yes | No |  |  |









### dbo.z4zbBidFix



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| PackedCode | varchar(50) | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |
| DoNotDiscount | int | Yes | No |  |  |
| GrossPrice | money | Yes | No |  |  |
| z4ItemId | int | Yes | No |  |  |
| z4Price | decimal(33,13) | Yes | No |  |  |
| z4BidQuantity | int | Yes | No |  |  |
| z4GrossPrice | money | Yes | No |  |  |
| zbItemId | int | Yes | No |  |  |
| zbPrice | decimal(33,13) | Yes | No |  |  |
| zbBidQuantity | int | Yes | No |  |  |
| zbGrossPrice | money | Yes | No |  |  |









### dbo.z4zbReqDetail



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| RequisitionId | int | No | No |  |  |
| DetailId | int | No | No |  |  |
| BidPrice | money | Yes | No |  |  |
| ItemId | int | Yes | No |  |  |
| BidItemId | int | Yes | No |  |  |
| z4ItemId | int | Yes | No |  |  |
| zbItemId | int | Yes | No |  |  |
| Filtered | int | Yes | No |  |  |







**Indexes:**
- SKI_DetailFiltered_BidPrice (NONCLUSTERED): BidPrice, DetailId, Filtered
- SKI_Filtered_DetailPrice (NONCLUSTERED): DetailId, BidPrice, Filtered




### EDSIQWebUser.migratorversions



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| version | varchar(25) | Yes | No |  |  |









### EDSIQWebUser.TableOfContents



**Rows:** 6,664

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| TCId | int | No | Yes |  |  |
| Title | varchar(255) | Yes | No |  |  |
| PageNbr | int | Yes | No |  |  |
| OrderBookId | int | Yes | No |  |  |



**Primary Key:** TCId





**Indexes:**
- PK_TableOfContents (CLUSTERED): TCId




### EDSIQWebUser.UnsubscriptionEmail



**Rows:** 0

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| Id | int | No | Yes |  |  |
| Email | varchar(100) | No | No |  |  |
| CreatedAt | datetime | Yes | No | (getdate()) |  |



**Primary Key:** Id





**Indexes:**
- PK_UnsubscriptionEmail (CLUSTERED): Id
- UnsubscriptionEmail_uindex (NONCLUSTERED): Email




### EDSWebRpts.REPMAN_GROUPS



**Rows:** 1

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| GROUP_CODE | int | No | No |  |  |
| GROUP_NAME | varchar(100) | Yes | No |  |  |
| PARENT_GROUP | int | No | No |  |  |



**Primary Key:** GROUP_CODE





**Indexes:**
- PK__REPMAN_GROUPS__2DFCAC08 (CLUSTERED): GROUP_CODE




### EDSWebRpts.REPMAN_REPORTS



**Rows:** 1

#### Columns

| Column | Data Type | Nullable | Identity | Default | Description |
|--------|-----------|----------|----------|---------|-------------|
| REPORT_NAME | varchar(100) | No | No |  |  |
| REPORT | BLOB | No | No |  |  |
| REPORT_GROUP | int | Yes | No |  |  |
| USER_FLAG | int | Yes | No |  |  |



**Primary Key:** REPORT_NAME





**Indexes:**
- PK__REPMAN_REPORTS__2C146396 (CLUSTERED): REPORT_NAME





## Views


### dbo.BidAnalysisDetail



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| CategoryName | varchar(50) | Yes |  |
| PricePlanName | varchar(278) | No |  |
| BidHeaderId | int | Yes |  |
| BidRequestItemId | int | No |  |
| DistrictId | int | Yes |  |
| DistrictName | varchar(50) | No |  |
| ItemCode | varchar(50) | Yes |  |
| Description | varchar(1024) | Yes |  |
| UnitCode | varchar(20) | Yes |  |
| VendorName | varchar(50) | No |  |
| VendorCode | varchar(16) | No |  |
| BidUnits | varchar(16) | Yes |  |
| BidRequest | int | Yes |  |
| BidType | varchar(13) | Yes |  |
| QuantityBid | int | Yes |  |
| UnitPrice | decimal(34,13) | Yes |  |
| ExtendedCost | decimal(38,6) | Yes |  |
| Alternate | varchar(MAX) | Yes |  |
| VendorItemCode | varchar(50) | Yes |  |
| BidRequestStatus | varchar(50) | Yes |  |
| Status | varchar(51) | Yes |  |
| ResultsStatus | int | No |  |
| BidResultsId | int | Yes |  |
| Comments | varchar(1024) | Yes |  |
| ItemComments | varchar(1024) | Yes |  |
| PriceVarianceLevel | decimal(9,5) | Yes |  |
| FirstPrice | decimal(34,13) | Yes |  |
| FirstPriceBidResultsId | int | Yes |  |
| SecondPrice | decimal(34,13) | Yes |  |
| SecondPriceBidResultsId | int | Yes |  |
| Compliant1st | int | Yes |  |
| SortKey | varchar(124) | Yes |  |
| Variance | decimal(38,6) | Yes |  |
| ItemStatus | varchar(MAX) | Yes |  |
| PageNo | int | Yes |  |
| BidResultsItemsPerUnit | varchar(50) | Yes |  |
| ItemsItemsPerUnit | varchar(50) | Yes |  |



### dbo.BidAnalysisDetailReq



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| CategoryName | varchar(50) | Yes |  |
| PricePlanName | varchar(278) | No |  |
| BidHeaderId | int | Yes |  |
| BidRequestItemId | int | No |  |
| DistrictId | int | Yes |  |
| DistrictName | varchar(50) | No |  |
| ItemCode | varchar(50) | Yes |  |
| Description | varchar(1024) | Yes |  |
| UnitCode | varchar(20) | Yes |  |
| VendorName | varchar(50) | No |  |
| VendorCode | varchar(16) | No |  |
| BidUnits | varchar(16) | Yes |  |
| BidRequest | int | Yes |  |
| BidType | varchar(13) | Yes |  |
| QuantityBid | int | Yes |  |
| UnitPrice | decimal(34,13) | Yes |  |
| ExtendedCost | decimal(38,6) | Yes |  |
| Alternate | varchar(MAX) | Yes |  |
| VendorItemCode | varchar(50) | Yes |  |
| BidRequestStatus | varchar(50) | Yes |  |
| Status | varchar(51) | Yes |  |
| BidResultsId | int | Yes |  |
| Comments | varchar(1024) | Yes |  |
| ItemComments | varchar(1024) | Yes |  |
| PriceVarianceLevel | decimal(9,5) | Yes |  |
| FirstPrice | decimal(34,13) | Yes |  |
| FirstPriceBidResultsId | int | Yes |  |
| SecondPrice | decimal(34,13) | Yes |  |
| SecondPriceBidResultsId | int | Yes |  |
| Compliant1st | int | Yes |  |
| OtherReqs | int | No |  |
| SortKey | varchar(124) | Yes |  |
| Variance | decimal(38,6) | Yes |  |
| ItemStatus | varchar(MAX) | Yes |  |



### dbo.BidHeadersView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| Active | tinyint | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| PricePlanCode | varchar(20) | Yes |  |
| PricePlanName | varchar(255) | Yes |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| BidDate | datetime | Yes |  |
| BidAwardDate | datetime | Yes |  |
| BidMessage | varchar(1024) | Yes |  |
| BidReportName | varchar(27) | No |  |



### dbo.bidinfolookup



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | varchar(50) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| PriceplanCode | varchar(20) | Yes |  |
| PricePlanDescription | varchar(278) | Yes |  |
| BidType | varchar(30) | No |  |
| BidYears | varchar(11) | Yes |  |
| BidAdDate | datetime | Yes |  |
| BidHeaderKey | int | No |  |



### dbo.BidItemsView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidItemId | int | No |  |
| BidId | int | Yes |  |
| ItemCode | varchar(50) | Yes |  |
| ItemDescription | varchar(512) | Yes |  |
| Price | money | Yes |  |
| Alternate | varchar(512) | Yes |  |
| BidQuantity | int | Yes |  |
| AwardId | int | Yes |  |
| VendorItemCode | varchar(50) | Yes |  |
| SortSeq | varchar(64) | Yes |  |



### dbo.BidItemView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| Title | varchar(255) | Yes |  |
| Keyword | varchar(50) | Yes |  |
| ItemCode | varchar(50) | Yes |  |
| Description | varchar(1024) | Yes |  |
| UnitCode | varchar(20) | Yes |  |
| Alternate | varchar(512) | Yes |  |
| VendorItemCode | varchar(50) | Yes |  |
| SortSeq | varchar(64) | Yes |  |
| HeadingId | int | Yes |  |
| KeywordId | int | Yes |  |
| ItemId | int | No |  |
| BidHeaderId | int | Yes |  |
| BidPrice | decimal(29,9) | Yes |  |



### dbo.BidMgrBidRankingMSRPView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| ActiveBid | int | No |  |
| VendorName | varchar(50) | Yes |  |
| DiscountRate | decimal(9,5) | Yes |  |
| DiscountRateString | char(10) | Yes |  |
| ManufacturerId | int | No |  |
| ManufacturerName | varchar(100) | No |  |
| WriteInFlag | tinyint | Yes |  |
| WriteInManufacturer | varchar(100) | No |  |
| BidHeaderId | int | No |  |
| BidImportId | int | No |  |
| BidMSRPResultsId | int | No |  |
| WinningBidFlag | int | No |  |
| TieBid | int | No |  |
| VendorNotes | varchar(1000) | Yes |  |
| VendorId | int | No |  |
| VendorCode | varchar(16) | Yes |  |
| WinningBidOverride | tinyint | No |  |



### dbo.BidMgrBidRequestAndWriteInMSRPView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| WriteIn | int | No |  |
| ManufacturerName | varchar(100) | No |  |
| ManufacturerId | int | Yes |  |
| BidRequestManufacturerId | int | No |  |
| SequenceNumber | int | Yes |  |
| UniqueIdString | varchar(60) | Yes |  |



### dbo.BidMgrBidRequestDetail



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| BidRequestItemId | int | No |  |
| Active | tinyint | Yes |  |
| CategoryId | int | Yes |  |
| DistrictId | int | Yes |  |
| RequisitionCount | int | Yes |  |
| ItemId | int | No |  |
| ItemCode | varchar(50) | Yes |  |
| ItemDescription | varchar(512) | Yes |  |
| UnitCode | varchar(20) | Yes |  |
| CrossReferencesText | varchar(1024) | Yes |  |
| BidRequest | int | Yes |  |
| BrandName | varchar(50) | Yes |  |
| ManufacturorNumber | varchar(50) | Yes |  |
| VendorName | varchar(50) | Yes |  |
| VendorPartNumber | varchar(50) | Yes |  |
| Keyword | varchar(50) | Yes |  |
| Title | varchar(255) | Yes |  |
| ExtraDetail | varchar(1024) | Yes |  |
| ItemsPerUnit | varchar(50) | Yes |  |
| SortSeq | varchar(64) | Yes |  |
| Status | varchar(50) | Yes |  |
| Comments | varchar(1024) | Yes |  |
| FullDescription | varchar(1156) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| CategoryType | int | Yes |  |
| Weight | real | Yes |  |



### dbo.BidMgrBidRequestMSRPView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| Active | tinyint | Yes |  |
| ManufacturerName | varchar(100) | No |  |
| ManufacturerId | int | Yes |  |
| BidRequestManufacturerId | int | No |  |
| SequenceNumber | int | Yes |  |



### dbo.BidMgrBidResultsMSRPView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| ManufacturerName | varchar(100) | No |  |
| ActiveBid | int | No |  |
| BidHeaderId | int | No |  |
| BidImportId | int | No |  |
| ManufacturerId | int | Yes |  |
| DiscountRate | decimal(9,5) | Yes |  |
| DiscountRateString | char(10) | Yes |  |
| WriteInFlag | tinyint | Yes |  |
| WriteInManufacturer | varchar(100) | Yes |  |
| Modified | datetime | No |  |
| BidMSRPResultsId | int | No |  |
| WinningBidFlag | int | No |  |
| BidRequestManufacturerId | int | Yes |  |
| WinningBidOverride | tinyint | No |  |



### dbo.BidMgrBidTradeCountiesView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| CountyName | varchar(50) | No |  |
| State | char(2) | No |  |
| BidTradeCountyId | int | No |  |
| BidTradeId | int | No |  |
| CountyId | int | No |  |
| StateId | int | Yes |  |



### dbo.BidMgrBidTradeCountyTotals



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| BidImportId | int | No |  |
| BidTradeId | int | No |  |
| CountyId | int | No |  |
| Name | varchar(50) | No |  |
| State | char(2) | No |  |
| CountyTotalUsedInAward | money | Yes |  |
| ActiveBidImport | tinyint | Yes |  |
| ActiveCounty | tinyint | Yes |  |
| BidImportCountyId | int | No |  |
| ActiveBidAndCounty | tinyint | Yes |  |



### dbo.BidMgrBidTradeLowBidder



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| BidTradeId | int | No |  |
| CountyId | int | No |  |
| BidImportId | int | No |  |
| CountyTotalUsedInAward | money | Yes |  |
| VendorId | int | Yes |  |
| VendorName | varchar(50) | Yes |  |
| CountyName | varchar(50) | No |  |
| VendorCode | varchar(16) | Yes |  |
| State | char(2) | No |  |
| Active | tinyint | Yes |  |
| Comments | varchar(1024) | Yes |  |
| ActiveCounty | tinyint | Yes |  |
| BidImportCountyId | int | No |  |
| ActiveBidAndCounty | tinyint | Yes |  |
| CommentsCounty | varchar(4096) | Yes |  |



### dbo.BidMgrMSRP2ResultsView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| ManufacturerId | int | Yes |  |
| ManufacturerName | varchar(100) | No |  |
| ManufacturerProductLineId | int | No |  |
| ProductLineName | varchar(100) | No |  |
| MSRPOptionId | int | No |  |
| OptionName | varchar(50) | No |  |
| BidMSRPResultsId | int | Yes |  |
| BidMSRPResultsProductLineId | int | Yes |  |
| WriteInManufacturer | varchar(100) | Yes |  |
| WriteInFlag | tinyint | Yes |  |
| WinningBidOverride | tinyint | Yes |  |
| DiscountRate | decimal(38,6) | Yes |  |
| PriceListTypeId | int | Yes |  |
| TotalAward | tinyint | Yes |  |
| TotalAwardDiscount | decimal(9,5) | Yes |  |
| ProductLineWeight | decimal(9,5) | Yes |  |
| TotalAwardManufacturerWeight | decimal(38,6) | Yes |  |
| TotalAwardProductLineWeight | decimal(38,6) | Yes |  |
| SortKey | varchar(15) | Yes |  |
| PriceListType | varchar(50) | Yes |  |
| VendorId | int | Yes |  |
| VendorName | varchar(50) | Yes |  |
| PriceListWarning | varchar(28) | No |  |
| WinningBidFlag | int | No |  |
| AllFlag | int | No |  |



### dbo.BidMgrMSRP2VendorReportView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| BidImportId | int | No |  |
| ActiveBidImport | tinyint | Yes |  |
| VendorsCode | varchar(16) | Yes |  |
| VendorsName | varchar(50) | Yes |  |
| VendorId | int | Yes |  |
| WriteInFlag | tinyint | No |  |
| ManufacturerName | varchar(100) | No |  |
| ActiveManufBid | int | No |  |
| AuthorizationLetter | tinyint | No |  |
| SubmittedExcel | tinyint | No |  |
| ProductCatalog | tinyint | No |  |
| TotalAward | tinyint | No |  |
| VendorPriceFile | tinyint | No |  |
| TotalAwardString | varchar(20) | Yes |  |
| TotalAwardDiscount | decimal(9,5) | Yes |  |
| BidMSRPResultsId | int | No |  |
| BidRequestManufacturerId | int | Yes |  |
| ManufacturerId | int | Yes |  |
| PriceListTypeId | int | No |  |
| PriceListType | varchar(50) | No |  |
| WriteInManufacturer | varchar(100) | Yes |  |
| BidMSRPResultsProductLineId | int | No |  |
| ActiveProdLine | tinyint | Yes |  |
| ProdLineOrWriteIn | varchar(100) | No |  |
| WriteInProductLineFlag | tinyint | Yes |  |
| BidRequestProductLineId | int | Yes |  |
| BidRequestOptionId | int | Yes |  |
| MSRPOptionId | int | Yes |  |
| OptionName | varchar(50) | Yes |  |
| WeightedDiscount | decimal(9,5) | Yes |  |
| ProdLineSortKey | varchar(512) | Yes |  |
| ManufacturerProductLineId | int | No |  |
| AllActive | int | No |  |
| WinningBidFlag | int | No |  |
| AllProductLine | int | No |  |
| FakeRecord | int | No |  |
| VendorALLWinner | int | No |  |



### dbo.BidMgrMSRP2VendorReportViewTemp



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| BidImportId | int | No |  |
| ActiveBidImport | tinyint | Yes |  |
| VendorsCode | varchar(16) | Yes |  |
| VendorsName | varchar(50) | Yes |  |
| VendorId | int | Yes |  |
| WriteInFlag | tinyint | No |  |
| ManufacturerName | varchar(100) | No |  |
| ActiveManufBid | int | No |  |
| AuthorizationLetter | tinyint | No |  |
| SubmittedExcel | tinyint | No |  |
| ProductCatalog | tinyint | No |  |
| TotalAward | tinyint | No |  |
| VendorPriceFile | tinyint | No |  |
| TotalAwardString | varchar(20) | Yes |  |
| TotalAwardDiscount | decimal(9,5) | Yes |  |
| BidMSRPResultsId | int | No |  |
| BidRequestManufacturerId | int | Yes |  |
| ManufacturerId | int | Yes |  |
| PriceListTypeId | int | No |  |
| PriceListType | varchar(50) | No |  |
| WriteInManufacturer | varchar(100) | Yes |  |
| BidMSRPResultsProductLineId | int | No |  |
| ActiveProdLine | tinyint | Yes |  |
| ProdLineOrWriteIn | varchar(100) | No |  |
| WriteInProductLineFlag | tinyint | Yes |  |
| BidRequestProductLineId | int | Yes |  |
| BidRequestOptionId | int | Yes |  |
| MSRPOptionId | int | Yes |  |
| OptionName | varchar(50) | Yes |  |
| WeightedDiscount | decimal(9,5) | Yes |  |
| ProdLineSortKey | varchar(512) | Yes |  |
| ManufacturerProductLineId | int | No |  |
| AllActive | int | No |  |
| WinningBidFlag | int | No |  |
| AllProductLine | int | No |  |
| TotalAwardManufacturerWeight | decimal(38,6) | Yes |  |



### dbo.BidMgrMSRPVendorBidsView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| BidImportId | int | No |  |
| Active | tinyint | Yes |  |
| VendorsCode | varchar(16) | Yes |  |
| VendorsName | varchar(50) | Yes |  |
| VendorId | int | Yes |  |



### dbo.BidMgrView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidResultsId | int | No |  |
| BidHeaderId | int | Yes |  |
| BidRequestItemId | int | Yes |  |
| BidImportId | int | Yes |  |
| VendorName | varchar(50) | Yes |  |
| Quantity | int | Yes |  |
| QuantityBid | int | Yes |  |
| UnitPrice | money | Yes |  |
| Cost | money | Yes |  |
| VendorItemCode | varchar(50) | Yes |  |
| Alternate | varchar(512) | Yes |  |
| ItemsPerUnit | varchar(50) | Yes |  |
| Status | varchar(51) | Yes |  |
| ItemBidType | char(1) | Yes |  |
| PageNo | int | Yes |  |
| BidResultsActive | int | Yes |  |
| BidImportsActive | tinyint | Yes |  |
| SortStatus | int | Yes |  |
| Compliance | varchar(18) | No |  |



### dbo.BidMgrView2



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| BidImportId | int | No |  |
| Active | tinyint | Yes |  |
| BidItemDiscountRate | decimal(9,5) | Yes |  |
| VendorBidNumber | varchar(50) | Yes |  |
| ItemsBid | int | Yes |  |
| AmountBid | money | Yes |  |
| VendorsCode | varchar(16) | Yes |  |
| VendorsName | varchar(50) | Yes |  |
| CatalogName | varchar(50) | Yes |  |
| BidId | int | Yes |  |
| AwardId | int | Yes |  |
| CalculatedItems | int | No |  |
| CalculatedAmount | int | No |  |
| CalculatedItemsBid | int | No |  |
| CalculatedAmountBid | int | No |  |
| PercentBid | int | No |  |
| CatalogDiscountRate | int | No |  |
| ItemsWon | int | No |  |
| PercentWon | int | No |  |
| POCount | int | No |  |
| TotalPOs | int | No |  |
| AveragePO | int | No |  |



### dbo.BidMgrWeightView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidRequestItemId | int | No |  |
| BidHeaderId | int | Yes |  |
| weight | decimal(20,0) | Yes |  |



### dbo.BidProjectAveragePO



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| VendorId | int | No |  |
| VendorCode | varchar(16) | Yes |  |
| VendorName | varchar(50) | Yes |  |
| VendorInfo | varchar(376) | Yes |  |
| Items | int | No |  |
| Total | money | No |  |
| POCount | int | No |  |
| TotalQuantity | int | No |  |
| AvgPO | money | No |  |



### dbo.BidRequestDetail



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| BidRequestItemId | int | No |  |
| Active | tinyint | Yes |  |
| CategoryId | int | Yes |  |
| DistrictId | int | Yes |  |
| RequisitionCount | int | Yes |  |
| ItemId | int | No |  |
| ItemCode | varchar(50) | Yes |  |
| ItemDescription | varchar(512) | Yes |  |
| UnitCode | varchar(20) | Yes |  |
| CrossReferencesText | varchar(1024) | No |  |
| BidRequest | int | Yes |  |
| BrandName | varchar(50) | Yes |  |
| ManufacturorNumber | varchar(50) | Yes |  |
| VendorName | varchar(50) | Yes |  |
| VendorPartNumber | varchar(50) | Yes |  |
| Keyword | varchar(50) | No |  |
| Title | varchar(255) | No |  |
| ExtraDetail | varchar(1153) | No |  |
| ItemsPerUnit | varchar(50) | Yes |  |
| SortSeq | varchar(64) | Yes |  |
| Status | varchar(50) | Yes |  |
| Comments | varchar(1024) | Yes |  |
| FullDescription | varchar(1024) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| CategoryType | int | Yes |  |
| Weight | real | Yes |  |
| HeadingDescription | varchar(4096) | No |  |



### dbo.BidRequestDetail1



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| BidRequestItemId | int | No |  |
| Active | tinyint | Yes |  |
| CategoryId | int | Yes |  |
| DistrictId | int | Yes |  |
| RequisitionCount | int | Yes |  |
| ItemId | int | No |  |
| ItemCode | varchar(50) | Yes |  |
| ItemDescription | varchar(512) | Yes |  |
| UnitCode | varchar(20) | Yes |  |
| CrossReferencesText | varchar(1024) | Yes |  |
| BidRequest | int | Yes |  |
| BrandName | varchar(50) | Yes |  |
| ManufacturorNumber | varchar(50) | Yes |  |
| VendorName | varchar(50) | Yes |  |
| VendorPartNumber | varchar(50) | Yes |  |
| Keyword | varchar(50) | Yes |  |
| Title | varchar(255) | Yes |  |
| ExtraDetail | varchar(1153) | No |  |
| ItemsPerUnit | varchar(50) | Yes |  |
| SortSeq | varchar(64) | Yes |  |
| Status | varchar(50) | Yes |  |
| Comments | varchar(1024) | Yes |  |
| FullDescription | varchar(1024) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| CategoryType | int | Yes |  |
| Weight | real | Yes |  |



### dbo.BidRequestDetail2



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| BidRequestItemId | int | No |  |
| Active | tinyint | Yes |  |
| CategoryId | int | Yes |  |
| DistrictId | int | Yes |  |
| RequisitionCount | int | Yes |  |
| ItemId | int | No |  |
| ItemCode | varchar(50) | Yes |  |
| ItemDescription | varchar(512) | Yes |  |
| UnitCode | varchar(20) | Yes |  |
| CrossReferencesText | varchar(1024) | Yes |  |
| BidRequest | int | Yes |  |
| BrandName | varchar(50) | Yes |  |
| ManufacturorNumber | varchar(50) | Yes |  |
| VendorName | varchar(50) | Yes |  |
| VendorPartNumber | varchar(50) | Yes |  |
| Keyword | varchar(50) | Yes |  |
| Title | varchar(255) | Yes |  |
| ExtraDetail | varchar(1153) | No |  |
| ItemsPerUnit | varchar(50) | Yes |  |
| SortSeq | varchar(64) | Yes |  |
| Status | varchar(50) | Yes |  |
| Comments | varchar(1024) | Yes |  |
| FullDescription | varchar(3650) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| CategoryType | int | Yes |  |
| Weight | real | Yes |  |



### dbo.BidRequestItemsCrossRefsView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidRequestItemId | int | No |  |
| BidHeaderId | int | Yes |  |
| CrossReferencesText | varchar(1024) | Yes |  |



### dbo.BidRequestItemsView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidRequestItemId | int | No |  |
| BidHeaderId | int | Yes |  |
| ItemId | int | No |  |
| ItemCode | varchar(50) | Yes |  |
| Description | varchar(512) | Yes |  |
| UnitCode | varchar(20) | Yes |  |
| BidRequest | int | Yes |  |
| RequisitionCount | int | Yes |  |
| Active | tinyint | Yes |  |
| SortSeq | varchar(64) | Yes |  |



### dbo.BidRequestItemsView1



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidRequestItemId | int | No |  |
| BidHeaderId | int | Yes |  |
| ItemId | int | No |  |
| ItemCode | varchar(50) | Yes |  |
| Description | varchar(1665) | Yes |  |
| UnitCode | varchar(20) | Yes |  |
| BidRequest | int | Yes |  |
| RequisitionCount | int | Yes |  |
| Active | tinyint | Yes |  |
| SortSeq | varchar(64) | Yes |  |
| Heading | varchar(308) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| CrossRefText | varchar(1024) | Yes |  |



### dbo.BidRequestItemsView1Original



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidRequestItemId | int | No |  |
| BidHeaderId | int | Yes |  |
| ItemId | int | No |  |
| ItemCode | varchar(50) | Yes |  |
| Description | varchar(512) | Yes |  |
| UnitCode | varchar(20) | Yes |  |
| BidRequest | int | Yes |  |
| RequisitionCount | int | Yes |  |
| Active | tinyint | Yes |  |
| SortSeq | varchar(64) | Yes |  |
| Heading | varchar(308) | Yes |  |
| DistrictName | varchar(50) | No |  |
| CrossRefText | varchar(1024) | Yes |  |



### dbo.BidRequestItemsWeightView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidRequestItemId | int | No |  |
| BidHeaderId | int | Yes |  |
| Weight | real | Yes |  |



### dbo.BidResultsView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidResultsId | int | No |  |
| BidImportId | int | Yes |  |
| BidHeaderId | int | Yes |  |
| BidRequestItemId | int | Yes |  |
| CategoryId | int | Yes |  |
| DistrictId | int | Yes |  |
| ItemId | int | Yes |  |
| ItemCode | varchar(50) | Yes |  |
| Units | varchar(16) | Yes |  |
| Alternate | varchar(512) | Yes |  |
| Quantity | int | Yes |  |
| ItemBidType | char(1) | Yes |  |
| UnitPrice | money | Yes |  |
| Cost | money | Yes |  |
| VendorItemCode | varchar(50) | Yes |  |
| QuantityBid | int | Yes |  |
| ItemsPerUnit | varchar(50) | Yes |  |
| UnitId | int | Yes |  |
| Status | varchar(51) | Yes |  |
| Comments | varchar(1024) | Yes |  |
| Active | int | Yes |  |
| ItemDescription | varchar(1024) | Yes |  |
| SortSeq | varchar(64) | Yes |  |



### dbo.BidsView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidId | int | No |  |
| BidHeaderId | int | Yes |  |
| Active | tinyint | Yes |  |
| EffectiveFrom | datetime | Yes |  |
| EffectiveUntil | datetime | Yes |  |
| BidName | varchar(255) | Yes |  |
| PricePlanId | int | No |  |
| PricePlanCode | varchar(20) | Yes |  |
| PricePlanDescription | varchar(255) | Yes |  |
| CategoryId | int | No |  |
| CategoryName | varchar(50) | Yes |  |
| VendorId | int | No |  |
| VendorCode | varchar(16) | Yes |  |
| VendorName | varchar(50) | Yes |  |
| BidDiscountRate | decimal(8,5) | Yes |  |
| VendorBidNumber | varchar(50) | Yes |  |
| DistrictId | int | No |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| ItemsBid | int | Yes |  |
| AmountBid | money | Yes |  |
| CatalogId | int | No |  |
| CatalogName | varchar(50) | Yes |  |
| BidDescription | varchar(511) | Yes |  |



### dbo.BudgetsView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | No |  |
| BudgetId | int | No |  |
| Name | varchar(30) | Yes |  |
| EndDate | datetime | Yes |  |



### dbo.cfv_Districts



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | No |  |
| DistrictId | int | No |  |
| DistrictName | varchar(50) | Yes |  |
| DistrictCode | varchar(4) | Yes |  |



### dbo.cfv_Schools



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | No |  |
| DistrictId | int | No |  |
| SchoolId | int | No |  |
| SchoolName | varchar(50) | Yes |  |



### dbo.cfv_Users



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | No |  |
| DistrictId | int | No |  |
| SchoolId | int | No |  |
| UserId | int | No |  |
| UserName | varchar(56) | Yes |  |



### dbo.CoverViewNew



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictId | int | Yes |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| DistrictAddress1 | varchar(30) | Yes |  |
| DistrictAddress2 | varchar(30) | Yes |  |
| DistrictAddress3 | varchar(30) | Yes |  |
| DistrictCity | varchar(25) | Yes |  |
| DistrictState | varchar(2) | Yes |  |
| DistrictZipcode | varchar(10) | Yes |  |
| SchoolId | int | Yes |  |
| SchoolName | varchar(50) | Yes |  |
| SchoolAddress1 | varchar(30) | Yes |  |
| SchoolAddress2 | varchar(30) | Yes |  |
| SchoolAddress3 | varchar(30) | Yes |  |
| SchoolCity | varchar(25) | Yes |  |
| SchoolState | varchar(2) | Yes |  |
| SchoolZipcode | varchar(10) | Yes |  |
| UserId | int | Yes |  |
| UserName | varchar(50) | Yes |  |
| CometId | int | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| AccountCount | int | Yes |  |
| BudgetStartDate | datetime | Yes |  |
| BudgetEndDate | datetime | Yes |  |
| ItemCount | int | Yes |  |
| CategoryId | int | Yes |  |
| OrderBookId | int | Yes |  |
| CategoryDescription | varchar(255) | Yes |  |
| PricePlanDescription | varchar(255) | Yes |  |
| UsesBooklet | int | Yes |  |
| UsesOnline | int | Yes |  |
| RepMsg | varchar(237) | Yes |  |
| IBTypeId | int | No |  |
| BookType | varchar(50) | No |  |
| ScheduleGroup | varchar(50) | No |  |
| StateName | varchar(50) | No |  |



### dbo.CoverViewNewSave



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictId | int | Yes |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| DistrictAddress1 | varchar(30) | Yes |  |
| DistrictAddress2 | varchar(30) | Yes |  |
| DistrictAddress3 | varchar(30) | Yes |  |
| DistrictCity | varchar(25) | Yes |  |
| DistrictState | varchar(2) | Yes |  |
| DistrictZipcode | varchar(10) | Yes |  |
| SchoolId | int | Yes |  |
| SchoolName | varchar(50) | Yes |  |
| SchoolAddress1 | varchar(30) | Yes |  |
| SchoolAddress2 | varchar(30) | Yes |  |
| SchoolAddress3 | varchar(30) | Yes |  |
| SchoolCity | varchar(25) | Yes |  |
| SchoolState | varchar(2) | Yes |  |
| SchoolZipcode | varchar(10) | Yes |  |
| UserId | int | Yes |  |
| UserName | varchar(50) | Yes |  |
| CometId | int | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| AccountCount | int | Yes |  |
| BudgetStartDate | datetime | Yes |  |
| BudgetEndDate | datetime | Yes |  |
| ItemCount | int | Yes |  |
| CategoryId | int | Yes |  |
| OrderBookId | int | Yes |  |
| CategoryDescription | varchar(255) | Yes |  |
| PricePlanDescription | varchar(255) | Yes |  |



### dbo.CoverViewNewTest



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictId | int | Yes |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| DistrictAddress1 | varchar(30) | Yes |  |
| DistrictAddress2 | varchar(30) | Yes |  |
| DistrictAddress3 | varchar(30) | Yes |  |
| DistrictCity | varchar(25) | Yes |  |
| DistrictState | varchar(2) | Yes |  |
| DistrictZipcode | varchar(10) | Yes |  |
| SchoolId | int | Yes |  |
| SchoolName | varchar(50) | Yes |  |
| SchoolAddress1 | varchar(30) | Yes |  |
| SchoolAddress2 | varchar(30) | Yes |  |
| SchoolAddress3 | varchar(30) | Yes |  |
| SchoolCity | varchar(25) | Yes |  |
| SchoolState | varchar(2) | Yes |  |
| SchoolZipcode | varchar(10) | Yes |  |
| UserId | int | Yes |  |
| UserName | varchar(50) | Yes |  |
| CometId | int | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| AccountCount | int | Yes |  |
| BudgetStartDate | datetime | Yes |  |
| BudgetEndDate | datetime | Yes |  |
| ItemCount | int | Yes |  |
| CategoryId | int | Yes |  |
| OrderBookId | int | Yes |  |
| CategoryDescription | varchar(255) | Yes |  |
| PricePlanDescription | varchar(255) | Yes |  |
| UsesBooklet | int | Yes |  |
| UsesOnline | int | Yes |  |
| RepMsg | varchar(237) | Yes |  |
| IBTypeId | int | No |  |
| BookType | varchar(50) | No |  |
| ScheduleGroup | varchar(50) | No |  |
| StateName | varchar(50) | No |  |



### dbo.CoverViewNewTest1



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictId | int | Yes |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| DistrictAddress1 | varchar(30) | Yes |  |
| DistrictAddress2 | varchar(30) | Yes |  |
| DistrictAddress3 | varchar(30) | Yes |  |
| DistrictCity | varchar(25) | Yes |  |
| DistrictState | varchar(2) | Yes |  |
| DistrictZipcode | varchar(10) | Yes |  |
| SchoolId | int | Yes |  |
| SchoolName | varchar(50) | Yes |  |
| SchoolAddress1 | varchar(30) | Yes |  |
| SchoolAddress2 | varchar(30) | Yes |  |
| SchoolAddress3 | varchar(30) | Yes |  |
| SchoolCity | varchar(25) | Yes |  |
| SchoolState | varchar(2) | Yes |  |
| SchoolZipcode | varchar(10) | Yes |  |
| UserId | int | Yes |  |
| UserName | varchar(50) | Yes |  |
| CometId | int | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| AccountCount | int | Yes |  |
| BudgetStartDate | datetime | Yes |  |
| BudgetEndDate | datetime | Yes |  |
| ItemCount | int | Yes |  |
| CategoryId | int | Yes |  |
| OrderBookId | int | Yes |  |
| CategoryDescription | varchar(255) | Yes |  |
| PricePlanDescription | varchar(255) | Yes |  |
| UsesBooklet | int | Yes |  |
| UsesOnline | int | Yes |  |
| RepMsg | varchar(237) | Yes |  |
| IBTypeId | int | No |  |
| BookType | varchar(50) | No |  |
| ScheduleGroup | varchar(50) | No |  |
| StateName | varchar(50) | No |  |



### dbo.cvw_NJSavings



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BudgetId | int | No |  |
| BudgetName | varchar(30) | Yes |  |
| DistrictId | int | Yes |  |
| DistrictName | varchar(189) | Yes |  |
| CYDollars | varchar(30) | Yes |  |
| CYIncludedDollars | varchar(30) | Yes |  |
| CYIncludedPercent | int | Yes |  |
| CYExcludedDollars | varchar(30) | Yes |  |
| GTDollars | varchar(30) | Yes |  |
| GTYears | int | No |  |
| PricePlanCode | varchar(20) | Yes |  |
| County | varchar(50) | No |  |



### dbo.cvw_NYSavings



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BudgetId | int | No |  |
| Name | varchar(30) | Yes |  |
| DistrictId | int | Yes |  |
| DistrictName | varchar(189) | Yes |  |
| CYDollars | varchar(30) | Yes |  |
| CYIncludedDollars | varchar(30) | Yes |  |
| CYIncludedPercent | int | Yes |  |
| CYExcludedDollars | varchar(30) | Yes |  |
| GTDollars | varchar(30) | Yes |  |
| GTYears | int | No |  |
| PricePlanCode | varchar(20) | Yes |  |



### dbo.cvw_Savings



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BudgetId | int | No |  |
| BudgetName | varchar(30) | Yes |  |
| DistrictId | int | Yes |  |
| DistrictName | varchar(189) | Yes |  |
| CYDollars | varchar(30) | Yes |  |
| CYIncludedDollars | varchar(30) | Yes |  |
| CYIncludedPercent | int | Yes |  |
| CYExcludedDollars | varchar(30) | Yes |  |
| GTDollars | varchar(30) | Yes |  |
| GTYears | int | No |  |
| PricePlanCode | varchar(20) | Yes |  |
| County | varchar(50) | No |  |



### dbo.DetailView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DetailId | int | No |  |
| RequisitionId | int | Yes |  |
| CatalogId | int | Yes |  |
| ItemId | int | Yes |  |
| AddendumItem | tinyint | Yes |  |
| ItemCode | varchar(50) | Yes |  |
| Quantity | int | Yes |  |
| LastYearsQuantity | int | Yes |  |
| Description | varchar(1024) | Yes |  |
| UnitId | int | Yes |  |
| UnitCode | varchar(20) | Yes |  |
| BidPrice | money | Yes |  |
| CatalogPrice | money | Yes |  |
| GrossPrice | money | Yes |  |
| DiscountRate | decimal(9,5) | Yes |  |
| CatalogPage | char(4) | Yes |  |
| PricePlanId | int | Yes |  |
| PriceId | int | Yes |  |
| AwardId | int | Yes |  |
| VendorId | int | Yes |  |
| VendorItemCode | varchar(50) | Yes |  |
| Alternate | varchar(1024) | Yes |  |
| POId | int | Yes |  |
| BatchDetailId | int | Yes |  |
| Modified | datetime | Yes |  |
| ModifiedById | int | Yes |  |
| SourceId | int | Yes |  |
| SortSeq | varchar(64) | Yes |  |
| BidItemId | int | Yes |  |
| ExtraDescription | varchar(1024) | Yes |  |
| ReProc | tinyint | Yes |  |
| UseGrossPrices | tinyint | Yes |  |
| BidHeaderId | int | Yes |  |
| DistrictRequisitionNumber | varchar(50) | Yes |  |
| HeadingTitle | varchar(255) | Yes |  |
| Keyword | varchar(50) | Yes |  |
| SectionId | int | Yes |  |
| SectionName | varchar(255) | Yes |  |
| OriginalItemId | int | Yes |  |
| HeadingId | int | Yes |  |
| KeywordId | int | Yes |  |
| ItemMustBeBid | int | Yes |  |
| SessionId | int | Yes |  |
| Active | tinyint | Yes |  |
| RTK_MSDSId | int | Yes |  |



### dbo.DistrictContactProblemView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| District | varchar(50) | Yes |  |
| ContactType | varchar(50) | No |  |
| MissingContact | int | No |  |
| MissingEmail | int | No |  |
| ErrorMessage | varchar(270) | No |  |
| DistrictId | int | No |  |
| DistrictContactId | int | Yes |  |
| DistrictContactTypeId | int | No |  |
| CSRepId | int | Yes |  |
| RepName | varchar(30) | Yes |  |



### dbo.DistrictUsersView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| SchoolName | varchar(50) | Yes |  |
| UserName | varchar(10) | Yes |  |
| CometCode | varchar(5) | Yes |  |
| Attention | varchar(50) | Yes |  |
| ApprovalLevel | tinyint | Yes |  |
| ApproveeCount | int | Yes |  |
| ApproverName | varchar(50) | Yes |  |
| PriorReqs | int | Yes |  |



### dbo.InstructionBookCalendar



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| IBTypeId | int | No |  |
| StateId | int | Yes |  |
| GroupId | int | No |  |
| IBYear | int | No |  |
| EventDescription | varchar(50) | Yes |  |
| EventDate | datetime | No |  |



### dbo.InstructionBookView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictId | int | No |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| DistrictAddress1 | varchar(30) | Yes |  |
| DistrictAddress2 | varchar(30) | Yes |  |
| DistrictAddress3 | varchar(30) | Yes |  |
| DistrictCity | varchar(25) | Yes |  |
| DistrictState | varchar(2) | Yes |  |
| DistrictZipcode | varchar(10) | Yes |  |
| SchoolId | int | No |  |
| SchoolName | varchar(50) | Yes |  |
| SchoolAddress1 | varchar(30) | Yes |  |
| SchoolAddress2 | varchar(30) | Yes |  |
| SchoolAddress3 | varchar(30) | Yes |  |
| SchoolCity | varchar(25) | Yes |  |
| SchoolState | varchar(2) | Yes |  |
| SchoolZipcode | varchar(10) | Yes |  |
| UserId | int | No |  |
| UserName | varchar(50) | Yes |  |
| CometId | int | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| AccountCount | int | Yes |  |
| BudgetStartDate | datetime | Yes |  |
| BudgetEndDate | datetime | Yes |  |
| ItemCount | int | Yes |  |
| CategoryId | int | Yes |  |
| OrderBookId | int | Yes |  |
| CategoryDescription | varchar(14) | Yes |  |
| PricePlanDescription | int | Yes |  |
| UsesBooklet | int | No |  |
| UsesOnline | int | No |  |
| RepMsg | varchar(237) | Yes |  |
| IBTypeId | int | No |  |
| BookType | varchar(50) | No |  |
| StateName | varchar(50) | No |  |
| ScheduleGroup | varchar(50) | No |  |



### dbo.InstructionBookView09



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictId | int | No |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| DistrictAddress1 | varchar(30) | Yes |  |
| DistrictAddress2 | varchar(30) | Yes |  |
| DistrictAddress3 | varchar(30) | Yes |  |
| DistrictCity | varchar(25) | Yes |  |
| DistrictState | varchar(2) | Yes |  |
| DistrictZipcode | varchar(10) | Yes |  |
| SchoolId | int | No |  |
| SchoolName | varchar(50) | Yes |  |
| SchoolAddress1 | varchar(30) | Yes |  |
| SchoolAddress2 | varchar(30) | Yes |  |
| SchoolAddress3 | varchar(30) | Yes |  |
| SchoolCity | varchar(25) | Yes |  |
| SchoolState | varchar(2) | Yes |  |
| SchoolZipcode | varchar(10) | Yes |  |
| UserId | int | No |  |
| UserName | varchar(50) | Yes |  |
| CometId | int | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| AccountCount | int | Yes |  |
| BudgetStartDate | datetime | Yes |  |
| BudgetEndDate | datetime | Yes |  |
| ItemCount | int | Yes |  |
| CategoryId | int | Yes |  |
| OrderBookId | int | Yes |  |
| CategoryDescription | varchar(15) | Yes |  |
| PricePlanDescription | int | Yes |  |
| UsesBooklet | int | No |  |
| UsesOnline | int | No |  |
| RepMsg | varchar(237) | Yes |  |



### dbo.InstructionBookViewCF



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictId | int | No |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| DistrictAddress1 | varchar(30) | Yes |  |
| DistrictAddress2 | varchar(30) | Yes |  |
| DistrictAddress3 | varchar(30) | Yes |  |
| DistrictCity | varchar(25) | Yes |  |
| DistrictState | varchar(2) | Yes |  |
| DistrictZipcode | varchar(10) | Yes |  |
| SchoolId | int | No |  |
| SchoolName | varchar(50) | Yes |  |
| SchoolAddress1 | varchar(30) | Yes |  |
| SchoolAddress2 | varchar(30) | Yes |  |
| SchoolAddress3 | varchar(30) | Yes |  |
| SchoolCity | varchar(25) | Yes |  |
| SchoolState | varchar(2) | Yes |  |
| SchoolZipcode | varchar(10) | Yes |  |
| UserId | int | No |  |
| UserName | varchar(50) | Yes |  |
| CometId | int | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| AccountCount | int | Yes |  |
| BudgetStartDate | datetime | Yes |  |
| BudgetEndDate | datetime | Yes |  |
| ItemCount | int | Yes |  |
| CategoryId | int | Yes |  |
| OrderBookId | int | Yes |  |
| CategoryDescription | varchar(14) | Yes |  |
| PricePlanDescription | int | Yes |  |
| UsesBooklet | int | No |  |
| UsesOnline | int | No |  |
| RepMsg | varchar(305) | Yes |  |
| IBTypeId | int | No |  |
| BookType | varchar(50) | No |  |
| StateName | varchar(50) | No |  |
| ScheduleGroup | varchar(50) | No |  |



### dbo.InstructionBookViewCF2013



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictId | int | No |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| DistrictAddress1 | varchar(30) | Yes |  |
| DistrictAddress2 | varchar(30) | Yes |  |
| DistrictAddress3 | varchar(30) | Yes |  |
| DistrictCity | varchar(25) | Yes |  |
| DistrictState | varchar(2) | Yes |  |
| DistrictZipcode | varchar(10) | Yes |  |
| SchoolId | int | No |  |
| SchoolName | varchar(50) | Yes |  |
| SchoolAddress1 | varchar(30) | Yes |  |
| SchoolAddress2 | varchar(30) | Yes |  |
| SchoolAddress3 | varchar(30) | Yes |  |
| SchoolCity | varchar(25) | Yes |  |
| SchoolState | varchar(2) | Yes |  |
| SchoolZipcode | varchar(10) | Yes |  |
| UserId | int | No |  |
| UserName | varchar(50) | Yes |  |
| CometId | varchar(5) | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| AccountCount | int | Yes |  |
| BudgetStartDate | datetime | Yes |  |
| BudgetEndDate | datetime | Yes |  |
| ItemCount | int | Yes |  |
| CategoryId | int | Yes |  |
| OrderBookId | int | Yes |  |
| CategoryDescription | varchar(14) | Yes |  |
| PricePlanDescription | int | Yes |  |
| UsesBooklet | int | No |  |
| UsesOnline | int | No |  |
| RepMsg | varchar(305) | Yes |  |
| IBTypeId | int | No |  |
| BookType | varchar(50) | No |  |
| StateName | varchar(50) | No |  |
| ScheduleGroup | varchar(50) | No |  |
| AllowAddenda | bit | No |  |
| AllowVendorChanges | int | No |  |
| BudgetId | int | No |  |
| AllowAccountCodeMgmt | tinyint | No |  |
| HasAdminAccess | bit | No |  |



### dbo.InstructionBookViewwork



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictId | int | No |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| DistrictAddress1 | varchar(30) | Yes |  |
| DistrictAddress2 | varchar(30) | Yes |  |
| DistrictAddress3 | varchar(30) | Yes |  |
| DistrictCity | varchar(25) | Yes |  |
| DistrictState | varchar(2) | Yes |  |
| DistrictZipcode | varchar(10) | Yes |  |
| SchoolId | int | No |  |
| SchoolName | varchar(50) | Yes |  |
| SchoolAddress1 | varchar(30) | Yes |  |
| SchoolAddress2 | varchar(30) | Yes |  |
| SchoolAddress3 | varchar(30) | Yes |  |
| SchoolCity | varchar(25) | Yes |  |
| SchoolState | varchar(2) | Yes |  |
| SchoolZipcode | varchar(10) | Yes |  |
| UserId | int | No |  |
| UserName | varchar(50) | Yes |  |
| CometId | int | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| AccountCount | int | Yes |  |
| BudgetStartDate | datetime | Yes |  |
| BudgetEndDate | datetime | Yes |  |
| ItemCount | int | Yes |  |
| CategoryId | int | Yes |  |
| OrderBookId | int | Yes |  |
| CategoryDescription | varchar(15) | Yes |  |
| PricePlanDescription | int | Yes |  |
| UsesBooklet | int | No |  |
| UsesOnline | int | No |  |
| RepMsg | varchar(237) | Yes |  |



### dbo.ItemsBidHeaderView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| ItemId | int | No |  |
| ItemCode | varchar(565) | Yes |  |
| SortSeq | varchar(64) | Yes |  |



### dbo.Keywords1



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| KeywordId | int | No |  |
| Active | int | Yes |  |
| CategoryId | int | Yes |  |
| HeadingId | int | Yes |  |
| DistrictId | int | Yes |  |
| Keyword | varchar(50) | Yes |  |
| rowguid | uniqueidentifier | No |  |



### dbo.NewFF1



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| ItemId | int | No |  |
| ItemCode | varchar(50) | Yes |  |
| Description | varchar(512) | Yes |  |
| UnitId | int | Yes |  |
| Code | varchar(20) | Yes |  |
| CrossRefId | int | No |  |
| CatalogPrice | money | Yes |  |
| VendorItemCode | varchar(50) | Yes |  |
| Page | char(4) | Yes |  |
| BidPrice | decimal(34,13) | Yes |  |
| CatalogId | int | Yes |  |
| Name | varchar(50) | Yes |  |
| CategoryId | int | Yes |  |
| VendorId | int | No |  |
| VendorName | varchar(50) | Yes |  |
| PricePlanId | int | Yes |  |
| AwardId | int | No |  |
| DistrictId | int | Yes |  |
| DiscountRate | decimal(9,5) | Yes |  |
| PriceId | uniqueidentifier | No |  |
| PricesDescription | varchar(1024) | Yes |  |
| ParentCatalogId | int | Yes |  |
| GrossPrice | money | Yes |  |



### dbo.OrderBookDetailView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| OrderBookDetailId | int | No |  |
| OrderBookId | int | No |  |
| ItemCode | varchar(50) | Yes |  |
| UnitCode | varchar(20) | Yes |  |
| GrossPrice | money | Yes |  |
| CatalogPage | varchar(4) | Yes |  |
| CatalogYear | varchar(2) | Yes |  |
| VendorName | varchar(255) | Yes |  |
| VendorItemCode | varchar(50) | Yes |  |
| TotalQuantity | int | No |  |
| TotalRequisitions | int | No |  |
| ExpandAll | tinyint | Yes |  |
| Weight | int | No |  |
| SortSeq | varchar(64) | Yes |  |
| Active | tinyint | Yes |  |
| Alternate | varchar(1024) | Yes |  |
| VendorId | int | Yes |  |
| VendorCode | varchar(16) | Yes |  |
| ItemDescription | varchar(512) | Yes |  |
| HeadingId | int | Yes |  |
| HeadingCode | varchar(16) | Yes |  |
| HeadingTitle | varchar(255) | Yes |  |
| HeadingDescription | varchar(4096) | Yes |  |



### dbo.OrderBookView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| OrderBookId | int | No |  |
| PricePlanDescription | varchar(255) | Yes |  |
| Category | varchar(255) | Yes |  |
| PricePlanId | int | Yes |  |
| CategoryId | int | Yes |  |
| AwardId | int | Yes |  |
| BookType | varchar(11) | No |  |
| Active | int | Yes |  |
| BidHeaderId | int | Yes |  |
| DistrictId | int | Yes |  |



### dbo.pa_Accounts



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | Yes |  |
| AccountId | int | Yes |  |
| Code | varchar(50) | Yes |  |



### dbo.pa_Budgets



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | Yes |  |
| BudgetId | int | Yes |  |
| Name | varchar(30) | Yes |  |



### dbo.pa_Category



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | Yes |  |
| CategoryId | int | Yes |  |
| Name | varchar(50) | Yes |  |



### dbo.pa_ReqList



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| Accounts_Code | varchar(50) | Yes |  |
| ApprovalDescription | varchar(50) | Yes |  |
| ApprovalDate | datetime | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| CometId | int | Yes |  |
| RequisitionNumber | varchar(24) | Yes |  |
| Requisitions_Attention | varchar(50) | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| DateEntered | datetime | Yes |  |
| TotalRequisitionCost | money | Yes |  |
| BidHeaderId | int | Yes |  |
| PendingApprovals_SchoolId | int | Yes |  |
| PendingApprovals_UserId | int | Yes |  |
| PendingApprovals_BudgetId | int | Yes |  |
| PendingApprovals_AccountId | int | Yes |  |
| PendingApprovals_CategoryId | int | Yes |  |
| PendingApprovals_StatusId | int | Yes |  |
| PendingApprovals_ApprovalDate | datetime | Yes |  |
| PendingApprovals_ApprovalLevel | tinyint | Yes |  |
| SessionId | int | Yes |  |
| Tagged | int | No |  |
| RequisitionId | int | Yes |  |



### dbo.pa_School



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | Yes |  |
| SchoolId | int | Yes |  |
| Name | varchar(50) | Yes |  |



### dbo.pa_Status



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | Yes |  |
| StatusId | int | Yes |  |
| Name | varchar(50) | Yes |  |



### dbo.pa_Users



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | Yes |  |
| UserId | int | Yes |  |
| Attention | varchar(50) | Yes |  |



### dbo.POAttentionList



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictId | int | Yes |  |
| PONumber | varchar(24) | Yes |  |
| AttentionName | varchar(50) | Yes |  |



### dbo.PODetail



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| PODetailItemId | int | No |  |
| DetailId | int | No |  |
| ItemCode | varchar(50) | No |  |
| Description | varchar(8000) | Yes |  |
| Quantity | int | Yes |  |
| UnitCode | varchar(20) | Yes |  |
| GrossPrice | money | Yes |  |
| ExtendedGross | money | Yes |  |
| BidPrice | money | No |  |
| ExtendedBid | money | Yes |  |
| VendorData | varchar(68) | No |  |
| Alternate | varchar(17) | No |  |
| VendorItemCode | varchar(50) | No |  |
| POId | int | No |  |
| PONumber | varchar(24) | Yes |  |
| POTotal | money | Yes |  |
| POItemCount | int | Yes |  |
| DiscountRate | decimal(9,5) | Yes |  |
| TotalGross | money | Yes |  |
| DiscountAmount | money | Yes |  |
| VendorNameAddress | varchar(320) | Yes |  |
| VendorPhone | varchar(25) | Yes |  |
| VendorFax | varchar(20) | Yes |  |
| VendorBidNumber | varchar(50) | Yes |  |
| VendorUseGross | int | Yes |  |
| SchoolNameAddress | varchar(189) | Yes |  |
| DistrictNameAddress | varchar(189) | Yes |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictUseGross | tinyint | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| Attention | varchar(50) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| CategoryCode | char(1) | Yes |  |
| LocationCode | varchar(32) | No |  |
| SortSeq | varchar(64) | Yes |  |
| ShippingNameAddress | varchar(189) | Yes |  |
| ShippingPercentage | decimal(9,5) | Yes |  |
| ShippingAmount | money | Yes |  |
| VendorId | int | No |  |
| DistrictVendorCode | varchar(20) | Yes |  |
| BidAwardDate | datetime | Yes |  |
| BidHeaderId | int | Yes |  |
| VendorName | varchar(50) | Yes |  |
| VendorInfo | varchar(249) | Yes |  |



### dbo.PODetail_old



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| PODetailItemId | int | No |  |
| DetailId | int | No |  |
| ItemCode | varchar(50) | No |  |
| Description | varchar(1024) | Yes |  |
| Quantity | int | Yes |  |
| UnitCode | varchar(20) | Yes |  |
| GrossPrice | money | Yes |  |
| ExtendedGross | money | Yes |  |
| BidPrice | money | No |  |
| ExtendedBid | money | Yes |  |
| VendorData | varchar(1075) | No |  |
| Alternate | varchar(1024) | No |  |
| VendorItemCode | varchar(50) | No |  |
| POId | int | No |  |
| PONumber | varchar(24) | Yes |  |
| POTotal | money | Yes |  |
| POItemCount | int | Yes |  |
| DiscountRate | decimal(9,5) | Yes |  |
| TotalGross | money | Yes |  |
| DiscountAmount | money | Yes |  |
| VendorNameAddress | varchar(249) | Yes |  |
| VendorPhone | varchar(20) | Yes |  |
| VendorFax | varchar(20) | Yes |  |
| VendorBidNumber | varchar(50) | Yes |  |
| VendorUseGross | int | Yes |  |
| SchoolNameAddress | varchar(189) | Yes |  |
| DistrictNameAddress | varchar(189) | Yes |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictUseGross | tinyint | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| Attention | varchar(50) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| CategoryCode | char(1) | Yes |  |
| LocationCode | varchar(32) | No |  |
| SortSeq | varchar(64) | Yes |  |
| ShippingNameAddress | varchar(189) | Yes |  |
| ShippingPercentage | decimal(9,5) | Yes |  |
| ShippingAmount | money | Yes |  |
| VendorId | int | No |  |
| DistrictVendorCode | varchar(20) | Yes |  |
| BidAwardDate | datetime | Yes |  |



### dbo.PODetail_Orig



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| PODetailItemId | int | No |  |
| DetailId | int | No |  |
| ItemCode | varchar(50) | No |  |
| Description | varchar(3650) | Yes |  |
| Quantity | int | Yes |  |
| UnitCode | varchar(20) | Yes |  |
| GrossPrice | money | Yes |  |
| ExtendedGross | money | Yes |  |
| BidPrice | money | No |  |
| ExtendedBid | money | Yes |  |
| VendorData | varchar(1075) | No |  |
| Alternate | varchar(1024) | No |  |
| VendorItemCode | varchar(50) | No |  |
| POId | int | No |  |
| PONumber | varchar(24) | Yes |  |
| POTotal | money | Yes |  |
| POItemCount | int | Yes |  |
| DiscountRate | decimal(9,5) | Yes |  |
| TotalGross | money | Yes |  |
| DiscountAmount | money | Yes |  |
| VendorNameAddress | varchar(320) | Yes |  |
| VendorPhone | varchar(25) | Yes |  |
| VendorFax | varchar(20) | Yes |  |
| VendorBidNumber | varchar(50) | Yes |  |
| VendorUseGross | int | Yes |  |
| SchoolNameAddress | varchar(189) | Yes |  |
| DistrictNameAddress | varchar(189) | Yes |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictUseGross | tinyint | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| Attention | varchar(50) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| CategoryCode | char(1) | Yes |  |
| LocationCode | varchar(32) | No |  |
| SortSeq | varchar(64) | Yes |  |
| ShippingNameAddress | varchar(189) | Yes |  |
| ShippingPercentage | decimal(9,5) | Yes |  |
| ShippingAmount | money | Yes |  |
| VendorId | int | No |  |
| DistrictVendorCode | varchar(20) | Yes |  |
| BidAwardDate | datetime | Yes |  |



### dbo.PODetailExport



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| PODetailItemId | int | No |  |
| DetailId | int | No |  |
| ItemCode | varchar(50) | No |  |
| Description | varchar(3650) | Yes |  |
| Quantity | int | Yes |  |
| UnitCode | varchar(20) | Yes |  |
| GrossPrice | money | Yes |  |
| ExtendedGross | money | Yes |  |
| BidPrice | money | No |  |
| ExtendedBid | money | Yes |  |
| VendorData | varchar(1075) | No |  |
| Alternate | varchar(1024) | No |  |
| VendorItemCode | varchar(50) | Yes |  |
| POId | int | No |  |
| PONumber | varchar(24) | Yes |  |
| POTotal | money | Yes |  |
| POItemCount | int | Yes |  |
| DiscountRate | decimal(9,5) | Yes |  |
| TotalGross | money | Yes |  |
| DiscountAmount | money | Yes |  |
| VendorNameAddress | varchar(249) | Yes |  |
| VendorPhone | varchar(25) | Yes |  |
| VendorFax | varchar(20) | Yes |  |
| VendorBidNumber | varchar(50) | Yes |  |
| VendorUseGross | int | Yes |  |
| SchoolNameAddress | varchar(189) | Yes |  |
| DistrictNameAddress | varchar(189) | Yes |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictUseGross | tinyint | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| Attention | varchar(50) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| CategoryCode | char(1) | Yes |  |
| LocationCode | varchar(32) | No |  |
| SortSeq | varchar(64) | Yes |  |
| ShippingNameAddress | varchar(189) | Yes |  |
| ShippingPercentage | decimal(9,5) | Yes |  |
| ShippingAmount | money | Yes |  |
| PODate | datetime | Yes |  |
| VendorId | int | No |  |
| DistrictName | varchar(50) | Yes |  |
| DistrictAddress1 | varchar(30) | Yes |  |
| DistrictAddress2 | varchar(30) | Yes |  |
| DistrictAddress3 | varchar(30) | Yes |  |
| DistrictCity | varchar(25) | Yes |  |
| DistrictState | varchar(2) | Yes |  |
| DistrictZip | varchar(10) | Yes |  |
| DistrictPhone | varchar(20) | Yes |  |
| DistrictFax | varchar(20) | Yes |  |
| DistrictEMail | varchar(255) | Yes |  |
| ShippingName | varchar(50) | Yes |  |
| ShippingAddress1 | varchar(30) | Yes |  |
| ShippingAddress2 | varchar(30) | Yes |  |
| ShippingAddress3 | varchar(30) | Yes |  |
| ShippingCity | varchar(25) | Yes |  |
| ShippingState | varchar(2) | Yes |  |
| ShippingZipCode | varchar(10) | Yes |  |
| ShippingPhone | varchar(20) | Yes |  |
| ShippingFax | varchar(14) | Yes |  |
| ShippingEMail | varchar(255) | Yes |  |
| VendorsAccountCode | varchar(50) | Yes |  |
| CometId | int | Yes |  |
| ShippingId | int | No |  |
| BusinessUnit | varchar(17) | Yes |  |
| UploadType | int | Yes |  |
| DistrictId | int | No |  |



### dbo.PODetailExport_old



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| PODetailItemId | int | No |  |
| DetailId | int | No |  |
| ItemCode | varchar(50) | No |  |
| Description | varchar(1024) | Yes |  |
| Quantity | int | Yes |  |
| UnitCode | varchar(20) | Yes |  |
| GrossPrice | money | Yes |  |
| ExtendedGross | money | Yes |  |
| BidPrice | money | No |  |
| ExtendedBid | money | Yes |  |
| VendorData | varchar(1075) | No |  |
| Alternate | varchar(1024) | No |  |
| VendorItemCode | varchar(50) | Yes |  |
| POId | int | No |  |
| PONumber | varchar(24) | Yes |  |
| POTotal | money | Yes |  |
| POItemCount | int | Yes |  |
| DiscountRate | decimal(9,5) | Yes |  |
| TotalGross | money | Yes |  |
| DiscountAmount | money | Yes |  |
| VendorNameAddress | varchar(249) | Yes |  |
| VendorPhone | varchar(20) | Yes |  |
| VendorFax | varchar(20) | Yes |  |
| VendorBidNumber | varchar(50) | Yes |  |
| VendorUseGross | int | Yes |  |
| SchoolNameAddress | varchar(189) | Yes |  |
| DistrictNameAddress | varchar(189) | Yes |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictUseGross | tinyint | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| Attention | varchar(50) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| CategoryCode | char(1) | Yes |  |
| LocationCode | varchar(32) | No |  |
| SortSeq | varchar(64) | Yes |  |
| ShippingNameAddress | varchar(189) | Yes |  |
| ShippingPercentage | decimal(9,5) | Yes |  |
| ShippingAmount | money | Yes |  |
| PODate | datetime | Yes |  |
| VendorId | int | No |  |
| DistrictName | varchar(50) | Yes |  |
| DistrictAddress1 | varchar(30) | Yes |  |
| DistrictAddress2 | varchar(30) | Yes |  |
| DistrictAddress3 | varchar(30) | Yes |  |
| DistrictCity | varchar(25) | Yes |  |
| DistrictState | varchar(2) | Yes |  |
| DistrictZip | varchar(10) | Yes |  |
| DistrictPhone | varchar(20) | Yes |  |
| DistrictFax | varchar(20) | Yes |  |
| DistrictEMail | varchar(255) | Yes |  |
| ShippingName | varchar(50) | Yes |  |
| ShippingAddress1 | varchar(30) | Yes |  |
| ShippingAddress2 | varchar(30) | Yes |  |
| ShippingAddress3 | varchar(30) | Yes |  |
| ShippingCity | varchar(25) | Yes |  |
| ShippingState | varchar(2) | Yes |  |
| ShippingZipCode | varchar(10) | Yes |  |
| ShippingPhone | varchar(20) | Yes |  |
| ShippingFax | varchar(14) | Yes |  |
| ShippingEMail | varchar(255) | Yes |  |
| VendorsAccountCode | varchar(50) | Yes |  |
| CometId | int | Yes |  |
| ShippingId | int | No |  |
| BusinessUnit | varchar(17) | Yes |  |
| UploadType | int | Yes |  |
| DistrictId | int | No |  |



### dbo.PODetailJavaExport



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| PODetailItemId | int | No |  |
| DetailId | int | No |  |
| ItemCode | varchar(50) | No |  |
| Description | nvarchar(MAX) | Yes |  |
| Quantity | int | No |  |
| UnitCode | varchar(20) | Yes |  |
| GrossPrice | money | No |  |
| ExtendedGross | money | Yes |  |
| BidPrice | money | No |  |
| ExtendedBid | money | Yes |  |
| VendorData | varchar(1075) | No |  |
| Alternate | varchar(1024) | No |  |
| VendorItemCode | varchar(255) | Yes |  |
| POId | int | No |  |
| PONumber | varchar(24) | No |  |
| POTotal | money | No |  |
| POItemCount | int | No |  |
| DiscountRate | decimal(9,5) | No |  |
| TotalGross | money | No |  |
| DiscountAmount | money | No |  |
| VendorNameAddress | varchar(249) | Yes |  |
| VendorPhone | varchar(25) | No |  |
| VendorFax | varchar(20) | No |  |
| VendorBidNumber | varchar(50) | Yes |  |
| VendorUseGross | int | No |  |
| SchoolNameAddress | varchar(189) | Yes |  |
| DistrictNameAddress | varchar(189) | Yes |  |
| DistrictCode | varchar(4) | No |  |
| DistrictUseGross | tinyint | No |  |
| AccountCode | varchar(50) | No |  |
| Attention | varchar(50) | No |  |
| CategoryName | varchar(50) | No |  |
| CategoryCode | char(1) | Yes |  |
| LocationCode | varchar(32) | No |  |
| SortSeq | varchar(64) | No |  |
| ShippingNameAddress | varchar(189) | Yes |  |
| ShippingPercentage | decimal(9,5) | No |  |
| ShippingAmount | money | No |  |
| PODate | datetime | Yes |  |
| VendorId | int | No |  |
| DistrictName | varchar(50) | No |  |
| DistrictAddress1 | varchar(50) | No |  |
| DistrictAddress2 | varchar(50) | No |  |
| DistrictAddress3 | varchar(1) | No |  |
| DistrictCity | varchar(50) | No |  |
| DistrictState | varchar(2) | No |  |
| DistrictZip | varchar(10) | No |  |
| DistrictPhone | nvarchar(MAX) | Yes |  |
| DistrictFax | nvarchar(MAX) | Yes |  |
| DistrictEMail | varchar(255) | No |  |
| ShippingName | varchar(50) | No |  |
| ShippingAddress1 | varchar(61) | Yes |  |
| ShippingAddress2 | varchar(30) | No |  |
| ShippingAddress3 | varchar(30) | No |  |
| ShippingCity | varchar(25) | No |  |
| ShippingState | varchar(2) | No |  |
| ShippingZipCode | varchar(10) | No |  |
| ShippingPhone | nvarchar(MAX) | Yes |  |
| ShippingFax | nvarchar(MAX) | Yes |  |
| ShippingEMail | varchar(255) | Yes |  |
| VendorsAccountCode | varchar(50) | Yes |  |
| CometId | int | Yes |  |
| ShippingId | varchar(50) | Yes |  |
| BusinessUnit | varchar(17) | No |  |
| UploadType | int | Yes |  |
| DistrictId | int | No |  |
| cXMLAddress | varchar(255) | No |  |
| UploadEmailList | varchar(4096) | No |  |
| cXMLFromDomain | varchar(50) | No |  |
| cXMLFromIdentity | varchar(50) | No |  |
| cXMLToDomain | varchar(50) | No |  |
| cXMLToIdentity | varchar(50) | No |  |
| cXMLSenderDomain | varchar(50) | No |  |
| cXMLSenderIdentity | varchar(50) | No |  |
| cXMLSenderSharedSecret | varchar(50) | No |  |
| dateSubmitted | datetime | No |  |
| isActualNumber | tinyint | No |  |
| hostUserName | varchar(255) | No |  |
| hostPassword | varchar(255) | No |  |
| RequestedDeliveryDate | date | Yes |  |
| DistrictContactId | int | Yes |  |
| PerishableItem | bit | Yes |  |



### dbo.PODetailJavaExportNew



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| PODetailItemId | int | No |  |
| DetailId | int | No |  |
| ItemCode | varchar(50) | No |  |
| Description | varchar(3650) | Yes |  |
| Quantity | int | No |  |
| UnitCode | varchar(20) | No |  |
| GrossPrice | money | No |  |
| ExtendedGross | money | Yes |  |
| BidPrice | money | No |  |
| ExtendedBid | money | Yes |  |
| VendorData | varchar(1075) | No |  |
| Alternate | varchar(1024) | No |  |
| VendorItemCode | varchar(255) | Yes |  |
| POId | int | No |  |
| PONumber | varchar(24) | No |  |
| POTotal | money | No |  |
| POItemCount | int | No |  |
| DiscountRate | decimal(9,5) | No |  |
| TotalGross | money | No |  |
| DiscountAmount | money | No |  |
| VendorNameAddress | varchar(249) | Yes |  |
| VendorPhone | varchar(25) | No |  |
| VendorFax | varchar(20) | No |  |
| VendorBidNumber | varchar(50) | Yes |  |
| VendorUseGross | int | No |  |
| SchoolNameAddress | varchar(189) | Yes |  |
| DistrictNameAddress | varchar(189) | Yes |  |
| DistrictCode | varchar(4) | No |  |
| DistrictUseGross | tinyint | No |  |
| AccountCode | varchar(50) | No |  |
| Attention | varchar(50) | No |  |
| CategoryName | varchar(50) | No |  |
| CategoryCode | char(1) | Yes |  |
| LocationCode | varchar(32) | No |  |
| SortSeq | varchar(64) | No |  |
| ShippingNameAddress | varchar(189) | Yes |  |
| ShippingPercentage | decimal(9,5) | No |  |
| ShippingAmount | money | No |  |
| PODate | datetime | Yes |  |
| VendorId | int | No |  |
| DistrictName | varchar(50) | No |  |
| DistrictAddress1 | varchar(30) | No |  |
| DistrictAddress2 | varchar(30) | No |  |
| DistrictAddress3 | varchar(30) | No |  |
| DistrictCity | varchar(25) | No |  |
| DistrictState | varchar(2) | No |  |
| DistrictZip | varchar(10) | No |  |
| DistrictPhone | varchar(20) | No |  |
| DistrictFax | varchar(20) | No |  |
| DistrictEMail | varchar(255) | No |  |
| ShippingName | varchar(50) | No |  |
| ShippingAddress1 | varchar(30) | No |  |
| ShippingAddress2 | varchar(30) | No |  |
| ShippingAddress3 | varchar(30) | No |  |
| ShippingCity | varchar(25) | No |  |
| ShippingState | varchar(2) | No |  |
| ShippingZipCode | varchar(10) | No |  |
| ShippingPhone | varchar(20) | No |  |
| ShippingFax | varchar(14) | No |  |
| ShippingEMail | varchar(255) | No |  |
| VendorsAccountCode | varchar(50) | No |  |
| CometId | int | Yes |  |
| ShippingId | int | No |  |
| BusinessUnit | varchar(17) | No |  |
| UploadType | int | Yes |  |
| DistrictId | int | No |  |
| cXMLAddress | varchar(255) | No |  |
| UploadEmailList | varchar(4096) | No |  |



### dbo.PODetailTest



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| PODetailItemId | int | No |  |
| DetailId | int | No |  |
| ItemCode | varchar(50) | No |  |
| Description | varchar(3650) | Yes |  |
| Quantity | int | Yes |  |
| UnitCode | varchar(20) | Yes |  |
| GrossPrice | money | Yes |  |
| ExtendedGross | money | Yes |  |
| BidPrice | money | No |  |
| ExtendedBid | money | Yes |  |
| VendorData | varchar(1075) | No |  |
| Alternate | varchar(1024) | No |  |
| VendorItemCode | varchar(50) | No |  |
| POId | int | No |  |
| PONumber | varchar(24) | Yes |  |
| POTotal | money | Yes |  |
| POItemCount | int | Yes |  |
| DiscountRate | decimal(9,5) | Yes |  |
| TotalGross | money | Yes |  |
| DiscountAmount | money | Yes |  |
| VendorNameAddress | varchar(320) | Yes |  |
| VendorPhone | varchar(25) | Yes |  |
| VendorFax | varchar(20) | Yes |  |
| VendorBidNumber | varchar(50) | Yes |  |
| VendorUseGross | int | Yes |  |
| SchoolNameAddress | varchar(189) | Yes |  |
| DistrictNameAddress | varchar(189) | Yes |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictUseGross | tinyint | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| Attention | varchar(50) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| CategoryCode | char(1) | Yes |  |
| LocationCode | varchar(32) | No |  |
| SortSeq | varchar(64) | Yes |  |
| ShippingNameAddress | varchar(189) | Yes |  |
| ShippingPercentage | decimal(9,5) | Yes |  |
| ShippingAmount | money | Yes |  |
| VendorId | int | No |  |
| DistrictVendorCode | varchar(20) | Yes |  |
| BidAwardDate | datetime | Yes |  |



### dbo.POHeader



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| POId | int | No |  |
| PONumber | varchar(24) | Yes |  |
| ItemCount | int | Yes |  |
| Amount | money | Yes |  |
| BudgetName | varchar(30) | Yes |  |
| RequisitionNumber | varchar(24) | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| Attention | varchar(50) | Yes |  |
| CometId | int | Yes |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| DistrictNameAddress | varchar(237) | Yes |  |
| SchoolName | varchar(50) | Yes |  |
| SchoolNameAddress | varchar(189) | Yes |  |
| VendorCode | varchar(16) | Yes |  |
| VendorPhone | varchar(25) | Yes |  |
| DistrictVendorCode | varchar(20) | Yes |  |
| VendorName | varchar(50) | Yes |  |
| VendorNameAddress | varchar(249) | Yes |  |
| PODate | datetime | Yes |  |
| DatePrinted | datetime | Yes |  |
| DatePrintedDetail | datetime | Yes |  |
| DateExported | datetime | Yes |  |
| DistrictId | int | Yes |  |
| CategoryId | int | Yes |  |
| BudgetId | int | Yes |  |
| AccountId | int | No |  |
| VendorId | int | Yes |  |
| UserId | int | Yes |  |
| SchoolId | int | No |  |
| VendorBidNumber | varchar(50) | Yes |  |
| VendorBidComments | varchar(606) | Yes |  |
| CategoryCode | char(1) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| DiscountRate | decimal(9,5) | Yes |  |
| DiscountAmount | money | Yes |  |
| TotalGross | money | Yes |  |
| LocationCode | varchar(32) | No |  |
| ShippingAmount | money | Yes |  |
| ShippingPercentage | decimal(9,5) | Yes |  |
| ShippingNameAddress | varchar(189) | Yes |  |
| DistrictAddress1 | varchar(30) | Yes |  |
| DistrictAddress2 | varchar(30) | Yes |  |
| DistrictAddress3 | varchar(30) | Yes |  |
| DistrictCity | varchar(25) | Yes |  |
| DistrictState | varchar(2) | Yes |  |
| DistrictZipcode | varchar(10) | Yes |  |
| SchoolAddress1 | varchar(30) | Yes |  |
| SchoolAddress2 | varchar(30) | Yes |  |
| SchoolAddress3 | varchar(30) | Yes |  |
| SchoolCity | varchar(25) | Yes |  |
| SchoolState | varchar(2) | Yes |  |
| SchoolZipcode | varchar(10) | Yes |  |
| VendorsAddress1 | varchar(50) | Yes |  |
| VendorsAddress2 | varchar(50) | Yes |  |
| VendorsAddress3 | varchar(50) | Yes |  |
| VendorsCity | varchar(50) | Yes |  |
| VendorsState | varchar(2) | Yes |  |
| VendorsZipcode | varchar(10) | Yes |  |
| ShipLocationsAddress1 | varchar(30) | Yes |  |
| ShipLocationsAddress2 | varchar(30) | Yes |  |
| ShipLocationsAddress3 | varchar(30) | Yes |  |
| ShipLocationsCity | varchar(25) | Yes |  |
| ShipLocationsState | varchar(2) | Yes |  |
| ShipLocationsZipcode | varchar(10) | Yes |  |
| ShipLocationsName | varchar(50) | Yes |  |
| DistrictMessage | varchar(4096) | Yes |  |
| BidDate | datetime | Yes |  |
| UsersDistrictAcctgCode | varchar(20) | Yes |  |
| AwardsBidHeaderId | int | Yes |  |
| ExportedToVendor | datetime | Yes |  |
| ePOSuppressed | tinyint | Yes |  |



### dbo.POHeader_Test



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| POId | int | No |  |
| PONumber | varchar(24) | Yes |  |
| ItemCount | int | Yes |  |
| Amount | money | Yes |  |
| BudgetName | varchar(30) | Yes |  |
| RequisitionNumber | varchar(24) | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| Attention | varchar(50) | Yes |  |
| CometId | int | Yes |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| DistrictNameAddress | varchar(237) | Yes |  |
| SchoolName | varchar(50) | Yes |  |
| SchoolNameAddress | varchar(189) | Yes |  |
| VendorCode | varchar(16) | Yes |  |
| VendorPhone | varchar(25) | Yes |  |
| DistrictVendorCode | varchar(20) | Yes |  |
| VendorName | varchar(50) | Yes |  |
| VendorNameAddress | varchar(249) | Yes |  |
| PODate | datetime | Yes |  |
| DatePrinted | datetime | Yes |  |
| DatePrintedDetail | datetime | Yes |  |
| DateExported | datetime | Yes |  |
| DistrictId | int | Yes |  |
| CategoryId | int | Yes |  |
| BudgetId | int | Yes |  |
| AccountId | int | Yes |  |
| VendorId | int | Yes |  |
| UserId | int | Yes |  |
| SchoolId | int | No |  |
| VendorBidNumber | varchar(50) | Yes |  |
| VendorBidComments | varchar(540) | Yes |  |
| CategoryCode | char(1) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| DiscountRate | decimal(9,5) | Yes |  |
| DiscountAmount | money | Yes |  |
| TotalGross | money | Yes |  |
| LocationCode | varchar(32) | No |  |
| ShippingAmount | money | Yes |  |
| ShippingPercentage | decimal(9,5) | Yes |  |
| ShippingNameAddress | varchar(189) | Yes |  |
| DistrictAddress1 | varchar(30) | Yes |  |
| DistrictAddress2 | varchar(30) | Yes |  |
| DistrictAddress3 | varchar(30) | Yes |  |
| DistrictCity | varchar(25) | Yes |  |
| DistrictState | varchar(2) | Yes |  |
| DistrictZipcode | varchar(10) | Yes |  |
| SchoolAddress1 | varchar(30) | Yes |  |
| SchoolAddress2 | varchar(30) | Yes |  |
| SchoolAddress3 | varchar(30) | Yes |  |
| SchoolCity | varchar(25) | Yes |  |
| SchoolState | varchar(2) | Yes |  |
| SchoolZipcode | varchar(10) | Yes |  |
| VendorsAddress1 | varchar(50) | Yes |  |
| VendorsAddress2 | varchar(50) | Yes |  |
| VendorsAddress3 | varchar(50) | Yes |  |
| VendorsCity | varchar(50) | Yes |  |
| VendorsState | varchar(2) | Yes |  |
| VendorsZipcode | varchar(10) | Yes |  |
| ShipLocationsAddress1 | varchar(30) | Yes |  |
| ShipLocationsAddress2 | varchar(30) | Yes |  |
| ShipLocationsAddress3 | varchar(30) | Yes |  |
| ShipLocationsCity | varchar(25) | Yes |  |
| ShipLocationsState | varchar(2) | Yes |  |
| ShipLocationsZipcode | varchar(10) | Yes |  |
| ShipLocationsName | varchar(50) | Yes |  |
| DistrictMessage | varchar(4096) | Yes |  |
| BidDate | datetime | Yes |  |
| UsersDistrictAcctgCode | varchar(20) | Yes |  |
| AwardsBidHeaderId | int | Yes |  |
| ExportedToVendor | datetime | Yes |  |



### dbo.POHeaderSummary



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| POId | int | Yes |  |
| PONumber | varchar(24) | Yes |  |
| ItemCount | int | Yes |  |
| Amount | money | Yes |  |
| BudgetName | varchar(30) | Yes |  |
| RequisitionNumber | varchar(24) | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| Attention | varchar(50) | Yes |  |
| CometId | int | Yes |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| DistrictNameAddress | varchar(189) | Yes |  |
| SchoolName | varchar(50) | Yes |  |
| SchoolNameAddress | varchar(189) | Yes |  |
| VendorCode | varchar(16) | Yes |  |
| VendorPhone | varchar(25) | Yes |  |
| DistrictVendorCode | varchar(20) | Yes |  |
| VendorName | varchar(50) | Yes |  |
| VendorNameAddress | varchar(249) | Yes |  |
| PODate | datetime | Yes |  |
| DatePrinted | datetime | Yes |  |
| DatePrintedDetail | datetime | Yes |  |
| DateExported | datetime | Yes |  |
| DistrictId | int | No |  |
| CategoryId | int | Yes |  |
| BudgetId | int | No |  |
| AccountId | int | No |  |
| VendorId | int | Yes |  |
| UserId | int | Yes |  |
| SchoolId | int | Yes |  |
| VendorBidNumber | varchar(50) | No |  |
| VendorBidComments | varchar(606) | Yes |  |
| CategoryCode | varchar(16) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| DiscountRate | decimal(38,6) | Yes |  |
| DiscountAmount | money | Yes |  |
| TotalGross | money | Yes |  |
| LocationCode | varchar(32) | Yes |  |
| ShippingAmount | money | Yes |  |
| ShippingPercentage | decimal(9,5) | Yes |  |
| ShippingNameAddress | varchar(189) | Yes |  |
| DistrictAddress1 | varchar(30) | Yes |  |
| DistrictAddress2 | varchar(30) | Yes |  |
| DistrictAddress3 | varchar(30) | Yes |  |
| DistrictCity | varchar(25) | Yes |  |
| DistrictState | varchar(2) | Yes |  |
| DistrictZipcode | varchar(10) | Yes |  |
| SchoolAddress1 | varchar(30) | Yes |  |
| SchoolAddress2 | varchar(30) | Yes |  |
| SchoolAddress3 | varchar(30) | Yes |  |
| SchoolCity | varchar(25) | Yes |  |
| SchoolState | varchar(2) | Yes |  |
| SchoolZipcode | varchar(10) | Yes |  |
| VendorsAddress1 | varchar(50) | Yes |  |
| VendorsAddress2 | varchar(50) | Yes |  |
| VendorsAddress3 | varchar(50) | Yes |  |
| VendorsCity | varchar(50) | Yes |  |
| VendorsState | varchar(2) | Yes |  |
| VendorsZipcode | varchar(10) | Yes |  |
| ShipLocationsAddress1 | varchar(30) | Yes |  |
| ShipLocationsAddress2 | varchar(30) | Yes |  |
| ShipLocationsAddress3 | varchar(30) | Yes |  |
| ShipLocationsCity | varchar(25) | Yes |  |
| ShipLocationsState | varchar(2) | Yes |  |
| ShipLocationsZipcode | varchar(10) | Yes |  |
| ShipLocationsName | varchar(50) | Yes |  |
| DistrictMessage | varchar(4096) | Yes |  |
| BidDate | datetime | Yes |  |
| UsersDistrictAcctgCode | varchar(20) | Yes |  |
| AwardsBidHeaderId | int | Yes |  |
| ExportedToVendor | datetime | Yes |  |



### dbo.POHeaderSummary_04232018



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| POId | int | Yes |  |
| PONumber | varchar(24) | Yes |  |
| ItemCount | int | Yes |  |
| Amount | money | Yes |  |
| BudgetName | varchar(30) | Yes |  |
| RequisitionNumber | varchar(24) | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| Attention | varchar(50) | Yes |  |
| CometId | int | Yes |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| DistrictNameAddress | varchar(189) | Yes |  |
| SchoolName | varchar(50) | Yes |  |
| SchoolNameAddress | varchar(189) | Yes |  |
| VendorCode | varchar(16) | Yes |  |
| VendorPhone | varchar(25) | Yes |  |
| DistrictVendorCode | varchar(20) | Yes |  |
| VendorName | varchar(50) | Yes |  |
| VendorNameAddress | varchar(249) | Yes |  |
| PODate | datetime | Yes |  |
| DatePrinted | datetime | Yes |  |
| DatePrintedDetail | datetime | Yes |  |
| DateExported | datetime | Yes |  |
| DistrictId | int | No |  |
| CategoryId | int | Yes |  |
| BudgetId | int | No |  |
| AccountId | int | Yes |  |
| VendorId | int | Yes |  |
| UserId | int | Yes |  |
| SchoolId | int | Yes |  |
| VendorBidNumber | varchar(50) | No |  |
| VendorBidComments | varchar(540) | Yes |  |
| CategoryCode | varchar(16) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| DiscountRate | decimal(38,6) | Yes |  |
| DiscountAmount | money | Yes |  |
| TotalGross | money | Yes |  |
| LocationCode | varchar(32) | Yes |  |
| ShippingAmount | money | Yes |  |
| ShippingPercentage | decimal(9,5) | Yes |  |
| ShippingNameAddress | varchar(189) | Yes |  |
| DistrictAddress1 | varchar(30) | Yes |  |
| DistrictAddress2 | varchar(30) | Yes |  |
| DistrictAddress3 | varchar(30) | Yes |  |
| DistrictCity | varchar(25) | Yes |  |
| DistrictState | varchar(2) | Yes |  |
| DistrictZipcode | varchar(10) | Yes |  |
| SchoolAddress1 | varchar(30) | Yes |  |
| SchoolAddress2 | varchar(30) | Yes |  |
| SchoolAddress3 | varchar(30) | Yes |  |
| SchoolCity | varchar(25) | Yes |  |
| SchoolState | varchar(2) | Yes |  |
| SchoolZipcode | varchar(10) | Yes |  |
| VendorsAddress1 | varchar(50) | Yes |  |
| VendorsAddress2 | varchar(50) | Yes |  |
| VendorsAddress3 | varchar(50) | Yes |  |
| VendorsCity | varchar(50) | Yes |  |
| VendorsState | varchar(2) | Yes |  |
| VendorsZipcode | varchar(10) | Yes |  |
| ShipLocationsAddress1 | varchar(30) | Yes |  |
| ShipLocationsAddress2 | varchar(30) | Yes |  |
| ShipLocationsAddress3 | varchar(30) | Yes |  |
| ShipLocationsCity | varchar(25) | Yes |  |
| ShipLocationsState | varchar(2) | Yes |  |
| ShipLocationsZipcode | varchar(10) | Yes |  |
| ShipLocationsName | varchar(50) | Yes |  |
| DistrictMessage | varchar(4096) | Yes |  |
| BidDate | datetime | Yes |  |
| UsersDistrictAcctgCode | varchar(20) | Yes |  |
| AwardsBidHeaderId | int | Yes |  |
| ExportedToVendor | datetime | Yes |  |



### dbo.POHeaderTest



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| POId | int | No |  |
| PONumber | varchar(24) | Yes |  |
| ItemCount | int | Yes |  |
| Amount | money | Yes |  |
| BudgetName | varchar(30) | Yes |  |
| RequisitionNumber | varchar(24) | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| Attention | varchar(50) | Yes |  |
| CometId | int | Yes |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| DistrictNameAddress | varchar(237) | Yes |  |
| SchoolName | varchar(50) | Yes |  |
| SchoolNameAddress | varchar(189) | Yes |  |
| VendorCode | varchar(16) | Yes |  |
| VendorPhone | varchar(25) | Yes |  |
| DistrictVendorCode | varchar(20) | Yes |  |
| VendorName | varchar(50) | Yes |  |
| VendorNameAddress | varchar(249) | Yes |  |
| PODate | datetime | Yes |  |
| DatePrinted | datetime | Yes |  |
| DatePrintedDetail | datetime | Yes |  |
| DateExported | datetime | Yes |  |
| DistrictId | int | Yes |  |
| CategoryId | int | Yes |  |
| BudgetId | int | Yes |  |
| AccountId | int | Yes |  |
| VendorId | int | Yes |  |
| UserId | int | Yes |  |
| SchoolId | int | No |  |
| VendorBidNumber | varchar(50) | Yes |  |
| VendorBidComments | varchar(540) | Yes |  |
| CategoryCode | char(1) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| DiscountRate | decimal(9,5) | Yes |  |
| DiscountAmount | money | Yes |  |
| TotalGross | money | Yes |  |
| LocationCode | varchar(32) | No |  |
| ShippingAmount | money | Yes |  |
| ShippingPercentage | decimal(9,5) | Yes |  |
| ShippingNameAddress | varchar(189) | Yes |  |
| DistrictAddress1 | varchar(30) | Yes |  |
| DistrictAddress2 | varchar(30) | Yes |  |
| DistrictAddress3 | varchar(30) | Yes |  |
| DistrictCity | varchar(25) | Yes |  |
| DistrictState | varchar(2) | Yes |  |
| DistrictZipcode | varchar(10) | Yes |  |
| SchoolAddress1 | varchar(30) | Yes |  |
| SchoolAddress2 | varchar(30) | Yes |  |
| SchoolAddress3 | varchar(30) | Yes |  |
| SchoolCity | varchar(25) | Yes |  |
| SchoolState | varchar(2) | Yes |  |
| SchoolZipcode | varchar(10) | Yes |  |
| VendorsAddress1 | varchar(50) | Yes |  |
| VendorsAddress2 | varchar(50) | Yes |  |
| VendorsAddress3 | varchar(50) | Yes |  |
| VendorsCity | varchar(50) | Yes |  |
| VendorsState | varchar(2) | Yes |  |
| VendorsZipcode | varchar(10) | Yes |  |
| ShipLocationsAddress1 | varchar(30) | Yes |  |
| ShipLocationsAddress2 | varchar(30) | Yes |  |
| ShipLocationsAddress3 | varchar(30) | Yes |  |
| ShipLocationsCity | varchar(25) | Yes |  |
| ShipLocationsState | varchar(2) | Yes |  |
| ShipLocationsZipcode | varchar(10) | Yes |  |
| ShipLocationsName | varchar(50) | Yes |  |
| DistrictMessage | varchar(4096) | Yes |  |
| BidDate | datetime | Yes |  |
| UsersDistrictAcctgCode | varchar(20) | Yes |  |
| AwardsBidHeaderId | int | Yes |  |
| ExportedToVendor | datetime | Yes |  |



### dbo.PPCategoryView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| PricePlanId | int | Yes |  |
| CategoryId | int | Yes |  |



### dbo.PricePlanView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| PricePlanId | int | No |  |
| Code | varchar(20) | Yes |  |



### dbo.ReqDetail



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| RequisitionNumber | varchar(24) | Yes |  |
| SchoolId | int | Yes |  |
| UserId | int | Yes |  |
| BudgetId | int | Yes |  |
| BudgetAccountId | int | Yes |  |
| UserAccountId | int | Yes |  |
| CategoryId | int | Yes |  |
| ShippingId | int | Yes |  |
| Attention | varchar(50) | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| DateEntered | datetime | Yes |  |
| ShippingPercent | decimal(9,5) | Yes |  |
| DiscountPercent | decimal(9,5) | Yes |  |
| ShippingCost | money | Yes |  |
| TotalItemsCost | money | Yes |  |
| TotalRequisitionCost | money | Yes |  |
| Comments | varchar(1023) | Yes |  |
| ApprovalRequired | tinyint | Yes |  |
| ApprovalId | int | Yes |  |
| ApprovalLevel | tinyint | Yes |  |
| StatusId | int | Yes |  |
| OrderDate | datetime | Yes |  |
| BidId | int | Yes |  |
| DateExported | datetime | Yes |  |
| DetailId | int | No |  |
| CatalogId | int | Yes |  |
| ItemId | int | Yes |  |
| AddendumItem | tinyint | Yes |  |
| ItemCode | varchar(50) | Yes |  |
| Quantity | int | Yes |  |
| LastYearsQuantity | int | Yes |  |
| Description | varchar(1024) | Yes |  |
| UnitId | int | Yes |  |
| UnitCode | varchar(20) | Yes |  |
| BidPrice | money | Yes |  |
| CatalogPrice | money | Yes |  |
| GrossPrice | money | Yes |  |
| DiscountRate | decimal(9,5) | Yes |  |
| CatalogPage | char(4) | Yes |  |
| PricePlanId | int | Yes |  |
| PriceId | int | Yes |  |
| AwardId | int | Yes |  |
| VendorId | int | Yes |  |
| VendorItemCode | varchar(50) | Yes |  |
| Alternate | varchar(1024) | Yes |  |
| POId | int | Yes |  |
| BatchDetailId | int | Yes |  |
| Modified | datetime | Yes |  |
| ModifiedById | int | Yes |  |
| SortSeq | varchar(64) | Yes |  |



### dbo.RequisitionsView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| Active | tinyint | Yes |  |
| RequisitionNumber | varchar(24) | Yes |  |
| SchoolId | int | Yes |  |
| UserId | int | Yes |  |
| BudgetId | int | Yes |  |
| BudgetAccountId | int | Yes |  |
| UserAccountId | int | Yes |  |
| CategoryId | int | Yes |  |
| ShippingId | int | Yes |  |
| Attention | varchar(50) | Yes |  |
| DateEntered | datetime | Yes |  |
| ShippingPercent | decimal(9,5) | Yes |  |
| DiscountPercent | decimal(9,5) | Yes |  |
| ShippingCost | money | Yes |  |
| TotalItemsCost | money | Yes |  |
| TotalRequisitionCost | money | Yes |  |
| Comments | varchar(1023) | Yes |  |
| ApprovalRequired | tinyint | Yes |  |
| ApprovalId | int | Yes |  |
| OrderDate | datetime | Yes |  |
| DateExported | datetime | Yes |  |
| StatusId | int | Yes |  |



### dbo.rs_DistrictSummary



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| CategoryName | varchar(50) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| ItemId | int | Yes |  |
| ItemCode | varchar(50) | Yes |  |
| SortSeq | varchar(50) | Yes |  |
| Description | varchar(1536) | Yes |  |
| UnitCode | varchar(16) | Yes |  |
| Quantity | int | Yes |  |
| VendorCode | varchar(10) | Yes |  |
| UnitPrice | money | Yes |  |
| ExtendedPrice | money | Yes |  |
| BidPrice | money | Yes |  |
| GrossPrice | money | Yes |  |
| DiscountRate | decimal(9,5) | Yes |  |
| UseGrossPrices | tinyint | Yes |  |
| VendorId | int | Yes |  |
| VendorItemCode | varchar(50) | Yes |  |
| Alternate | varchar(1024) | Yes |  |
| DistrictId | int | Yes |  |
| CategoryId | int | Yes |  |
| PricePlanId | int | Yes |  |
| AwardId | int | Yes |  |
| BudgetId | int | Yes |  |
| VendorTotal | money | Yes |  |
| VendorCount | int | Yes |  |
| CategoryTotal | money | Yes |  |
| CategoryCount | int | Yes |  |
| DistrictTotal | money | Yes |  |
| DistrictCount | int | Yes |  |
| ListId | int | Yes |  |
| BidHeaderId | int | Yes |  |



### dbo.rs_DistrictSummaryAwardLetter



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RSId | int | Yes |  |
| DistrictId | int | Yes |  |
| CategoryId | int | Yes |  |
| PricePlanId | int | Yes |  |
| VendorId | int | Yes |  |
| ItemsBid | int | Yes |  |
| AmountBid | money | Yes |  |
| ItemsAwarded | int | Yes |  |
| AmountAwarded | money | Yes |  |
| AwardId | int | Yes |  |
| BidDate | datetime | Yes |  |
| BidAwardDate | datetime | Yes |  |
| TotalItemsAwarded | int | Yes |  |
| TotalItemsBid | int | Yes |  |
| TotalAmountBid | money | Yes |  |
| TotalAmountAwarded | money | Yes |  |
| BidHeaderId | int | Yes |  |
| VendorCode | varchar(20) | Yes |  |
| VendorName | varchar(50) | Yes |  |



### dbo.rs_DistrictSummaryVendors



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RSId | int | Yes |  |
| VendorId | int | Yes |  |
| CategoryId | int | Yes |  |
| BidHeaderId | int | Yes |  |
| LineCount | int | Yes |  |
| GrossCost | money | Yes |  |
| DiscountAmount | money | Yes |  |
| NetCost | money | Yes |  |
| TotalLineCount | int | Yes |  |
| TotalGrossCost | money | Yes |  |
| TotalDiscountAmount | money | Yes |  |
| TotalNetCost | money | Yes |  |
| VendorCode | varchar(20) | Yes |  |
| VendorName | varchar(50) | Yes |  |



### dbo.rs_SBS_AccountRecap_District



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RSId | int | Yes |  |
| ItemCount | int | Yes |  |
| GrossTotal | money | Yes |  |
| DiscountTotal | decimal(38,13) | Yes |  |
| NetTotal | decimal(38,13) | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| CategoryCode | char(1) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| UseGrossPrices | tinyint | Yes |  |
| SchoolId | int | No |  |
| SchoolName | varchar(50) | Yes |  |
| BudgetName | varchar(30) | Yes |  |
| CategoryId | int | No |  |
| DistrictId | int | No |  |



### dbo.rs_SBS_AccountRecap_School



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RSId | int | Yes |  |
| ItemCount | int | Yes |  |
| GrossTotal | money | Yes |  |
| DiscountTotal | decimal(38,13) | Yes |  |
| NetTotal | decimal(38,13) | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| CategoryCode | char(1) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| UseGrossPrices | tinyint | Yes |  |
| SchoolId | int | No |  |
| SchoolName | varchar(50) | Yes |  |
| BudgetName | varchar(30) | Yes |  |
| CategoryId | int | No |  |



### dbo.rs_SBS_SchoolSummary



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RSId | int | Yes |  |
| CategoryCode | varchar(16) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| CategoryId | int | No |  |
| Attention | varchar(50) | Yes |  |
| AccountCode | varchar(50) | No |  |
| DistrictId | int | No |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| SchoolId | int | No |  |
| SchoolName | varchar(50) | Yes |  |
| BudgetName | varchar(30) | Yes |  |
| CometId | int | Yes |  |
| UserId | int | No |  |
| RequisitionId | int | No |  |



### dbo.rs_SBS_SchoolSummary_Detail



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RSId | int | Yes |  |
| ItemCode | varchar(50) | Yes |  |
| Description | varchar(2880) | Yes |  |
| CatalogPage | char(4) | Yes |  |
| UnitCode | varchar(20) | Yes |  |
| Quantity | int | Yes |  |
| BidPrice | money | Yes |  |
| GrossPrice | money | Yes |  |
| CatalogPrice | money | Yes |  |
| BidTotal | money | Yes |  |
| VendorItemCode | varchar(50) | Yes |  |
| Alternate | varchar(1024) | Yes |  |
| DiscountRate | int | No |  |
| GrossTotal | money | Yes |  |
| NetTotal | decimal(34,13) | Yes |  |
| VendorCode | varchar(16) | Yes |  |
| VendorName | varchar(50) | Yes |  |
| CategoryCode | char(1) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| RequisitionId | int | No |  |
| Attention | varchar(50) | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| DistrictId | int | No |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| SchoolId | int | No |  |
| SchoolName | varchar(50) | Yes |  |
| BudgetName | varchar(30) | Yes |  |
| CometId | int | Yes |  |
| UserId | int | No |  |
| SortSeq | varchar(64) | Yes |  |



### dbo.rs_SBS_UserRecap_District



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RSId | int | Yes |  |
| ItemCount | int | Yes |  |
| GrossTotal | money | Yes |  |
| DiscountTotal | decimal(38,13) | Yes |  |
| NetTotal | decimal(38,13) | Yes |  |
| Attention | varchar(50) | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| CategoryCode | char(1) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| UseGrossPrices | tinyint | Yes |  |
| SchoolName | varchar(50) | Yes |  |
| BudgetName | varchar(30) | Yes |  |
| CometId | int | Yes |  |
| CategoryId | int | No |  |
| DistrictId | int | No |  |
| SchoolId | int | No |  |



### dbo.rs_SBS_UserRecap_School



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RSId | int | Yes |  |
| ItemCount | int | Yes |  |
| GrossTotal | money | Yes |  |
| DiscountTotal | decimal(38,13) | Yes |  |
| NetTotal | decimal(38,13) | Yes |  |
| Attention | varchar(50) | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| CategoryCode | char(1) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| UseGrossPrices | tinyint | Yes |  |
| SchoolName | varchar(50) | Yes |  |
| BudgetName | varchar(30) | Yes |  |
| CometId | int | Yes |  |
| CategoryId | int | No |  |
| SchoolId | int | No |  |



### dbo.rs_SBS_VendorRecap_District



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RSId | int | Yes |  |
| VendorCode | varchar(16) | Yes |  |
| VendorName | varchar(50) | Yes |  |
| ItemCount | int | Yes |  |
| GrossTotal | money | Yes |  |
| DiscountTotal | decimal(38,13) | Yes |  |
| NetTotal | decimal(38,13) | Yes |  |
| CategoryCode | char(1) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| UseGrossPrices | tinyint | Yes |  |
| BudgetName | varchar(30) | Yes |  |
| DistrictId | int | No |  |
| CategoryId | int | No |  |
| DiscountRate | decimal(9,5) | Yes |  |



### dbo.rs_SBS_VendorRecap_School



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RSId | int | Yes |  |
| VendorCode | varchar(16) | Yes |  |
| VendorName | varchar(50) | Yes |  |
| ItemCount | int | Yes |  |
| GrossTotal | money | Yes |  |
| DiscountTotal | decimal(38,13) | Yes |  |
| NetTotal | decimal(38,13) | Yes |  |
| CategoryCode | char(1) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| UseGrossPrices | tinyint | Yes |  |
| SchoolName | varchar(50) | Yes |  |
| BudgetName | varchar(30) | Yes |  |
| SchoolId | int | No |  |
| CategoryId | int | No |  |
| DiscountRate | decimal(9,5) | Yes |  |



### dbo.rs_SBS_VendorRecap_User



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RSId | int | Yes |  |
| VendorCode | varchar(16) | Yes |  |
| VendorName | varchar(50) | Yes |  |
| ItemCount | int | Yes |  |
| GrossTotal | money | Yes |  |
| DiscountTotal | decimal(38,13) | Yes |  |
| NetTotal | decimal(38,13) | Yes |  |
| CategoryCode | char(1) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| Attention | varchar(50) | Yes |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| UseGrossPrices | tinyint | Yes |  |
| SchoolName | varchar(50) | Yes |  |
| BudgetName | varchar(30) | Yes |  |
| CometId | int | Yes |  |
| RequisitionId | int | No |  |
| DiscountRate | decimal(9,5) | Yes |  |



### dbo.rs_SBS_VendorUserRecap_District



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RSId | int | Yes |  |
| ItemCount | int | Yes |  |
| AwardId | int | Yes |  |
| GrossTotal | money | Yes |  |
| DiscountTotal | decimal(38,13) | Yes |  |
| NetTotal | decimal(38,13) | Yes |  |
| Attention | varchar(50) | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| CategoryCode | char(1) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| UseGrossPrices | tinyint | Yes |  |
| SchoolId | int | No |  |
| SchoolName | varchar(50) | Yes |  |
| BudgetName | varchar(30) | Yes |  |
| CometId | int | Yes |  |
| CategoryId | int | No |  |
| VendorId | int | No |  |
| VendorCode | varchar(16) | Yes |  |
| VendorName | varchar(50) | Yes |  |
| VendorPhone | varchar(20) | Yes |  |
| BidStartDate | datetime | Yes |  |
| BidEndDate | datetime | Yes |  |
| VendorBidNumber | varchar(50) | Yes |  |
| AwardDescription | varchar(511) | Yes |  |
| DistrictId | int | No |  |
| DiscountRate | decimal(9,5) | Yes |  |



### dbo.rs_SBS_VendorUserRecap_School



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RSId | int | Yes |  |
| ItemCount | int | Yes |  |
| AwardId | int | Yes |  |
| GrossTotal | money | Yes |  |
| DiscountTotal | decimal(38,13) | Yes |  |
| NetTotal | decimal(38,13) | Yes |  |
| Attention | varchar(50) | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| CategoryCode | char(1) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| UseGrossPrices | tinyint | Yes |  |
| SchoolId | int | No |  |
| SchoolName | varchar(50) | Yes |  |
| BudgetName | varchar(30) | Yes |  |
| CometId | int | Yes |  |
| CategoryId | int | No |  |
| VendorId | int | No |  |
| VendorCode | varchar(16) | Yes |  |
| VendorName | varchar(50) | Yes |  |
| VendorPhone | varchar(20) | Yes |  |
| BidStartDate | datetime | Yes |  |
| BidEndDate | datetime | Yes |  |
| VendorBidNumber | varchar(50) | Yes |  |
| AwardDescription | varchar(511) | Yes |  |
| DiscountRate | decimal(9,5) | Yes |  |



### dbo.rs_SBSDetailRecap



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RSId | int | Yes |  |
| RequisitionId | int | No |  |
| Attention | varchar(50) | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| ItemCode | varchar(50) | Yes |  |
| Quantity | int | Yes |  |
| Description | varchar(1024) | Yes |  |
| UnitCode | varchar(20) | Yes |  |
| BidPrice | money | Yes |  |
| CatalogPrice | money | Yes |  |
| GrossPrice | money | Yes |  |
| DiscountRate | decimal(9,5) | No |  |
| CatalogPage | char(4) | Yes |  |
| BidTotal | money | Yes |  |
| VendorItemCode | varchar(50) | Yes |  |
| Alternate | varchar(1024) | Yes |  |
| GrossTotal | money | Yes |  |
| NetTotal | decimal(34,13) | Yes |  |
| VendorCode | varchar(16) | Yes |  |
| VendorName | varchar(50) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| CategoryCode | varchar(16) | Yes |  |
| BudgetName | varchar(30) | Yes |  |
| DistrictId | int | No |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| SchoolId | int | No |  |
| SchoolName | varchar(50) | Yes |  |
| UserId | int | No |  |
| CometId | int | Yes |  |
| CategoryId | int | No |  |
| SortSeq | varchar(64) | Yes |  |
| BidType | tinyint | No |  |



### dbo.rs_SBSReqRecap



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RSId | int | Yes |  |
| Attention | varchar(50) | Yes |  |
| AccountCode | varchar(50) | No |  |
| CategoryId | int | No |  |
| CategoryName | varchar(50) | Yes |  |
| CategoryCode | varchar(16) | Yes |  |
| BudgetName | varchar(30) | Yes |  |
| DistrictId | int | No |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| SchoolId | int | No |  |
| SchoolName | varchar(50) | Yes |  |
| UserId | int | No |  |
| CometId | int | Yes |  |



### dbo.rs_SBSVendorRecap



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RSId | int | Yes |  |
| Attention | varchar(50) | Yes |  |
| CometId | int | Yes |  |
| ItemCount | int | Yes |  |
| GrossTotal | money | Yes |  |
| DiscountTotal | decimal(38,13) | Yes |  |
| NetTotal | decimal(38,13) | Yes |  |
| DiscountRate | varchar(16) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| CategoryCode | varchar(16) | Yes |  |
| BudgetName | varchar(30) | Yes |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| UseGrossPrices | tinyint | Yes |  |
| SchoolName | varchar(50) | Yes |  |
| VendorCode | varchar(16) | Yes |  |
| VendorName | varchar(50) | Yes |  |
| CategoryId | int | No |  |
| UserId | int | No |  |
| AccountCode | varchar(50) | Yes |  |



### dbo.rs_VendorRecap



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RSId | int | Yes |  |
| Attention | varchar(50) | Yes |  |
| CometId | int | Yes |  |
| ItemCount | int | Yes |  |
| GrossTotal | money | Yes |  |
| DiscountTotal | decimal(38,13) | Yes |  |
| NetTotal | decimal(38,13) | Yes |  |
| DiscountRate | varchar(16) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| CategoryCode | varchar(16) | Yes |  |
| BudgetName | varchar(30) | Yes |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| UseGrossPrices | tinyint | Yes |  |
| SchoolName | varchar(50) | Yes |  |
| VendorCode | varchar(16) | Yes |  |
| VendorName | varchar(50) | Yes |  |



### dbo.RTK_Item_StructureView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RTK_ItemsId | int | No |  |
| AlternateDesc | varchar(60) | No |  |
| ItemDesc | varchar(512) | No |  |
| MSDSDetail | nvarchar(MAX) | No |  |



### dbo.SearchItemsHeadingsView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| Title | varchar(255) | No |  |
| Description | varchar(4096) | Yes |  |
| HeadingId | int | Yes |  |
| SearchLetter | varchar(1) | No |  |



### dbo.SearchItemsKeywordsView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| Title | varchar(255) | Yes |  |
| Description | varchar(4096) | Yes |  |
| HeadingId | int | Yes |  |
| Keyword | varchar(50) | Yes |  |
| KeywordId | int | Yes |  |



### dbo.SearchItemsView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| ItemId | int | No |  |
| ItemCode | varchar(50) | Yes |  |
| Description | varchar(512) | Yes |  |
| Code | varchar(20) | Yes |  |
| Title | varchar(255) | Yes |  |
| HeadingsDescription | varchar(4096) | Yes |  |
| Keyword | varchar(50) | Yes |  |
| SortSeq | varchar(64) | Yes |  |
| HeadingId | int | Yes |  |
| KeywordId | int | Yes |  |
| BidPrice | decimal(33,13) | Yes |  |



### dbo.TestAllFF



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| ItemId | int | No |  |
| ItemCode | varchar(50) | Yes |  |
| Description | varchar(512) | Yes |  |
| UnitId | int | Yes |  |
| Code | varchar(20) | Yes |  |
| CrossRefId | int | No |  |
| CatalogPrice | money | Yes |  |
| VendorItemCode | varchar(50) | Yes |  |
| CatalogId | int | Yes |  |
| Name | varchar(50) | Yes |  |
| CategoryId | int | Yes |  |
| VendorId | int | Yes |  |
| VendorName | varchar(50) | Yes |  |
| AwardId | int | No |  |
| DistrictId | int | Yes |  |
| PriceId | uniqueidentifier | No |  |
| PricesDescription | varchar(1024) | Yes |  |
| PricePlanId | int | Yes |  |
| DiscountRate | decimal(9,5) | Yes |  |



### dbo.TestFF



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| ItemId | int | No |  |
| ItemCode | varchar(50) | Yes |  |
| Description | varchar(512) | Yes |  |
| UnitId | int | Yes |  |
| Code | varchar(20) | Yes |  |
| CrossRefId | int | No |  |
| CatalogPrice | money | Yes |  |
| VendorItemCode | varchar(50) | Yes |  |
| CatalogId | int | Yes |  |
| Name | varchar(50) | Yes |  |
| CategoryId | int | Yes |  |
| VendorId | int | Yes |  |
| VendorName | varchar(50) | Yes |  |
| PricePlanId | int | Yes |  |
| AwardId | int | No |  |
| DistrictId | int | Yes |  |
| DiscountRate | decimal(5,2) | Yes |  |
| PriceId | uniqueidentifier | No |  |
| PricesDescription | varchar(1024) | Yes |  |



### dbo.TMDistrictInfo



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| TMSurveyId | int | No |  |
| Name | varchar(50) | Yes |  |
| County | varchar(50) | Yes |  |



### dbo.UploadView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| UploadId | int | No |  |
| FileName | varchar(255) | Yes |  |
| DateCreated | datetime | Yes |  |
| DateUploaded | datetime | No |  |
| Status | varchar(255) | Yes |  |
| VendorId | int | No |  |
| VendorName | varchar(50) | Yes |  |
| UploadEmailList | varchar(4096) | Yes |  |
| HostURL | varchar(255) | Yes |  |
| HostPort | int | Yes |  |
| HostDirectory | varchar(255) | Yes |  |
| HostUserName | varchar(255) | Yes |  |
| HostPassword | varchar(255) | Yes |  |
| DistrictId | int | No |  |
| DistrictName | varchar(50) | Yes |  |
| VendorAccountNumber | varchar(50) | Yes |  |



### dbo.UserContactProblemView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| UserName | varchar(10) | Yes |  |
| Attention | varchar(50) | Yes |  |
| ErrorMessage | varchar(270) | No |  |
| DistrictName | varchar(50) | Yes |  |
| DistrictId | int | No |  |
| RepName | varchar(30) | Yes |  |
| CSRepId | int | No |  |
| Active | tinyint | Yes |  |
| SchoolId | int | Yes |  |
| UserId | int | No |  |



### dbo.UserListView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SchoolName | varchar(50) | Yes |  |
| UserNumber | int | Yes |  |
| UserName | varchar(50) | Yes |  |
| Password | varchar(11) | No |  |
| Attention | varchar(50) | Yes |  |
| DistrictAccountingCode | varchar(20) | No |  |
| ShipLocation | varchar(50) | No |  |
| LocationCode | varchar(32) | No |  |
| AccountCode | varchar(50) | No |  |
| AllocationAmount | money | No |  |
| AllocationAvailable | numeric(19,4) | No |  |
| UseAllocations | tinyint | No |  |
| ApproverName | varchar(50) | No |  |
| SessionId | int | No |  |
| SchoolId | int | No |  |
| Email | varchar(255) | Yes |  |



### dbo.UsersApprovees



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| UserId | int | No |  |
| CometId | int | Yes |  |
| Attention | varchar(50) | Yes |  |
| DisableNewRequisition | tinyint | No |  |
| DistrictAcctgCode | varchar(20) | Yes |  |
| SchoolName | varchar(50) | Yes |  |
| ApprovalLevelDescription | varchar(50) | Yes |  |
| ApproverId | int | Yes |  |



### dbo.UserTreeView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| UserId | int | No |  |
| DistrictId | int | Yes |  |
| SchoolId | int | Yes |  |
| ShippingId | int | Yes |  |
| UserName | varchar(50) | Yes |  |
| Password | varchar(11) | No |  |
| Attention | varchar(50) | Yes |  |
| ApprovalLevel | tinyint | Yes |  |
| CometId | int | Yes |  |
| DisableNewRequisition | tinyint | Yes |  |
| DistrictAcctgCode | varchar(20) | Yes |  |
| ApproverId | int | Yes |  |
| Children | int | Yes |  |



### dbo.VendorBidLookup



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| vendorbidid | varchar(50) | Yes |  |
| calendarid | int | Yes |  |
| code | varchar(16) | Yes |  |
| name | varchar(50) | Yes |  |
| priceplan | varchar(16) | Yes |  |
| categoryname | varchar(255) | Yes |  |
| state | char(2) | Yes |  |



### dbo.VendorContactProblemView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VendorName | varchar(50) | Yes |  |
| CODE | varchar(16) | Yes |  |
| ErrorMessage | varchar(270) | No |  |
| BidContactCount | int | Yes |  |
| POContactCount | int | Yes |  |
| FULLNAME | varchar(150) | Yes |  |
| EMAIL | varchar(255) | Yes |  |
| BIDCONTACT | tinyint | Yes |  |
| POCONTACT | tinyint | Yes |  |
| VENDORID | int | No |  |
| VENDORCONTACTID | int | Yes |  |
| Active | tinyint | Yes |  |



### dbo.vw_ActiveBids



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| BidId | int | No |  |
| VendorId | int | No |  |
| VendorName | varchar(50) | Yes |  |
| VendorCode | varchar(16) | Yes |  |
| CategoryId | int | No |  |
| CategoryName | varchar(50) | Yes |  |
| CategoryType | int | Yes |  |
| PricePlanId | int | No |  |
| PricePlan | varchar(20) | Yes |  |
| BidType | tinyint | Yes |  |



### dbo.vw_ActiveCatalogs



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| CategoryId | int | No |  |
| CategoryName | varchar(50) | Yes |  |
| CatalogId | int | No |  |
| CatalogName | varchar(50) | Yes |  |
| VendorId | int | No |  |
| VendorName | varchar(50) | Yes |  |



### dbo.vw_ActiveDistrictList



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| Name | varchar(50) | Yes |  |
| Address | varchar(50) | Yes |  |
| City | varchar(50) | Yes |  |
| State | varchar(2) | Yes |  |
| Zipcode | varchar(10) | Yes |  |
| BAName | varchar(174) | Yes |  |
| RTK | int | Yes |  |
| CooperativeBids | int | Yes |  |
| TimeAndMaterialBids | int | Yes |  |
| DistrictId | int | No |  |
| RepName | varchar(30) | Yes |  |
| RepEmail | varchar(128) | Yes |  |
| RepPhone | varchar(20) | Yes |  |



### dbo.vw_ActiveVendors



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VendorId | int | No |  |
| Active | tinyint | Yes |  |
| Code | varchar(16) | Yes |  |
| Name | varchar(50) | Yes |  |
| Address1 | varchar(50) | Yes |  |
| Address2 | varchar(50) | Yes |  |
| Address3 | varchar(50) | Yes |  |
| City | varchar(25) | Yes |  |
| State | varchar(2) | Yes |  |
| ZipCode | varchar(10) | Yes |  |
| Phone | varchar(20) | Yes |  |
| Fax | varchar(20) | Yes |  |
| EMail | varchar(255) | Yes |  |
| UseGrossPrices | tinyint | Yes |  |
| ShippingPercentage | decimal(9,5) | Yes |  |
| DistrictId | int | Yes |  |
| Password | varchar(50) | Yes |  |
| HostURL | varchar(255) | Yes |  |
| HostPort | int | Yes |  |
| HostDirectory | varchar(255) | Yes |  |
| HostUserName | varchar(255) | Yes |  |
| HostPassword | varchar(255) | Yes |  |
| UploadEMailList | varchar(4096) | Yes |  |
| UploadType | int | Yes |  |
| BusinessUnit | varchar(17) | Yes |  |
| POPassword | varchar(50) | Yes |  |
| cXMLAddress | varchar(255) | Yes |  |
| VendorLogo | varbinary(MAX) | Yes |  |
| cXMLFromDomain | varchar(50) | Yes |  |
| cXMLFromIdentity | varchar(50) | Yes |  |
| cXMLToDomain | varchar(50) | Yes |  |
| cXMLToIdentity | varchar(50) | Yes |  |
| cXMLSenderDomain | varchar(50) | Yes |  |
| cXMLSenderIdentity | varchar(50) | Yes |  |
| cXMLSenderSharedSecret | varchar(50) | Yes |  |
| rowguid | uniqueidentifier | No |  |
| Contact | varchar(50) | Yes |  |



### dbo.vw_ApprovalsHistory



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| ApprovalDate | datetime | Yes |  |
| Submitter | varchar(56) | No |  |
| Approver | varchar(56) | No |  |
| StatusName | varchar(50) | No |  |



### dbo.vw_ApproveRequisitions



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| RequisitionNumber | varchar(24) | Yes |  |
| StatusID | int | No |  |
| StatusName | varchar(50) | No |  |
| TotalRequisitionCost | money | No |  |
| ApprovalLevel | tinyint | No |  |
| Attention | varchar(50) | Yes |  |
| CometId | varchar(5) | Yes |  |
| DateUpdated | datetime | Yes |  |
| NotesCount | int | No |  |
| OrderType | tinyint | No |  |
| OrderTypeDisplay | varchar(10) | No |  |
| UserDisplayName | varchar(56) | Yes |  |
| CategoryID | int | No |  |
| CategoryName | varchar(50) | Yes |  |
| BudgetID | int | No |  |
| AccountID | int | No |  |
| AccountCode | varchar(50) | No |  |
| DistrictID | int | No |  |
| DistrictName | varchar(50) | No |  |
| SchoolID | int | No |  |
| SchoolName | varchar(50) | Yes |  |
| UserID | int | No |  |
| UserAccountId | int | No |  |
| SessionId | int | No |  |
| AllocationAvailable | money | Yes |  |
| REQ_UAID | int | Yes |  |
| UseBudgetAccountAllocations | tinyint | No |  |
| BudgetAmount | money | No |  |
| UseAllocations | tinyint | No |  |
| AllocationAmount | money | No |  |
| HistoryCount | int | No |  |
| StatusDesc | varchar(104) | No |  |
| AddendaTotal | money | Yes |  |
| LastAlteredSessionId | int | Yes |  |



### dbo.vw_ApproveRequisitionsBySession



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| RequisitionNumber | varchar(24) | Yes |  |
| StatusID | int | No |  |
| StatusName | varchar(50) | No |  |
| TotalRequisitionCost | money | No |  |
| ApprovalLevel | tinyint | No |  |
| Attention | varchar(50) | Yes |  |
| CometId | varchar(5) | Yes |  |
| DateUpdated | datetime | Yes |  |
| NotesCount | int | No |  |
| OrderType | tinyint | No |  |
| OrderTypeDisplay | varchar(10) | No |  |
| UserDisplayName | varchar(56) | Yes |  |
| CategoryID | int | No |  |
| CategoryName | varchar(50) | Yes |  |
| BudgetID | int | No |  |
| AccountID | int | No |  |
| AccountCode | varchar(62) | No |  |
| DistrictID | int | No |  |
| DistrictName | varchar(50) | No |  |
| SchoolID | int | No |  |
| SchoolName | varchar(103) | Yes |  |
| UserID | int | No |  |
| UserAccountId | int | No |  |
| SessionId | int | No |  |
| AllocationAvailable | money | Yes |  |
| REQ_UAID | int | Yes |  |
| UseBudgetAccountAllocations | tinyint | No |  |
| BudgetAmount | money | No |  |
| UseAllocations | tinyint | No |  |
| AllocationAmount | money | No |  |
| HistoryCount | int | No |  |
| StatusDesc | varchar(104) | No |  |
| AddendaTotal | money | No |  |
| LastAlteredSessionId | int | Yes |  |
| LowPOCount | int | Yes |  |
| DistrictPOMinimum | money | No |  |
| InactiveAccount | int | No |  |
| AdditionalShipping | int | Yes |  |
| AdditionalShippingCost | decimal(38,2) | Yes |  |



### dbo.vw_ApproveRequisitionsBySession_Test



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| RequisitionNumber | varchar(24) | Yes |  |
| StatusID | int | No |  |
| StatusName | varchar(50) | No |  |
| TotalRequisitionCost | money | No |  |
| ApprovalLevel | tinyint | No |  |
| Attention | varchar(50) | Yes |  |
| CometId | varchar(5) | Yes |  |
| DateUpdated | datetime | Yes |  |
| NotesCount | int | No |  |
| OrderType | tinyint | No |  |
| OrderTypeDisplay | varchar(10) | No |  |
| UserDisplayName | varchar(56) | Yes |  |
| CategoryID | int | No |  |
| CategoryName | varchar(50) | Yes |  |
| BudgetID | int | No |  |
| AccountID | int | No |  |
| AccountCode | varchar(62) | No |  |
| DistrictID | int | No |  |
| DistrictName | varchar(50) | No |  |
| SchoolID | int | No |  |
| SchoolName | varchar(103) | Yes |  |
| UserID | int | No |  |
| UserAccountId | int | No |  |
| SessionId | int | No |  |
| AllocationAvailable | money | Yes |  |
| REQ_UAID | int | Yes |  |
| UseBudgetAccountAllocations | tinyint | No |  |
| BudgetAmount | money | No |  |
| UseAllocations | tinyint | No |  |
| AllocationAmount | money | No |  |
| HistoryCount | int | No |  |
| StatusDesc | varchar(104) | No |  |
| AddendaTotal | money | No |  |
| LastAlteredSessionId | int | Yes |  |
| LowPOCount | int | Yes |  |
| DistrictPOMinimum | money | No |  |
| InactiveAccount | int | No |  |
| AdditionalShipping | int | Yes |  |
| AdditionalShippingCost | decimal(38,2) | Yes |  |



### dbo.vw_ApproveRequisitionsTest



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| RequisitionNumber | varchar(24) | Yes |  |
| StatusID | int | No |  |
| StatusName | varchar(50) | No |  |
| TotalRequisitionCost | money | No |  |
| ApprovalLevel | tinyint | No |  |
| Attention | varchar(50) | Yes |  |
| CometId | varchar(5) | Yes |  |
| DateUpdated | datetime | Yes |  |
| NotesCount | int | No |  |
| OrderType | tinyint | No |  |
| OrderTypeDisplay | varchar(10) | No |  |
| UserDisplayName | varchar(56) | Yes |  |
| CategoryID | int | No |  |
| CategoryName | varchar(50) | Yes |  |
| BudgetID | int | No |  |
| AccountID | int | No |  |
| AccountCode | varchar(50) | No |  |
| DistrictID | int | No |  |
| DistrictName | varchar(50) | No |  |
| SchoolID | int | No |  |
| SchoolName | varchar(50) | Yes |  |
| UserID | int | No |  |
| UserAccountId | int | No |  |
| SessionId | int | No |  |
| AllocationAvailable | money | Yes |  |
| REQ_UAID | int | Yes |  |
| UseBudgetAccountAllocations | tinyint | No |  |
| BudgetAmount | money | No |  |
| UseAllocations | tinyint | No |  |
| AllocationAmount | money | No |  |
| HistoryCount | int | No |  |
| StatusDesc | varchar(104) | No |  |
| AddendaTotal | money | Yes |  |
| LastAlteredSessionId | int | Yes |  |



### dbo.vw_ARAccounts



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| Tagged | int | No |  |
| SessionId | int | No |  |
| AccountId | int | No |  |
| AccountCode | varchar(50) | No |  |



### dbo.vw_ARBudgets



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| Tagged | int | No |  |
| SessionId | int | No |  |
| BudgetId | int | No |  |
| BudgetName | varchar(30) | No |  |



### dbo.vw_ARCategories



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| Tagged | int | No |  |
| SessionId | int | No |  |
| CategoryId | int | No |  |
| CategoryName | varchar(50) | Yes |  |



### dbo.vw_ARSchools



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| Tagged | int | No |  |
| SessionId | int | No |  |
| SchoolId | int | No |  |
| SchoolName | varchar(50) | No |  |



### dbo.vw_ARStatuses



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| Tagged | int | No |  |
| SessionId | int | No |  |
| BudgetId | int | No |  |
| StatusId | int | No |  |
| StatusDesc | varchar(104) | No |  |
| StatusCode | int | No |  |



### dbo.vw_ARUsers



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| Tagged | int | No |  |
| SessionId | int | No |  |
| UserId | int | No |  |
| UserNumber | int | No |  |
| Attention | varchar(50) | No |  |



### dbo.vw_AtAGlance



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| CSRepId | int | No |  |
| CSRepName | varchar(30) | No |  |
| DistrictId | int | No |  |
| DistrictName | varchar(50) | No |  |
| BudgetId | int | No |  |
| BudgetName | varchar(30) | No |  |
| Schedule | varchar(50) | No |  |
| ReqCount | int | No |  |
| ProcessedReqCount | int | No |  |
| ReqPOCount | int | No |  |
| DownloadedCount | int | No |  |
| ManualPOCount | int | No |  |
| POCount | int | No |  |
| ReadyToBidCount | int | No |  |
| OutToBidCount | int | No |  |
| NeedingToBeBidCount | int | No |  |
| BAApprovals | int | No |  |
| ReqsOverBudget | int | No |  |
| ExcessiveReqs | int | No |  |



### dbo.vw_AvailableReqBids



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| BidHeaderId | int | Yes |  |
| HeaderText | varchar(305) | Yes |  |



### dbo.vw_AvailableUserAccounts



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| UserId | int | No |  |
| BudgetId | int | No |  |
| BudgetAccountId | int | No |  |
| UseAllocations | tinyint | Yes |  |
| BudgetAmount | money | Yes |  |
| AmountAvailable | money | Yes |  |
| AccountId | int | No |  |
| Code | varchar(50) | Yes |  |



### dbo.vw_AVBidsVendorsCategoriesBySession



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | No |  |
| CategoryId | int | No |  |
| CategoryName | varchar(50) | Yes |  |
| CategoryType | int | Yes |  |
| VendorId | int | No |  |
| VendorName | varchar(50) | Yes |  |
| VendorCode | varchar(16) | Yes |  |
| BidHeaderId | int | Yes |  |
| BidAdvertised | datetime | Yes |  |
| BidAwardDate | datetime | Yes |  |
| EffectiveFrom | datetime | Yes |  |
| EffectiveUntil | datetime | Yes |  |
| BidType | tinyint | No |  |
| VendorBidNumber | varchar(50) | Yes |  |
| Comments | varchar(1538) | Yes |  |
| Address1 | varchar(50) | Yes |  |
| Address2 | varchar(50) | Yes |  |
| City | varchar(50) | Yes |  |
| State | char(2) | Yes |  |
| Zipcode | varchar(10) | Yes |  |
| VendorContactFullName | varchar(150) | Yes |  |
| VendorContactEMail | varchar(255) | Yes |  |
| VendorContactPhone | varchar(25) | Yes |  |
| VendorContactFax | varchar(20) | Yes |  |
| CatalogId | int | Yes |  |
| BidYears | varchar(11) | Yes |  |
| BidMessage | varchar(1024) | Yes |  |



### dbo.vw_AVCategoriesBySession



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | No |  |
| CategoryId | int | No |  |
| CategoryName | varchar(50) | Yes |  |



### dbo.vw_AVVendorsBySession



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | No |  |
| VendorId | int | No |  |
| VendorName | varchar(50) | Yes |  |
| VendorCode | varchar(16) | Yes |  |



### dbo.vw_AVVendorsExport



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BudgetId | int | No |  |
| VendorId | int | No |  |
| VendorName | varchar(50) | No |  |
| ContactInfo | varchar(548) | Yes |  |
| CategoryId | int | No |  |
| CategoryName | varchar(308) | Yes |  |
| BidHeaderId | int | Yes |  |
| VendorBidNumber | varchar(50) | No |  |
| AdditionalHandlingAmount | money | No |  |
| FreeHandlingAmount | money | No |  |
| BidComments | varchar(512) | No |  |
| EMail | varchar(255) | No |  |
| VendorCode | varchar(16) | No |  |
| DistrictVendorCode | varchar(20) | No |  |
| VendorsAccountCode | varchar(50) | No |  |



### dbo.vw_AwardedBidResults



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| Item Code | varchar(50) | Yes |  |
| Vendor Item Code | varchar(50) | No |  |
| Bid Price | decimal(33,13) | Yes |  |
| Qty | int | Yes |  |
| Description | varchar(1156) | Yes |  |
| UOM | varchar(20) | No |  |
| Items Per Unit | varchar(50) | No |  |
| Item Bid Type | varchar(32) | No |  |
| Alternate | varchar(512) | No |  |
| Manufacturer | varchar(50) | No |  |
| Manufacturer Part Number | varchar(50) | No |  |
| UPC / EAN / ISBN | varchar(20) | No |  |
| SDS URL | varchar(300) | No |  |
| Image URL | varchar(300) | No |  |
| Awarded Vendor Name | varchar(50) | No |  |
| Vendor Code | varchar(16) | No |  |
| UniqueId Do Not Modify | int | No |  |
| BidHeaderId | int | Yes |  |
| VendorId | int | Yes |  |
| SortSeq | varchar(64) | No |  |
| UNSPSC | varchar(50) | No |  |
| UniqueItemNumber | varchar(50) | No |  |
| PerishableItem | bit | No |  |
| PrescriptionRequired | bit | No |  |
| DigitallyDelivered | tinyint | No |  |
| MinimumOrderQuantity | int | No |  |



### dbo.vw_AwardedVendorsAllCurrentAndFutureBids



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VendorId | int | No |  |
| BidImportId | int | No |  |
| VendorName | varchar(50) | No |  |
| ContactInfo | varchar(548) | Yes |  |
| CategoryId | int | No |  |
| CategoryName | varchar(308) | Yes |  |
| BidHeaderId | int | Yes |  |
| VendorBidNumber | varchar(50) | No |  |
| AdditionalHandlingAmount | money | No |  |
| FreeHandlingAmount | money | No |  |
| BidComments | varchar(512) | No |  |
| EMail | varchar(255) | No |  |
| VendorCode | varchar(16) | No |  |
| EffectiveFrom | datetime | Yes |  |
| EffectiveUntil | datetime | Yes |  |
| BidStateId | int | Yes |  |
| PricePlanId | int | Yes |  |
| CategoryType | int | Yes |  |



### dbo.vw_AwardedVendorsAllCurrentBids



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VendorId | int | No |  |
| BidImportId | int | No |  |
| VendorName | varchar(50) | No |  |
| ContactInfo | varchar(548) | Yes |  |
| CategoryId | int | No |  |
| CategoryName | varchar(308) | Yes |  |
| BidHeaderId | int | Yes |  |
| VendorBidNumber | varchar(50) | No |  |
| AdditionalHandlingAmount | money | No |  |
| FreeHandlingAmount | money | No |  |
| BidComments | varchar(512) | No |  |
| EMail | varchar(255) | No |  |
| VendorCode | varchar(16) | No |  |
| EffectiveFrom | datetime | Yes |  |
| EffectiveUntil | datetime | Yes |  |
| BidStateId | int | Yes |  |
| PricePlanId | int | Yes |  |
| CategoryType | int | Yes |  |



### dbo.vw_BAPCBG



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RepName | varchar(30) | Yes |  |
| RepEmail | varchar(128) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| FullName | varchar(195) | Yes |  |
| Email | varchar(255) | No |  |
| FullAddress | varchar(170) | Yes |  |



### dbo.vw_BidAnalysisDetail



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| CategoryName | varchar(50) | Yes |  |
| PricePlanName | varchar(278) | No |  |
| BidHeaderId | int | Yes |  |
| BidRequestItemId | int | No |  |
| DistrictId | int | Yes |  |
| DistrictName | varchar(50) | No |  |
| ItemCode | varchar(50) | Yes |  |
| Description | varchar(1024) | Yes |  |
| UnitCode | varchar(20) | Yes |  |
| VendorName | varchar(50) | No |  |
| VendorCode | varchar(16) | No |  |
| BidUnits | varchar(16) | Yes |  |
| BidRequest | int | Yes |  |
| BidType | varchar(13) | Yes |  |
| QuantityBid | int | Yes |  |
| UnitPrice | decimal(34,13) | Yes |  |
| ExtendedCost | decimal(38,6) | Yes |  |
| Alternate | varchar(MAX) | Yes |  |
| VendorItemCode | varchar(50) | No |  |
| BidRequestStatus | varchar(50) | No |  |
| Status | varchar(51) | No |  |
| ResultsStatus | int | No |  |
| BidResultsId | int | Yes |  |
| Comments | varchar(1024) | No |  |
| ItemComments | varchar(1024) | No |  |
| PriceVarianceLevel | decimal(9,5) | Yes |  |
| FirstPrice | decimal(34,13) | Yes |  |
| FirstPriceBidResultsId | int | Yes |  |
| SecondPrice | decimal(34,13) | Yes |  |
| SecondPriceBidResultsId | int | Yes |  |
| Compliant1st | int | Yes |  |
| SortKey | varchar(124) | Yes |  |
| Variance | decimal(38,6) | Yes |  |
| ItemStatus | varchar(MAX) | Yes |  |
| PageNo | int | Yes |  |
| BidResultsItemsPerUnit | varchar(50) | Yes |  |
| ItemsItemsPerUnit | varchar(50) | Yes |  |



### dbo.vw_BidAnalysisVendorSummary



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| BidImportId | int | No |  |
| ItemsBid | int | Yes |  |
| AmountBid | money | Yes |  |
| VendorsCode | varchar(16) | Yes |  |
| VendorsName | varchar(50) | Yes |  |
| CalculatedAmount | money | Yes |  |
| ItemsWon | int | Yes |  |
| POCount | int | No |  |
| POTotal | money | No |  |
| AvgPO | money | No |  |



### dbo.vw_BidAnalysisVendorSummaryByDistrict



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| BidImportId | int | No |  |
| ItemsBid | int | Yes |  |
| AmountBid | money | Yes |  |
| VendorsCode | varchar(16) | Yes |  |
| VendorsName | varchar(50) | Yes |  |
| CalculatedAmount | money | Yes |  |
| ItemsWon | int | No |  |
| POCount | int | No |  |
| POTotal | money | No |  |
| AvgPO | money | No |  |
| DistrictId | int | Yes |  |



### dbo.vw_BidAnalysisVendorSummaryTest



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| BidImportId | int | No |  |
| ItemsBid | int | Yes |  |
| AmountBid | money | Yes |  |
| VendorsCode | varchar(16) | Yes |  |
| VendorsName | varchar(50) | Yes |  |
| CalculatedAmount | money | Yes |  |
| ItemsWon | int | Yes |  |
| POCount | int | No |  |
| POTotal | money | No |  |
| AvgPO | money | No |  |



### dbo.vw_BidAncillaryBySession



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | No |  |
| CategoryName | varchar(1077) | Yes |  |
| BidDate | datetime | Yes |  |
| BidAwardDate | datetime | Yes |  |
| EffectiveFrom | datetime | Yes |  |
| EffectiveUntil | datetime | Yes |  |
| BidHeaderId | int | Yes |  |



### dbo.vw_BidAnswers



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidAnswerId | int | No |  |
| BidImportId | int | No |  |
| BidQuestionId | int | No |  |
| CountyId | int | No |  |
| BidTradeId | int | No |  |
| VendorBidTMAnswerId | int | Yes |  |
| BidAnswerJournalId | int | Yes |  |
| SessionId | int | Yes |  |
| DateModified | datetime | Yes |  |
| Sequence | int | Yes |  |
| BidAnswer | varchar(512) | Yes |  |
| BidAnswerExtended | varchar(512) | Yes |  |
| VendorBidTMAnswerJournalId | int | Yes |  |
| BidEntryDisplayLabel | varchar(255) | Yes |  |
| QuestionText | varchar(MAX) | No |  |
| QuestionQty | int | Yes |  |
| AnswerTypeId | int | Yes |  |
| AnswerTypeMask | varchar(50) | Yes |  |
| ExtdCalcMask | varchar(50) | Yes |  |
| UOM | varchar(50) | No |  |
| BidSection | varchar(255) | Yes |  |
| Weight | decimal(9,5) | Yes |  |
| ExtdCalcTypeId | int | Yes |  |



### dbo.vw_BidComplianceBySession



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | No |  |
| Description | varchar(255) | Yes |  |
| TradeTitle | varchar(255) | No |  |
| PackageNumber | int | Yes |  |
| BidTradeCountyId | int | No |  |
| BidDate | datetime | Yes |  |
| BidAwardDate | datetime | Yes |  |
| EffectiveFrom | datetime | Yes |  |
| EffectiveUntil | datetime | Yes |  |
| BidHeaderId | int | Yes |  |
| CategoryName | varchar(50) | Yes |  |



### dbo.vw_BidContactsVendorList



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| VendorId | int | No |  |
| VendorCode | varchar(16) | Yes |  |
| VendorName | varchar(50) | No |  |
| FullName | varchar(143) | Yes |  |
| ContactFullAddress | varchar(170) | Yes |  |
| ContactAddress1 | varchar(50) | No |  |
| ContactAddress2 | varchar(50) | No |  |
| ContactCity | varchar(50) | No |  |
| ContactState | char(2) | No |  |
| ContactZipcode | varchar(10) | No |  |
| CategoryName | varchar(50) | Yes |  |
| Description | varchar(278) | No |  |
| DistrictName | varchar(57) | No |  |



### dbo.vw_BidDescriptions



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| ItemId | int | Yes |  |
| BidRequestItemId | int | No |  |
| ItemDescription | varchar(1024) | Yes |  |
| ExtraDescription | varchar(1024) | No |  |



### dbo.vw_BidDocumentsList



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| Name | varchar(50) | No |  |



### dbo.vw_BidDocumentTypeNames



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DocumentName | varchar(50) | No |  |
| MinBidDocumentTypeId | int | Yes |  |



### dbo.vw_BidDuplicateIdentifiers



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| CategoryId | int | Yes |  |
| ItemId | int | Yes |  |
| VendorId | int | Yes |  |
| VendorItemCode | varchar(50) | Yes |  |
| ManufacturerBid | varchar(50) | Yes |  |
| ManufPartNoBid | varchar(50) | Yes |  |
| BidHeaderId | int | Yes |  |
| PageNo | int | Yes |  |
| BidResultsId | int | No |  |



### dbo.vw_BidGrouper



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| MainBidHeaderId | int | Yes |  |
| AltBidHeaderId | int | Yes |  |
| BidType | tinyint | Yes |  |



### dbo.vw_BidHeadersList



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| Active | tinyint | No |  |
| AllowTotalAward | tinyint | No |  |
| AlertLink | varchar(255) | No |  |
| AlertMsg | varchar(4096) | No |  |
| AwardMsg | varchar(1024) | No |  |
| BidAwardDate | datetime | Yes |  |
| BidDate | datetime | Yes |  |
| BidMessage | varchar(1024) | No |  |
| BidType | tinyint | No |  |
| BudgetYearOption | tinyint | No |  |
| CalendarId | int | No |  |
| CategoryId | int | No |  |
| DateCreated | datetime | Yes |  |
| Description | varchar(512) | No |  |
| DistrictId | int | No |  |
| EffectiveFrom | datetime | Yes |  |
| EffectiveUntil | datetime | Yes |  |
| HostDistrictId | int | No |  |
| ParentBidHeaderId | int | No |  |
| PricePlanId | int | No |  |
| ScheduledReaward | datetime | Yes |  |
| StateId | int | No |  |
| TotalAwardMinimumDiscount | decimal(9,5) | No |  |
| SectionName | int | No |  |
| MarkAsOriginal | int | No |  |
| PriceVarianceLevel | decimal(9,5) | No |  |
| CategoryName | varchar(50) | No |  |
| PricePlanDescription | varchar(255) | No |  |
| StateName | varchar(50) | No |  |



### dbo.vw_BidImportMostRecentContactInfo



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidImportId | int | No |  |
| UseVendorContactInfo | tinyint | Yes |  |
| VendorId | int | Yes |  |
| CategoryId | int | Yes |  |
| ContactEmail | varchar(255) | Yes |  |
| ContactName | varchar(50) | Yes |  |
| ContactPhone | varchar(20) | Yes |  |
| ContactFax | varchar(20) | Yes |  |



### dbo.vw_BidItemDescription



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| ItemId | int | No |  |
| BidHeaderId | int | Yes |  |
| ItemDescription | varchar(4740) | Yes |  |



### dbo.vw_BidItemLongDescription



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| ItemId | int | No |  |
| BidHeaderId | int | Yes |  |
| ItemDescription | varchar(6035) | Yes |  |



### dbo.vw_BidLeadComplianceBySession



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | No |  |
| Description | varchar(255) | Yes |  |
| TradeTitle | varchar(255) | No |  |
| PackageNumber | int | Yes |  |
| BidTradeCountyId | int | No |  |
| BidDate | datetime | Yes |  |
| BidAwardDate | datetime | Yes |  |
| EffectiveFrom | datetime | Yes |  |
| EffectiveUntil | datetime | Yes |  |
| BidHeaderId | int | Yes |  |
| CategoryName | varchar(50) | Yes |  |



### dbo.vw_BidLines



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| BidImportId | int | No |  |
| VendorId | int | Yes |  |
| ItemCode | varchar(50) | Yes |  |
| Description | varchar(512) | Yes |  |
| Title | varchar(255) | Yes |  |
| Keyword | varchar(50) | Yes |  |
| UnitPrice | decimal(11,2) | Yes |  |
| UOM | varchar(20) | Yes |  |
| VendorItemCode | varchar(50) | Yes |  |
| Alternate | varchar(512) | Yes |  |
| HeadingId | int | No |  |
| KeywordId | int | No |  |



### dbo.vw_BidManufacturerPartNumbers



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| CategoryId | int | Yes |  |
| ItemId | int | Yes |  |
| VendorId | int | Yes |  |
| VendorItemCode | varchar(50) | Yes |  |
| ManufacturerBid | varchar(50) | Yes |  |
| ManufPartNoBid | varchar(50) | Yes |  |
| BidHeaderId | int | Yes |  |
| PageNo | int | Yes |  |
| BidResultsId | int | No |  |



### dbo.vw_BidMgrBidderDocs



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| BidImportId | int | No |  |
| VendorId | int | Yes |  |
| VendorBidNumber | varchar(50) | Yes |  |
| BidHeaderCheckListId | int | No |  |
| BidderCheckListId | int | Yes |  |
| DocumentUploadId | int | Yes |  |
| VendorCode | varchar(16) | Yes |  |
| VendorName | varchar(50) | Yes |  |
| DisplaySequence | int | Yes |  |
| DocumentName | varchar(50) | Yes |  |
| CheckListText | varchar(100) | Yes |  |
| UploadEligible | tinyint | No |  |
| UploadEligibleStr | varchar(3) | No |  |
| VendorUploadDateTime | datetime2 | Yes |  |
| DocumentNumber | varchar(255) | Yes |  |
| DocumentExpiration | datetime | Yes |  |
| DocStatus | char(1) | No |  |
| StatusStr | varchar(9) | No |  |
| DocRejectReasonComments | varchar(1024) | No |  |
| InDMS | int | No |  |
| InDmsStr | varchar(12) | No |  |
| DocumentTypeId | int | Yes |  |
| ExpirationDateReqd | tinyint | No |  |
| DocNumberReqd | tinyint | No |  |
| DocNumberLabel | varchar(50) | Yes |  |
| OptionalDocument | tinyint | Yes |  |
| DMSCountOfDocType | int | Yes |  |
| BidDocsCountOfDocType | int | Yes |  |



### dbo.vw_BidMSRPManufacturerProductLinePrices



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidMSRPResultsId | int | No |  |
| BidMSRPResultsProductLineId | int | Yes |  |
| ManufacturerProductLineId | int | Yes |  |
| MSRPOptionId | int | Yes |  |
| OptionName | varchar(50) | No |  |
| TotalAwardDiscount | decimal(9,5) | Yes |  |
| TotalAward | tinyint | Yes |  |
| WeightedDiscount | decimal(9,5) | Yes |  |



### dbo.vw_BidMSRPRankedManufacturerProductLines



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| ManufacturerId | int | Yes |  |
| ManufacturerName | varchar(100) | No |  |
| ManufacturerProductLineId | int | No |  |
| ProductLineName | varchar(100) | No |  |
| MSRPOptionId | int | No |  |
| OptionName | varchar(50) | No |  |



### dbo.vw_BidMSRPRankedManufacturerProductLinesOrdered



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| ManufacturerId | int | Yes |  |
| ManufacturerName | varchar(100) | No |  |
| ManufacturerProductLineId | int | No |  |
| ProductLineName | varchar(100) | No |  |
| MSRPOptionId | int | No |  |
| OptionName | varchar(50) | No |  |
| BidMSRPResultsId | int | Yes |  |
| BidMSRPResultsProductLineId | int | Yes |  |
| WriteInManufacturer | varchar(100) | Yes |  |
| WriteInFlag | tinyint | Yes |  |
| WinningBidOverride | tinyint | Yes |  |
| DiscountRate | decimal(38,6) | Yes |  |
| PriceListTypeId | int | Yes |  |
| TotalAward | tinyint | Yes |  |
| TotalAwardDiscount | decimal(9,5) | Yes |  |
| ProductLineWeight | decimal(9,5) | Yes |  |
| TotalAwardManufacturerWeight | decimal(38,6) | Yes |  |
| TotalAwardProductLineWeight | decimal(38,6) | Yes |  |
| SortKey | varchar(15) | Yes |  |
| PriceListType | varchar(50) | Yes |  |
| VendorId | int | Yes |  |
| VendorName | varchar(50) | Yes |  |
| PriceListWarning | varchar(28) | No |  |
| AllFlag | int | No |  |
| AllActive | int | No |  |
| EntryFiltered | int | No |  |



### dbo.vw_BidMSRPRankedManufacturerProductLinesOrderedNew



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| ManufacturerId | int | Yes |  |
| ManufacturerName | varchar(100) | No |  |
| ManufacturerProductLineId | int | No |  |
| ProductLineName | varchar(100) | No |  |
| MSRPOptionId | int | No |  |
| OptionName | varchar(50) | No |  |
| BidMSRPResultsId | int | Yes |  |
| BidMSRPResultsProductLineId | int | Yes |  |
| WriteInManufacturer | varchar(100) | Yes |  |
| WriteInFlag | tinyint | Yes |  |
| WinningBidOverride | tinyint | Yes |  |
| DiscountRate | decimal(38,6) | Yes |  |
| PriceListTypeId | int | Yes |  |
| TotalAward | tinyint | Yes |  |
| TotalAwardDiscount | decimal(9,5) | Yes |  |
| ProductLineWeight | decimal(9,5) | Yes |  |
| TotalAwardManufacturerWeight | decimal(38,6) | Yes |  |
| TotalAwardProductLineWeight | decimal(38,6) | Yes |  |
| SortKey | varchar(20) | Yes |  |
| PriceListType | varchar(50) | Yes |  |
| VendorId | int | Yes |  |
| VendorName | varchar(50) | Yes |  |
| PriceListWarning | varchar(28) | No |  |
| AllFlag | int | No |  |
| AllActive | int | No |  |
| EntryFiltered | int | No |  |
| ManufacturerAverageWeightedDiscount | decimal(38,6) | Yes |  |
| ProductLineAverageWeightedDiscount | decimal(38,6) | Yes |  |
| OptionAverageWeightedDiscount | decimal(38,6) | Yes |  |
| MRRSortKey | varchar(3) | Yes |  |
| MRTBSortKey | varchar(2) | Yes |  |



### dbo.vw_BidMSRPRankedManufacturerProductLinesOrderedSaved



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| ManufacturerId | int | Yes |  |
| ManufacturerName | varchar(100) | No |  |
| ManufacturerProductLineId | int | No |  |
| ProductLineName | varchar(100) | No |  |
| MSRPOptionId | int | No |  |
| OptionName | varchar(50) | No |  |
| BidMSRPResultsId | int | Yes |  |
| BidMSRPResultsProductLineId | int | Yes |  |
| WriteInManufacturer | varchar(100) | Yes |  |
| WriteInFlag | tinyint | Yes |  |
| WinningBidOverride | tinyint | Yes |  |
| DiscountRate | decimal(10,5) | No |  |
| PriceListTypeId | int | Yes |  |
| TotalAward | tinyint | Yes |  |
| TotalAwardDiscount | decimal(9,5) | Yes |  |
| ProductLineWeight | decimal(9,5) | Yes |  |
| TotalAwardManufacturerWeight | decimal(38,6) | Yes |  |
| TotalAwardProductLineWeight | decimal(38,6) | Yes |  |
| SortKey | varchar(14) | Yes |  |
| PriceListType | varchar(50) | Yes |  |
| VendorId | int | Yes |  |
| VendorName | varchar(50) | Yes |  |
| PriceListWarning | varchar(28) | No |  |
| AllFlag | int | No |  |
| AllActive | int | No |  |



### dbo.vw_BidMSRPRankedManufacturers



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| ManufacturerId | int | Yes |  |
| ManufacturerName | varchar(100) | No |  |



### dbo.vw_BidMSRPResultsPriceRanges



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | No |  |
| BidImportId | int | No |  |
| BidMSRPResultsId | int | No |  |
| BidMSRPResultsProductLineId | int | Yes |  |
| ManufacturerProductLineId | int | Yes |  |
| MSRPOptionId | int | Yes |  |
| OptionName | varchar(50) | Yes |  |
| TotalAwardDiscount | decimal(9,5) | Yes |  |
| TotalAward | tinyint | Yes |  |
| BidMSRPResultPricesId | int | Yes |  |
| ManufacturerId | int | Yes |  |
| RangeValue | decimal(9,5) | Yes |  |
| RangeBase | money | Yes |  |
| RangeWeight | decimal(9,5) | Yes |  |



### dbo.vw_BidMSRPResultsPrices



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | No |  |
| BidImportId | int | No |  |
| BidMSRPResultsId | int | No |  |
| BidMSRPResultsProductLineId | int | Yes |  |
| ManufacturerProductLineId | int | Yes |  |
| ProductLineName | varchar(100) | Yes |  |
| MSRPOptionId | int | Yes |  |
| OptionName | varchar(50) | Yes |  |
| TotalAwardDiscount | decimal(9,5) | Yes |  |
| TotalAward | tinyint | Yes |  |
| ManufacturerId | int | Yes |  |
| WeightedDiscount | decimal(9,5) | Yes |  |
| TotalWeights | decimal(38,5) | Yes |  |



### dbo.vw_BidPricing



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| ItemId | int | No |  |
| ItemCode | varchar(50) | Yes |  |
| ItemDescription | varchar(1156) | Yes |  |
| UOM | varchar(20) | Yes |  |
| VendorItemCode | varchar(50) | No |  |
| ItemBidType | varchar(32) | No |  |
| Alternate | varchar(512) | No |  |
| PageNo | int | No |  |
| NetPrice | decimal(33,13) | No |  |
| SortSeq | varchar(64) | Yes |  |
| VendorName | varchar(50) | Yes |  |



### dbo.vw_BidProductLinePrices



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidProductLineId | int | No |  |
| RangeBase | money | Yes |  |
| RangeTop | numeric(20,4) | Yes |  |
| DiscountRate | decimal(9,5) | Yes |  |



### dbo.vw_BidProjectAveragePO



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| VendorId | int | No |  |
| VendorCode | varchar(16) | Yes |  |
| VendorName | varchar(50) | Yes |  |
| VendorInfo | varchar(376) | Yes |  |
| Items | int | No |  |
| Total | money | No |  |
| POCount | int | No |  |
| TotalQuantity | int | No |  |
| AvgPO | money | No |  |



### dbo.vw_BidRequestItemMergeDetail



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| ItemCode | varchar(50) | Yes |  |
| ItemDesc | varchar(512) | Yes |  |
| BidRequestItemId | int | No |  |
| ItemId | int | Yes |  |
| BidRequest | int | Yes |  |
| Active | tinyint | Yes |  |
| RequisitionCount | int | Yes |  |
| BidRequestAmount | money | Yes |  |
| Checksum | int | Yes |  |
| UnitCode | varchar(20) | Yes |  |
| SortSeq | varchar(64) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| Heading | varchar(308) | Yes |  |



### dbo.vw_BidRequestItemMergeHeader



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| ItemCode | varchar(50) | Yes |  |
| ItemDesc | varchar(512) | Yes |  |
| BidRequestItemId | int | No |  |
| ItemId | int | Yes |  |
| BidRequest | int | Yes |  |
| Active | tinyint | Yes |  |
| RequisitionCount | int | Yes |  |
| BidRequestAmount | money | Yes |  |
| Checksum | int | Yes |  |
| ExcludeFlag | int | No |  |
| MergedFlag | int | No |  |
| MasterItemFlag | int | No |  |
| MasterItemCode | varchar(50) | No |  |
| UnitCode | varchar(20) | Yes |  |



### dbo.vw_BidRequestItemsBidMgr



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidRequestItemId | int | No |  |
| BidHeaderId | int | Yes |  |
| ItemId | int | Yes |  |
| BidRequest | int | Yes |  |
| Active | tinyint | Yes |  |
| RequisitionCount | int | Yes |  |
| Status | varchar(50) | No |  |
| Comments | varchar(1024) | No |  |
| CrossReferencesText | varchar(1024) | No |  |
| ItemCode | varchar(50) | Yes |  |
| SortSeq | varchar(64) | Yes |  |
| Description | varchar(512) | Yes |  |
| UnitId | int | No |  |
| Code | varchar(20) | Yes |  |
| BIDMGRTAGFILEID | int | No |  |
| TAGUSR | int | Yes |  |
| TAGTBL | int | Yes |  |
| TAGPTR | int | Yes |  |
| TAGVAL | char(10) | Yes |  |
| WEIGHT | real | Yes |  |



### dbo.vw_BidResults



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| BidId | int | No |  |
| ItemId | int | Yes |  |
| UnitPrice | money | Yes |  |
| Alternate | varchar(512) | Yes |  |
| QuantityBid | int | Yes |  |
| BidRequest | int | Yes |  |
| AwardId | int | No |  |
| VendorItemCode | varchar(50) | Yes |  |
| CrossRefId | int | Yes |  |
| ItemBidType | varchar(13) | No |  |
| PackedItemCode | varchar(50) | Yes |  |
| PackedVendorItemCode | varchar(50) | Yes |  |
| PageNo | int | Yes |  |
| ContractNumber | varchar(50) | Yes |  |
| DateModified | datetime | No |  |
| BidResultsId | int | Yes |  |
| VendorId | int | Yes |  |



### dbo.vw_BidTabReadyNotifications



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictNotificationId | int | Yes |  |
| DistrictId | int | No |  |
| DistrictName | varchar(50) | Yes |  |
| CategoryId | int | No |  |
| CategoryName | varchar(50) | Yes |  |
| NotifyUser | int | Yes |  |
| NotifyApprover | int | Yes |  |
| NotifyBA | int | Yes |  |
| NotifyPrimary | int | Yes |  |
| NotifyAD | int | Yes |  |
| NotifyBG | int | Yes |  |
| OtherNotify | varchar(4096) | Yes |  |



### dbo.vw_BidTrades



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| StateCode | char(2) | Yes |  |
| StateName | varchar(50) | Yes |  |
| CountyName | varchar(50) | No |  |
| TradeName | varchar(255) | Yes |  |
| BidTradeCountyId | int | No |  |
| BidDate | datetime | Yes |  |
| BidAwardDate | datetime | Yes |  |
| EffectiveFrom | datetime | Yes |  |
| EffectiveUntil | datetime | Yes |  |
| BidHeaderId | int | Yes |  |



### dbo.vw_BidTradesBySession



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | No |  |
| Description | varchar(255) | Yes |  |
| TradeTitle | varchar(255) | No |  |
| PackageNumber | int | No |  |
| BidTradeCountyId | int | No |  |
| BidDate | datetime | Yes |  |
| BidAwardDate | datetime | Yes |  |
| EffectiveFrom | datetime | Yes |  |
| EffectiveUntil | datetime | Yes |  |
| BidHeaderId | int | Yes |  |



### dbo.vw_BidTradesBySession_Test



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | No |  |
| Description | varchar(255) | Yes |  |
| TradeTitle | varchar(255) | No |  |
| PackageNumber | int | No |  |
| BidTradeCountyId | int | No |  |
| BidDate | datetime | Yes |  |
| BidAwardDate | datetime | Yes |  |
| EffectiveFrom | datetime | Yes |  |
| EffectiveUntil | datetime | Yes |  |
| BidHeaderId | int | Yes |  |



### dbo.vw_BidTradesVendorDetailForReports



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidTradeCountyId | int | No |  |
| BidImportId | int | Yes |  |
| BidHeaderId | int | Yes |  |
| BidCounty | varchar(50) | No |  |
| BidState | varchar(50) | Yes |  |
| TradeName | varchar(255) | No |  |
| AwardType | varchar(50) | Yes |  |
| BidDate | datetime | Yes |  |
| BidAwardDate | datetime | Yes |  |
| VendorCode | varchar(16) | No |  |
| VendorName | varchar(50) | No |  |
| ContactName | varchar(150) | No |  |
| ContactPhone | varchar(25) | No |  |
| ContactFax | varchar(20) | No |  |
| ContactEmail | varchar(255) | No |  |
| Address1 | varchar(50) | No |  |
| Address2 | varchar(50) | No |  |
| City | varchar(50) | No |  |
| State | char(2) | No |  |
| Zipcode | varchar(10) | No |  |
| HostName | varchar(50) | Yes |  |
| HostNameAndAddress | varchar(222) | Yes |  |
| BidEntryDisplayLabel | varchar(255) | Yes |  |
| BidAnswer | varchar(4096) | Yes |  |
| UOM | varchar(51) | No |  |
| Sequence | int | Yes |  |



### dbo.vw_BidTradesVendors



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidTradeCountyId | int | No |  |
| BidImportId | int | Yes |  |
| BidHeaderId | int | Yes |  |
| VendorId | int | No |  |
| BidCounty | varchar(50) | No |  |
| BidState | varchar(50) | Yes |  |
| TradeName | varchar(255) | Yes |  |
| VendorCode | varchar(16) | No |  |
| VendorName | varchar(50) | No |  |
| ContactName | varchar(150) | No |  |
| ContactPhone | varchar(25) | No |  |
| ContactFax | varchar(20) | No |  |
| ContactEmail | varchar(255) | No |  |
| Address1 | varchar(50) | No |  |
| Address2 | varchar(50) | No |  |
| City | varchar(50) | No |  |
| State | char(2) | No |  |
| Zipcode | varchar(10) | No |  |
| AwardAmount | numeric(19,4) | No |  |



### dbo.vw_BidTradesVendorsAnswers



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidImportId | int | No |  |
| BidTradeCountyId | int | No |  |
| Sequence | int | Yes |  |
| BidEntryDisplayLabel | varchar(255) | Yes |  |
| BidAnswer | varchar(4148) | Yes |  |



### dbo.vw_BidTradesVendorsAnswersBySession



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidImportId | int | No |  |
| BidTradeCountyId | int | No |  |
| Sequence | int | Yes |  |
| QuestionText | varchar(MAX) | No |  |
| BidAnswer | varchar(512) | Yes |  |



### dbo.vw_BidTradesVendorsBySession



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | No |  |
| BidTradeCountyId | int | No |  |
| BidImportId | int | Yes |  |
| VendorBidComments | varchar(1024) | No |  |
| VendorCountyBidComments | varchar(4096) | No |  |
| BidHeaderId | int | Yes |  |
| BidCounty | varchar(50) | No |  |
| BidState | varchar(50) | Yes |  |
| AwardType | varchar(50) | Yes |  |
| VendorCode | varchar(16) | No |  |
| VendorName | varchar(50) | No |  |
| ContactName | varchar(150) | No |  |
| ContactPhone | varchar(25) | No |  |
| ContactFax | varchar(20) | No |  |
| ContactEmail | varchar(255) | No |  |
| Address1 | varchar(50) | No |  |
| Address2 | varchar(50) | No |  |
| City | varchar(50) | No |  |
| State | char(2) | No |  |
| Zipcode | varchar(10) | No |  |



### dbo.vw_BidTradesVendorsForReports



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidTradeCountyId | int | No |  |
| BidImportId | int | Yes |  |
| BidHeaderId | int | Yes |  |
| BidCounty | varchar(50) | No |  |
| BidState | varchar(50) | Yes |  |
| TradeName | varchar(255) | No |  |
| PackageNumber | int | Yes |  |
| TradeDescription | varchar(255) | Yes |  |
| AwardType | varchar(50) | Yes |  |
| BidDate | datetime | Yes |  |
| BidAwardDate | datetime | Yes |  |
| EffectiveFrom | datetime | Yes |  |
| EffectiveUntil | datetime | Yes |  |
| VendorCode | varchar(16) | No |  |
| VendorName | varchar(50) | No |  |
| ContactName | varchar(150) | No |  |
| ContactPhone | varchar(25) | No |  |
| ContactFax | varchar(20) | No |  |
| ContactEmail | varchar(255) | No |  |
| Address1 | varchar(50) | No |  |
| Address2 | varchar(50) | No |  |
| City | varchar(50) | No |  |
| State | char(2) | No |  |
| Zipcode | varchar(10) | No |  |
| VendorContactInfo | varchar(5824) | Yes |  |
| HostName | varchar(50) | Yes |  |
| HostNameAndAddress | varchar(222) | Yes |  |
| CategoryType | int | Yes |  |
| CategoryName | varchar(1074) | Yes |  |
| Grouping | varchar(50) | No |  |



### dbo.vw_BidType



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| CategoryType | int | Yes |  |
| Grouping | varchar(50) | Yes |  |
| TradeCount | int | Yes |  |
| ItemCount | int | Yes |  |



### dbo.vw_BidUPCs



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| CategoryId | int | Yes |  |
| ItemId | int | Yes |  |
| VendorId | int | Yes |  |
| VendorItemCode | varchar(50) | Yes |  |
| BidHeaderId | int | Yes |  |
| PageNo | int | Yes |  |
| BidResultsId | int | No |  |
| UPC_ISBN | varchar(20) | Yes |  |



### dbo.vw_BidVendor



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| CategoryId | int | Yes |  |
| VendorId | int | Yes |  |
| Description | varchar(512) | Yes |  |
| BidMessage | varchar(1024) | Yes |  |
| EffectiveFrom | datetime | Yes |  |
| EffectiveUntil | datetime | Yes |  |



### dbo.vw_BidVendorItemCodes



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| CategoryId | int | Yes |  |
| ItemId | int | Yes |  |
| VendorId | int | Yes |  |
| VendorItemCode | varchar(50) | Yes |  |
| ManufacturerBid | varchar(50) | Yes |  |
| ManufPartNoBid | varchar(50) | Yes |  |
| BidHeaderId | int | Yes |  |
| PageNo | int | Yes |  |
| BidResultsId | int | No |  |



### dbo.vw_BidVendorList



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| VendorId | int | Yes |  |
| VendorCode | varchar(16) | Yes |  |
| VendorName | varchar(MAX) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| CategoryId | int | No |  |
| Description | varchar(278) | No |  |
| DistrictName | varchar(57) | No |  |



### dbo.vw_BidVendorsBySession



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | No |  |
| BidImportId | int | Yes |  |
| VendorBidComments | varchar(1541) | No |  |
| VendorCountyBidComments | varchar(1) | No |  |
| BidHeaderId | int | Yes |  |
| BidCounty | varchar(50) | No |  |
| BidState | varchar(50) | Yes |  |
| AwardType | varchar(15) | No |  |
| VendorCode | varchar(16) | No |  |
| VendorName | varchar(50) | No |  |
| ContactName | varchar(150) | No |  |
| ContactPhone | varchar(25) | No |  |
| ContactFax | varchar(20) | No |  |
| ContactEmail | varchar(255) | No |  |
| Address1 | varchar(50) | No |  |
| Address2 | varchar(50) | No |  |
| City | varchar(50) | No |  |
| State | char(2) | No |  |
| Zipcode | varchar(10) | No |  |



### dbo.vw_BidVendorsSinceLastYear



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| VendorId | int | No |  |
| CategoryId | int | Yes |  |



### dbo.vw_BidYears



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidYears | varchar(11) | Yes |  |



### dbo.vw_BillingStatus



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictId | int | No |  |
| Name | varchar(50) | Yes |  |
| CurrentBudgetId | int | No |  |
| NextBudgetId | int | No |  |
| CurrentEDSAmount | money | Yes |  |
| CurrentEDSType | varchar(63) | Yes |  |
| NextEDSAmount | money | Yes |  |
| NextEDSType | varchar(50) | Yes |  |
| CurrentRTKAmount | money | Yes |  |
| CurrentRTKType | varchar(13) | No |  |
| NextRTKAmount | money | Yes |  |
| CurrentTMAmount | money | Yes |  |
| NextTMAmount | money | Yes |  |
| CurrentTMType | varchar(13) | No |  |
| NeedsEDS | int | No |  |
| NeedsRTK | int | No |  |
| NeedsTM | int | No |  |



### dbo.vw_BrowseDistrictBidHeaders



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| HeadingId | int | Yes |  |
| Title | varchar(255) | Yes |  |



### dbo.vw_BudgetDistrictBySession



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | No |  |
| DistrictName | varchar(50) | Yes |  |
| BudgetName | varchar(30) | Yes |  |
| BudgetId | int | Yes |  |
| StateName | varchar(50) | Yes |  |
| CountyName | varchar(50) | Yes |  |
| DistrictId | int | Yes |  |



### dbo.vw_BudgetPrice



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidPrice | money | Yes |  |
| BidItemId | int | Yes |  |
| CrossRefId | int | No |  |
| VendorId | int | Yes |  |
| CatalogId | int | Yes |  |
| CatalogPrice | money | Yes |  |
| GrossPrice | money | Yes |  |
| DiscountRate | int | Yes |  |
| CatalogPage | char(4) | Yes |  |
| PricePlanId | int | Yes |  |
| AwardId | int | Yes |  |
| VendorItemCode | varchar(50) | Yes |  |
| Alternate | int | Yes |  |
| ItemMustBeBid | int | No |  |
| CatalogYear | char(2) | Yes |  |
| ItemId | int | No |  |
| SortKey | varchar(42) | Yes |  |



### dbo.vw_BudgetsFilter



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BudgetName | varchar(9) | Yes |  |
| BudgetFilterId | int | Yes |  |



### dbo.vw_CatalogCompare



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| CatalogIdOld | int | Yes |  |
| CrossRefId | int | No |  |
| VendorItemCodeOld | varchar(50) | Yes |  |
| PageOld | char(4) | Yes |  |
| CatalogPriceOld | money | Yes |  |
| GrossPriceOld | money | Yes |  |
| DoNotDiscountOld | int | Yes |  |
| DescriptionOld | varchar(512) | Yes |  |
| UnitCodeOld | varchar(20) | Yes |  |
| NewCatalogId | int | Yes |  |
| sysid | int | No |  |
| VendorItemCodeNew | varchar(50) | Yes |  |
| PageNew | int | Yes |  |
| CatalogPriceNew | money | Yes |  |
| GrossPriceNew | money | Yes |  |
| DoNotDiscountNew | int | Yes |  |
| DescriptionNew | varchar(512) | Yes |  |
| UnitCodeNew | varchar(16) | Yes |  |
| CatalogPriceChangePercent | money | Yes |  |
| GrossPriceChangePercent | money | Yes |  |



### dbo.vw_CatalogImport



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| CatalogImportFieldId | int | No |  |
| CatalogImportId | int | No |  |
| SequenceId | int | Yes |  |
| Name | varchar(50) | No |  |
| Optional | tinyint | Yes |  |
| rowguid | uniqueidentifier | No |  |
| CatalogImportMapId | int | Yes |  |
| CatalogId | int | Yes |  |
| ImportIndex | int | Yes |  |
| ImportRegExp | varchar(1024) | Yes |  |



### dbo.vw_CatalogImporter1



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| CategoryName | varchar(50) | Yes |  |
| VendorName | varchar(50) | Yes |  |
| VendorCode | varchar(16) | Yes |  |
| CategoryId | int | Yes |  |
| VendorId | int | Yes |  |



### dbo.vw_CatalogImporter1Dtl



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| CategoryName | varchar(50) | Yes |  |
| VendorName | varchar(50) | Yes |  |
| BidHeaderId | int | Yes |  |
| BidDescription | varchar(512) | Yes |  |
| EffectiveFrom | datetime | Yes |  |
| EffectiveUntil | datetime | Yes |  |
| CategoryId | int | Yes |  |
| VendorId | int | Yes |  |
| BidHeaderActive | tinyint | Yes |  |



### dbo.vw_CatalogImporterCat



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| CategoryName | varchar(50) | Yes |  |
| CategoryId | int | Yes |  |



### dbo.vw_CatalogImporterVen



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VendorName | varchar(50) | Yes |  |
| VendorId | int | No |  |
| VendorCode | varchar(16) | Yes |  |



### dbo.vw_CatalogImports



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| CategoryName | varchar(50) | Yes |  |
| VendorName | varchar(50) | Yes |  |
| CatalogYear | char(2) | Yes |  |
| CatalogName | varchar(50) | Yes |  |
| NumberOfItems | int | Yes |  |
| DatePosted | varchar(30) | No |  |
| WebLink | varchar(30) | No |  |
| CatalogId | int | No |  |



### dbo.vw_CatalogPages



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| ItemId | int | Yes |  |
| CatalogId | int | No |  |
| Name | varchar(50) | Yes |  |
| Page | char(4) | Yes |  |
| PDFAvailable | tinyint | Yes |  |
| VendorItemCode | varchar(50) | Yes |  |
| VendorId | int | Yes |  |



### dbo.vw_CatalogPages_Orig



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| ItemId | int | Yes |  |
| CatalogId | int | No |  |
| Name | varchar(50) | Yes |  |
| Page | char(4) | Yes |  |
| PDFAvailable | tinyint | Yes |  |
| VendorItemCode | varchar(50) | Yes |  |
| VendorId | int | Yes |  |



### dbo.vw_CatalogPages1



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| ItemId | int | No |  |
| CatalogId | int | No |  |
| Name | varchar(50) | Yes |  |
| Page | int | Yes |  |
| PDFAvailable | tinyint | Yes |  |
| VendorItemCode | varchar(50) | Yes |  |
| VendorId | int | Yes |  |



### dbo.vw_CatalogPricing



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| ItemId | int | Yes |  |
| CrossRefId | int | No |  |
| BidHeaderId | int | Yes |  |
| AwardCatalogId | int | No |  |
| AwardId | int | No |  |
| BidId | int | No |  |
| NetPrice | decimal(34,13) | Yes |  |



### dbo.vw_CatalogRefsItemTest



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| ItemId | int | No |  |
| CatalogRefs | nvarchar(MAX) | Yes |  |



### dbo.vw_CatalogRequestStatus



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| CatalogRequestId | int | No |  |
| VendorId | int | Yes |  |
| EmailAddress | varchar(255) | Yes |  |
| ContactName | varchar(255) | Yes |  |
| SendDate | datetime | Yes |  |
| CatalogRequestNotes | varchar(1000) | Yes |  |
| Status | varchar(18) | Yes |  |
| StatusDate | datetime | Yes |  |
| FollowUpDate | datetime | Yes |  |
| CatalogRequestStatusId | int | Yes |  |
| VendorName | varchar(50) | Yes |  |



### dbo.vw_CatalogsAttachedToBids



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| CategoryName | varchar(50) | Yes |  |
| BidNumber | int | Yes |  |
| VendorName | varchar(50) | Yes |  |
| CatalogName | varchar(50) | Yes |  |
| CrossRefCount | int | Yes |  |
| DatePosted | varchar(30) | No |  |
| LastAwardDate | varchar(30) | No |  |
| AwardWarning | varchar(58) | Yes |  |
| CatalogId | int | No |  |
| DiscountRate | decimal(9,5) | Yes |  |
| AvgDiscPercent | money | Yes |  |
| CatalogDiscountComments | varchar(512) | Yes |  |
| BidItemDiscountRate | decimal(9,5) | Yes |  |
| BidImportId | int | No |  |



### dbo.vw_Categories



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| CategoryName | varchar(50) | Yes |  |



### dbo.vw_CategoriesAndVendors



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| UserId | int | No |  |
| DistrictId | int | No |  |
| CategoryName | varchar(50) | Yes |  |
| VendorName | varchar(50) | Yes |  |



### dbo.vw_ContinuanceCharges



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| Id | uniqueidentifier | No |  |
| Email | varchar(255) | Yes |  |
| Status | char(1) | Yes |  |
| SignedBy | varchar(255) | Yes |  |
| Received | datetime | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| NameAndAddress | varchar(1024) | Yes |  |
| ParentDistrict | varchar(50) | Yes |  |
| BudgetName | varchar(30) | Yes |  |
| SchoolYear | varchar(61) | Yes |  |
| SchoolYearNumber | int | Yes |  |
| LMAmount | money | Yes |  |
| RTKAmount | money | Yes |  |
| ChargeTypeId | int | No |  |
| Description | varchar(50) | Yes |  |
| section | int | No |  |
| LM | int | Yes |  |
| RTK | int | Yes |  |
| Amount | money | Yes |  |
| FrequencyData | varchar(50) | Yes |  |
| BillDate | date | Yes |  |
| CycleAmount | money | Yes |  |



### dbo.vw_ContinuanceSection0Charges



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| Id | uniqueidentifier | No |  |
| BillDate | date | Yes |  |
| TotalLMAmount | money | Yes |  |
| TotalRTKAmount | money | Yes |  |
| LMAmount | money | Yes |  |
| RTKAmount | money | Yes |  |



### dbo.vw_ContinuanceSection1Charges



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| Id | uniqueidentifier | No |  |
| BillDate | date | Yes |  |
| Amount | money | Yes |  |
| Title | varchar(50) | Yes |  |
| Covering | varchar(101) | Yes |  |



### dbo.vw_CrossRefsDescription



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| ItemId | int | No |  |
| CrossRefId | int | No |  |
| ItemDescription | nvarchar(4000) | Yes |  |
| FullDescription | nvarchar(4000) | Yes |  |



### dbo.vw_CrossRefsLongDescription



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| ItemId | int | No |  |
| CrossRefId | int | No |  |
| ItemDescription | varchar(4740) | Yes |  |



### dbo.vw_CSReps



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| Name | varchar(30) | Yes |  |



### dbo.vw_DetailDescription



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DetailId | int | No |  |
| ItemDescription | nvarchar(MAX) | Yes |  |
| ShortDescription | nvarchar(MAX) | Yes |  |



### dbo.vw_DetailDescription_old



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DetailId | int | No |  |
| ItemDescription | varchar(2311) | Yes |  |



### dbo.vw_DetailDescriptionPrint



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DetailId | int | No |  |
| ItemDescription | varchar(2356) | Yes |  |



### dbo.vw_DetailDescriptionSBS



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DetailId | int | No |  |
| ItemDescription | varchar(2880) | Yes |  |



### dbo.vw_DetailDescriptionTest



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DetailId | int | No |  |
| ItemDescription | varchar(2356) | Yes |  |



### dbo.vw_DetailNotifications



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DetailNotificationId | bigint | No |  |
| DetailId | bigint | No |  |
| NotificationId | bigint | Yes |  |
| DateCreated | datetime | No |  |
| OrigItemId | int | Yes |  |
| NewItemId | int | Yes |  |
| OrigVendorId | int | Yes |  |
| NewVendorId | int | Yes |  |
| OrigBidPrice | decimal(11,5) | Yes |  |
| NewBidPrice | decimal(11,5) | Yes |  |



### dbo.vw_DetailOnBid



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DetailId | int | Yes |  |
| BidHeaderId | int | Yes |  |
| BidAwardDate | datetime | Yes |  |
| EffectiveFrom | datetime | Yes |  |
| EffectiveUntil | datetime | Yes |  |
| ReadyToUseDate | datetime | Yes |  |



### dbo.vw_DetailView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | Yes |  |
| DetailId | int | No |  |
| ItemId | int | Yes |  |
| ItemCode | varchar(50) | No |  |
| Quantity | int | No |  |
| LastYearsQuantity | int | No |  |
| Description | varchar(3650) | Yes |  |
| UnitCode | varchar(20) | No |  |
| BidPrice | money | No |  |
| Extended | money | No |  |
| SessionId | int | No |  |
| VendorName | varchar(50) | No |  |
| VendorCode | varchar(16) | No |  |
| CatalogName | varchar(50) | No |  |
| AltDescription | varchar(1024) | No |  |
| VendorItemCode | varchar(50) | Yes |  |
| CatalogPage | char(4) | Yes |  |
| NoBid | int | No |  |
| ItemMustBeBid | int | No |  |
| BidInfo | varchar(51) | Yes |  |
| HasBeenBid | int | No |  |
| AllowOverride | int | No |  |
| VendorOverridden | int | No |  |
| ItemBidType | varchar(32) | Yes |  |



### dbo.vw_DistrictBudgetList



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| selected | int | No |  |
| BudgetId | int | No |  |
| BudgetName | varchar(30) | No |  |
| DistrictId | int | No |  |
| DistrictName | varchar(50) | No |  |
| DistrictCode | varchar(4) | No |  |
| BAName | varchar(194) | No |  |
| DistrictNameAndAddress | varchar(189) | Yes |  |
| BudgetsFilterId | int | Yes |  |



### dbo.vw_DistrictBudgetPP



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| selected | int | No |  |
| BudgetId | int | No |  |
| BudgetName | varchar(30) | No |  |
| DistrictId | int | No |  |
| DistrictName | varchar(50) | No |  |
| DistrictCode | varchar(4) | No |  |
| PricePlanId | int | No |  |
| PricePlanCode | varchar(20) | No |  |
| BudgetsFilterId | int | Yes |  |



### dbo.vw_DistrictContactsList



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictId | int | No |  |
| DistrictContactId | int | No |  |
| FullName | varchar(174) | Yes |  |
| FullAddress | varchar(167) | Yes |  |
| FullContacts | varchar(316) | Yes |  |
| ContactPosition | varchar(50) | Yes |  |



### dbo.vw_DistrictCounties_BidMgr



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| StateCode | varchar(2) | Yes |  |
| CountyName | varchar(50) | Yes |  |



### dbo.vw_DistrictList



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| County | varchar(50) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| Code | char(2) | Yes |  |
| StateName | varchar(50) | Yes |  |



### dbo.vw_DistrictPaymentSchedule



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SysId | int | No |  |
| DistrictId | int | Yes |  |
| BudgetId | int | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| DistrictNameAndAddress | varchar(1024) | Yes |  |
| DearMsg | varchar(1024) | Yes |  |
| LMFeeMsg | varchar(1024) | Yes |  |
| RTKFeeMsg | varchar(1024) | Yes |  |
| ExplainationMsg | varchar(1024) | Yes |  |
| AcknowledgeMsg | varchar(1024) | Yes |  |
| ProgramName | varchar(50) | Yes |  |
| BudgetYear | varchar(50) | Yes |  |
| OrderYear | varchar(50) | Yes |  |
| CDateHeader | varchar(50) | Yes |  |
| LMAmountHeader | varchar(50) | Yes |  |
| RTKAmountHeader | varchar(50) | Yes |  |
| TotalLMCharges | money | Yes |  |
| TotalLMChargesStr | varchar(20) | Yes |  |
| TotalRTKCharges | money | Yes |  |
| TotalRTKChargesStr | varchar(20) | Yes |  |
| CDate | datetime | Yes |  |
| CDateStr | varchar(20) | Yes |  |
| ChargeId | int | Yes |  |
| LMAmount | money | Yes |  |
| LMAmountStr | varchar(20) | Yes |  |
| RTKAmount | money | Yes |  |
| RTKAmountStr | varchar(20) | Yes |  |
| RTK | int | Yes |  |
| AccountingDistrictCode | varchar(50) | Yes |  |
| LMChargeCode | varchar(50) | Yes |  |
| RTKChargeCode | varchar(50) | Yes |  |
| Street1 | varchar(50) | Yes |  |
| City | varchar(50) | Yes |  |
| State | varchar(10) | Yes |  |
| Zipcode | varchar(10) | Yes |  |
| PODiskAmount | money | Yes |  |
| PODiskCode | varchar(50) | Yes |  |
| GenericPOAmount | money | Yes |  |
| GenericPOCode | varchar(50) | Yes |  |
| EPOAmount | money | Yes |  |
| EPOCode | varchar(50) | Yes |  |



### dbo.vw_DistrictPOInfo



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RepName | varchar(30) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| State | varchar(2) | Yes |  |
| LY Estimated PO Count | int | Yes |  |
| LY PO Count | int | Yes |  |
| LY PO Printed Count | int | Yes |  |
| LY PO Exported Count | int | Yes |  |
| LY PIT Estimated PO Count | int | Yes |  |
| LY PIT PO Count | int | Yes |  |
| LY PIT PO Printed Count | int | Yes |  |
| LY PIT PO Exported Count | int | Yes |  |
| CY Estimated PO Count | int | Yes |  |
| CY PO Count | int | Yes |  |
| CY PO Printed Count | int | Yes |  |
| CY PO Exported Count | int | Yes |  |



### dbo.vw_Districts_Assoc_With_Bid



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| DistrictId | int | No |  |
| Name | varchar(50) | Yes |  |



### dbo.vw_DistrictSchools



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictId | int | Yes |  |
| SchoolId | int | No |  |
| Name | varchar(50) | Yes |  |



### dbo.vw_DistrictsNeedingReview



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| CSRepId | int | No |  |
| CSRepName | varchar(30) | No |  |
| DistrictId | int | No |  |
| DistrictName | varchar(50) | No |  |
| BudgetId | int | No |  |
| BudgetName | varchar(30) | No |  |
| Schedule | varchar(50) | No |  |
| CategoryName | varchar(50) | Yes |  |
| ReqsNeedingToBeBid | int | No |  |
| BidAddendaReqsOnHold | int | No |  |
| BidAddendaReqsBeingApproved | int | No |  |
| BidAddendaReqsApproved | int | No |  |
| BidAddendaReqsAtEDS | int | No |  |



### dbo.vw_DistrictStates_BidMgr



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| StateCode | varchar(2) | Yes |  |



### dbo.vw_DMSAllDocuments



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DocumentType | varchar(255) | No |  |
| DocName | varchar(8000) | Yes |  |
| DocId | uniqueidentifier | No |  |
| PagesCaptured | int | Yes |  |



### dbo.vw_DMSBidDocuments



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| BidNbr | varchar(MAX) | Yes |  |
| DocType | varchar(MAX) | Yes |  |
| DocId | uniqueidentifier | Yes |  |
| DistrictVisible | varchar(MAX) | Yes |  |
| PagesCaptured | int | Yes |  |
| FIleName | varchar(8000) | Yes |  |



### dbo.vw_DMSBidDocuments_View



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | varchar(30) | Yes |  |
| BidNbr | varchar(MAX) | Yes |  |
| DocType | varchar(MAX) | Yes |  |
| DocId | uniqueidentifier | No |  |
| DistrictVisible | varchar(MAX) | No |  |
| PagesCaptured | int | Yes |  |
| FileName | varchar(1024) | No |  |



### dbo.vw_DMSRTKDocuments



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| MSDSId | varchar(MAX) | Yes |  |
| DocId | uniqueidentifier | No |  |
| PagesCaptured | int | Yes |  |
| DocName | varchar(1024) | Yes |  |



### dbo.vw_DMSRTKSurveys



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictId | varchar(MAX) | Yes |  |
| FacilityNumber | varchar(MAX) | Yes |  |
| FacilityName | varchar(MAX) | Yes |  |
| ReportYear | varchar(MAX) | Yes |  |
| DocId | uniqueidentifier | No |  |



### dbo.vw_DMSSDSDocuments



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| MSDSId | int | No |  |
| DocId | uniqueidentifier | No |  |
| PagesCaptured | int | Yes |  |
| DocName | varchar(1024) | Yes |  |



### dbo.vw_DMSSDSDocuments_View



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| MSDSId | varchar(MAX) | Yes |  |
| DocId | uniqueidentifier | No |  |
| PagesCaptured | int | Yes |  |
| DocName | varchar(1024) | Yes |  |



### dbo.vw_DMSVendorBidDocuments



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VendorCode | varchar(10) | Yes |  |
| DistrictVisible | varchar(10) | Yes |  |
| BidHeaderId | int | Yes |  |
| BidNbr | varchar(20) | Yes |  |
| DocType | varchar(8000) | Yes |  |
| ExpirationDate | varchar(30) | Yes |  |
| DocumentNumber | varchar(255) | Yes |  |
| DocId | uniqueidentifier | Yes |  |
| PagesCaptured | int | Yes |  |
| FileName | varchar(8000) | Yes |  |



### dbo.vw_DMSVendorBidDocuments_04232018



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VendorCode | varchar(MAX) | No |  |
| DistrictVisible | varchar(MAX) | No |  |
| BidHeaderId | int | Yes |  |
| BidNbr | varchar(MAX) | Yes |  |
| DocType | varchar(MAX) | Yes |  |
| ExpirationDate | varchar(MAX) | No |  |
| DocumentNumber | varchar(MAX) | No |  |
| DocId | uniqueidentifier | No |  |
| PagesCaptured | int | Yes |  |



### dbo.vw_DMSVendorBidDocuments_View



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VendorCode | varchar(MAX) | No |  |
| DistrictVisible | varchar(MAX) | No |  |
| BidHeaderId | varchar(30) | Yes |  |
| BidNbr | varchar(MAX) | Yes |  |
| DocType | varchar(MAX) | Yes |  |
| ExpirationDate | varchar(MAX) | No |  |
| DocumentNumber | varchar(MAX) | No |  |
| DocId | uniqueidentifier | Yes |  |
| PagesCaptured | int | Yes |  |
| FileName | varchar(1024) | No |  |



### dbo.vw_DMSVendorBidDocuments_ViewTest



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VendorCode | varchar(MAX) | No |  |
| DistrictVisible | varchar(MAX) | No |  |
| BidHeaderId | varchar(30) | Yes |  |
| BidNbr | varchar(MAX) | Yes |  |
| DocType | varchar(MAX) | Yes |  |
| ExpirationDate | varchar(MAX) | No |  |
| DocumentNumber | varchar(MAX) | No |  |
| DocId | uniqueidentifier | Yes |  |
| PagesCaptured | int | Yes |  |
| FileName | varchar(1024) | No |  |



### dbo.vw_DMSVendorBidDocumentsTest



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VendorCode | varchar(MAX) | No |  |
| DistrictVisible | varchar(MAX) | No |  |
| BidHeaderId | int | Yes |  |
| BidNbr | varchar(MAX) | Yes |  |
| DocType | varchar(MAX) | Yes |  |
| DocId | uniqueidentifier | No |  |
| PagesCaptured | int | Yes |  |



### dbo.vw_DMSVendorDocuments



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VendorCode | varchar(10) | Yes |  |
| DistrictVisible | varchar(10) | Yes |  |
| DocType | varchar(255) | Yes |  |
| ExpirationDate | varchar(30) | Yes |  |
| DocumentNumber | varchar(255) | Yes |  |
| DocId | uniqueidentifier | Yes |  |
| PagesCaptured | int | Yes |  |
| FileName | varchar(8000) | Yes |  |



### dbo.vw_DMSVendorDocuments_View



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VendorCode | varchar(30) | Yes |  |
| DistrictVisible | varchar(MAX) | No |  |
| DocType | varchar(MAX) | No |  |
| ExpirationDate | varchar(MAX) | No |  |
| DocumentNumber | varchar(MAX) | No |  |
| DocId | uniqueidentifier | Yes |  |
| PagesCaptured | int | Yes |  |
| FileName | varchar(1024) | No |  |



### dbo.vw_DocumentTypes



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidDocumentTypeId | int | No |  |
| BidType | varchar(30) | No |  |
| Name | varchar(50) | No |  |
| Description | varchar(4096) | Yes |  |
| VendorSpecific | varchar(3) | No |  |
| State | char(2) | Yes |  |
| Sequence | int | Yes |  |
| DistrictVisible | varchar(3) | No |  |



### dbo.vw_EmailBlastChangeNotificationHTMLTableApprover_NotUsed



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionersBlastId | int | Yes |  |
| ApproverUserId | int | Yes |  |
| EmailHTMLTable | nvarchar(MAX) | Yes |  |



### dbo.vw_EmailBlastChangeNotificationHTMLTableRequisitioner_NotUsed



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| EmailBlastId | int | Yes |  |
| UserId | int | No |  |
| EmailHTMLTable | nvarchar(MAX) | Yes |  |



### dbo.vw_ExistingRequisitions



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | No |  |
| RequisitionId | int | No |  |
| RequisitionNumber | varchar(24) | Yes |  |
| Attention | varchar(50) | Yes |  |
| DateEntered | datetime | Yes |  |
| TotalItemsCost | money | No |  |
| CategoryId | int | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| StatusName | varchar(50) | Yes |  |
| ApprovalLevel | tinyint | Yes |  |
| RequisitionStatus | varchar(255) | Yes |  |
| Available | money | No |  |



### dbo.vw_ExistingUserAccounts



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| UserId | int | No |  |
| BudgetId | int | No |  |
| BudgetAccountId | int | No |  |
| UseAllocations | tinyint | Yes |  |
| BudgetAmount | money | Yes |  |
| AmountAvailable | money | Yes |  |
| AccountId | int | No |  |
| Code | varchar(50) | Yes |  |



### dbo.vw_ExistingUserAccounts_NEW



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| UserId | int | No |  |
| BudgetId | int | No |  |
| BudgetAccountId | int | No |  |
| budgetUseAllocations | tinyint | Yes |  |
| BudgetAmount | money | Yes |  |
| AmountAvailable | money | Yes |  |
| AccountId | int | No |  |
| Code | varchar(50) | Yes |  |
| UserAccountID | int | No |  |
| UseAllocations | tinyint | Yes |  |
| AllocationAmount | money | Yes |  |



### dbo.vw_FA_ALLBudgetAccounts



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BudgetAccountID | int | No |  |
| BudgetAmount | money | No |  |
| AmountAvailable | money | No |  |
| UseAllocations | tinyint | No |  |
| BudgetName | varchar(30) | Yes |  |
| BudgetID | int | No |  |
| Code | varchar(50) | Yes |  |
| Type | varchar(50) | Yes |  |
| AccountID | int | No |  |
| Allocated | money | No |  |
| Spent | money | No |  |
| SchoolID | int | No |  |
| SessionID | int | No |  |
| Active | int | No |  |



### dbo.vw_FA_ALLUserAccounts



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BudgetAccountID | int | No |  |
| BudgetAmount | money | No |  |
| AmountAvailable | money | No |  |
| UseBudgetAccountAllocations | tinyint | No |  |
| BudgetName | varchar(30) | Yes |  |
| BudgetID | int | No |  |
| Code | varchar(50) | Yes |  |
| Type | varchar(50) | Yes |  |
| AccountID | int | No |  |
| Allocated | money | No |  |
| Spent | money | No |  |
| SchoolID | int | No |  |
| SessionID | int | No |  |
| UserAccountId | int | No |  |
| UserId | int | Yes |  |
| AllocationAmount | money | No |  |
| AllocationAvailable | money | No |  |
| UseAllocations | tinyint | No |  |
| UserSpent | money | No |  |
| Active | int | No |  |



### dbo.vw_FA_BudgetAccounts



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BudgetAccountID | int | No |  |
| BudgetAmount | money | No |  |
| AmountAvailable | money | No |  |
| UseAllocations | tinyint | No |  |
| BudgetName | varchar(30) | Yes |  |
| BudgetID | int | No |  |
| Code | varchar(50) | Yes |  |
| Type | varchar(50) | Yes |  |
| AccountID | int | No |  |
| Allocated | money | No |  |
| Spent | money | No |  |
| SchoolID | int | No |  |
| SessionID | int | No |  |



### dbo.vw_FA_BudgetsView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | No |  |
| BudgetId | int | No |  |
| Name | varchar(30) | Yes |  |
| EndDate | datetime | Yes |  |
| AnnualCutoff | datetime | Yes |  |
| CurrentBudget | int | No |  |
| AllowEdit | int | No |  |



### dbo.vw_FA_CategoriesAndVendors



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| CategoryID | int | No |  |
| CategoryName | varchar(50) | Yes |  |
| VendorId | int | No |  |
| VendorName | varchar(50) | Yes |  |



### dbo.vw_FA_EDSUser



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| UserId | int | No |  |
| DistrictId | int | Yes |  |
| SchoolId | int | Yes |  |
| ShippingId | int | Yes |  |
| Active | tinyint | No |  |
| UserName | varchar(50) | Yes |  |
| Password | varchar(100) | Yes |  |
| Attention | varchar(50) | Yes |  |
| ApprovalLevel | tinyint | Yes |  |
| CometId | int | Yes |  |
| DisableNewRequisition | tinyint | Yes |  |
| DistrictAcctgCode | varchar(20) | Yes |  |
| ApproverId | int | Yes |  |
| NewRequisitionButton | int | No |  |
| AllowIncidentals | tinyint | No |  |
| AllowVendorChanges | tinyint | No |  |
| AllowShipToChanges | tinyint | No |  |
| AllowTM | tinyint | No |  |
| Email | varchar(255) | Yes |  |
| SecurityRoleId | int | Yes |  |
| Use20 | int | Yes |  |
| EmailByPassDate | date | Yes |  |
| FirstName | varchar(20) | Yes |  |
| LastName | varchar(30) | Yes |  |
| useCF | int | No |  |
| AllowExport | bit | No |  |
| HasAdminAccess | bit | No |  |
| Role | varchar(50) | No |  |
| UserDisplayName | varchar(56) | Yes |  |
| AllowAddenda | bit | No |  |
| AllowMSRP | tinyint | No |  |
| AllowAccountCodeMgmt | tinyint | No |  |
| POAccess | int | No |  |
| AllowVendorCodeMaintenance | tinyint | No |  |
| PositionData | nvarchar(4000) | Yes |  |



### dbo.vw_FA_ReqCategories



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictId | int | Yes |  |
| BudgetId | int | No |  |
| CategoryId | int | No |  |
| Name | varchar(50) | Yes |  |
| CategoryType | int | Yes |  |



### dbo.vw_FA_Requisitions



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| RequisitionNumber | varchar(24) | Yes |  |
| StatusID | int | No |  |
| StatusName | varchar(50) | No |  |
| TotalRequisitionCost | money | Yes |  |
| ApprovalLevel | tinyint | No |  |
| Attention | varchar(50) | Yes |  |
| CometId | varchar(5) | Yes |  |
| DateUpdated | datetime | Yes |  |
| NotesCount | int | Yes |  |
| OrderType | tinyint | Yes |  |
| OrderTypeDisplay | varchar(10) | No |  |
| UsersFullName | varchar(56) | Yes |  |
| CategoryID | int | No |  |
| CategoryName | varchar(50) | Yes |  |
| BudgetID | int | No |  |
| AccountID | int | No |  |
| AccountCode | varchar(50) | No |  |
| DistrictID | int | No |  |
| DistrictName | varchar(50) | No |  |
| SchoolID | int | No |  |
| SchoolName | varchar(50) | Yes |  |
| UserID | int | No |  |
| UserAccountId | int | Yes |  |
| SessionId | int | No |  |



### dbo.vw_FA_UserAccounts



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BudgetAccountID | int | No |  |
| BudgetAmount | money | No |  |
| AmountAvailable | money | No |  |
| UseBudgetAccountAllocations | tinyint | No |  |
| BudgetName | varchar(30) | Yes |  |
| BudgetID | int | No |  |
| Code | varchar(50) | Yes |  |
| Type | varchar(50) | Yes |  |
| AccountID | int | No |  |
| Allocated | money | No |  |
| Spent | money | No |  |
| SchoolID | int | No |  |
| SessionID | int | No |  |
| UserAccountId | int | No |  |
| Active | tinyint | Yes |  |
| UserId | int | Yes |  |
| AllocationAmount | money | No |  |
| AllocationAvailable | money | No |  |
| UseAllocations | tinyint | No |  |
| UserSpent | money | No |  |



### dbo.vw_FA_UserDisplayName



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| UserID | int | No |  |
| UserDisplayName | varchar(56) | Yes |  |



### dbo.vw_FA_UserList



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | No |  |
| DistrictId | int | No |  |
| SchoolId | int | No |  |
| UserId | int | No |  |
| DisplayName | varchar(56) | Yes |  |



### dbo.vw_FA_UserLogin



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| UserIsActive | tinyint | Yes |  |
| UserID | int | No |  |
| CometId | int | Yes |  |
| Password | varchar(10) | Yes |  |
| Attention | varchar(50) | Yes |  |
| ApprovalLevel | tinyint | Yes |  |
| ApproverID | int | Yes |  |
| HasAdminAccess | bit | Yes |  |
| SchoolIsActive | tinyint | Yes |  |
| SchoolID | int | No |  |
| SchoolName | varchar(50) | Yes |  |
| DistrictIsActive | tinyint | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| DistrictID | int | No |  |
| DistrictCode | varchar(4) | Yes |  |
| CSRepID | int | Yes |  |



### dbo.vw_Financials



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictId | int | Yes |  |
| BudgetId | int | No |  |
| Description | varchar(50) | Yes |  |
| dcId | uniqueidentifier | Yes |  |
| Status | varchar(13) | No |  |
| Received | datetime | Yes |  |
| SignedBy | varchar(255) | Yes |  |
| Comments | varchar(4096) | Yes |  |
| DistrictChargeId | int | Yes |  |
| Amount | money | Yes |  |
| FrequencyData | varchar(50) | Yes |  |
| dpcId | uniqueidentifier | Yes |  |
| ProposedAmount | money | Yes |  |
| PreviousAmount | money | Yes |  |
| BillMonths | varchar(8000) | Yes |  |



### dbo.vw_FormattedDetailDescription



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DetailId | int | No |  |
| ItemDescription | varchar(2893) | Yes |  |



### dbo.vw_GetMSDSInfo



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| MSDSId | int | No |  |
| ItemDescription | varchar(60) | Yes |  |
| ItemList | varchar(1024) | Yes |  |



### dbo.vw_HeadingsByBid



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| HeadingId | int | No |  |
| HeadingTitle | varchar(255) | Yes |  |



### dbo.vw_HeadingsByReq



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| HeadingId | int | No |  |
| Title | varchar(255) | Yes |  |
| DateCreated | datetime | Yes |  |
| DistrictId | int | Yes |  |



### dbo.vw_HeadingsByReqTest



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| HeadingId | int | No |  |
| Title | varchar(255) | Yes |  |



### dbo.vw_HeadingsKeywordsByBid



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| HeadingId | int | No |  |
| HeadingTitle | varchar(255) | No |  |
| KeywordId | int | No |  |
| Keyword | varchar(50) | No |  |



### dbo.vw_IncidentalOrderDownloads



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictId | int | No |  |
| BudgetId | int | Yes |  |
| RequisitionId | int | Yes |  |
| RequisitionNumber | varchar(24) | Yes |  |
| UploadDate | datetime | Yes |  |



### dbo.vw_IncidentalOrderDownloadsDetail



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | Yes |  |
| DistrictRequisitionNumber | varchar(50) | Yes |  |



### dbo.vw_InstructionBookCalendar



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictId | int | No |  |
| UserId | int | No |  |
| CalendarId | int | No |  |
| HeaderText | varchar(8000) | Yes |  |
| FooterText | varchar(8000) | Yes |  |
| HeaderTextHTML | varchar(4096) | Yes |  |
| FooterTextHTML | varchar(4096) | No |  |
| CalendarTypeId | int | No |  |
| DateCount | int | No |  |
| Description | varchar(50) | Yes |  |
| Date1 | datetime | No |  |
| Date2 | datetime | Yes |  |
| Date3 | datetime | Yes |  |
| Date4 | datetime | Yes |  |
| BookType | varchar(50) | No |  |
| ScheduleGroup | varchar(50) | No |  |
| CalendarName | varchar(83) | Yes |  |



### dbo.vw_InstructionBookContents



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictId | int | No |  |
| UserId | int | No |  |
| Priority | int | Yes |  |
| Title | varchar(255) | Yes |  |
| TitleInTOC | tinyint | Yes |  |
| Body | varchar(4096) | Yes |  |
| HeaderAttributes | int | Yes |  |
| IBCId | int | No |  |
| SubReportName | varchar(1024) | Yes |  |
| HTMLBody | varchar(MAX) | No |  |



### dbo.vw_IsRequisitionLocked



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| IsLocked | int | No |  |



### dbo.vw_ItemDescription



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| ItemId | int | No |  |
| CategoryId | int | Yes |  |
| ItemDescription | varchar(1156) | Yes |  |



### dbo.vw_ItemDescriptionNoExtra



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| ItemId | int | No |  |
| ItemDescription | varchar(1156) | Yes |  |



### dbo.vw_ItemDescriptionNoExtraNH



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| ItemId | int | No |  |
| ItemDescription | varchar(848) | Yes |  |



### dbo.vw_ItemPricing



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| categoryId | int | Yes |  |
| ItemId | int | No |  |
| CatalogId | int | Yes |  |
| CrossRefId | int | Yes |  |
| ItemCode | varchar(50) | Yes |  |
| Description | varchar(2356) | Yes |  |
| UnitId | int | Yes |  |
| UnitCode | varchar(20) | Yes |  |
| BidPrice | decimal(34,13) | Yes |  |
| CatalogPrice | money | Yes |  |
| GrossPrice | money | Yes |  |
| DiscountRate | decimal(15,5) | Yes |  |
| CatalogPage | varchar(16) | Yes |  |
| CatalogYear | char(2) | Yes |  |
| PricePlanId | int | Yes |  |
| AwardId | int | Yes |  |
| VendorId | int | Yes |  |
| VendorItemCode | varchar(50) | Yes |  |
| PackedVendorItemCode | varchar(255) | Yes |  |
| Alternate | varchar(512) | Yes |  |
| SortSeq | varchar(64) | Yes |  |
| BidItemId | int | Yes |  |
| ItemMustBeBid | int | No |  |
| PriceSort | varchar(82) | Yes |  |



### dbo.vw_ItemsByBid



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| CategoryId | int | Yes |  |
| ItemId | int | No |  |
| ItemCode | varchar(50) | No |  |
| ItemDescription | varchar(1156) | No |  |
| UnitCode | varchar(20) | No |  |
| HeadingId | int | No |  |
| HeadingTitle | varchar(255) | No |  |
| KeywordId | int | No |  |
| Keyword | varchar(50) | No |  |
| VendorId | int | No |  |
| VendorName | varchar(50) | No |  |
| SortSeq | varchar(64) | Yes |  |
| NetPrice | decimal(33,13) | Yes |  |
| CatalogName | varchar(50) | No |  |
| CatalogPrice | money | No |  |
| RequisitionId | int | No |  |
| DetailId | int | No |  |
| Quantity | int | No |  |
| Alternate | varchar(512) | No |  |
| ItemBidType | varchar(32) | No |  |
| PageNo | int | No |  |
| VendorItemCode | varchar(50) | No |  |



### dbo.vw_JavaReqDetail



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DetailId | int | No |  |
| RequisitionId | int | Yes |  |
| Alternate | varchar(1024) | No |  |
| BidPrice | money | No |  |
| CatalogPage | char(4) | No |  |
| CatalogPrice | money | No |  |
| Description | varchar(1024) | No |  |
| DistrictRequisitionNumber | varchar(50) | No |  |
| ExtraDescription | varchar(1024) | No |  |
| HeadingTitle | varchar(255) | No |  |
| ItemCode | varchar(50) | No |  |
| ItemMustBeBid | int | No |  |
| Keyword | varchar(50) | No |  |
| LastYearsQuantity | int | No |  |
| Modified | datetime | Yes |  |
| Quantity | int | No |  |
| SectionName | varchar(255) | No |  |
| SortSeq | varchar(64) | No |  |
| UnitCode | varchar(20) | No |  |
| VendorItemCode | varchar(50) | No |  |
| UserNbr | int | No |  |
| Attention | varchar(50) | No |  |
| VendorName | varchar(50) | No |  |
| DistrictVendorCode | varchar(20) | No |  |
| VendorsAccountCode | varchar(50) | No |  |
| CatalogName | varchar(50) | No |  |



### dbo.vw_KeywordsByBid



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| KeywordId | int | No |  |
| Keyword | varchar(50) | No |  |



### dbo.vw_KeywordsByReqHeading



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| HeadingId | int | No |  |
| KeywordId | int | No |  |
| Keyword | varchar(50) | Yes |  |



### dbo.vw_LastBidAwardDate



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| LastAwardDate | varchar(30) | No |  |
| LastAwardDateSort | varchar(30) | No |  |



### dbo.vw_LatestCrossRef



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| ItemId | int | Yes |  |
| CrossRefId | int | No |  |
| CatalogYear | char(2) | Yes |  |
| CatalogPrice | money | Yes |  |



### dbo.vw_LowestPrice



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| BidRequestItemId | int | No |  |
| BidResultsId | int | No |  |
| BidPrice | decimal(34,13) | Yes |  |



### dbo.vw_MPIHeadings



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| HeadingId | bigint | Yes |  |
| HeadingTitle | varchar(308) | Yes |  |



### dbo.vw_MSRPBidReqManufacturer



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidRequestManufacturerId | int | No |  |
| Active | tinyint | Yes |  |
| BidHeaderId | int | Yes |  |
| ManufacturerId | int | Yes |  |
| SequenceNumber | int | Yes |  |
| AllowAdditionalProductLines | tinyint | Yes |  |
| UseOptions | tinyint | Yes |  |
| Name | varchar(100) | No |  |



### dbo.vw_MSRPBidReqManufacturerWriteIn



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidRequestManufacturerId | int | No |  |
| Active | tinyint | Yes |  |
| BidHeaderId | int | Yes |  |
| ManufacturerId | int | Yes |  |
| SequenceNumber | int | Yes |  |
| AllowAdditionalProductLines | tinyint | Yes |  |
| UseOptions | tinyint | Yes |  |
| Name | varchar(100) | No |  |



### dbo.vw_MSRPBidReqProdLineAndOption



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| BidRequestManufacturerId | int | No |  |
| ManufacturerId | int | Yes |  |
| ManufacturerName | varchar(100) | Yes |  |
| BidRequestProductLineId | int | No |  |
| ManufacturerProductLineId | int | Yes |  |
| ProductLineName | varchar(100) | Yes |  |
| BidRequestoptionId | int | No |  |
| OptionName | varchar(50) | Yes |  |
| SortKey | varchar(512) | Yes |  |



### dbo.vw_MSRPBidReqProdLineAndOptionWriteIn



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| BidRequestManufacturerId | int | No |  |
| ManufacturerId | int | Yes |  |
| ManufacturerName | varchar(100) | Yes |  |
| BidRequestProductLineId | int | No |  |
| ManufacturerProductLineId | int | Yes |  |
| ProductLineName | varchar(100) | Yes |  |
| BidRequestoptionId | int | No |  |
| OptionName | varchar(50) | Yes |  |
| SortKey | varchar(512) | Yes |  |



### dbo.vw_MSRPBidReqProductLine



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidRequestProductLineId | int | No |  |
| Active | tinyint | Yes |  |
| BidRequestManufacturerId | int | No |  |
| ManufacturerProductLineId | int | Yes |  |
| NameManufProdLine | varchar(100) | No |  |
| AllFlag | int | No |  |



### dbo.vw_MSRPBidResultsManufRev2



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | No |  |
| BidImportId | int | No |  |
| WriteInFlag | tinyint | No |  |
| ManufacturerName | varchar(100) | No |  |
| Active | int | No |  |
| AuthorizationLetter | tinyint | No |  |
| SubmittedExcel | tinyint | No |  |
| ProductCatalog | tinyint | No |  |
| TotalAward | tinyint | No |  |
| VendorPriceFile | tinyint | No |  |
| TotalAwardString | varchar(20) | Yes |  |
| BidMSRPResultsId | int | No |  |
| BidRequestManufacturerId | int | Yes |  |
| ManufacturerId | int | Yes |  |
| PriceListTypeId | int | No |  |
| WriteInManufacturer | varchar(100) | Yes |  |
| VendorName | varchar(50) | Yes |  |
| ActiveBidImport | tinyint | Yes |  |
| ActiveBidMSRPResults | tinyint | Yes |  |
| TotalAwardDiscount | decimal(9,5) | Yes |  |
| ExcelFileApproved | tinyint | No |  |



### dbo.vw_MSRPBidResultsProdLines



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidMSRPResultsProductLineId | int | No |  |
| BidMSRPResultsId | int | No |  |
| Active | tinyint | Yes |  |
| ProdLineOrWriteIn | varchar(100) | No |  |
| WriteInProductLineFlag | tinyint | Yes |  |
| BidRequestProductLineId | int | Yes |  |
| BidRequestOptionId | int | Yes |  |
| MSRPOptionId | int | Yes |  |
| OptionName | varchar(50) | Yes |  |
| WeightedDiscount | decimal(9,5) | Yes |  |
| Modified | datetime | Yes |  |
| SortKey | varchar(512) | Yes |  |
| ManufacturerProductLineId | int | No |  |



### dbo.vw_MSRPCategoriesBySession



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | No |  |
| CategoryId | int | No |  |
| CategoryName | varchar(50) | Yes |  |
| BidHeaderId | varchar(8000) | Yes |  |



### dbo.vw_MSRPManufacturersBySession



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | No |  |
| VendorId | int | No |  |
| ManufacturerId | int | No |  |
| ManufacturerName | varchar(100) | No |  |
| WebsiteLink | varchar(255) | No |  |
| BidHeaderId | int | Yes |  |
| DiscountRate | decimal(9,5) | Yes |  |
| DiscountRateStr | varchar(32) | Yes |  |
| UpDownStr | varchar(10) | No |  |
| VendorsManufacturerNotes | varchar(1000) | No |  |
| CategoryId | int | No |  |



### dbo.vw_MSRPMPLVendorsCategoriesBySession



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | No |  |
| CategoryId | int | No |  |
| CategoryName | varchar(50) | Yes |  |
| VendorId | int | No |  |
| VendorName | varchar(50) | No |  |
| VendorCode | varchar(16) | No |  |
| ManufacturerId | int | No |  |
| ManufacturerName | varchar(100) | No |  |
| BidHeaderId | int | Yes |  |
| BidAdvertised | datetime | Yes |  |
| BidAwardDate | datetime | Yes |  |
| EffectiveFrom | datetime | Yes |  |
| EffectiveUntil | datetime | Yes |  |
| BidMessage | varchar(1024) | Yes |  |
| HostAwardDate | datetime | Yes |  |
| VendorBidNumber | varchar(50) | Yes |  |
| Comments | varchar(1024) | Yes |  |
| Website | varchar(255) | Yes |  |
| ManufacturersDiscountRate | decimal(9,5) | Yes |  |
| ManufacturersDiscountRateStr | varchar(32) | Yes |  |
| ManufacturersUpDownStr | varchar(9) | No |  |
| Address1 | varchar(50) | Yes |  |
| Address2 | varchar(50) | Yes |  |
| City | varchar(50) | Yes |  |
| State | char(2) | Yes |  |
| Zipcode | varchar(10) | Yes |  |
| VendorContactFullName | varchar(150) | Yes |  |
| VendorContactEMail | varchar(255) | Yes |  |
| VendorContactPhone | varchar(25) | Yes |  |
| VendorContactFax | varchar(20) | Yes |  |
| VendorsManufacturerNotes | varchar(1000) | No |  |
| StateName | varchar(50) | No |  |
| ProductLine | varchar(100) | No |  |
| OptionName | varchar(50) | No |  |
| ProductLineDiscountRate | decimal(9,5) | Yes |  |
| ProductLineDiscountRateStr | varchar(32) | Yes |  |
| ProductLineUpDownStr | varchar(9) | No |  |
| RangeBase | numeric(19,4) | Yes |  |
| RangeTop | numeric(20,4) | Yes |  |
| PriceRangeDiscountRate | decimal(9,5) | Yes |  |
| PriceRangeDiscountRateStr | varchar(32) | Yes |  |
| PriceRangeUpDownStr | varchar(9) | No |  |
| BMAId | int | No |  |
| ManufacturerProductLineId | int | No |  |
| MSRPOptionId | int | No |  |
| BidProductLineId | int | No |  |



### dbo.vw_MSRPMPLVendorsCategoriesReport



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| CategoryId | int | No |  |
| CategoryName | varchar(50) | Yes |  |
| VendorId | int | No |  |
| VendorName | varchar(50) | No |  |
| VendorCode | varchar(16) | No |  |
| ManufacturerId | int | No |  |
| ManufacturerName | varchar(100) | No |  |
| BidHeaderId | int | Yes |  |
| BidAdvertised | datetime | Yes |  |
| BidAwardDate | datetime | Yes |  |
| EffectiveFrom | datetime | Yes |  |
| EffectiveUntil | datetime | Yes |  |
| BidMessage | varchar(1024) | Yes |  |
| HostAwardDate | datetime | Yes |  |
| VendorBidNumber | varchar(50) | Yes |  |
| Comments | varchar(1024) | Yes |  |
| Website | varchar(255) | Yes |  |
| ManufacturersDiscountRate | decimal(9,5) | Yes |  |
| ManufacturersDiscountRateStr | varchar(32) | Yes |  |
| ManufacturersUpDownStr | varchar(9) | No |  |
| Address1 | varchar(50) | Yes |  |
| Address2 | varchar(50) | Yes |  |
| City | varchar(50) | Yes |  |
| State | char(2) | Yes |  |
| Zipcode | varchar(10) | Yes |  |
| VendorContactFullName | varchar(150) | Yes |  |
| VendorContactEMail | varchar(255) | Yes |  |
| VendorContactPhone | varchar(25) | Yes |  |
| VendorContactFax | varchar(20) | Yes |  |
| VendorsManufacturerNotes | varchar(1000) | No |  |
| StateName | varchar(50) | No |  |
| ProductLine | varchar(100) | No |  |
| OptionName | varchar(50) | No |  |
| ProductLineDiscountRate | decimal(9,5) | Yes |  |
| ProductLineDiscountRateStr | varchar(32) | Yes |  |
| ProductLineUpDownStr | varchar(9) | No |  |
| RangeBase | money | Yes |  |
| RangeTop | numeric(20,4) | Yes |  |
| PriceRangeDiscountRate | decimal(9,5) | Yes |  |
| PriceRangeDiscountRateStr | varchar(32) | Yes |  |
| PriceRangeUpDownStr | varchar(9) | No |  |
| BMAId | int | No |  |
| ManufacturerProductLineId | int | No |  |
| MSRPOptionId | int | No |  |
| BidProductLineId | int | No |  |
| HostDistrict | varchar(50) | No |  |
| RangeStr | varchar(43) | Yes |  |
| VendorNameAndAddress | varchar(394) | Yes |  |
| ContactName | varchar(170) | Yes |  |
| AwardType | varchar(10) | No |  |
| ReawardDate | datetime | Yes |  |
| ReawardFrom | datetime | Yes |  |
| ReawardUntil | datetime | Yes |  |
| PricePlanId | int | Yes |  |



### dbo.vw_MSRPMPLVendorsCategoriesReportBC



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| CategoryId | int | No |  |
| CategoryName | varchar(50) | Yes |  |
| VendorId | int | No |  |
| VendorName | varchar(50) | No |  |
| VendorCode | varchar(16) | No |  |
| ManufacturerId | int | No |  |
| ManufacturerName | varchar(100) | No |  |
| BidHeaderId | int | Yes |  |
| BidAdvertised | datetime | Yes |  |
| BidAwardDate | datetime | Yes |  |
| EffectiveFrom | datetime | Yes |  |
| EffectiveUntil | datetime | Yes |  |
| BidMessage | varchar(1024) | Yes |  |
| HostAwardDate | datetime | Yes |  |
| VendorBidNumber | varchar(50) | Yes |  |
| Comments | varchar(1024) | Yes |  |
| Website | varchar(255) | Yes |  |
| ManufacturersDiscountRate | decimal(9,5) | Yes |  |
| ManufacturersDiscountRateStr | varchar(32) | Yes |  |
| ManufacturersUpDownStr | varchar(9) | No |  |
| Address1 | varchar(50) | Yes |  |
| Address2 | varchar(50) | Yes |  |
| City | varchar(50) | Yes |  |
| State | char(2) | Yes |  |
| Zipcode | varchar(10) | Yes |  |
| VendorContactFullName | varchar(150) | Yes |  |
| VendorContactEMail | varchar(255) | Yes |  |
| VendorContactPhone | varchar(25) | Yes |  |
| VendorContactFax | varchar(20) | Yes |  |
| VendorsManufacturerNotes | varchar(1000) | No |  |
| StateName | varchar(50) | No |  |
| ProductLine | varchar(100) | No |  |
| OptionName | varchar(50) | No |  |
| ProductLineDiscountRate | decimal(9,5) | Yes |  |
| ProductLineDiscountRateStr | varchar(32) | Yes |  |
| ProductLineUpDownStr | varchar(9) | No |  |
| RangeBase | money | Yes |  |
| RangeTop | numeric(20,4) | Yes |  |
| PriceRangeDiscountRate | decimal(9,5) | Yes |  |
| PriceRangeDiscountRateStr | varchar(32) | Yes |  |
| PriceRangeUpDownStr | varchar(9) | No |  |
| BMAId | int | No |  |
| ManufacturerProductLineId | int | No |  |
| MSRPOptionId | int | No |  |
| BidProductLineId | int | No |  |
| HostDistrict | varchar(50) | No |  |
| RangeStr | varchar(43) | Yes |  |
| VendorNameAndAddress | varchar(394) | Yes |  |
| ContactName | varchar(170) | Yes |  |
| AwardType | varchar(10) | No |  |
| ReawardDate | datetime | Yes |  |
| ReawardFrom | datetime | Yes |  |
| ReawardUntil | datetime | Yes |  |
| PricePlanId | int | Yes |  |



### dbo.vw_MSRPProductLineExceptions



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| ManufacturerId | int | Yes |  |
| ProductLineExceptions | varchar(8000) | Yes |  |



### dbo.vw_MSRPRankManufacturerAWD



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidMSRPResultsId | int | No |  |
| ManufacturerId | int | Yes |  |
| AverageWeightedDiscount | decimal(38,6) | Yes |  |



### dbo.vw_MSRPRankOptionAWD



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidMSRPResultsId | int | No |  |
| BidMSRPResultsProductLineId | int | No |  |
| BidRequestOptionId | int | Yes |  |
| BidRequestProductLineId | int | Yes |  |
| ManufacturerProductLineId | int | Yes |  |
| MSRPOptionId | int | Yes |  |
| OptionName | varchar(50) | Yes |  |
| Weight | decimal(9,5) | Yes |  |
| AverageWeightedDiscount | decimal(38,6) | Yes |  |



### dbo.vw_MSRPRankProductLineAWD



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidMSRPResultsId | int | No |  |
| ManufacturerProductLineId | int | Yes |  |
| AverageWeightedDiscount | decimal(38,6) | Yes |  |



### dbo.vw_MSRPRankRequirements



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidMSRPResultsId | int | No |  |
| BidMSRPResultsProductLineId | int | No |  |
| SortKey | varchar(3) | Yes |  |



### dbo.vw_MSRPRankTieBreaker



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidMSRPResultsId | int | No |  |
| BidMSRPResultsProductLineId | int | No |  |
| SortKey | varchar(2) | No |  |



### dbo.vw_MSRPVendorsAndManufacturersByReq



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| BidHeaderId | int | Yes |  |
| VendorId | int | No |  |
| VendorName | varchar(50) | Yes |  |
| ManufacturerId | int | No |  |
| ManufacturerName | varchar(100) | No |  |
| DiscountRate | decimal(9,5) | No |  |
| FullName | varchar(150) | Yes |  |
| Phone | varchar(25) | Yes |  |
| VendorURL | varchar(255) | No |  |
| ManufacturerURL | varchar(255) | Yes |  |



### dbo.vw_MSRPVendorsBidHeaderBySession



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | No |  |
| VendorId | int | No |  |
| VendorName | varchar(50) | No |  |
| VendorCode | varchar(16) | No |  |
| BidHeaderId | int | Yes |  |
| CategoryId | int | No |  |



### dbo.vw_MSRPVendorsCategoriesBySession



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | No |  |
| CategoryId | int | No |  |
| CategoryName | varchar(50) | Yes |  |
| VendorId | int | No |  |
| VendorName | varchar(50) | No |  |
| VendorCode | varchar(16) | No |  |
| ManufacturerId | int | No |  |
| ManufacturerName | varchar(100) | No |  |
| BidHeaderId | int | Yes |  |
| BidAdvertised | datetime | Yes |  |
| BidAwardDate | datetime | Yes |  |
| EffectiveFrom | datetime | Yes |  |
| EffectiveUntil | datetime | Yes |  |
| BidMessage | varchar(1024) | Yes |  |
| HostAwardDate | datetime | Yes |  |
| VendorBidNumber | varchar(50) | Yes |  |
| Comments | varchar(1024) | Yes |  |
| Website | varchar(255) | Yes |  |
| DiscountRate | decimal(9,5) | Yes |  |
| DiscountRateStr | varchar(32) | Yes |  |
| UpDownStr | varchar(9) | No |  |
| Address1 | varchar(50) | Yes |  |
| Address2 | varchar(50) | Yes |  |
| City | varchar(50) | Yes |  |
| State | char(2) | Yes |  |
| Zipcode | varchar(10) | Yes |  |
| VendorContactFullName | varchar(150) | Yes |  |
| VendorContactEMail | varchar(255) | Yes |  |
| VendorContactPhone | varchar(25) | Yes |  |
| VendorContactFax | varchar(20) | Yes |  |
| VendorsManufacturerNotes | varchar(1000) | No |  |
| StateName | varchar(50) | No |  |



### dbo.vw_MultiVendorPODistrictsAndBudgets



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictId | int | No |  |
| BudgetId | int | No |  |
| VendorSessionId | int | No |  |
| DistrictName | varchar(50) | Yes |  |
| BudgetName | varchar(30) | Yes |  |
| VendorsAccountCode | varchar(50) | No |  |
| BudgetFilterId | int | Yes |  |
| CurrentBidPOCount | int | Yes |  |



### dbo.vw_NJDistricts



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictId | int | No |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| NameAndAddress | varchar(1024) | Yes |  |
| BAName | varchar(50) | No |  |
| PhoneNumber | varchar(20) | Yes |  |
| County | varchar(50) | No |  |
| CSRepName | varchar(30) | No |  |



### dbo.vw_NY_TM_Districts



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| Name | varchar(50) | Yes |  |
| FullName | varchar(174) | No |  |
| Email | varchar(255) | No |  |
| Description | varchar(50) | No |  |
| Address1 | varchar(50) | No |  |
| City | varchar(50) | No |  |
| State | char(2) | No |  |
| Zipcode | varchar(10) | No |  |



### dbo.vw_NY_TM_Districts_Mailing



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| Name | varchar(50) | Yes |  |
| FullName | varchar(174) | Yes |  |
| Address1 | varchar(50) | Yes |  |
| City | varchar(50) | No |  |
| State | varchar(2) | No |  |
| Zipcode | varchar(10) | No |  |



### dbo.vw_OverrideReferences



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| FilterByDetailId | int | No |  |
| DetailId | int | No |  |
| RequisitionNumber | varchar(24) | Yes |  |
| Requisitions_Attention | varchar(50) | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| TotalRequisitionCost | money | Yes |  |
| School_Name | varchar(50) | Yes |  |
| District_Name | varchar(50) | Yes |  |
| CometId | int | Yes |  |
| Status | varchar(104) | No |  |
| CategoryName | varchar(50) | Yes |  |
| ApprovalDate | datetime | Yes |  |



### dbo.vw_OverrideVendorBidders



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DetailId | int | No |  |
| Active | int | Yes |  |
| BidResultsId | int | No |  |
| BidPrice | decimal(34,13) | Yes |  |
| VendorName | varchar(69) | No |  |
| ItemBidType | varchar(13) | No |  |
| VendorItemCode | varchar(50) | Yes |  |
| Alternate | varchar(512) | Yes |  |
| VendorDescription | varchar(1497) | Yes |  |
| PageNumber | varchar(30) | No |  |
| UOM | varchar(16) | No |  |
| Original | varchar(18) | No |  |
| VOMId | int | Yes |  |
| Comments | varchar(1024) | No |  |
| SortKey | varchar(16) | Yes |  |



### dbo.vw_PendingDetailChangeNotifications



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DetailNotificationId | bigint | No |  |
| DetailId | bigint | No |  |
| NotificationId | bigint | Yes |  |
| DateCreated | datetime | No |  |
| OrigItemId | int | Yes |  |
| NewItemId | int | Yes |  |
| OrigVendorId | int | Yes |  |
| NewVendorId | int | Yes |  |
| OrigBidPrice | decimal(11,5) | Yes |  |
| NewBidPrice | decimal(11,5) | Yes |  |
| ReqUserId | int | Yes |  |
| ApprovalById | int | Yes |  |
| NotificationType | varchar(8) | No |  |
| Email | varchar(255) | No |  |



### dbo.vw_PLBidItems



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| ItemId | int | No |  |
| BidHeaderId | int | Yes |  |
| BidId | int | No |  |
| BidItemId | int | No |  |
| CrossRefId | int | Yes |  |
| AwardId | int | No |  |



### dbo.vw_PLCatalog



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| ItemId | int | No |  |
| BidHeaderId | int | Yes |  |
| BidId | int | No |  |
| BidItemId | int | Yes |  |
| CrossRefId | int | No |  |
| AwardId | int | No |  |



### dbo.vw_POHeaderBidImports



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| POId | int | Yes |  |
| BidImportId | int | Yes |  |
| VendorId | int | Yes |  |
| BidType | int | No |  |



### dbo.vw_POStatus



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| POId | int | No |  |
| AwardsBidHeaderId | int | Yes |  |
| CategoryId | int | Yes |  |
| RequisitionId | int | No |  |
| SchoolId | int | No |  |
| VendorId | int | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| Amount | money | Yes |  |
| Attention | varchar(50) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| ExportedToVendor | datetime | Yes |  |
| ItemCount | int | Yes |  |
| PONumber | varchar(24) | Yes |  |
| RequisitionNumber | varchar(24) | Yes |  |
| SchoolName | varchar(50) | Yes |  |
| POStatus | varchar(125) | Yes |  |
| VendorName | varchar(50) | Yes |  |
| CometId | int | Yes |  |



### dbo.vw_POStatus_Test



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| POId | int | No |  |
| AwardsBidHeaderId | int | Yes |  |
| CategoryId | int | Yes |  |
| RequisitionId | int | No |  |
| SchoolId | int | No |  |
| VendorId | int | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| Amount | money | Yes |  |
| Attention | varchar(50) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| ExportedToVendor | datetime | Yes |  |
| ItemCount | int | Yes |  |
| PONumber | varchar(24) | Yes |  |
| RequisitionNumber | varchar(24) | Yes |  |
| SchoolName | varchar(50) | Yes |  |
| POStatus | varchar(125) | Yes |  |
| VendorName | varchar(50) | Yes |  |
| CometId | int | Yes |  |



### dbo.vw_PricePlanFilter



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| PricePlanId | int | No |  |
| Code | varchar(20) | Yes |  |
| Description | varchar(255) | Yes |  |



### dbo.vw_RefList



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictName | varchar(50) | Yes |  |
| Budgetname | varchar(30) | Yes |  |
| SchoolName | varchar(50) | Yes |  |
| CometId | int | Yes |  |
| Attention | varchar(50) | Yes |  |
| ItemCode | varchar(50) | Yes |  |
| VendorItemCode | varchar(50) | No |  |
| Quantity | int | Yes |  |
| BidPrice | money | Yes |  |
| description | varchar(1024) | Yes |  |
| ItemBidType | varchar(32) | No |  |
| Alternate | varchar(1024) | No |  |
| ReqStatus | varchar(255) | Yes |  |
| POId | int | No |  |
| PONumber | varchar(24) | No |  |
| ExportedToVendor | datetime | Yes |  |
| BidHeaderId | int | Yes |  |
| Category Name | varchar(50) | Yes |  |
| Account Code | varchar(50) | No |  |
| Account Balance | varchar(30) | Yes |  |
| BudgetId | int | No |  |
| DistrictId | int | No |  |
| RequisitionId | int | No |  |
| detailId | int | No |  |
| ItemId | int | Yes |  |
| CategoryId | int | Yes |  |
| UserId | int | No |  |
| BidItemId | int | Yes |  |
| VendorId | int | Yes |  |
| SortSeq | varchar(64) | Yes |  |
| LastYearsQuantity | int | Yes |  |
| ItemMustBeBid | int | No |  |
| RequisitionNumber | varchar(24) | Yes |  |
| UniqueItemNumber | varchar(50) | Yes |  |



### dbo.vw_RepsDistricts



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| Active | tinyint | No |  |
| DistrictId | int | No |  |
| DistrictCode | varchar(4) | No |  |
| DistrictName | varchar(50) | No |  |
| BAName | varchar(50) | No |  |
| Phone | varchar(20) | No |  |
| Fax | varchar(20) | No |  |
| CSRepId | int | No |  |



### dbo.vw_ReqBidReview



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RSId | int | Yes |  |
| RepName | varchar(30) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| SchoolName | varchar(50) | Yes |  |
| ShipName | varchar(50) | Yes |  |
| CometId | int | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| BudgetName | varchar(30) | Yes |  |
| BidHeaderId | int | Yes |  |
| RequisitionNumber | varchar(24) | Yes |  |
| Attention | varchar(50) | Yes |  |
| TotalRequisitionCost | money | Yes |  |
| ItemCount | int | Yes |  |
| ItemCode | varchar(50) | Yes |  |
| Description | varchar(1024) | Yes |  |
| Quantity | int | Yes |  |
| BidPrice | money | Yes |  |
| UnitCode | varchar(20) | Yes |  |
| ItemStatus | varchar(65) | No |  |



### dbo.vw_ReqCategories



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| CategoryId | int | No |  |
| Name | varchar(50) | Yes |  |



### dbo.vw_ReqDetail



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DetailId | int | No |  |
| ItemId | int | Yes |  |
| ItemCode | varchar(50) | No |  |
| Quantity | int | No |  |
| LastYearsQuantity | int | No |  |
| Description | nvarchar(MAX) | Yes |  |
| LongDescription | nvarchar(MAX) | Yes |  |
| UnitCode | varchar(20) | No |  |
| BidPrice | money | No |  |
| Extended | money | No |  |
| LastAlteredSessionID | int | No |  |
| VendorName | varchar(50) | Yes |  |
| VendorCode | varchar(16) | No |  |
| CatalogName | varchar(50) | No |  |
| AltDescription | varchar(1024) | No |  |
| VendorItemCode | varchar(50) | Yes |  |
| CatalogPage | char(4) | Yes |  |
| NoBid | int | No |  |
| ItemMustBeBid | int | No |  |
| BidInfo | varchar(53) | Yes |  |
| HasBeenBid | int | No |  |
| AllowOverride | int | No |  |
| VendorOverridden | int | No |  |
| ItemBidType | varchar(32) | Yes |  |
| SortSeq | varchar(64) | Yes |  |
| RequisitionId | int | No |  |
| AddendumAdded | tinyint | No |  |
| MostPopular | int | No |  |
| TabSelection | varchar(7) | No |  |
| AddedFromAddenda | datetime | Yes |  |
| VendorID | int | Yes |  |
| UnitId | int | Yes |  |
| HeadingID | int | Yes |  |
| KeywordID | int | Yes |  |
| BrandName | varchar(50) | Yes |  |
| ManufacturerId | int | Yes |  |
| ManufacturorNumber | varchar(50) | Yes |  |
| VendorPartNumber | varchar(50) | Yes |  |
| ListPrice | money | Yes |  |
| ItemsPerUnit | varchar(50) | Yes |  |
| Items_VendorID | int | Yes |  |
| VendorToSupplyManufacturer | tinyint | Yes |  |
| ExtraDescription | varchar(1024) | Yes |  |
| DateAvailable | datetime | Yes |  |
| Modified | datetime | Yes |  |
| BidStatus | varchar(14) | No |  |
| BaseDescription | varchar(512) | No |  |
| SortKey | datetime | Yes |  |
| BidHeaderId | int | Yes |  |
| CatalogRefs | varchar(1) | No |  |
| BidderToSupplyVendor | tinyint | Yes |  |
| BidderToSupplyVendorPartNbr | tinyint | Yes |  |
| DistrictVendorCode | varchar(20) | No |  |
| VendorsAccountCode | varchar(50) | No |  |
| VendorBidInfo | varchar(576) | Yes |  |
| BidItemId | int | Yes |  |
| BelowMinimumItem | int | No |  |
| MinimumPOAmount | money | No |  |
| AdditionalShipping | tinyint | No |  |
| SDSAvail | int | Yes |  |
| ShortDescription | nvarchar(MAX) | Yes |  |
| ImageURL | varchar(1024) | Yes |  |
| ShippingCost | decimal(9,2) | Yes |  |
| ShippingUpdateRequired | int | No |  |
| DeliveryDate | nvarchar(4000) | Yes |  |
| PerishableItem | bit | Yes |  |
| DoctorsName | varchar(100) | Yes |  |
| DEANumber | varchar(9) | Yes |  |
| PrescriptionRequired | bit | Yes |  |
| DigitallyDelivered | tinyint | Yes |  |
| DigitallyDeliveredEmail | varchar(255) | Yes |  |
| MinimumOrderQuantity | int | Yes |  |
| CrossRefId | int | Yes |  |
| UserId | int | Yes |  |
| SchoolId | int | Yes |  |
| DistrictId | int | Yes |  |
| BudgetId | int | No |  |
| SDSURL | varchar(512) | Yes |  |
| ManufacturorNumberDetail | varchar(50) | Yes |  |
| BrandNameDetail | varchar(50) | Yes |  |
| OrderedYear | int | Yes |  |



### dbo.vw_ReqDetail_BK20241205



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DetailId | int | No |  |
| ItemId | int | Yes |  |
| ItemCode | varchar(50) | No |  |
| Quantity | int | No |  |
| LastYearsQuantity | int | No |  |
| Description | nvarchar(MAX) | Yes |  |
| LongDescription | nvarchar(MAX) | Yes |  |
| UnitCode | varchar(20) | No |  |
| BidPrice | money | No |  |
| Extended | money | No |  |
| LastAlteredSessionID | int | No |  |
| VendorName | varchar(50) | Yes |  |
| VendorCode | varchar(16) | No |  |
| CatalogName | varchar(50) | No |  |
| AltDescription | varchar(1024) | No |  |
| VendorItemCode | varchar(50) | Yes |  |
| CatalogPage | char(4) | Yes |  |
| NoBid | int | No |  |
| ItemMustBeBid | int | No |  |
| BidInfo | varchar(53) | Yes |  |
| HasBeenBid | int | No |  |
| AllowOverride | int | No |  |
| VendorOverridden | int | No |  |
| ItemBidType | varchar(32) | Yes |  |
| SortSeq | varchar(64) | Yes |  |
| RequisitionId | int | No |  |
| AddendumAdded | tinyint | No |  |
| MostPopular | int | No |  |
| TabSelection | varchar(7) | No |  |
| AddedFromAddenda | datetime | Yes |  |
| VendorID | int | Yes |  |
| UnitId | int | Yes |  |
| HeadingID | int | Yes |  |
| KeywordID | int | Yes |  |
| BrandName | varchar(50) | Yes |  |
| ManufacturerId | int | Yes |  |
| ManufacturorNumber | varchar(50) | Yes |  |
| VendorPartNumber | varchar(50) | Yes |  |
| ListPrice | money | Yes |  |
| ItemsPerUnit | varchar(50) | Yes |  |
| Items_VendorID | int | Yes |  |
| VendorToSupplyManufacturer | tinyint | Yes |  |
| ExtraDescription | varchar(1024) | Yes |  |
| DateAvailable | datetime | Yes |  |
| Modified | datetime | Yes |  |
| BidStatus | varchar(14) | No |  |
| BaseDescription | varchar(512) | No |  |
| SortKey | datetime | Yes |  |
| BidHeaderId | int | Yes |  |
| CatalogRefs | varchar(1) | No |  |
| BidderToSupplyVendor | tinyint | Yes |  |
| BidderToSupplyVendorPartNbr | tinyint | Yes |  |
| DistrictVendorCode | varchar(20) | No |  |
| VendorsAccountCode | varchar(50) | No |  |
| VendorBidInfo | varchar(576) | Yes |  |
| BidItemId | int | Yes |  |
| BelowMinimumItem | int | No |  |
| MinimumPOAmount | money | No |  |
| AdditionalShipping | tinyint | No |  |
| SDSAvail | int | Yes |  |
| ShortDescription | nvarchar(MAX) | Yes |  |
| ImageURL | varchar(1024) | Yes |  |
| ShippingCost | decimal(9,2) | Yes |  |
| ShippingUpdateRequired | int | No |  |
| DeliveryDate | nvarchar(4000) | Yes |  |
| PerishableItem | bit | Yes |  |
| DoctorsName | varchar(100) | Yes |  |
| DEANumber | varchar(9) | Yes |  |
| PrescriptionRequired | bit | Yes |  |



### dbo.vw_ReqDetail_BK20241227



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DetailId | int | No |  |
| ItemId | int | Yes |  |
| ItemCode | varchar(50) | No |  |
| Quantity | int | No |  |
| LastYearsQuantity | int | No |  |
| Description | nvarchar(MAX) | Yes |  |
| LongDescription | nvarchar(MAX) | Yes |  |
| UnitCode | varchar(20) | No |  |
| BidPrice | money | No |  |
| Extended | money | No |  |
| LastAlteredSessionID | int | No |  |
| VendorName | varchar(50) | Yes |  |
| VendorCode | varchar(16) | No |  |
| CatalogName | varchar(50) | No |  |
| AltDescription | varchar(1024) | No |  |
| VendorItemCode | varchar(50) | Yes |  |
| CatalogPage | char(4) | Yes |  |
| NoBid | int | No |  |
| ItemMustBeBid | int | No |  |
| BidInfo | varchar(53) | Yes |  |
| HasBeenBid | int | No |  |
| AllowOverride | int | No |  |
| VendorOverridden | int | No |  |
| ItemBidType | varchar(32) | Yes |  |
| SortSeq | varchar(64) | Yes |  |
| RequisitionId | int | No |  |
| AddendumAdded | tinyint | No |  |
| MostPopular | int | No |  |
| TabSelection | varchar(7) | No |  |
| AddedFromAddenda | datetime | Yes |  |
| VendorID | int | Yes |  |
| UnitId | int | Yes |  |
| HeadingID | int | Yes |  |
| KeywordID | int | Yes |  |
| BrandName | varchar(50) | Yes |  |
| ManufacturerId | int | Yes |  |
| ManufacturorNumber | varchar(50) | Yes |  |
| VendorPartNumber | varchar(50) | Yes |  |
| ListPrice | money | Yes |  |
| ItemsPerUnit | varchar(50) | Yes |  |
| Items_VendorID | int | Yes |  |
| VendorToSupplyManufacturer | tinyint | Yes |  |
| ExtraDescription | varchar(1024) | Yes |  |
| DateAvailable | datetime | Yes |  |
| Modified | datetime | Yes |  |
| BidStatus | varchar(14) | No |  |
| BaseDescription | varchar(512) | No |  |
| SortKey | datetime | Yes |  |
| BidHeaderId | int | Yes |  |
| CatalogRefs | varchar(1) | No |  |
| BidderToSupplyVendor | tinyint | Yes |  |
| BidderToSupplyVendorPartNbr | tinyint | Yes |  |
| DistrictVendorCode | varchar(20) | No |  |
| VendorsAccountCode | varchar(50) | No |  |
| VendorBidInfo | varchar(576) | Yes |  |
| BidItemId | int | Yes |  |
| BelowMinimumItem | int | No |  |
| MinimumPOAmount | money | No |  |
| AdditionalShipping | tinyint | No |  |
| SDSAvail | int | Yes |  |
| ShortDescription | nvarchar(MAX) | Yes |  |
| ImageURL | varchar(1024) | Yes |  |
| ShippingCost | decimal(9,2) | Yes |  |
| ShippingUpdateRequired | int | No |  |
| DeliveryDate | nvarchar(4000) | Yes |  |
| PerishableItem | bit | Yes |  |
| DoctorsName | varchar(100) | Yes |  |
| DEANumber | varchar(9) | Yes |  |
| PrescriptionRequired | bit | Yes |  |
| DigitallyDelivered | tinyint | Yes |  |
| DigitallyDeliveredEmail | varchar(255) | Yes |  |
| UserId | int | Yes |  |
| SchoolId | int | Yes |  |
| DistrictId | int | Yes |  |
| SDS_URL | varchar(300) | Yes |  |
| ManufacturorNumberDetail | varchar(50) | Yes |  |
| BrandNameDetail | varchar(50) | Yes |  |
| OrderedYear | int | Yes |  |



### dbo.vw_ReqDetail1



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DetailId | int | No |  |
| ItemId | int | Yes |  |
| ItemCode | varchar(50) | No |  |
| Quantity | int | No |  |
| LastYearsQuantity | int | No |  |
| Description | nvarchar(MAX) | Yes |  |
| UnitCode | varchar(20) | No |  |
| BidPrice | money | No |  |
| Extended | money | No |  |
| SessionId | int | No |  |
| VendorName | varchar(50) | No |  |
| VendorCode | varchar(16) | No |  |
| CatalogName | varchar(50) | No |  |
| AltDescription | varchar(1024) | No |  |
| VendorItemCode | varchar(50) | Yes |  |
| CatalogPage | char(4) | Yes |  |
| NoBid | int | No |  |
| ItemMustBeBid | int | No |  |
| BidInfo | varchar(53) | Yes |  |
| HasBeenBid | int | No |  |
| AllowOverride | int | No |  |
| VendorOverridden | int | No |  |
| ItemBidType | varchar(32) | Yes |  |
| SortSeq | varchar(64) | Yes |  |
| RequisitionId | int | No |  |
| AddendumAdded | tinyint | No |  |
| MostPopular | int | No |  |
| TabSelection | varchar(7) | No |  |
| AddedFromAddenda | datetime | Yes |  |
| VendorID | int | Yes |  |
| UnitId | int | Yes |  |
| HeadingID | int | Yes |  |
| KeywordID | int | Yes |  |
| BrandName | varchar(50) | Yes |  |
| ManufacturorNumber | varchar(50) | Yes |  |
| VendorPartNumber | varchar(50) | Yes |  |
| ListPrice | money | Yes |  |
| ItemsPerUnit | varchar(50) | Yes |  |
| Items_VendorID | int | Yes |  |
| ExtraDescription | varchar(1024) | Yes |  |
| DateAvailable | datetime | Yes |  |
| BidStatus | varchar(14) | No |  |
| BaseDescription | varchar(512) | No |  |
| SortKey | datetime | Yes |  |
| UserId | int | Yes |  |
| SchoolId | int | Yes |  |
| DistrictId | int | Yes |  |
| PageList | varchar(8000) | Yes |  |



### dbo.vw_ReqDetailAsp1



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | Yes |  |
| DetailId | int | No |  |
| ItemId | int | Yes |  |
| ItemCode | varchar(50) | No |  |
| Quantity | int | No |  |
| LastYearsQuantity | int | No |  |
| Description | varchar(4480) | Yes |  |
| UnitCode | varchar(20) | No |  |
| BidPrice | money | No |  |
| Extended | money | No |  |
| SessionId | int | No |  |
| VendorName | varchar(50) | No |  |
| VendorCode | varchar(16) | No |  |
| CatalogName | varchar(50) | No |  |
| AltDescription | varchar(1024) | No |  |
| VendorItemCode | varchar(50) | Yes |  |
| CatalogPage | char(4) | Yes |  |
| NoBid | int | No |  |
| ItemMustBeBid | int | No |  |
| BidInfo | varchar(51) | Yes |  |
| HasBeenBid | int | No |  |
| AllowOverride | int | No |  |
| VendorOverridden | int | No |  |
| ItemBidType | varchar(32) | Yes |  |
| SortSeq | varchar(64) | Yes |  |
| CatalogRefs | varchar(8000) | Yes |  |
| AllowDescriptionModify | int | No |  |



### dbo.vw_ReqDetailPrint



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| Alternate | varchar(2050) | Yes |  |
| BidItemId | int | No |  |
| BidPrice | money | No |  |
| CatalogPage | char(4) | No |  |
| CatalogPrice | money | No |  |
| ShortDescription | varchar(1024) | No |  |
| ExtraDescription | varchar(1024) | No |  |
| ItemCode | varchar(50) | No |  |
| Quantity | int | No |  |
| RequisitionId | int | No |  |
| SortSeq | varchar(64) | No |  |
| UnitCode | varchar(20) | No |  |
| VendorItemCode | varchar(50) | No |  |
| ItemBidType | varchar(16) | No |  |
| ExtendedBidPrice | decimal(20,4) | Yes |  |
| AccountCode | varchar(50) | No |  |
| Attention | varchar(50) | No |  |
| DateEntered | datetime | No |  |
| RequisitionNumber | varchar(24) | No |  |
| ShippingCost | money | No |  |
| TotalItemsCost | money | No |  |
| TotalRequisitionCost | money | No |  |
| CategoryName | varchar(50) | Yes |  |
| BudgetName | varchar(30) | No |  |
| DistrictName | varchar(50) | No |  |
| DistrictCode | varchar(4) | No |  |
| ShipToName | varchar(50) | No |  |
| ShipToAddress1 | varchar(30) | No |  |
| ShipToAddress2 | varchar(30) | No |  |
| ShipToAddress3 | varchar(30) | No |  |
| ShipToCity | varchar(25) | No |  |
| ShipToState | varchar(2) | No |  |
| ShipToZipcode | varchar(10) | No |  |
| UserNumber | int | No |  |
| BidHeaderId | int | No |  |
| BidMsg | varchar(583) | Yes |  |
| FreeHandlingAmount | money | No |  |
| HandlingAmount | money | No |  |
| FreeHandlingStart | datetime | No |  |
| FreeHandlingEnd | datetime | No |  |
| VendorId | int | No |  |
| VendorCode | varchar(16) | No |  |
| VendorName | varchar(50) | No |  |
| VendorContactName | varchar(150) | No |  |
| VendorContactAddress1 | varchar(50) | No |  |
| VendorContactAddress2 | varchar(50) | No |  |
| VendorContactCity | varchar(50) | No |  |
| VendorContactState | char(2) | No |  |
| VendorContactZip | varchar(10) | No |  |
| VendorContactPhone | varchar(25) | No |  |
| VendorContactFax | varchar(20) | No |  |
| VendorContactEmail | varchar(255) | No |  |
| VendorBidNumber | varchar(50) | No |  |
| VendorAwardMsg | varchar(511) | No |  |
| DistrictVendorCode | varchar(20) | No |  |
| VendorsAccountCode | varchar(50) | No |  |
| FullDescription | varchar(8000) | Yes |  |
| FullVendorInfo | varchar(726) | Yes |  |
| FullDistrictInfo | varchar(420) | No |  |
| FullShipToInfo | varchar(315) | Yes |  |
| CompliantAlert | tinyint | No |  |
| SortKey | varchar(121) | Yes |  |
| SortVendorKey | varchar(51) | Yes |  |
| BidType | tinyint | No |  |
| PrintBidAs | tinyint | No |  |
| ItemsNotBid | int | No |  |
| BidsThisVendor | int | No |  |
| BelowMinimum | int | No |  |
| AdditionalShipping | int | Yes |  |



### dbo.vw_ReqDetailPrintTest



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| Alternate | varchar(2050) | Yes |  |
| BidItemId | int | No |  |
| BidPrice | money | No |  |
| CatalogPage | char(4) | No |  |
| CatalogPrice | money | No |  |
| ShortDescription | varchar(1024) | No |  |
| ExtraDescription | varchar(1024) | No |  |
| ItemCode | varchar(50) | No |  |
| Quantity | int | No |  |
| RequisitionId | int | No |  |
| SortSeq | varchar(64) | No |  |
| UnitCode | varchar(20) | No |  |
| VendorItemCode | varchar(50) | No |  |
| ItemBidType | varchar(16) | No |  |
| ExtendedBidPrice | decimal(20,4) | Yes |  |
| AccountCode | varchar(50) | No |  |
| Attention | varchar(50) | No |  |
| DateEntered | datetime | No |  |
| RequisitionNumber | varchar(24) | No |  |
| ShippingCost | money | No |  |
| TotalItemsCost | money | No |  |
| TotalRequisitionCost | money | No |  |
| CategoryName | varchar(50) | Yes |  |
| BudgetName | varchar(30) | No |  |
| DistrictName | varchar(50) | No |  |
| DistrictCode | varchar(4) | No |  |
| ShipToName | varchar(50) | No |  |
| ShipToAddress1 | varchar(30) | No |  |
| ShipToAddress2 | varchar(30) | No |  |
| ShipToAddress3 | varchar(30) | No |  |
| ShipToCity | varchar(25) | No |  |
| ShipToState | varchar(2) | No |  |
| ShipToZipcode | varchar(10) | No |  |
| UserNumber | int | No |  |
| BidHeaderId | int | No |  |
| BidMsg | varchar(583) | Yes |  |
| FreeHandlingAmount | money | No |  |
| HandlingAmount | money | No |  |
| FreeHandlingStart | datetime | No |  |
| FreeHandlingEnd | datetime | No |  |
| VendorId | int | No |  |
| VendorCode | varchar(16) | No |  |
| VendorName | varchar(50) | No |  |
| VendorContactName | varchar(150) | No |  |
| VendorContactAddress1 | varchar(50) | No |  |
| VendorContactAddress2 | varchar(50) | No |  |
| VendorContactCity | varchar(50) | No |  |
| VendorContactState | char(2) | No |  |
| VendorContactZip | varchar(10) | No |  |
| VendorContactPhone | varchar(25) | No |  |
| VendorContactFax | varchar(20) | No |  |
| VendorContactEmail | varchar(255) | No |  |
| VendorBidNumber | varchar(50) | No |  |
| VendorAwardMsg | varchar(511) | No |  |
| DistrictVendorCode | varchar(20) | No |  |
| VendorsAccountCode | varchar(50) | No |  |
| FullDescription | nvarchar(MAX) | Yes |  |
| FullVendorInfo | varchar(726) | Yes |  |
| FullDistrictInfo | varchar(420) | No |  |
| FullShipToInfo | varchar(315) | Yes |  |
| CompliantAlert | tinyint | No |  |
| SortKey | varchar(121) | Yes |  |
| SortVendorKey | varchar(51) | Yes |  |
| BidType | tinyint | No |  |
| PrintBidAs | tinyint | No |  |
| ItemsNotBid | int | No |  |
| BidsThisVendor | int | No |  |
| BelowMinimum | int | No |  |
| AdditionalShipping | int | Yes |  |



### dbo.vw_ReqDetail-removed 12082010



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DetailId | int | No |  |
| ItemId | int | Yes |  |
| ItemCode | varchar(50) | No |  |
| Quantity | int | No |  |
| LastYearsQuantity | int | No |  |
| Description | varchar(3650) | Yes |  |
| UnitCode | varchar(20) | No |  |
| BidPrice | money | No |  |
| Extended | money | No |  |
| SessionId | int | No |  |
| VendorName | varchar(50) | No |  |
| VendorCode | varchar(16) | No |  |
| CatalogName | varchar(50) | No |  |
| AltDescription | varchar(1024) | No |  |
| VendorItemCode | varchar(50) | No |  |
| CatalogPage | char(4) | Yes |  |
| NoBid | int | No |  |
| ItemMustBeBid | int | No |  |
| BidInfo | varchar(51) | Yes |  |
| HasBeenBid | int | No |  |
| AllowOverride | int | No |  |
| VendorOverridden | int | No |  |
| ItemBidType | varchar(32) | Yes |  |
| SortSeq | varchar(64) | Yes |  |
| RequisitionId | int | No |  |



### dbo.vw_ReqDetailSummary



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionNumber | varchar(24) | No |  |
| DateEntered | datetime | No |  |
| TotalRequisitionCost | money | No |  |
| TotalItemsCost | money | No |  |
| ShippingCost | money | No |  |
| CategoryName | varchar(50) | No |  |
| AccountCode | varchar(50) | No |  |
| BudgetName | varchar(30) | No |  |
| BidHeaderId | int | No |  |
| BidMsg | varchar(583) | Yes |  |
| FreeHandlingStart | datetime | No |  |
| FreeHandlingEnd | datetime | No |  |
| FreeHandlingAmount | money | No |  |
| HandlingAmount | money | No |  |
| RequisitionId | int | No |  |
| VendorId | int | No |  |
| VendorCode | varchar(16) | No |  |
| VendorName | varchar(50) | No |  |
| VendorBidNumber | varchar(50) | No |  |
| DistrictVendorCode | varchar(20) | No |  |
| VendorsAccountCode | varchar(50) | No |  |
| FullDistrictInfo | varchar(420) | No |  |
| FullShipToInfo | varchar(315) | Yes |  |
| Lines | int | Yes |  |
| TotalQuantity | int | Yes |  |
| TotalBidCost | decimal(38,4) | Yes |  |
| BidsThisVendor | int | No |  |
| SortVendorKey | varchar(51) | Yes |  |
| AdditionalShippingItems | int | Yes |  |



### dbo.vw_ReqDetailTab



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DetailId | int | No |  |
| RequisitionId | int | Yes |  |
| Quantity | int | Yes |  |
| BidPrice | money | Yes |  |
| TabSelection | varchar(7) | No |  |



### dbo.vw_Reqs_Assoc_With_Bid



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| DistrictId | int | No |  |
| RequisitionId | int | No |  |
| ApprovalsStatusId | int | No |  |
| WaitingBidReadyFlag | int | No |  |



### dbo.vw_ReqTotalsByVendor



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| VendorCode | varchar(16) | Yes |  |
| VendorName | varchar(50) | Yes |  |
| AdditionalHandlingAmount | money | No |  |
| FreeHandlingAmount | money | No |  |
| FreeHandlingStart | datetime | Yes |  |
| FreeHandlingEnd | datetime | Yes |  |
| HandlingAmount | money | No |  |
| VendorTotal | decimal(38,2) | Yes |  |
| ItemsTotal | money | Yes |  |
| POBelowMinimum | int | No |  |
| MinimumPOAmount | money | No |  |
| AdditionalShipping | tinyint | Yes |  |
| TotalShippingCost | decimal(38,2) | Yes |  |
| UpdateRequired | int | Yes |  |



### dbo.vw_ReqTotalsByVendorTest



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| VendorCode | varchar(16) | Yes |  |
| VendorName | varchar(50) | Yes |  |
| AdditionalHandlingAmount | money | No |  |
| FreeHandlingAmount | money | No |  |
| FreeHandlingStart | datetime | Yes |  |
| FreeHandlingEnd | datetime | Yes |  |
| HandlingAmount | money | No |  |
| VendorTotal | money | Yes |  |
| ItemsTotal | money | Yes |  |



### dbo.vw_RequisitionAccountBalance



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| AccountCode | varchar(50) | Yes |  |
| UseAllocations | int | No |  |
| AmountAvailable | varchar(30) | Yes |  |



### dbo.vw_RequisitionCatalogList



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| CatalogId | int | No |  |
| Name | varchar(50) | Yes |  |



### dbo.vw_RequisitionIsVisible



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | No |  |
| RequisitionId | int | No |  |
| IsVisible | int | Yes |  |



### dbo.vw_RequisitionList



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| Tagged | int | No |  |
| SessionId | int | No |  |
| SchoolId | int | Yes |  |
| UserId | int | Yes |  |
| RequisitionId | int | No |  |
| BudgetId | int | Yes |  |
| AccountId | int | Yes |  |
| CategoryId | int | Yes |  |
| TotalRequisitionCost | money | No |  |
| ApprovalLevel | tinyint | No |  |
| StatusId | int | Yes |  |
| LastApprovalId | int | No |  |
| NextApproverId | int | No |  |
| LastApproverId | int | No |  |
| RequisitionNumber | varchar(24) | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| SchoolName | varchar(50) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| Attention | varchar(50) | Yes |  |
| CometId | varchar(5) | Yes |  |
| DateEntered | datetime | Yes |  |
| OrderDate | datetime | Yes |  |
| POCreated | int | No |  |
| BidInfo | varchar(51) | Yes |  |
| Status | varchar(104) | No |  |



### dbo.vw_Requisitions



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| Active | tinyint | Yes |  |
| RequisitionNumber | varchar(24) | Yes |  |
| SchoolId | int | Yes |  |
| UserId | int | Yes |  |
| BudgetId | int | Yes |  |
| BudgetAccountId | int | Yes |  |
| UserAccountId | int | Yes |  |
| CategoryId | int | Yes |  |
| ShippingId | int | Yes |  |
| Attention | varchar(50) | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| DateEntered | datetime | Yes |  |
| ShippingPercent | decimal(9,5) | Yes |  |
| DiscountPercent | decimal(9,5) | Yes |  |
| ShippingCost | money | Yes |  |
| TotalItemsCost | money | Yes |  |
| TotalRequisitionCost | money | Yes |  |
| Comments | varchar(1023) | Yes |  |
| ApprovalRequired | tinyint | Yes |  |
| ApprovalId | int | Yes |  |
| ApprovalLevel | tinyint | Yes |  |
| StatusId | int | Yes |  |
| OrderDate | datetime | Yes |  |
| DateExported | datetime | Yes |  |
| BidId | int | Yes |  |
| BookId | int | Yes |  |
| SourceId | int | Yes |  |
| BidHeaderId | int | Yes |  |
| LastAlteredSessionId | int | Yes |  |
| DateUpdated | datetime | Yes |  |
| OrderType | tinyint | Yes |  |
| NotesCount | int | Yes |  |
| AddendaTotal | money | Yes |  |
| ApprovalCount | int | Yes |  |
| AdditionalShipping | int | Yes |  |
| ShippingUpdateRequired | int | Yes |  |
| AdditionalShippingCost | decimal(38,2) | Yes |  |
| AllowRequestAddenda | tinyint | No |  |
| CSAllowRequestAddenda | tinyint | No |  |



### dbo.vw_RequisitionsAccounts



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| BudgetId | int | Yes |  |
| UserId | int | Yes |  |
| UserAccountId | int | No |  |
| BudgetAccountId | int | Yes |  |
| Code | varchar(77) | Yes |  |



### dbo.vw_RequisitionsCategories



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| CategoryId | int | No |  |
| Name | varchar(69) | Yes |  |



### dbo.vw_RequisitionShippingCosts



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| BidHeaderId | int | Yes |  |
| VendorId | int | No |  |
| VendorName | varchar(50) | Yes |  |
| Extended | money | Yes |  |
| ShippingCost | money | No |  |
| FreeHandlingAmount | money | No |  |
| FreeHandlingStart | datetime | Yes |  |
| FreeHandlingEnd | datetime | Yes |  |
| AdditionalHandlingAmount | money | No |  |
| POBelowMinimum | int | No |  |
| MinimumPOAmount | money | No |  |
| AdditionalShipping | tinyint | Yes |  |
| DistrictVendorCode | varchar(20) | No |  |
| VendorBidInfo | varchar(576) | No |  |
| TotalShippingCost | decimal(38,2) | Yes |  |
| UpdateRequired | int | Yes |  |



### dbo.vw_RequisitionShippingCostsTest



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| BidHeaderId | int | Yes |  |
| VendorId | int | No |  |
| VendorName | varchar(50) | Yes |  |
| Extended | money | Yes |  |
| ShippingCost | money | No |  |
| FreeHandlingAmount | money | No |  |
| FreeHandlingStart | datetime | Yes |  |
| FreeHandlingEnd | datetime | Yes |  |
| AdditionalHandlingAmount | money | No |  |
| POBelowMinimum | int | No |  |
| MinimumPOAmount | money | No |  |
| AdditionalShipping | tinyint | Yes |  |
| DistrictVendorCode | varchar(20) | No |  |
| VendorBidInfo | varchar(576) | No |  |



### dbo.vw_RequisitionsPrint



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| RequisitionNumber | varchar(24) | No |  |
| Attention | varchar(50) | No |  |
| ItemsNotBid | int | No |  |



### dbo.vw_RequisitionsShippingLocations



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| Requisitionid | int | No |  |
| ShippingId | int | No |  |
| Name | varchar(50) | Yes |  |



### dbo.vw_RequisitionStatus



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| StatusId | int | No |  |
| StatusDesc | varchar(104) | No |  |
| StatusCode | int | No |  |
| ApprovalDate | datetime | Yes |  |
| BidStatus | varchar(20) | No |  |
| BaseStatus | varchar(50) | No |  |



### dbo.vw_RequisitionStatus_orig



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| StatusId | int | No |  |
| StatusDesc | varchar(104) | No |  |
| StatusCode | int | No |  |
| ApprovalDate | datetime | Yes |  |
| BidStatus | varchar(20) | No |  |



### dbo.vw_RequisitionStatusBySession



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| SessionId | int | No |  |
| StatusId | int | No |  |
| StatusDesc | varchar(104) | No |  |
| StatusCode | int | No |  |
| ApprovalDate | datetime | Yes |  |
| BidStatus | varchar(20) | No |  |
| BaseStatus | varchar(50) | No |  |



### dbo.vw_ReqVendors



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| VendorId | int | No |  |
| VendorName | varchar(50) | Yes |  |
| WebURL | varchar(255) | Yes |  |



### dbo.vw_RptExpireDateBidDocs



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| VendorName | varchar(50) | No |  |
| VendorCode | varchar(16) | No |  |
| DocumentName | varchar(50) | Yes |  |
| ExpirationDatePerDMS | varchar(10) | Yes |  |
| ExpirationDatePerDocUpload | varchar(10) | Yes |  |
| DocUploadStatus | char(1) | No |  |
| ExpirationDateStatus | varchar(46) | Yes |  |
| StatusCode | int | Yes |  |
| EffectiveFrom | date | Yes |  |
| EffectiveUntil | date | Yes |  |
| DocumentUploadId | int | Yes |  |
| DMSId | uniqueidentifier | Yes |  |



### dbo.vw_RptExpireDateBidDocsAndMore



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| VendorName | varchar(50) | No |  |
| VendorCode | varchar(16) | No |  |
| DocumentName | varchar(50) | Yes |  |
| ExpirationDatePerDMS | varchar(10) | Yes |  |
| ExpirationDatePerDocUpload | varchar(10) | Yes |  |
| DocUploadStatus | char(1) | No |  |
| ExpirationDateStatus | varchar(46) | Yes |  |
| StatusCode | int | Yes |  |
| EffectiveFrom | date | Yes |  |
| EffectiveUntil | date | Yes |  |
| DocInOtherBid | varchar(10) | No |  |
| ExpirationDatePerOtherBid | varchar(10) | No |  |
| DocumentUploadId | int | Yes |  |
| DMSId | uniqueidentifier | Yes |  |



### dbo.vw_RptMarkedReadyEmailBlastStats



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| CategoryName | varchar(50) | Yes |  |
| BidHeaderId | int | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| DistrictCode | varchar(4) | Yes |  |
| RepName | varchar(30) | Yes |  |
| BlastSent | varchar(10) | Yes |  |
| NotifyByEmail | varchar(5) | Yes |  |
| AssocReqsAll | int | Yes |  |
| AssocReqsWtgForBidReady | int | Yes |  |
| AssocUsers | int | Yes |  |
| Approvers | int | Yes |  |



### dbo.vw_RptMissingURLsByBidAndVendor



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| bidheaderid | int | Yes |  |
| VendorId | int | Yes |  |
| Vendor Code | varchar(16) | No |  |
| Awarded Vendor Name | varchar(50) | No |  |
| AwardedItems | int | Yes |  |
| MissingURLs | int | Yes |  |



### dbo.vw_RTK_MSDSandCC



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| Active | tinyint | Yes |  |
| RevisionDate | datetime | Yes |  |
| AlternateDescription | varchar(60) | Yes |  |
| EDSItemCode | varchar(100) | Yes |  |
| ManufacturerName | varchar(100) | Yes |  |
| ProductName | varchar(100) | Yes |  |
| ManufacturerPartNumber | varchar(500) | Yes |  |
| EPARegistrationNumber | varchar(100) | Yes |  |
| MSDSId | int | No |  |
| CurrentVersionMSDSId | int | Yes |  |
| ContentCentralMSDSDocId | varchar(36) | Yes |  |
| FullFileName | varchar(520) | Yes |  |
| DefaultVersion | int | No |  |



### dbo.vw_RTK_Sites



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RTK_SitesId | int | No |  |
| DistrictId | int | No |  |
| DistrictName | varchar(50) | No |  |
| FacilityName | varchar(50) | No |  |
| NJEIN | varchar(20) | No |  |
| CoMunCode | varchar(5) | No |  |
| ChemicalInventoryStatus | tinyint | No |  |
| ExposedEmployeesCount | int | No |  |
| FacilityEmergencyContact | varchar(100) | No |  |
| EmergencyPhone | varchar(50) | No |  |
| FacilityLocation | varchar(408) | Yes |  |
| MailingAddress | varchar(408) | Yes |  |
| ResponsibleOfficial | varchar(100) | No |  |
| TitleResponsibleOfficial | varchar(100) | No |  |
| PhoneResponsibleOfficial | varchar(50) | No |  |
| EmailResponsibleOfficial | varchar(200) | No |  |
| RTKContact | varchar(174) | No |  |
| RTKEmail | varchar(255) | No |  |
| RTKPhone | varchar(20) | No |  |



### dbo.vw_RTKContentCentralMSDS



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| CatalogName | varchar(50) | Yes |  |
| DocumentType | varchar(50) | Yes |  |
| DocFolder | varchar(260) | Yes |  |
| DocName | varchar(260) | Yes |  |
| BaseName | varchar(260) | Yes |  |
| FullFileName | varchar(520) | Yes |  |
| VersionMajor | bigint | Yes |  |
| VersionMinor | bigint | Yes |  |
| CreatedUtc | datetime | No |  |
| PagesCaptured | int | Yes |  |
| DocId | uniqueidentifier | No |  |
| RevisionDate | datetime | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| EDSItemCode | varchar(100) | Yes |  |
| ManufacturerName | varchar(100) | Yes |  |
| ProductName | varchar(100) | Yes |  |
| ManufacturerPartNumber | varchar(500) | Yes |  |
| EPARegistrationNumber | varchar(100) | Yes |  |
| SendTo | varchar(50) | Yes |  |
| AttachedRTKItems | int | Yes |  |



### dbo.vw_RTKDefaultMSDSLocation



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RTKLocation | varchar(50) | Yes |  |
| DistrictId | int | Yes |  |
| MSDSId | int | No |  |
| FacilityNumber | varchar(20) | Yes |  |



### dbo.vw_RTKInfo



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| Year | int | Yes |  |
| DistrictId | int | No |  |
| Name | varchar(50) | Yes |  |
| NJEIN | varchar(20) | Yes |  |
| FacilityId | varchar(1) | No |  |
| FacilityName | varchar(50) | Yes |  |
| CoMunCode | varchar(5) | Yes |  |
| ExposedEmployeesCount | int | Yes |  |
| FacilityEmergencyContact | varchar(100) | Yes |  |
| EmergencyPhone | varchar(50) | Yes |  |
| Location | varchar(406) | Yes |  |
| MailingAddress | varchar(406) | Yes |  |
| EmailResponsibleOfficial | varchar(200) | Yes |  |
| PhoneResponsibleOfficial | varchar(50) | Yes |  |
| TitleResponsibleOfficial | varchar(100) | Yes |  |
| AlternateDesc | varchar(60) | Yes |  |
| Manufacturer | varchar(50) | No |  |
| MSDSId | int | Yes |  |
| Quantity | int | Yes |  |
| InventoryCode | char(2) | Yes |  |
| InventoryDesc | varchar(25) | Yes |  |
| ProductLocation | varchar(50) | No |  |
| ProductExposedEmployees | int | Yes |  |
| Purpose | varchar(50) | Yes |  |
| RTK_PurposeID | int | Yes |  |
| UOMCode | char(1) | Yes |  |
| UOM | varchar(20) | Yes |  |
| SubstanceNo | char(4) | Yes |  |
| CASChemicalName | varchar(50) | Yes |  |
| CASRegNo | varchar(11) | No |  |
| DOT_Id | char(4) | Yes |  |
| MixturePercentCode | char(2) | Yes |  |
| MixtureDesc | varchar(12) | Yes |  |
| SpecHazCodes | varchar(36) | Yes |  |
| ContainerCode | char(2) | Yes |  |
| ContainerDesc | varchar(30) | Yes |  |
| CategoryId | int | Yes |  |



### dbo.vw_RTKInfoAnnual



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| Year | int | Yes |  |
| DistrictId | int | No |  |
| Name | varchar(50) | Yes |  |
| NJEIN | varchar(20) | Yes |  |
| FacilityId | varchar(1) | No |  |
| FacilityName | varchar(50) | Yes |  |
| CoMunCode | varchar(5) | Yes |  |
| ExposedEmployeesCount | int | Yes |  |
| FacilityEmergencyContact | varchar(100) | Yes |  |
| EmergencyPhone | varchar(50) | Yes |  |
| Location | varchar(406) | Yes |  |
| MailingAddress | varchar(406) | Yes |  |
| EmailResponsibleOfficial | varchar(200) | Yes |  |
| PhoneResponsibleOfficial | varchar(50) | Yes |  |
| TitleResponsibleOfficial | varchar(100) | Yes |  |
| AlternateDesc | varchar(60) | Yes |  |
| Manufacturer | varchar(50) | No |  |
| MSDSId | int | Yes |  |
| Quantity | int | Yes |  |
| InventoryCode | char(2) | Yes |  |
| InventoryDesc | varchar(25) | Yes |  |
| ProductLocation | varchar(50) | No |  |
| ProductExposedEmployees | int | Yes |  |
| Purpose | varchar(50) | Yes |  |
| RTK_PurposeID | int | Yes |  |
| UOMCode | char(1) | Yes |  |
| UOM | varchar(20) | Yes |  |
| SubstanceNo | char(4) | Yes |  |
| CASChemicalName | varchar(50) | Yes |  |
| CASRegNo | varchar(11) | No |  |
| DOT_Id | char(4) | Yes |  |
| MixturePercentCode | char(2) | Yes |  |
| MixtureDesc | varchar(12) | Yes |  |
| SpecHazCodes | varchar(36) | Yes |  |
| ContainerCode | char(2) | Yes |  |
| ContainerDesc | varchar(30) | Yes |  |
| CategoryId | int | Yes |  |



### dbo.vw_RTKItems



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| CategoryName | varchar(50) | Yes |  |
| ItemCode | varchar(50) | No |  |
| ItemDescription | varchar(512) | No |  |
| RTK_ItemsId | int | No |  |
| CategoryId | int | Yes |  |
| ItemId | int | Yes |  |
| LegacyCometCode | varchar(16) | Yes |  |
| AlternateDesc | varchar(60) | Yes |  |
| CaseCount | int | Yes |  |
| MeasurePct | decimal(9,5) | Yes |  |
| ContainerCodesId | int | Yes |  |
| UOMCodesId | int | Yes |  |
| OtherContainerDesc | varchar(20) | Yes |  |
| LegacyCometDesc | varchar(60) | Yes |  |
| PurposeDesc | varchar(50) | No |  |
| RTK_PurposeId | int | Yes |  |
| Manufacturer | varchar(50) | Yes |  |



### dbo.vw_RTKItems2



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| CategoryName | varchar(50) | No |  |
| ItemCode | varchar(50) | No |  |
| LegacyCometCode | varchar(16) | No |  |
| ItemDescription | varchar(512) | No |  |
| AlternateDesc | varchar(60) | No |  |
| CaseCount | int | Yes |  |
| MeasurePct | decimal(9,5) | Yes |  |
| ContainerCode | char(2) | Yes |  |
| UOMCode | char(1) | Yes |  |
| ReportQty | int | Yes |  |
| RTK_ItemsId | int | No |  |
| ContainerCodesID | int | Yes |  |
| UOMCodesID | int | Yes |  |
| ItemId | int | Yes |  |
| CategoryId | int | Yes |  |
| PurposeDesc | varchar(50) | No |  |
| RTK_PurposeId | int | Yes |  |
| Manufacturer | varchar(50) | Yes |  |



### dbo.vw_RTKItemsAnnual



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RTK_SitesId | int | Yes |  |
| Quantity | int | Yes |  |
| DistrictId | int | Yes |  |
| year | int | Yes |  |
| RTKDescription | varchar(60) | Yes |  |
| ExactLocationOnSite | varchar(50) | Yes |  |
| Manufacturer | varchar(50) | Yes |  |
| ContainerCodesId | int | Yes |  |
| RTK_PurposeId | int | Yes |  |
| UOMCodesId | int | Yes |  |
| MSDSId | int | Yes |  |
| CategoryId | int | Yes |  |



### dbo.vw_RTKItemsRev2



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RTK_SitesId | int | Yes |  |
| Quantity | int | Yes |  |
| DistrictId | int | Yes |  |
| year | int | Yes |  |
| RTKDescription | varchar(60) | Yes |  |
| ExactLocationOnSite | varchar(50) | Yes |  |
| Manufacturer | varchar(50) | Yes |  |
| ContainerCodesId | int | Yes |  |
| RTK_PurposeId | int | Yes |  |
| UOMCodesId | int | Yes |  |
| MSDSId | int | Yes |  |
| CategoryId | int | Yes |  |



### dbo.vw_RTKReportItems



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictName | varchar(50) | Yes |  |
| Year | int | Yes |  |
| SiteId | int | Yes |  |
| FacilityName | varchar(50) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| Quantity | int | Yes |  |
| ItemCode | varchar(50) | No |  |
| ItemDescription | varchar(512) | No |  |
| AlternateDesc | varchar(60) | No |  |
| ManuallyEntered | int | No |  |
| ManualEntryYesNo | varchar(3) | No |  |
| EDSItem | int | No |  |
| EDSItemYesNo | varchar(3) | No |  |
| RTK_ReportItemsId | int | No |  |
| RTK_ItemsId | int | No |  |
| RTK_SitesId | int | No |  |
| ItemId | int | No |  |
| CATEGORYID | int | Yes |  |
| DistrictId | int | Yes |  |
| MSDSId | int | Yes |  |
| ContentCentralMSDSDocId | varchar(36) | No |  |



### dbo.vw_Savings1



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BudgetId | int | No |  |
| BudgetName | varchar(30) | Yes |  |
| DistrictId | int | Yes |  |
| DistrictName | varchar(189) | Yes |  |
| CYDollars | varchar(30) | Yes |  |
| CYIncludedDollars | varchar(30) | Yes |  |
| CYIncludedPercent | int | Yes |  |
| CYExcludedDollars | varchar(30) | Yes |  |
| GTDollars | varchar(30) | Yes |  |
| GTYears | int | No |  |
| PricePlanCode | varchar(20) | Yes |  |
| County | varchar(50) | No |  |
| State | char(2) | No |  |
| TotalBidCost | money | Yes |  |
| TotalCatalogCost | numeric(38,6) | Yes |  |
| TotalStateContractCost | numeric(38,6) | Yes |  |
| StateContractDiscount | decimal(13,9) | Yes |  |
| OverallDiscount | numeric(38,6) | Yes |  |
| OverallSavings | numeric(38,6) | Yes |  |
| IncludedBidCost | money | Yes |  |
| IncludedCatalogCost | numeric(38,6) | Yes |  |
| IncludedDiscount | numeric(38,6) | Yes |  |
| IncludedSavings | numeric(38,6) | Yes |  |
| ExcludedBidCost | money | Yes |  |
| ExcludedCatalogCost | numeric(38,6) | Yes |  |
| ExcludedDiscount | numeric(38,6) | Yes |  |
| ExcludedSavings | numeric(38,6) | Yes |  |



### dbo.vw_Savings5



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BudgetId | int | No |  |
| BudgetName | varchar(30) | Yes |  |
| DistrictId | int | Yes |  |
| DistrictName | varchar(189) | Yes |  |
| CYDollars | varchar(30) | Yes |  |
| CYIncludedDollars | varchar(30) | Yes |  |
| CYIncludedPercent | int | Yes |  |
| CYExcludedDollars | varchar(30) | Yes |  |
| GTDollars | varchar(30) | Yes |  |
| GTYears | int | No |  |
| PricePlanCode | varchar(20) | Yes |  |
| County | varchar(50) | No |  |
| State | char(2) | No |  |



### dbo.vw_SavingsDetail1



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BudgetId | int | No |  |
| DistrictId | int | No |  |
| CategoryId | int | No |  |
| OnSavingsReport | int | No |  |
| DistrictName | varchar(189) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| ItemCode | varchar(50) | Yes |  |
| Quantity | int | Yes |  |
| BidPrice | money | Yes |  |
| CatalogPrice | numeric(22,6) | Yes |  |
| Discount | numeric(38,17) | Yes |  |
| BidExtended | money | Yes |  |
| CatalogExtended | numeric(33,6) | Yes |  |
| StateContractCost | numeric(38,6) | Yes |  |
| StateContractDiscount | decimal(13,9) | Yes |  |



### dbo.vw_SavingsDetail1NonFiltered



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BudgetId | int | No |  |
| DistrictId | int | No |  |
| CategoryId | int | No |  |
| OnSavingsReport | int | No |  |
| DistrictName | varchar(189) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| ItemCode | varchar(50) | Yes |  |
| Quantity | int | Yes |  |
| BidPrice | money | Yes |  |
| CatalogPrice | numeric(22,6) | Yes |  |
| Discount | numeric(38,17) | Yes |  |
| BidExtended | money | Yes |  |
| CatalogExtended | numeric(33,6) | Yes |  |
| StateContractCost | numeric(38,6) | Yes |  |
| StateContractDiscount | decimal(13,9) | Yes |  |



### dbo.vw_SavingsDetail2



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BudgetId | int | No |  |
| DistrictId | int | Yes |  |
| CategoryId | int | No |  |
| OnSavings | int | No |  |
| DistrictName | varchar(189) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| UniqueItems | int | Yes |  |
| TotalItems | int | Yes |  |
| TotalBidCost | money | Yes |  |
| TotalCatalogCost | numeric(38,6) | Yes |  |
| TotalStateContractCost | numeric(38,6) | Yes |  |
| StateContractDiscount | decimal(13,9) | Yes |  |
| OverallSavings | numeric(38,6) | Yes |  |
| OverallDiscount | numeric(38,17) | Yes |  |



### dbo.vw_SavingsDetail2NonFiltered



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BudgetId | int | No |  |
| DistrictId | int | Yes |  |
| CategoryId | int | No |  |
| OnSavings | int | No |  |
| DistrictName | varchar(189) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| UniqueItems | int | Yes |  |
| TotalItems | int | Yes |  |
| TotalBidCost | money | Yes |  |
| TotalCatalogCost | numeric(38,6) | Yes |  |
| TotalStateContractCost | numeric(38,6) | Yes |  |
| StateContractDiscount | decimal(13,9) | Yes |  |
| OverallSavings | numeric(38,6) | Yes |  |
| OverallDiscount | numeric(38,17) | Yes |  |



### dbo.vw_SavingsTotals



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BudgetId | int | No |  |
| Name | varchar(30) | Yes |  |
| DistrictId | int | Yes |  |
| DistrictName | varchar(189) | Yes |  |
| TotalBidCost | money | Yes |  |
| TotalCatalogCost | numeric(38,6) | Yes |  |
| TotalStateContractCost | numeric(38,6) | Yes |  |
| StateContractDiscount | decimal(13,9) | Yes |  |
| OverallSavings | numeric(38,6) | Yes |  |
| OverallDiscount | numeric(38,6) | Yes |  |
| IncludedCatalogCost | numeric(38,6) | Yes |  |
| IncludedBidCost | money | Yes |  |
| ExcludedCatalogCost | numeric(38,6) | Yes |  |
| ExcludedBidCost | money | Yes |  |
| IncludedSavings | numeric(38,6) | Yes |  |
| ExcludedSavings | numeric(38,6) | Yes |  |
| IncludedDiscount | numeric(38,6) | Yes |  |
| ExcludedDiscount | numeric(38,6) | Yes |  |



### dbo.vw_SavingsTotals5



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BudgetId | int | No |  |
| Name | varchar(30) | Yes |  |
| DistrictId | int | Yes |  |
| DistrictName | varchar(189) | Yes |  |
| PastYearsCount | int | Yes |  |
| GTSavings | numeric(38,6) | No |  |
| CatalogExtended | numeric(38,6) | No |  |
| BidExtended | money | No |  |



### dbo.vw_SavingsTotals5NJ



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| vw_SavingsTotals_Name | varchar(30) | Yes |  |
| vw_SavingsTotals_DistrictName | varchar(189) | Yes |  |
| vw_SavingsTotals_PastYearsCount | int | Yes |  |
| vw_SavingsTotals_GTSavings | numeric(38,6) | No |  |
| vw_SavingsTotals_CatalogExtended | numeric(38,6) | No |  |
| vw_SavingsTotals_BidExtended | money | No |  |



### dbo.vw_SavingsTotals5NonFiltered



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BudgetId | int | No |  |
| Name | varchar(30) | Yes |  |
| DistrictId | int | Yes |  |
| DistrictName | varchar(189) | Yes |  |
| PastYearsCount | int | Yes |  |
| GTSavings | numeric(38,6) | Yes |  |
| CatalogExtended | numeric(38,6) | Yes |  |
| BidExtended | money | Yes |  |



### dbo.vw_SavingsTotals5Test



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BudgetId | int | No |  |
| Name | varchar(30) | Yes |  |
| DistrictId | int | Yes |  |
| DistrictName | varchar(189) | Yes |  |
| PastYearsCount | int | Yes |  |
| GTSavings | numeric(38,6) | Yes |  |
| CatalogExtended | numeric(38,6) | Yes |  |
| BidExtended | money | Yes |  |



### dbo.vw_ScanDocLookupFields



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| ScanJobId | int | No |  |
| DocTypeFieldExternalLookupId | uniqueidentifier | No |  |
| ExternalTableName | nvarchar(128) | No |  |
| ItemOrder | int | No |  |
| DocTypeFieldExternalLookupItemId | uniqueidentifier | No |  |
| Type | nvarchar(50) | No |  |
| DocTypeFieldExternalLookupItemOrder | int | No |  |
| Name | nvarchar(50) | No |  |
| DocTypeFieldId | uniqueidentifier | No |  |



### dbo.vw_ScanDocLookups



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| ScanJobId | int | No |  |
| DocTypeFieldExternalLookupId | uniqueidentifier | No |  |
| ExternalTableName | nvarchar(128) | No |  |
| ItemOrder | int | No |  |



### dbo.vw_ScanDocLookupTargets



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| ScanJobId | int | No |  |
| DocTypeFieldExternalLookupId | uniqueidentifier | No |  |
| ExternalTableName | nvarchar(128) | No |  |
| ItemOrder | int | No |  |
| DocTypeFieldExternalLookupItemId | uniqueidentifier | No |  |
| DocTypeFieldExternalLookupItemOrder | int | No |  |
| ExternalValueColumn | nvarchar(128) | No |  |
| Name | nvarchar(50) | No |  |
| DocTypeFieldId | uniqueidentifier | No |  |



### dbo.vw_ScannedDocumentDataMSDS



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| CatalogName | nvarchar(50) | No |  |
| DocumentType | nvarchar(50) | No |  |
| DocFolder | nvarchar(260) | No |  |
| DocName | nvarchar(260) | No |  |
| BaseName | nvarchar(260) | No |  |
| FullFileName | nvarchar(520) | No |  |
| VersionMajor | int | No |  |
| VersionMinor | int | No |  |
| CreatedUtc | datetime | No |  |
| PagesCaptured | int | No |  |
| DocId | uniqueidentifier | No |  |
| RevisionDate | datetime | Yes |  |
| CategoryName | nvarchar(50) | Yes |  |
| EDSItemCode | nvarchar(4000) | Yes |  |
| ManufacturerName | nvarchar(4000) | Yes |  |
| ProductName | nvarchar(4000) | Yes |  |
| ManufacturerPartNumber | nvarchar(4000) | Yes |  |
| EPARegistrationNumber | nvarchar(4000) | Yes |  |
| SendTo | nvarchar(4000) | Yes |  |



### dbo.vw_ScannedDocumentDataMSDSCategories



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| CategoryName | nvarchar(50) | Yes |  |



### dbo.vw_ScannedDocumentDataMSDSManufacturers



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| ManufacturerName | varchar(50) | Yes |  |



### dbo.vw_scARCategories



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | No |  |
| DistrictId | int | No |  |
| BudgetId | int | No |  |
| CategoryId | int | No |  |
| Name | varchar(50) | Yes |  |



### dbo.vw_SchoolUsers



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SchoolId | int | Yes |  |
| UserId | int | No |  |
| CometId | varchar(58) | Yes |  |



### dbo.vw_SDSImportView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| MSDSId | int | No |  |
| MSDSRef | varchar(255) | Yes |  |
| ItemDescription | varchar(512) | Yes |  |
| ItemList | varchar(MAX) | Yes |  |
| Manufacturer | varchar(MAX) | Yes |  |
| ManufacturerPartNumber | varchar(MAX) | Yes |  |



### dbo.vw_SDSItems



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| ItemId | int | Yes |  |
| MSDSId | int | Yes |  |
| DocId | uniqueidentifier | No |  |
| SDSURL | varchar(99) | Yes |  |



### dbo.vw_SDSItemsAll



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SafetyDataSheetId | bigint | No |  |
| SDSURL | varchar(512) | No |  |



### dbo.vw_SDSReferencedURLs



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| ItemId | int | Yes |  |
| CrossRefId | int | Yes |  |
| VendorId | int | Yes |  |
| SDS_URL | varchar(300) | Yes |  |
| Manufacturer | varchar(50) | Yes |  |



### dbo.vw_SearchDescription



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| ItemId | int | No |  |
| BidHeaderId | int | Yes |  |
| ItemDescription | nvarchar(MAX) | Yes |  |
| ShortDescription | nvarchar(MAX) | Yes |  |



### dbo.vw_SearchItemsDetail



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| HeadingId | int | No |  |
| KeywordId | int | No |  |
| BidItems_BidItemId | int | Yes |  |
| Price | decimal(34,13) | Yes |  |
| BidItems_Alternate | varchar(512) | Yes |  |
| BidItems_VendorItemCode | varchar(50) | Yes |  |
| ItemBidType | varchar(32) | Yes |  |
| PageNo | int | Yes |  |
| Items_ItemCode | varchar(50) | Yes |  |
| Items_Description | varchar(512) | Yes |  |
| Items_HeadingId | int | Yes |  |
| Items_SortSeq | varchar(64) | Yes |  |
| BidDiscountRate | decimal(8,5) | Yes |  |
| Vendors_Name | varchar(50) | Yes |  |
| Units_Code | varchar(20) | Yes |  |
| DetailId | int | Yes |  |
| Quantity | int | Yes |  |
| ItemId | int | No |  |



### dbo.vw_SearchItemsHeadings



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| Title | varchar(255) | No |  |
| Description | varchar(4096) | Yes |  |
| HeadingId | int | No |  |
| SearchLetter | varchar(1) | No |  |



### dbo.vw_SearchItemsKeywords



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| BidHeaderId | int | Yes |  |
| Title | varchar(255) | Yes |  |
| Description | varchar(4096) | Yes |  |
| HeadingId | int | Yes |  |
| Keyword | varchar(50) | Yes |  |
| KeywordId | int | Yes |  |



### dbo.vw_SessionCategories



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | No |  |
| CategoryId | int | No |  |
| Name | varchar(50) | Yes |  |



### dbo.vw_SessionCategoryVendors



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | No |  |
| CategoryId | int | No |  |
| CategoryName | varchar(50) | Yes |  |
| VendorId | int | No |  |
| VendorName | varchar(50) | Yes |  |
| WebURL | varchar(255) | Yes |  |



### dbo.vw_SessionTableBudgets



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | No |  |
| BudgetId | int | No |  |
| Name | varchar(30) | Yes |  |
| EndDate | datetime | Yes |  |



### dbo.vw_ShortDescription



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| ItemId | int | No |  |
| VendorId | int | Yes |  |
| ShortDescription | varchar(4096) | Yes |  |



### dbo.vw_StatusDetailed



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | No |  |
| Status | varchar(104) | No |  |



### dbo.vw_StatusHistory



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| RequisitionId | int | Yes |  |
| StatusName | varchar(104) | No |  |
| ApprovalDate | datetime | Yes |  |
| ActionUserId | int | No |  |
| ActionCometId | int | Yes |  |
| ActionAttention | varchar(50) | Yes |  |
| ApproverUserId | int | Yes |  |
| ApproverAttention | varchar(50) | Yes |  |
| ApproverCometId | int | Yes |  |



### dbo.vw_TMAwardedVendors



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VendorId | int | No |  |
| VendorCode | varchar(16) | Yes |  |
| VendorName | varchar(50) | Yes |  |
| VendorNameAndAddress | varchar(394) | Yes |  |
| Address1 | varchar(50) | Yes |  |
| Address2 | varchar(50) | Yes |  |
| City | varchar(50) | Yes |  |
| State | char(2) | Yes |  |
| Zipcode | varchar(10) | Yes |  |
| Phone | varchar(25) | Yes |  |
| Fax | varchar(20) | Yes |  |
| EMail | varchar(255) | Yes |  |
| FullName | varchar(150) | Yes |  |
| BidHeaderId | int | Yes |  |
| BidMessage | varchar(1024) | Yes |  |
| VendorBidNumber | varchar(50) | Yes |  |
| Title | varchar(255) | No |  |
| PackageNumber | int | Yes |  |
| StateName | varchar(50) | Yes |  |
| CountyName | varchar(50) | No |  |
| AwardType | varchar(50) | Yes |  |
| EffectiveFrom | datetime | Yes |  |
| EffectiveUntil | datetime | Yes |  |
| BidAwardDate | datetime | Yes |  |
| StateId | int | Yes |  |
| HostDistrict | varchar(50) | Yes |  |
| ContactName | varchar(170) | Yes |  |



### dbo.vw_TMCountyTrades



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| TMSurveyId | int | No |  |
| BidTradeId | int | No |  |
| Description | varchar(255) | No |  |
| CountyId | int | No |  |
| TMYear | int | Yes |  |
| VendorCount | int | Yes |  |
| PrevTradeId | int | Yes |  |
| NextTradeId | int | Yes |  |



### dbo.vw_TMLineItems



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| BidImportId | int | No |  |
| Title | varchar(255) | No |  |
| ItemCode | varchar(50) | Yes |  |
| Description | varchar(512) | No |  |
| UnitCode | varchar(20) | No |  |
| BidPrice | decimal(33,13) | Yes |  |
| Alternate | varchar(512) | No |  |
| SortSeq | varchar(64) | Yes |  |



### dbo.vw_TMSurveyData



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| TMSurveyResultId | int | No |  |
| TMSurveyId | int | No |  |
| TMVendorId | int | No |  |
| Rating | int | Yes |  |
| Comments | varchar(MAX) | Yes |  |
| Name | varchar(50) | Yes |  |
| Sequence | varchar(50) | Yes |  |
| TradeId | int | No |  |
| BidTradeId | int | No |  |
| Title | varchar(255) | No |  |



### dbo.vw_TMSurveys



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| TMSurveyId | int | No |  |
| DistrictId | int | No |  |
| Submitter | varchar(255) | Yes |  |
| Title | varchar(255) | Yes |  |
| Email | varchar(255) | Yes |  |
| Started | datetime | Yes |  |
| Finished | datetime | Yes |  |
| CountyId | int | Yes |  |
| FirstTradeId | int | Yes |  |



### dbo.vw_TMTrades



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| TMSurveyId | int | No |  |
| TradeId | int | No |  |
| TMYear | int | Yes |  |
| CountyId | int | No |  |
| Description | varchar(255) | No |  |
| PrevTradeId | int | Yes |  |
| NextTradeId | int | Yes |  |



### dbo.vw_TMTradesAwardedVendors



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VendorId | int | No |  |
| VendorCode | varchar(16) | Yes |  |
| VendorName | varchar(50) | Yes |  |
| VendorNameAndAddress | varchar(394) | Yes |  |
| Address1 | varchar(50) | Yes |  |
| Address2 | varchar(50) | Yes |  |
| City | varchar(50) | Yes |  |
| State | char(2) | Yes |  |
| Zipcode | varchar(10) | Yes |  |
| Phone | varchar(25) | Yes |  |
| Fax | varchar(20) | Yes |  |
| EMail | varchar(255) | Yes |  |
| FullName | varchar(150) | Yes |  |
| BidHeaderId | int | Yes |  |
| BidMessage | varchar(1024) | Yes |  |
| VendorBidNumber | varchar(50) | Yes |  |
| Title | varchar(255) | No |  |
| PackageNumber | int | Yes |  |
| StateName | char(2) | No |  |
| CountyName | varchar(50) | No |  |
| AwardType | varchar(50) | Yes |  |
| EffectiveFrom | datetime | Yes |  |
| EffectiveUntil | datetime | Yes |  |
| BidAwardDate | datetime | Yes |  |
| StateId | int | Yes |  |
| HostDistrict | varchar(50) | Yes |  |
| ContactName | varchar(170) | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| CategoryId | int | No |  |
| AwardingType | varchar(10) | No |  |
| ReawardDate | datetime | Yes |  |
| ReawardFrom | datetime | Yes |  |
| ReawardUntil | datetime | Yes |  |
| PricePlanId | int | Yes |  |
| BidTradeCountyId | int | No |  |



### dbo.vw_TMTradesSummary



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | No |  |
| BidTradeCountyId | int | No |  |
| CountyId | int | No |  |
| AwardType | varchar(50) | Yes |  |
| VendorName | varchar(101) | Yes |  |



### dbo.vw_TMUsers



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| Attention | varchar(50) | Yes |  |
| UserNbr | varchar(5) | Yes |  |
| UserName | varchar(10) | Yes |  |
| Password | varchar(10) | Yes |  |
| userId | int | No |  |
| DistrictId | int | No |  |
| useCF | int | No |  |



### dbo.vw_TMVendorsForReports



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidTradeCountyId | int | Yes |  |
| BidImportId | int | Yes |  |
| BidHeaderId | int | Yes |  |
| BidCounty | varchar(30) | Yes |  |
| BidState | varchar(50) | Yes |  |
| TradeName | varchar(30) | Yes |  |
| PackageNumber | int | Yes |  |
| TradeDescription | varchar(30) | Yes |  |
| AwardType | varchar(15) | No |  |
| BidDate | datetime | Yes |  |
| BidAwardDate | datetime | Yes |  |
| EffectiveFrom | datetime | Yes |  |
| EffectiveUntil | datetime | Yes |  |
| VendorCode | varchar(16) | No |  |
| VendorName | varchar(50) | No |  |
| ContactName | varchar(150) | No |  |
| ContactPhone | varchar(25) | No |  |
| ContactFax | varchar(20) | No |  |
| ContactEmail | varchar(255) | No |  |
| Address1 | varchar(50) | No |  |
| Address2 | varchar(50) | No |  |
| City | varchar(50) | No |  |
| State | char(2) | No |  |
| Zipcode | varchar(10) | No |  |
| VendorContactInfo | varchar(1726) | Yes |  |
| HostName | varchar(50) | Yes |  |
| HostNameAndAddress | varchar(222) | Yes |  |
| CategoryType | int | Yes |  |
| CategoryName | varchar(1075) | Yes |  |
| Grouping | varchar(50) | No |  |



### dbo.vw_UsedAccountData



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BudgetId | int | No |  |
| BudgetName | varchar(30) | Yes |  |
| SchoolId | int | No |  |
| SchoolName | varchar(50) | Yes |  |
| UserId | int | No |  |
| CometId | int | Yes |  |
| UserAttention | varchar(50) | Yes |  |
| RequisitionId | int | No |  |
| Attention | varchar(50) | Yes |  |
| TotalRequisitionCost | money | Yes |  |
| CategoryId | int | No |  |
| CategoryName | varchar(50) | Yes |  |
| UserAccountId | int | Yes |  |
| UseUserAllocations | tinyint | Yes |  |
| AllocationAmount | money | Yes |  |
| AllocationAvailable | money | Yes |  |
| AccountId | int | Yes |  |
| Code | varchar(50) | Yes |  |



### dbo.vw_UserNotificationOptions



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| NotificationOptionId | int | No |  |
| Name | varchar(50) | No |  |



### dbo.vw_Users_Assoc_With_Bid



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| DistrictId | int | No |  |
| UserId | int | No |  |
| ApproverId | int | Yes |  |



### dbo.vw_ValidLogins



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| UserId | int | No |  |
| UserMatch | varchar(26) | Yes |  |
| Password | varchar(10) | No |  |



### dbo.vw_Vendor0528Items



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| ItemCode | varchar(50) | Yes |  |
| VendorItemCode | varchar(50) | No |  |
| description | varchar(1024) | Yes |  |
| Code | varchar(20) | Yes |  |
| atReq | int | Yes |  |
| atPO | int | Yes |  |



### dbo.vw_VendorBidDocumentsList



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| Name | varchar(50) | No |  |



### dbo.vw_VendorBidInfoStats



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| BidImportId | int | No |  |
| Name | varchar(50) | Yes |  |
| ItemsWon | int | Yes |  |
| UPC_ISBN_Provided | int | Yes |  |
| SDS_URLsProvided | int | Yes |  |
| URLsProvided | int | Yes |  |
| Max_URL_Duplicate_Count | int | No |  |
| Max_Duplicate_URL | varchar(300) | No |  |



### dbo.vw_VendorBlast



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VendorName | varchar(50) | Yes |  |
| VendorId | int | No |  |
| ContactFullName | varchar(150) | Yes |  |
| ContactEMail | varchar(255) | Yes |  |
| BidContact | tinyint | Yes |  |
| POContact | tinyint | Yes |  |
| CategoryId | int | Yes |  |
| BidHeaderId | int | Yes |  |
| BidScheduleId | int | Yes |  |
| VBCategoryId | int | Yes |  |
| AwardedBid | int | No |  |
| SubmittedBid | int | No |  |
| RegisteredToBid | int | No |  |
| DownloadedBid | int | No |  |
| RegisteredCategory | int | No |  |



### dbo.vw_VendorBlast_AwardedByBid



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VendorID | int | Yes |  |
| BidHeaderId | int | Yes |  |



### dbo.vw_VendorBlast_DownloadedBySchedule



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VendorId | int | Yes |  |
| BidScheduleId | int | Yes |  |



### dbo.vw_VendorBlast_RegisteredByBid



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VendorId | int | Yes |  |
| BidHeaderId | int | Yes |  |



### dbo.vw_VendorBlast_RegisteredByCategory



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VendorId | int | Yes |  |
| CategoryId | int | No |  |



### dbo.vw_VendorBlast_RegisteredBySchedule



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VendorId | int | Yes |  |
| BidScheduleId | int | No |  |



### dbo.vw_VendorBlast_SubmittedByBid



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VendorId | int | No |  |
| BidHeaderId | int | Yes |  |



### dbo.vw_VendorCategoryBids



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BudgetId | int | No |  |
| VendorId | int | No |  |
| VendorName | varchar(50) | No |  |
| ContactInfo | varchar(548) | Yes |  |
| CategoryId | int | No |  |
| CategoryName | varchar(308) | Yes |  |
| BidHeaderId | int | Yes |  |
| VendorBidNumber | varchar(50) | No |  |
| AdditionalHandlingAmount | money | No |  |
| FreeHandlingAmount | money | No |  |
| BidComments | varchar(512) | No |  |
| CatalogId | int | Yes |  |
| EMail | varchar(255) | No |  |
| VendorCode | varchar(16) | No |  |
| DistrictVendorCode | varchar(20) | No |  |
| VendorsAccountCode | varchar(50) | No |  |



### dbo.vw_VendorCategoryBids_Cats



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BudgetId | int | No |  |
| CategoryId | int | No |  |
| CategoryName | varchar(50) | Yes |  |



### dbo.vw_VendorCategoryBids_Vendors



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BudgetId | int | No |  |
| VendorId | int | No |  |
| VendorName | varchar(50) | No |  |



### dbo.vw_VendorDocRequestStatus



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VendorDocRequestId | int | No |  |
| Status | varchar(18) | Yes |  |
| StatusDate | datetime | Yes |  |
| FollowUpDate | datetime | Yes |  |
| VendorDocRequestStatusId | int | Yes |  |



### dbo.vw_VendorDocumentsList



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| Name | varchar(50) | No |  |



### dbo.vw_VendorPODistrictList



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| name | varchar(50) | Yes |  |
| dataValue | int | No |  |
| VendorSessionId | int | No |  |
| VendorId | int | No |  |
| VendorsAccountCode | varchar(50) | No |  |
| SummaryName | varchar(106) | Yes |  |



### dbo.vw_VendorPODistricts



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictId | int | No |  |
| VendorSessionId | int | No |  |
| VendorId | int | No |  |
| DistrictName | varchar(50) | Yes |  |
| VendorsAccountCode | varchar(50) | No |  |
| SummaryName | varchar(106) | Yes |  |



### dbo.vw_VendorPODistrictsAndBudgets



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictId | int | No |  |
| BudgetId | int | No |  |
| VendorSessionId | int | No |  |
| VendorId | int | No |  |
| DistrictName | varchar(50) | Yes |  |
| BudgetName | varchar(30) | Yes |  |
| VendorsAccountCode | varchar(50) | No |  |
| SummaryName | varchar(151) | Yes |  |
| BudgetFilterId | int | Yes |  |



### dbo.vw_VendorPODistrictsAndBudgetsCF



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictId | int | No |  |
| BudgetId | int | No |  |
| VendorSessionId | int | No |  |
| VendorId | int | No |  |
| DistrictName | varchar(50) | Yes |  |
| BudgetName | varchar(30) | Yes |  |
| VendorsAccountCode | varchar(50) | No |  |
| TotalPOCount | int | Yes |  |
| TotalPOAmount | money | No |  |
| ExportedPOCount | int | Yes |  |
| ExportedPOAmount | money | No |  |
| WaitingPOCount | int | Yes |  |
| WaitingPOAmount | money | No |  |
| BudgetFilterId | int | Yes |  |



### dbo.vw_VendorPODistrictsAndBudgetsOld



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictId | int | No |  |
| BudgetId | int | No |  |
| VendorSessionId | int | No |  |
| VendorId | int | No |  |
| DistrictName | varchar(50) | Yes |  |
| BudgetName | varchar(30) | Yes |  |
| VendorsAccountCode | varchar(50) | No |  |
| SummaryName | varchar(111) | Yes |  |
| BudgetFilterId | int | Yes |  |



### dbo.vw_VendorPODistrictsAndBudgetsTest



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictId | int | No |  |
| BudgetId | int | No |  |
| VendorSessionId | int | No |  |
| VendorId | int | No |  |
| DistrictName | varchar(50) | Yes |  |
| BudgetName | varchar(30) | Yes |  |
| VendorsAccountCode | varchar(50) | No |  |
| SummaryName | varchar(150) | Yes |  |
| BudgetFilterId | int | Yes |  |



### dbo.vw_VendorPOView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VendorSessionId | int | No |  |
| VendorId | int | No |  |
| DistrictId | int | No |  |
| POId | int | No |  |
| PONumber | varchar(24) | Yes |  |
| Amount | money | Yes |  |
| RequisitionNumber | varchar(24) | Yes |  |
| Attention | varchar(50) | No |  |
| TotalRequisitionCost | money | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| SchoolName | varchar(50) | Yes |  |
| UserNbr | int | Yes |  |
| CategoryId | int | No |  |
| CategoryName | varchar(50) | Yes |  |
| BudgetId | int | No |  |
| BudgetName | varchar(30) | Yes |  |
| OrderDate | datetime | Yes |  |
| RequisitionId | int | No |  |
| UploadId | int | No |  |
| DateUploaded | datetime | No |  |
| FileName | varchar(255) | No |  |
| Tagged | int | No |  |
| POLines | int | Yes |  |
| PayloadId | varchar(255) | No |  |
| UploadUser | varchar(50) | No |  |
| VendorsAccountCode | varchar(50) | No |  |
| UploadEMailList | varchar(4096) | No |  |
| UploadType | int | No |  |
| VendorName | varchar(50) | No |  |
| Cancelled | tinyint | No |  |



### dbo.vw_VendorPOView1



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VendorSessionId | int | No |  |
| VendorId | int | No |  |
| DistrictId | int | No |  |
| POId | int | No |  |
| PONumber | varchar(24) | Yes |  |
| Amount | money | Yes |  |
| RequisitionNumber | varchar(24) | Yes |  |
| Attention | varchar(50) | No |  |
| TotalRequisitionCost | money | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| SchoolName | varchar(50) | Yes |  |
| UserNbr | int | Yes |  |
| CategoryId | int | No |  |
| CategoryName | varchar(50) | Yes |  |
| BudgetId | int | No |  |
| BudgetName | varchar(30) | Yes |  |
| OrderDate | datetime | Yes |  |
| RequisitionId | int | No |  |
| UploadId | int | No |  |
| DateUploaded | datetime | No |  |
| FileName | varchar(255) | No |  |
| Tagged | int | No |  |
| POLines | int | Yes |  |
| PayloadId | varchar(255) | No |  |
| UploadUser | varchar(50) | No |  |
| VendorsAccountCode | varchar(50) | No |  |
| UploadEMailList | varchar(4096) | No |  |
| UploadType | int | No |  |
| VendorName | varchar(50) | No |  |
| Cancelled | tinyint | No |  |



### dbo.vw_VendorPOView2



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VendorSessionId | int | No |  |
| VendorId | int | No |  |
| DistrictId | int | No |  |
| POId | int | No |  |
| PONumber | varchar(24) | Yes |  |
| Amount | money | Yes |  |
| RequisitionNumber | varchar(24) | Yes |  |
| Attention | varchar(50) | Yes |  |
| TotalRequisitionCost | money | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| SchoolName | varchar(50) | Yes |  |
| UserNbr | int | Yes |  |
| CategoryId | int | No |  |
| CategoryName | varchar(50) | Yes |  |
| BudgetId | int | No |  |
| BudgetName | varchar(30) | Yes |  |
| OrderDate | datetime | Yes |  |
| RequisitionId | int | No |  |
| UploadId | int | No |  |
| DateUploaded | datetime | No |  |
| FileName | varchar(255) | No |  |
| Tagged | tinyint | No |  |
| POLines | int | Yes |  |



### dbo.vw_VendorQueryMSRPStatus



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VendorQueryMSRPId | int | No |  |
| BidHeaderId | int | Yes |  |
| VendorId | int | Yes |  |
| BidImportId | int | Yes |  |
| EmailAddress | varchar(255) | Yes |  |
| ContactName | varchar(255) | Yes |  |
| SendDate | datetime | Yes |  |
| VendorQueryMSRPNotes | varchar(1000) | Yes |  |
| Status | varchar(18) | Yes |  |
| StatusDate | datetime | Yes |  |
| FollowUpDate | datetime | Yes |  |
| VendorQueryMSRPStatusId | int | Yes |  |
| VendorName | varchar(50) | Yes |  |



### dbo.vw_VendorQueryStatus



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VendorQueryId | int | No |  |
| Status | varchar(18) | Yes |  |
| StatusDate | datetime | Yes |  |
| FollowUpDate | datetime | Yes |  |
| VendorQueryStatusId | int | Yes |  |



### dbo.vw_VendorQueryTandMStatus



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VendorQueryTandMId | int | No |  |
| BidHeaderId | int | Yes |  |
| VendorId | int | Yes |  |
| BidImportId | int | Yes |  |
| EmailAddress | varchar(255) | Yes |  |
| ContactName | varchar(255) | Yes |  |
| SendDate | datetime | Yes |  |
| VendorQueryTandMNotes | varchar(1000) | Yes |  |
| Status | varchar(18) | Yes |  |
| StatusDate | datetime | Yes |  |
| FollowUpDate | datetime | Yes |  |
| VendorQueryTandMStatusId | int | Yes |  |
| VendorName | varchar(50) | Yes |  |



### dbo.vw_Vendors



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VendorId | int | No |  |
| Code | varchar(16) | No |  |
| Name | varchar(50) | No |  |
| Address1 | varchar(50) | No |  |
| Address2 | varchar(50) | No |  |
| Address3 | varchar(1) | No |  |
| City | varchar(50) | No |  |
| State | char(2) | No |  |
| Zipcode | varchar(10) | No |  |
| Phone | varchar(25) | No |  |
| Fax | varchar(20) | No |  |
| EMail | varchar(255) | No |  |
| ShippingPercentage | decimal(9,5) | No |  |
| ContactInfo | varchar(548) | Yes |  |
| FullName | varchar(150) | Yes |  |



### dbo.vw_VendorsByBid



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| VendorId | int | No |  |
| VendorName | varchar(50) | No |  |



### dbo.vw_VendorsTable



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VendorId | int | No |  |
| Active | tinyint | Yes |  |
| Code | varchar(16) | Yes |  |
| Name | varchar(50) | Yes |  |
| Address1 | varchar(50) | No |  |
| Address2 | varchar(50) | No |  |
| Address3 | varchar(50) | No |  |
| City | varchar(50) | No |  |
| State | varchar(12) | No |  |
| ZipCode | varchar(12) | No |  |
| Phone | varchar(25) | No |  |
| Fax | varchar(20) | No |  |
| EMail | varchar(255) | No |  |
| UseGrossPrices | tinyint | Yes |  |
| ShippingPercentage | decimal(9,5) | Yes |  |
| DistrictId | int | Yes |  |
| Password | varchar(50) | Yes |  |
| HostURL | varchar(255) | Yes |  |
| HostPort | int | Yes |  |
| HostDirectory | varchar(255) | Yes |  |
| HostUserName | varchar(255) | Yes |  |
| HostPassword | varchar(255) | Yes |  |
| UploadEMailList | varchar(4096) | Yes |  |
| UploadType | int | Yes |  |
| BusinessUnit | varchar(17) | Yes |  |
| POPassword | varchar(50) | Yes |  |
| cXMLAddress | varchar(255) | Yes |  |
| Emails | varchar(2048) | Yes |  |
| Phones | varchar(2048) | Yes |  |



### dbo.vw_VPOLoginCheck



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VPORegistrationId | int | No |  |
| Active | tinyint | Yes |  |
| VPOUserCode | varchar(50) | No |  |
| VPOPassword | varchar(50) | No |  |
| VPOLastChange | datetime | No |  |
| VPOEMail | varchar(255) | No |  |
| VPOName | varchar(50) | No |  |
| VPOPhone | varchar(50) | No |  |
| VPOParentId | int | No |  |
| VPOCanCreateUser | tinyint | No |  |
| VPOStatus | tinyint | Yes |  |



### dbo.vw_VPOVendors



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VendorSessionId | int | No |  |
| VPORegistrationId | int | Yes |  |
| VendorId | int | No |  |
| Name | varchar(50) | Yes |  |



### dbo.vw_WincapVendors



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| Vendor Code | varchar(16) | No |  |
| Vendors Name | varchar(50) | Yes |  |
| Full Name And Address | varchar(704) | Yes |  |
| Category | varchar(50) | Yes |  |
| Vendor Bid Number | varchar(50) | No |  |
| Comments | varchar(1024) | No |  |
| District Vendor Code | varchar(20) | No |  |



### dbo.vw_WincapVendorsMaster



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| Vendor Name | varchar(50) | Yes |  |
| Ed-Data Vendor Code | varchar(16) | No |  |
| Contact Name | varchar(150) | No |  |
| Address1 | varchar(50) | No |  |
| Address2 | varchar(50) | No |  |
| City | varchar(50) | No |  |
| State | char(2) | No |  |
| Zip | varchar(10) | No |  |
| Phone | varchar(25) | No |  |
| Fax | varchar(20) | No |  |
| Email | varchar(255) | No |  |



### dbo.vw_WinningMSRPEntryPrices



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| VendorId | int | Yes |  |
| ManufacturerId | int | Yes |  |
| ManufacturerProductLineId | int | Yes |  |
| MSRPOptionId | int | Yes |  |
| RangeBase | money | Yes |  |
| RangeValue | decimal(9,5) | Yes |  |
| BidMSRPResultPricesId | int | No |  |
| BidMSRPResultsProductLineId | int | No |  |
| BidMSRPResultsId | int | No |  |



### dbo.vw_ZonalItems



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| CaptureName | nvarchar(50) | No |  |
| Folder | nvarchar(260) | Yes |  |
| CatalogName | nvarchar(50) | No |  |
| DocCategory | nvarchar(50) | No |  |
| DocType | nvarchar(50) | No |  |
| DocTypeFieldId | uniqueidentifier | No |  |
| TopLeftX | decimal(8,2) | Yes |  |
| TopLeftY | decimal(8,2) | Yes |  |
| TopRightX | decimal(9,2) | Yes |  |
| TopRightY | decimal(8,2) | Yes |  |
| BottomLeftX | decimal(8,2) | Yes |  |
| BottomLeftY | decimal(9,2) | Yes |  |
| BottomRightX | decimal(9,2) | Yes |  |
| BottomRightY | decimal(9,2) | Yes |  |
| ZonalRemovePage | bit | No |  |
| UseRegularExpression | bit | Yes |  |
| RegularExpression | nvarchar(1500) | Yes |  |
| DocTypeFieldRecognitionZoneId | uniqueidentifier | No |  |
| ScanJobId | int | No |  |



### EDSIQEndUser.Sessions



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| SessionId | int | No |  |
| UserId | int | No |  |
| DistrictId | int | Yes |  |
| SchoolId | int | Yes |  |
| Attention | varchar(50) | Yes |  |
| AllowIncidentals | tinyint | Yes |  |
| CurrentBudgetId | int | Yes |  |
| NextBudgetId | int | Yes |  |
| jSession | varchar(255) | No |  |
| IPAddress | varchar(50) | Yes |  |



### EDSIQWebUser.CategoryPP



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| CategoryId | int | Yes |  |
| PricePlanId | int | Yes |  |



### EDSIQWebUser.CoverView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictId | int | Yes |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| DistrictAddress1 | varchar(30) | Yes |  |
| DistrictAddress2 | varchar(30) | Yes |  |
| DistrictAddress3 | varchar(30) | Yes |  |
| DistrictCity | varchar(25) | Yes |  |
| DistrictState | varchar(2) | Yes |  |
| DistrictZipcode | varchar(10) | Yes |  |
| SchoolId | int | Yes |  |
| SchoolName | varchar(50) | Yes |  |
| SchoolAddress1 | varchar(30) | Yes |  |
| SchoolAddress2 | varchar(30) | Yes |  |
| SchoolAddress3 | varchar(30) | Yes |  |
| SchoolCity | varchar(25) | Yes |  |
| SchoolState | varchar(2) | Yes |  |
| SchoolZipcode | varchar(10) | Yes |  |
| UserId | int | Yes |  |
| UserName | varchar(50) | Yes |  |
| CometId | int | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| AccountCount | int | Yes |  |
| BudgetStartDate | datetime | Yes |  |
| BudgetEndDate | datetime | Yes |  |
| ItemCount | int | Yes |  |
| CategoryId | int | Yes |  |
| OrderBookId | int | Yes |  |
| CategoryDescription | varchar(255) | Yes |  |
| PricePlanDescription | varchar(255) | Yes |  |
| UsesBooklet | int | Yes |  |
| UsesOnline | int | Yes |  |



### EDSIQWebUser.CoverViewSrc



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictId | int | Yes |  |
| DistrictCode | varchar(2) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| DistrictAddress1 | varchar(30) | Yes |  |
| DistrictAddress2 | varchar(30) | Yes |  |
| DistrictAddress3 | varchar(30) | Yes |  |
| DistrictCity | varchar(25) | Yes |  |
| DistrictState | varchar(2) | Yes |  |
| DistrictZipcode | varchar(10) | Yes |  |
| SchoolId | int | Yes |  |
| SchoolName | varchar(50) | Yes |  |
| SchoolAddress1 | varchar(30) | Yes |  |
| SchoolAddress2 | varchar(30) | Yes |  |
| SchoolAddress3 | varchar(30) | Yes |  |
| SchoolCity | varchar(25) | Yes |  |
| SchoolState | varchar(2) | Yes |  |
| SchoolZipcode | varchar(10) | Yes |  |
| UserId | int | Yes |  |
| UserName | varchar(50) | Yes |  |
| CometId | int | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| AccountCount | int | Yes |  |
| BudgetStartDate | datetime | Yes |  |
| BudgetEndDate | datetime | Yes |  |
| ItemCount | int | Yes |  |
| CategoryId | int | Yes |  |
| OrderBookId | int | Yes |  |
| CategoryDescription | varchar(255) | Yes |  |
| PricePlanDescription | varchar(255) | Yes |  |



### EDSIQWebUser.MissingCoverView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictId | int | Yes |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| DistrictAddress1 | varchar(30) | Yes |  |
| DistrictAddress2 | varchar(30) | Yes |  |
| DistrictAddress3 | varchar(30) | Yes |  |
| DistrictCity | varchar(25) | Yes |  |
| DistrictState | varchar(2) | Yes |  |
| DistrictZipcode | varchar(10) | Yes |  |
| SchoolId | int | Yes |  |
| SchoolName | varchar(50) | Yes |  |
| SchoolAddress1 | varchar(30) | Yes |  |
| SchoolAddress2 | varchar(30) | Yes |  |
| SchoolAddress3 | varchar(30) | Yes |  |
| SchoolCity | varchar(25) | Yes |  |
| SchoolState | varchar(2) | Yes |  |
| SchoolZipcode | varchar(10) | Yes |  |
| UserId | int | Yes |  |
| UserName | varchar(50) | Yes |  |
| CometId | int | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| AccountCount | int | Yes |  |
| BudgetStartDate | datetime | Yes |  |
| BudgetEndDate | datetime | Yes |  |
| ItemCount | int | Yes |  |
| CategoryId | int | Yes |  |
| OrderBookId | int | Yes |  |
| CategoryDescription | varchar(255) | Yes |  |
| PricePlanDescription | varchar(255) | Yes |  |



### EDSIQWebUser.OrderBookDetailView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| OrderBookDetailId | int | No |  |
| OrderBookId | int | No |  |
| ItemCode | varchar(50) | Yes |  |
| UnitCode | varchar(20) | Yes |  |
| GrossPrice | money | Yes |  |
| CatalogPage | varchar(4) | Yes |  |
| CatalogYear | varchar(2) | Yes |  |
| VendorName | varchar(255) | Yes |  |
| VendorItemCode | varchar(50) | Yes |  |
| TotalQuantity | int | No |  |
| TotalRequisitions | int | No |  |
| ExpandAll | tinyint | Yes |  |
| Weight | int | No |  |
| SortSeq | varchar(64) | Yes |  |
| Active | tinyint | Yes |  |
| Alternate | varchar(1024) | Yes |  |
| VendorId | int | Yes |  |
| VendorCode | varchar(16) | Yes |  |
| ItemDescription | varchar(512) | Yes |  |
| HeadingId | int | Yes |  |
| HeadingCode | varchar(16) | Yes |  |
| HeadingTitle | varchar(255) | Yes |  |
| HeadingDescription | varchar(4096) | Yes |  |



### EDSIQWebUser.OrderBookView



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| OrderBookId | int | No |  |
| PricePlanDescription | varchar(255) | Yes |  |
| Category | varchar(255) | Yes |  |
| PricePlanId | int | Yes |  |
| CategoryId | int | Yes |  |
| AwardId | int | Yes |  |
| BookType | varchar(11) | No |  |
| Active | int | Yes |  |
| BidHeaderId | int | Yes |  |
| DistrictId | int | Yes |  |



### EDSIQWebUser.POAccountList



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictId | int | Yes |  |
| PONumber | varchar(24) | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| POAmount | money | Yes |  |



### EDSIQWebUser.POAccountsUsed



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| DistrictId | int | Yes |  |
| PONumber | varchar(24) | Yes |  |
| AccountCode | varchar(50) | Yes |  |
| POAmount | money | Yes |  |



### EDSIQWebUser.ScheduledByPricePlanCategory



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| PricePlanDescription | varchar(278) | No |  |
| CategoryName | varchar(50) | Yes |  |
| PercentIn | float(53) | Yes |  |
| PercentOut | float(53) | Yes |  |
| DistrictsIn | int | Yes |  |
| TotalDistricts | int | Yes |  |



### EDSIQWebUser.ScheduledByPricePlanCategoryRep



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| PricePlanDescription | varchar(278) | No |  |
| CategoryName | varchar(50) | Yes |  |
| PercentIn | float(53) | Yes |  |
| PercentOut | float(53) | Yes |  |
| DistrictsIn | int | Yes |  |
| TotalDistricts | int | Yes |  |
| RepName | varchar(30) | Yes |  |



### EDSIQWebUser.ScheduledDistrictsByPricePlanCategory



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| PricePlanDescription | varchar(278) | No |  |
| CategoryName | varchar(50) | Yes |  |
| DistrictCode | varchar(4) | Yes |  |
| DistrictName | varchar(50) | Yes |  |
| PercentIn | float(53) | Yes |  |
| PercentOut | float(53) | Yes |  |
| DistrictsIn | int | Yes |  |
| TotalDistricts | int | Yes |  |
| RepName | varchar(30) | Yes |  |



### VMS.vw_BidsByVendor



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| BidHeaderId | int | Yes |  |
| CategoryId | int | Yes |  |
| VendorId | int | Yes |  |
| Description | varchar(512) | Yes |  |
| BidMessage | varchar(1024) | Yes |  |
| EffectiveFrom | datetime | Yes |  |
| EffectiveUntil | datetime | Yes |  |
| ClosingDate | datetime | Yes |  |
| CategoryName | varchar(50) | Yes |  |
| PK | int | No |  |



### VMS.vw_Login



#### Columns

| Column | Data Type | Nullable | Description |
|--------|-----------|----------|-------------|
| VendorContactId | int | No |  |
| VendorId | int | No |  |
| FullName | varchar(150) | Yes |  |
| LastName | varchar(50) | Yes |  |
| FirstName | varchar(50) | Yes |  |
| EMail | varchar(255) | Yes |  |
| Password | varchar(50) | Yes |  |




## Stored Procedures

| Schema | Procedure Name | Created | Modified | Description |
|--------|----------------|---------|----------|-------------|
| dbo | _sp_FA_UpdateRequisitionStatus | 2012-06-14 00:03:50 | 2012-06-14 00:03:50 |  |
| dbo | bid2xls | 2008-08-26 14:13:13 | 2022-07-22 13:38:02 |  |
| dbo | bid2xlsTest | 2014-06-26 19:37:54 | 2018-07-23 12:40:35 |  |
| dbo | dt_addtosourcecontrol | 2006-08-29 12:12:36 | 2006-08-29 12:12:36 |  |
| dbo | dt_addtosourcecontrol_u | 2006-08-29 12:12:36 | 2006-08-29 12:12:36 |  |
| dbo | dt_adduserobject | 2006-08-29 12:12:36 | 2006-08-29 12:12:36 |  |
| dbo | dt_adduserobject_vcs | 2006-08-29 12:12:36 | 2006-08-29 12:12:36 |  |
| dbo | dt_checkinobject | 2006-08-29 12:12:36 | 2006-08-29 12:12:36 |  |
| dbo | dt_checkinobject_u | 2006-08-29 12:12:36 | 2006-08-29 12:12:36 |  |
| dbo | dt_checkoutobject | 2006-08-29 12:12:36 | 2006-08-29 12:12:36 |  |
| dbo | dt_checkoutobject_u | 2006-08-29 12:12:36 | 2006-08-29 12:12:36 |  |
| dbo | dt_displayoaerror | 2006-08-29 12:12:36 | 2006-08-29 12:12:36 |  |
| dbo | dt_displayoaerror_u | 2006-08-29 12:12:36 | 2006-08-29 12:12:36 |  |
| dbo | dt_droppropertiesbyid | 2006-08-29 12:12:36 | 2006-08-29 12:12:36 |  |
| dbo | dt_dropuserobjectbyid | 2006-08-29 12:12:36 | 2006-08-29 12:12:36 |  |
| dbo | dt_generateansiname | 2006-08-29 12:12:35 | 2006-08-29 12:12:35 |  |
| dbo | dt_getobjwithprop | 2006-08-29 12:12:36 | 2006-08-29 12:12:36 |  |
| dbo | dt_getobjwithprop_u | 2006-08-29 12:12:36 | 2006-08-29 12:12:36 |  |
| dbo | dt_getpropertiesbyid | 2006-08-29 12:12:36 | 2006-08-29 12:12:36 |  |
| dbo | dt_getpropertiesbyid_u | 2006-08-29 12:12:36 | 2006-08-29 12:12:36 |  |
| dbo | dt_getpropertiesbyid_vcs | 2006-08-29 12:12:36 | 2006-08-29 12:12:36 |  |
| dbo | dt_getpropertiesbyid_vcs_u | 2006-08-29 12:12:36 | 2006-08-29 12:12:36 |  |
| dbo | dt_isundersourcecontrol | 2006-08-29 12:12:36 | 2006-08-29 12:12:36 |  |
| dbo | dt_isundersourcecontrol_u | 2006-08-29 12:12:36 | 2006-08-29 12:12:36 |  |
| dbo | dt_removefromsourcecontrol | 2006-08-29 12:12:36 | 2006-08-29 12:12:36 |  |
| dbo | dt_setpropertybyid | 2006-08-29 12:12:36 | 2006-08-29 12:12:36 |  |
| dbo | dt_setpropertybyid_u | 2006-08-29 12:12:36 | 2006-08-29 12:12:36 |  |
| dbo | dt_validateloginparams | 2006-08-29 12:12:36 | 2006-08-29 12:12:36 |  |
| dbo | dt_validateloginparams_u | 2006-08-29 12:12:36 | 2006-08-29 12:12:36 |  |
| dbo | dt_vcsenabled | 2006-08-29 12:12:36 | 2006-08-29 12:12:36 |  |
| dbo | dt_verstamp006 | 2006-08-29 12:12:36 | 2006-08-29 12:12:36 |  |
| dbo | dt_verstamp007 | 2006-08-29 12:12:36 | 2006-08-29 12:12:36 |  |
| dbo | dt_whocheckedout | 2006-08-29 12:12:36 | 2006-08-29 12:12:36 |  |
| dbo | dt_whocheckedout_u | 2006-08-29 12:12:36 | 2006-08-29 12:12:36 |  |
| dbo | sp_AddDistrict | 2001-10-08 22:30:33 | 2022-07-21 13:12:26 |  |
| dbo | sp_AddISBN | 2002-04-30 23:32:40 | 2013-01-28 22:25:07 |  |
| dbo | sp_AddMSRPItem | 2013-05-30 13:26:57 | 2015-11-24 23:37:40 |  |
| dbo | sp_AddPPCatalog | 2001-10-15 02:26:56 | 2009-03-25 06:55:28 |  |
| dbo | sp_AddPricePlan | 2001-10-16 16:00:17 | 2009-03-25 06:55:28 |  |
| dbo | sp_AddSchool | 2001-10-05 08:09:34 | 2015-11-24 23:37:30 |  |
| dbo | sp_alterdiagram | 2009-03-26 16:18:10 | 2009-03-26 16:18:10 |  |
| dbo | sp_ApproveReq | 2001-08-24 14:40:44 | 2016-04-28 17:01:27 |  |
| dbo | sp_AttemptLogin | 2001-08-24 14:40:44 | 2025-03-26 09:00:48 |  |
| dbo | sp_AwardBid | 2002-06-13 17:37:16 | 2015-11-24 23:37:27 |  |
| dbo | sp_AwardBidHeader | 2004-06-09 02:02:01 | 2025-06-26 12:00:23 |  |
| dbo | sp_AwardBidHeaderSingleItem | 2015-08-05 15:03:27 | 2015-08-05 15:03:27 |  |
| dbo | sp_BAList | 2001-08-24 14:40:44 | 2010-05-25 14:11:18 |  |
| dbo | sp_BatchChanges | 2001-12-05 23:22:59 | 2009-03-25 06:55:28 |  |
| dbo | sp_BatchConvert | 2003-06-30 12:55:47 | 2009-03-25 06:55:28 |  |
| dbo | sp_BatchConvertNew | 2009-02-26 10:25:33 | 2009-03-25 06:55:28 |  |
| dbo | sp_BatchLoad | 2001-08-28 15:08:57 | 2015-11-24 23:37:34 |  |
| dbo | sp_BatchProcess | 2002-11-21 14:58:45 | 2009-03-25 06:55:28 |  |
| dbo | sp_BatchQueue | 2002-11-21 14:53:58 | 2015-11-24 23:37:40 |  |
| dbo | sp_BatchVerify | 2001-08-28 15:09:14 | 2014-10-07 17:53:27 |  |
| dbo | sp_BatchVerifyBook | 2002-12-03 14:12:18 | 2014-10-07 17:53:27 |  |
| dbo | sp_BatchVerifyForce | 2004-01-14 15:43:19 | 2014-10-07 17:53:25 |  |
| dbo | sp_BidCompare | 2004-09-02 15:06:28 | 2023-10-17 14:34:27 |  |
| dbo | sp_BidCompareDiscount | 2004-09-07 14:40:30 | 2009-03-25 06:55:28 |  |
| dbo | sp_BidCompareSame | 2019-11-20 17:16:32 | 2019-11-20 17:18:43 |  |
| dbo | sp_BidCompareSummary | 2022-10-14 16:28:56 | 2022-10-14 16:48:05 |  |
| dbo | sp_BidCopy | 2010-09-15 23:00:35 | 2022-12-08 11:43:22 |  |
| dbo | sp_BidCopyChangePP | 2010-09-15 23:02:40 | 2022-12-02 15:50:59 |  |
| dbo | sp_BidCopyWithIncrease | 2024-11-12 16:08:11 | 2024-11-12 16:08:11 |  |
| dbo | sp_BringBillingForward | 2015-02-04 12:01:19 | 2024-11-06 14:01:45 |  |
| dbo | sp_BringBillingForwardState | 2024-10-31 15:01:02 | 2024-11-11 11:57:58 |  |
| dbo | sp_BuildTopOrdered | 2003-06-30 12:55:47 | 2014-10-07 17:53:23 |  |
| dbo | sp_CanDeleteRequisition | 2001-08-24 14:40:45 | 2009-03-25 06:55:28 |  |
| dbo | sp_CatalogDataCheck | 2002-02-18 17:23:40 | 2009-03-25 06:55:28 |  |
| dbo | sp_CatalogDataPriceCheck | 2002-02-21 18:44:53 | 2009-03-25 06:55:28 |  |
| dbo | sp_CatalogImport | 2011-10-27 12:48:14 | 2011-12-07 13:46:23 |  |
| dbo | sp_CatalogImporter | 2012-11-14 19:57:29 | 2012-11-14 20:04:32 |  |
| dbo | sp_CatalogImporterXML | 2013-11-25 16:41:26 | 2014-06-03 15:39:58 |  |
| dbo | sp_CCAccountMaint | 2019-06-04 16:45:14 | 2019-06-13 08:40:40 |  |
| dbo | sp_CCAddAddendaItem | 2009-12-08 09:35:43 | 2019-01-28 16:18:33 |  |
| dbo | sp_CCAddAddendaMaint | 2009-12-07 16:06:02 | 2015-11-24 23:37:29 |  |
| dbo | sp_CCAnalysisReturn | 2007-06-26 13:59:48 | 2009-03-25 06:55:28 |  |
| dbo | sp_CCItemMaint | 2003-05-21 23:16:51 | 2019-08-01 07:59:19 |  |
| dbo | sp_CCSchoolMaint | 2004-09-30 20:37:39 | 2015-11-24 23:37:29 |  |
| dbo | sp_CCUpdateAddendaItem | 2009-12-04 14:59:29 | 2014-10-07 17:53:22 |  |
| dbo | sp_CCUpdateAddendaItemSizesOnly | 2005-01-27 12:36:27 | 2013-09-24 09:31:33 |  |
| dbo | sp_CCUpdateAddendaMaint | 2009-12-04 15:10:22 | 2013-09-24 09:31:16 |  |
| dbo | sp_CCUpdateResults | 2004-11-09 13:14:10 | 2009-03-25 06:55:28 |  |
| dbo | sp_CCUpdateUserAccounts | 2004-02-16 12:12:16 | 2015-11-24 23:37:28 |  |
| dbo | sp_CCUpdateUserAccounts_2 | 2008-05-19 16:30:36 | 2014-10-07 17:53:25 |  |
| dbo | sp_CCUpdateUserAccountsBulk | 2004-02-19 00:44:20 | 2015-11-24 23:37:27 |  |
| dbo | sp_CCUserAccountMaint | 2004-10-02 16:43:28 | 2009-03-25 06:55:28 |  |
| dbo | sp_CCUserGridMaint | 2004-10-03 16:24:21 | 2025-01-31 20:46:50 |  |
| dbo | sp_CombineReqs | 2007-06-04 10:46:17 | 2015-07-10 13:36:30 |  |
| dbo | sp_CombineReqsByVendorNoDelete | 2008-06-16 09:52:45 | 2015-03-24 14:59:07 |  |
| dbo | sp_CometLoad | 2002-02-19 08:08:40 | 2015-11-24 23:37:34 |  |
| dbo | sp_ConvertReqs | 2002-03-20 22:18:07 | 2022-04-01 08:49:58 |  |
| dbo | sp_ConvertTextbookReqs | 2002-06-12 15:13:07 | 2009-07-16 13:30:14 |  |
| dbo | sp_CopyBidImport | 2004-04-14 00:27:38 | 2009-03-25 06:55:28 |  |
| dbo | sp_CopyBudgetAmounts | 2013-12-05 07:37:52 | 2013-12-05 09:17:04 |  |
| dbo | sp_CopyCalendar | 2012-09-25 16:38:41 | 2017-11-27 13:28:21 |  |
| dbo | sp_CopyItems | 2012-11-12 14:15:58 | 2012-11-14 09:33:45 |  |
| dbo | sp_CopyMSRPVers2Bid | 2014-01-17 17:00:00 | 2020-08-07 14:39:44 |  |
| dbo | sp_CopyMSRPVers2BidBackup | 2014-02-11 16:46:56 | 2014-02-11 16:46:56 |  |
| dbo | sp_CopyMSRPVers2BidBackup-2014-10-29 | 2014-10-29 14:45:36 | 2014-10-29 14:45:36 |  |
| dbo | sp_CopyMSRPVers2BidUsingCursorSave | 2014-01-17 16:57:13 | 2015-11-24 23:37:42 |  |
| dbo | sp_CopyMSRPVers2BidUsingCursorSave2 | 2014-01-16 19:33:41 | 2015-11-24 23:37:42 |  |
| dbo | sp_CopyMSRPVers3Bid | 2020-08-07 14:35:27 | 2022-09-01 11:46:30 |  |
| dbo | sp_CopyMSRPVers4Bid | 2022-10-21 16:10:30 | 2022-10-21 16:10:30 |  |
| dbo | sp_CopyReqBulk | 2008-10-30 22:42:08 | 2025-06-26 11:44:19 |  |
| dbo | sp_CopyReqs | 2013-10-16 12:57:21 | 2013-10-16 12:57:21 |  |
| dbo | sp_CopyReqsBulk | 2008-11-01 19:02:23 | 2018-05-02 08:47:23 |  |
| dbo | sp_CopyToBudgetBook | 2003-10-31 10:42:20 | 2009-03-25 06:55:28 |  |
| dbo | sp_CreateBidFromRequest | 2002-06-08 20:40:58 | 2009-03-25 06:55:28 |  |
| dbo | sp_CreateBidHeaderDetail | 2003-05-08 09:09:37 | 2022-12-08 10:20:19 |  |
| dbo | sp_CreateBidHeaderItems | 2003-05-08 11:52:12 | 2015-11-24 23:37:33 |  |
| dbo | sp_creatediagram | 2009-03-26 16:18:10 | 2009-03-26 16:18:10 |  |
| dbo | sp_CreateNewBidHeader | 2003-06-30 12:55:48 | 2015-11-24 23:37:38 |  |
| dbo | sp_CreateNewDistrictReqNumber | 2003-12-11 16:25:56 | 2012-09-06 12:37:20 |  |
| dbo | sp_CreateNewPO | 2002-03-14 08:16:16 | 2025-06-26 11:53:09 |  |
| dbo | sp_CreateNewRequisition | 2001-08-24 14:40:45 | 2014-10-07 17:53:21 |  |
| dbo | sp_CreateNewRequisitionV | 2013-02-06 22:02:01 | 2014-10-07 17:53:24 |  |
| dbo | sp_CreateNewRequisitionVendor | 2012-04-11 21:23:14 | 2025-04-16 03:31:15 |  |
| dbo | sp_CreateNewRequisitionVendor_bk20250416 | 2025-04-15 22:37:30 | 2025-04-15 22:37:30 |  |
| dbo | sp_CreateOrderBook | 2004-08-04 11:19:28 | 2021-06-01 16:01:37 |  |
| dbo | sp_CreateOrderBook03 | 2003-08-24 14:30:09 | 2015-11-24 23:37:38 |  |
| dbo | sp_CreateOrderBookTest | 2021-06-01 13:11:48 | 2021-06-01 13:11:48 |  |
| dbo | sp_CreatePO | 2002-03-14 08:17:09 | 2025-06-26 11:52:27 |  |
| dbo | sp_CreatePO_Saved062724 | 2024-06-27 18:44:50 | 2024-06-27 18:44:50 |  |
| dbo | sp_CreatePOTest | 2024-06-27 18:20:41 | 2024-06-27 18:20:41 |  |
| dbo | sp_CreateQuoteRequest | 2004-05-07 17:37:37 | 2022-12-08 10:21:10 |  |
| dbo | sp_CreateQuoteRequestPrebid | 2010-10-26 16:14:34 | 2022-12-08 10:21:58 |  |
| dbo | sp_CreateTextBookBidRequest | 2002-06-08 15:19:01 | 2015-11-24 23:37:32 |  |
| dbo | sp_CreateVendorSession | 2009-03-11 17:12:27 | 2009-03-25 06:55:28 |  |
| dbo | sp_CXmlLogin | 2008-01-23 12:43:15 | 2024-10-18 06:40:48 |  |
| dbo | sp_DBCheck | 2002-02-13 01:12:41 | 2009-03-25 06:55:28 |  |
| dbo | sp_DefragAll | 2001-11-28 11:09:20 | 2001-11-28 11:09:20 |  |
| dbo | sp_DeleteBatch | 2002-02-27 11:15:00 | 2009-03-25 06:55:28 |  |
| dbo | sp_DeleteBook | 2002-02-27 11:19:20 | 2009-03-25 06:55:28 |  |
| dbo | sp_DeleteDistrictPOs | 2002-04-16 16:01:15 | 2009-03-25 06:55:28 |  |
| dbo | sp_DeleteNoBids | 2002-02-24 21:15:37 | 2009-03-25 06:55:28 |  |
| dbo | sp_DeletePO | 2002-04-16 15:56:44 | 2014-05-20 13:29:00 |  |
| dbo | sp_DeleteRequisition | 2001-12-13 12:59:39 | 2012-08-31 09:33:51 |  |
| dbo | sp_DeleteRequisitionRestricted | 2002-05-28 13:09:15 | 2017-05-11 15:15:45 |  |
| dbo | sp_DeleteRequisitionWithDetail | 2003-03-26 20:53:25 | 2009-03-25 06:55:28 |  |
| dbo | sp_DeleteZeros | 2001-08-24 14:40:45 | 2009-03-25 06:55:28 |  |
| dbo | sp_DistrictRequisitionDetail | 2003-12-11 16:55:27 | 2025-03-03 18:46:38 |  |
| dbo | sp_dropdiagram | 2009-03-26 16:18:10 | 2009-03-26 16:18:10 |  |
| dbo | sp_DSHeadings | 2017-10-23 16:29:03 | 2022-12-20 11:46:23 |  |
| dbo | sp_easyadd | 2001-08-24 14:40:45 | 2013-05-22 14:41:19 |  |
| dbo | sp_EDSItems | 2001-10-18 09:07:39 | 2009-03-25 06:55:28 |  |
| dbo | sp_EnhancedSearchItem | 2020-06-08 14:39:41 | 2024-07-12 09:40:43 |  |
| dbo | sp_ExportMSRPBid | 2014-07-16 14:14:15 | 2014-07-16 14:55:37 |  |
| dbo | sp_FA_AddUpdateAccountCode | 2012-06-14 00:06:04 | 2023-02-21 16:01:42 |  |
| dbo | sp_FA_ApproveReq | 2012-06-14 00:04:23 | 2022-07-07 21:41:51 |  |
| dbo | sp_FA_AttemptLogin | 2012-06-14 00:06:32 | 2024-10-18 03:57:04 |  |
| dbo | sp_FA_AttemptLogin_BK_20241018_Before_EncryptedPassword | 2024-10-18 03:17:08 | 2024-10-18 03:17:39 |  |
| dbo | sp_FA_AvailableAccounts | 2012-06-14 00:06:19 | 2012-06-14 00:06:19 |  |
| dbo | sp_FA_CCAddAddendaItem | 2012-07-11 11:08:17 | 2015-11-24 23:37:43 |  |
| dbo | sp_FA_CCUpdateAddendaItem | 2012-06-14 00:00:46 | 2015-11-24 23:37:31 |  |
| dbo | sp_FA_CreatePO | 2012-06-13 23:58:41 | 2012-06-13 23:58:41 |  |
| dbo | sp_FA_CreateReportSession | 2012-06-13 23:50:28 | 2012-06-13 23:50:28 |  |
| dbo | sp_FA_CreateReportSessionLinks | 2012-06-13 23:50:35 | 2012-06-13 23:50:35 |  |
| dbo | sp_FA_DeleteAccount | 2012-06-13 23:50:56 | 2012-06-13 23:50:56 |  |
| dbo | sp_FA_DeleteRequisition | 2013-03-13 10:41:06 | 2025-04-16 03:31:13 |  |
| dbo | sp_FA_DeleteRequisition_bk20250416 | 2025-04-15 22:25:26 | 2025-04-15 22:25:26 |  |
| dbo | sp_FA_DeleteUser | 2012-06-13 23:51:17 | 2012-06-13 23:51:17 |  |
| dbo | sp_FA_GetAlert | 2012-06-14 00:03:35 | 2012-06-14 00:03:35 |  |
| dbo | sp_FA_getUserKeys | 2012-06-14 00:05:35 | 2025-03-20 14:07:38 |  |
| dbo | sp_FA_NewPONumbers | 2012-06-14 00:08:08 | 2012-06-14 00:08:08 |  |
| dbo | sp_FA_NextPONumber | 2012-06-13 23:57:58 | 2014-01-10 17:09:24 |  |
| dbo | sp_FA_RequisitionsForPurchaseOrderModal | 2012-06-14 00:07:52 | 2025-07-03 14:36:43 |  |
| dbo | sp_FA_RequisitionsTotals | 2012-06-14 00:05:52 | 2022-05-19 15:15:12 |  |
| dbo | sp_FA_SaveHeading | 2012-06-13 23:48:40 | 2012-06-13 23:48:40 |  |
| dbo | sp_FA_SaveKeyword | 2012-06-13 23:48:22 | 2012-06-13 23:48:22 |  |
| dbo | sp_FA_SavePOs | 2012-06-13 23:59:03 | 2014-01-10 17:09:15 |  |
| dbo | sp_FA_SaveRequisitionNote | 2012-06-13 23:49:10 | 2025-04-16 16:45:52 |  |
| dbo | sp_FA_SaveRequisitionNoteEmails | 2012-06-13 23:49:30 | 2025-04-16 16:48:52 |  |
| dbo | sp_FA_SaveUser | 2012-06-13 23:51:30 | 2024-12-01 08:26:37 |  |
| dbo | sp_FA_SetBudgetAccount | 2012-06-13 23:51:05 | 2013-02-04 00:10:19 |  |
| dbo | sp_FA_SetUserAccount | 2012-06-13 23:51:12 | 2019-05-01 13:54:48 |  |
| dbo | sp_FA_UpdatePOStatus | 2012-06-13 23:48:34 | 2012-06-13 23:48:34 |  |
| dbo | sp_FA_UpdateRequisitionStatus | 2012-06-14 00:04:56 | 2020-03-03 11:30:26 |  |
| dbo | sp_FixVendorItemCode | 2009-07-23 13:29:04 | 2009-07-23 13:51:07 |  |
| dbo | sp_getCurrentPrices | 2012-10-10 13:49:38 | 2012-10-10 13:49:38 |  |
| dbo | sp_GetPODetailByIds | 2025-04-24 22:18:22 | 2025-04-24 22:25:22 |  |
| dbo | sp_GetRequisitionShipping | 2025-04-15 22:38:13 | 2025-04-15 22:38:13 |  |
| dbo | sp_GetUserRequisitions | 2025-04-16 00:23:39 | 2025-04-16 00:23:39 |  |
| dbo | sp_helpdiagramdefinition | 2009-03-26 16:18:10 | 2009-03-26 16:18:10 |  |
| dbo | sp_helpdiagrams | 2009-03-26 16:18:10 | 2009-03-26 16:18:10 |  |
| dbo | sp_HoldRequisition | 2002-03-06 16:39:54 | 2013-07-02 16:11:06 |  |
| dbo | sp_ImportVendorsBid | 2011-08-15 21:46:11 | 2022-08-12 11:04:50 |  |
| dbo | sp_IPQueueStart | 2012-12-18 16:26:38 | 2012-12-18 17:51:55 |  |
| dbo | sp_ISBNAdd | 2002-05-02 13:31:27 | 2013-07-15 11:39:16 |  |
| dbo | sp_Logout | 2001-08-24 14:40:45 | 2009-03-25 06:55:28 |  |
| dbo | sp_MakeReq | 2002-07-30 19:17:59 | 2015-11-24 23:37:35 |  |
| dbo | sp_MasterBudgetBook | 2004-10-01 14:05:29 | 2016-11-04 15:55:21 |  |
| dbo | sp_MergeAccounts | 2016-06-27 13:39:30 | 2016-06-27 13:39:30 |  |
| dbo | sp_MergeAwards | 2002-05-28 11:12:44 | 2009-03-25 06:55:28 |  |
| dbo | sp_MergeBidImports | 2004-04-14 00:29:47 | 2009-03-25 06:55:28 |  |
| dbo | sp_MergeBids | 2002-05-28 10:32:49 | 2009-03-25 06:55:28 |  |
| dbo | sp_MoveIndexes | 2004-01-30 19:54:57 | 2004-01-30 19:54:57 |  |
| dbo | sp_MoveReqs | 2014-04-07 11:35:31 | 2014-04-07 20:44:09 |  |
| dbo | sp_MPIHeadings | 2015-02-25 16:39:25 | 2021-03-23 10:22:14 |  |
| dbo | sp_MSRPExporter | 2014-09-08 19:29:31 | 2014-09-16 16:59:56 |  |
| dbo | sp_MSRPImporter | 2013-11-05 12:32:23 | 2014-09-11 18:38:30 |  |
| dbo | sp_NewReportSession | 2002-05-13 23:42:21 | 2015-11-24 23:37:41 |  |
| dbo | sp_NewRequisitionId | 2001-09-06 23:26:02 | 2025-06-26 11:50:16 |  |
| dbo | sp_NewRequisitionId_BK20250416 | 2025-04-15 22:01:31 | 2025-04-15 22:10:13 |  |
| dbo | sp_NewUpload | 2005-04-19 17:24:29 | 2009-03-25 06:55:28 |  |
| dbo | sp_OrderBookMaint | 2003-10-08 21:02:13 | 2015-11-24 23:37:31 |  |
| dbo | sp_PAAccounts | 2003-06-30 12:55:49 | 2003-06-30 12:55:49 |  |
| dbo | sp_PABudgets | 2003-06-30 12:55:49 | 2014-10-07 17:53:20 |  |
| dbo | sp_PACategories | 2003-06-30 12:55:50 | 2003-06-30 12:55:50 |  |
| dbo | sp_PAComet | 2003-06-30 12:55:50 | 2010-02-01 01:06:45 |  |
| dbo | sp_PARequisitions | 2003-06-30 12:55:51 | 2003-06-30 12:55:51 |  |
| dbo | sp_PARequisitionsTest | 2006-06-26 15:02:06 | 2006-06-26 15:02:06 |  |
| dbo | sp_PARequisitionsTotal | 2003-06-30 12:55:52 | 2003-06-30 12:55:52 |  |
| dbo | sp_PASchools | 2003-06-30 12:55:52 | 2003-06-30 12:55:52 |  |
| dbo | sp_PAStatus | 2003-06-30 12:55:53 | 2003-06-30 12:55:53 |  |
| dbo | sp_PAStatusTest | 2006-06-26 14:25:39 | 2006-06-26 14:25:39 |  |
| dbo | sp_PAStatusTest1 | 2008-07-02 10:49:47 | 2008-07-02 10:49:47 |  |
| dbo | sp_PAUsers | 2003-06-30 12:55:53 | 2010-02-01 01:04:41 |  |
| dbo | sp_PODetail | 2010-07-15 21:58:32 | 2010-07-15 22:25:11 |  |
| dbo | sp_PODetailLastItemOnly | 2025-05-20 11:07:07 | 2025-05-20 11:07:07 |  |
| dbo | sp_PrepareNextYear | 2003-08-23 01:05:38 | 2015-01-28 13:38:11 |  |
| dbo | sp_PrepTMSurvey | 2012-11-15 15:03:40 | 2013-10-06 23:15:25 |  |
| dbo | sp_ProcessCopyRequests | 2004-10-26 19:36:05 | 2009-03-25 06:55:28 |  |
| dbo | sp_processKill | 2008-02-21 00:47:38 | 2009-03-25 06:55:28 |  |
| dbo | sp_processMonitor | 2008-02-19 12:25:04 | 2012-12-27 17:33:21 |  |
| dbo | sp_processMonitorOrig | 2012-12-27 16:43:35 | 2012-12-27 16:43:35 |  |
| dbo | sp_processStatus | 2008-02-20 12:16:42 | 2009-06-15 10:16:41 |  |
| dbo | sp_QueueIPs | 2012-12-18 13:04:05 | 2012-12-18 14:51:36 |  |
| dbo | sp_QueueReqs | 2015-03-24 15:58:54 | 2015-03-24 15:58:54 |  |
| dbo | sp_Reaward_script | 2005-04-06 12:04:01 | 2009-03-25 06:55:28 |  |
| dbo | sp_RefreshAccounts | 2001-12-12 13:22:13 | 2009-03-25 06:55:28 |  |
| dbo | sp_RefreshDistrictVendors | 2003-06-30 12:55:54 | 2014-05-20 12:12:32 |  |
| dbo | sp_RefreshPendingApprovals | 2003-06-30 12:55:55 | 2009-03-25 06:55:28 |  |
| dbo | sp_ReindexAll | 2003-07-07 02:12:00 | 2003-07-07 02:12:00 |  |
| dbo | sp_renamediagram | 2009-03-26 16:18:10 | 2009-03-26 16:18:10 |  |
| dbo | sp_ReportReqData | 2002-01-24 00:55:08 | 2009-03-25 06:55:28 |  |
| dbo | sp_ReqAdd | 2001-10-18 09:08:34 | 2009-03-25 06:55:28 |  |
| dbo | sp_ResetDistrictAccountingYear | 2016-11-15 14:49:45 | 2016-11-15 14:53:26 |  |
| dbo | sp_retrieveTagset | 2012-04-02 17:32:17 | 2012-05-18 16:20:23 |  |
| dbo | sp_retrieveTagsetDMS | 2015-01-05 16:46:30 | 2015-01-05 16:46:30 |  |
| dbo | sp_ReturnUserReqs | 2001-08-24 14:40:45 | 2013-02-22 16:16:21 |  |
| dbo | sp_RTK_AddReportItems | 2005-03-21 15:18:19 | 2009-03-25 06:55:28 |  |
| dbo | sp_RTK_Build_MSDS_and_MSDSDetail | 2013-08-13 14:53:24 | 2015-11-24 23:37:38 |  |
| dbo | sp_RTKExport | 2004-03-04 12:57:23 | 2009-03-25 06:55:28 |  |
| dbo | sp_SaveTags | 2012-03-06 12:43:45 | 2012-03-06 18:39:00 |  |
| dbo | sp_SchoolMerge | 2016-09-26 11:45:44 | 2016-09-26 11:49:48 |  |
| dbo | sp_search | 2001-08-24 14:40:45 | 2009-03-25 06:55:28 |  |
| dbo | sp_SearchItems | 2001-11-12 21:58:36 | 2009-03-25 06:55:28 |  |
| dbo | sp_SearchItemsByReqHK | 2015-03-02 22:18:49 | 2018-08-07 23:49:16 |  |
| dbo | sp_SessionTableUpdate | 2004-09-29 09:31:25 | 2014-10-07 17:53:26 |  |
| dbo | sp_SetBudgetYear | 2002-01-23 11:54:33 | 2014-10-07 17:53:26 |  |
| dbo | sp_SetDistrictAndBudgetYear | 2004-11-30 17:13:19 | 2014-10-07 17:53:26 |  |
| dbo | sp_ShowAllDefrag | 2001-11-28 11:07:51 | 2001-11-28 11:07:51 |  |
| dbo | sp_ShowDistribution | 2002-06-11 12:44:17 | 2009-03-25 06:55:28 |  |
| dbo | sp_ShowTextbookSavings | 2002-06-11 13:45:33 | 2009-03-25 06:55:28 |  |
| dbo | sp_SmallPOCheck | 2015-03-19 16:25:51 | 2015-03-23 13:11:00 |  |
| dbo | sp_SubmitRequisition | 2001-08-24 14:40:45 | 2019-11-13 07:27:40 |  |
| dbo | sp_SubmitRequisitionNew | 2004-12-30 12:37:11 | 2009-03-25 06:55:28 |  |
| dbo | sp_UAAccounts | 2001-08-24 14:40:45 | 2009-03-25 06:55:28 |  |
| dbo | sp_UAList | 2001-08-24 14:40:45 | 2009-03-25 06:55:28 |  |
| dbo | sp_UAListTotals | 2001-08-24 14:40:45 | 2009-03-25 06:55:28 |  |
| dbo | sp_UAUsers | 2001-08-24 14:40:45 | 2009-03-25 06:55:28 |  |
| dbo | sp_UnawardBidHeader | 2004-02-24 00:24:39 | 2009-03-25 06:55:28 |  |
| dbo | sp_UnpostCatalog | 2012-01-03 22:11:08 | 2025-04-09 15:57:20 |  |
| dbo | sp_UpdateAllListPrices | 2012-10-12 13:06:31 | 2012-10-12 13:06:31 |  |
| dbo | sp_UpdateAllReqs | 2002-02-25 16:53:50 | 2009-03-25 06:55:28 |  |
| dbo | sp_UpdateCatalogText | 2012-02-21 00:22:39 | 2012-08-02 18:49:56 |  |
| dbo | sp_UpdateCatalogTextPart | 2012-07-31 22:48:04 | 2012-08-01 22:43:06 |  |
| dbo | sp_UpdateDetails | 2001-08-24 14:40:45 | 2009-03-25 06:55:28 |  |
| dbo | sp_UpdateHeading | 2001-12-07 15:52:21 | 2015-11-24 23:37:41 |  |
| dbo | sp_UpdateISBN | 2004-03-18 23:02:49 | 2015-11-24 23:37:28 |  |
| dbo | sp_UpdateListPrices | 2009-09-16 16:26:16 | 2012-10-11 11:22:32 |  |
| dbo | sp_UpdateMSRPItem | 2013-05-30 13:32:56 | 2014-10-07 17:53:20 |  |
| dbo | sp_UpdateNextNumber | 2002-04-04 15:19:08 | 2009-03-25 06:55:28 |  |
| dbo | sp_UpdatePOAmounts | 2002-06-12 15:19:45 | 2025-06-26 11:54:37 |  |
| dbo | sp_UpdatePricePlan | 2001-11-26 13:44:31 | 2009-03-25 06:55:28 |  |
| dbo | sp_UpdateReq | 2001-08-24 14:40:45 | 2012-07-30 13:56:22 |  |
| dbo | sp_UpdateReqDetail | 2004-01-28 12:56:31 | 2025-07-01 08:44:49 |  |
| dbo | sp_UpdateReqDetailItem | 2002-03-11 15:26:20 | 2009-03-25 06:55:28 |  |
| dbo | sp_UpdateReqDetailList | 2004-05-05 16:33:26 | 2009-03-25 06:55:28 |  |
| dbo | sp_UpdateReqDetailPricePlan | 2002-05-29 14:49:00 | 2009-03-25 06:55:28 |  |
| dbo | sp_UpdateReqHeader | 2001-10-12 10:53:56 | 2009-03-25 06:55:28 |  |
| dbo | sp_UpdateShippingCode | 2014-01-31 12:16:25 | 2014-01-31 12:16:25 |  |
| dbo | sp_UpdateVIC | 2010-03-05 11:16:34 | 2010-03-05 11:16:34 |  |
| dbo | sp_upgraddiagrams | 2009-03-26 16:18:10 | 2009-03-26 16:18:10 |  |
| dbo | sp_ValidateBidImport | 2003-07-15 16:20:30 | 2009-03-25 06:55:28 |  |
| dbo | sp_ValidateForPO | 2012-04-13 15:54:14 | 2015-03-23 19:14:07 |  |
| dbo | sp_VendorOverride | 2005-01-31 21:26:21 | 2009-03-25 06:55:28 |  |
| dbo | sp_VendorOverrideLine | 2008-03-06 21:26:34 | 2014-01-10 17:08:35 |  |
| dbo | sp_VendorOverrideOld | 2008-03-06 18:02:56 | 2009-03-25 06:55:28 |  |
| dbo | sp_VerifyForPO | 2015-03-23 21:31:50 | 2015-03-23 21:31:50 |  |
| dbo | sp_WarningsForPO | 2013-08-07 10:37:33 | 2015-04-07 10:00:23 |  |
| dbo | usp_BidMatchRefs | 2015-08-21 16:56:29 | 2019-08-20 15:00:35 |  |
| dbo | usp_BidPageNumberUpdate | 2019-01-10 11:15:05 | 2019-02-05 10:27:20 |  |
| dbo | usp_BidRanking | 2015-03-24 12:48:21 | 2015-03-24 13:07:04 |  |
| dbo | usp_BidRequestItemMergeDetail_notused | 2015-08-07 14:17:05 | 2019-08-16 15:17:28 |  |
| dbo | usp_BidRequestItemMergeDetailDavid | 2015-08-21 19:05:43 | 2022-08-23 14:57:27 |  |
| dbo | usp_BidRequestItemMergeDetailDavidTest_notused | 2015-08-30 12:26:23 | 2019-08-16 15:17:34 |  |
| dbo | usp_BidRequestItemMergeDetailTempKevin_notused | 2015-08-20 16:18:11 | 2019-08-16 15:17:42 |  |
| dbo | usp_BidRequestMergeActions | 2015-08-24 16:13:59 | 2015-11-24 23:37:35 |  |
| dbo | usp_BidRequestMergeActionsUNDO-wait | 2015-08-27 13:05:50 | 2015-09-01 16:00:40 |  |
| dbo | usp_BringAccountsForward | 2018-09-06 12:09:56 | 2022-05-04 15:44:34 |  |
| dbo | usp_ChangeBidHeaderNumber | 2015-12-02 21:11:23 | 2015-12-02 21:34:49 |  |
| dbo | usp_ContinuanceAcceptance | 2017-11-01 10:46:44 | 2024-02-28 14:28:10 |  |
| dbo | usp_CopyRequisition | 2025-03-26 17:45:26 | 2025-08-11 11:44:01 |  |
| dbo | usp_CreateFreightRequest | 2022-01-30 23:03:10 | 2022-02-16 13:48:39 |  |
| dbo | usp_DetailedIdentityColumnsReport | 2021-08-05 06:05:36 | 2021-08-05 06:21:13 |  |
| dbo | usp_EmailBlastProcessOrderDetailChangeNotifications | 2022-03-28 16:17:18 | 2022-04-01 10:36:19 |  |
| dbo | usp_EmailBlastSetNotificationBlastHTMLApprover | 2022-03-31 21:22:24 | 2024-03-01 12:48:44 |  |
| dbo | usp_EmailBlastSetNotificationBlastHTMLRequisitioner | 2022-03-31 21:24:29 | 2024-02-29 14:56:28 |  |
| dbo | usp_EmailBlastVarsOrderDetailChangeApprover_NotUsed | 2022-03-28 16:21:56 | 2022-04-06 13:07:27 |  |
| dbo | usp_EmailBlastVarsOrderDetailChangeRequistioner_NotUsed | 2022-03-28 16:23:50 | 2022-04-06 13:09:18 |  |
| dbo | usp_EndPOSend | 2019-04-28 12:45:09 | 2019-04-28 12:46:45 |  |
| dbo | usp_FindEmail | 2024-01-25 18:21:30 | 2024-08-14 23:33:25 |  |
| dbo | usp_FindEmail_BK | 2024-08-14 23:31:34 | 2024-08-14 23:31:34 |  |
| dbo | usp_GeneratePassword | 2023-09-20 16:34:11 | 2024-12-01 19:39:15 |  |
| dbo | usp_GeneratePassword_Print | 2025-01-03 09:17:08 | 2025-01-03 09:17:08 |  |
| dbo | usp_GetBidItemAIData | 2025-07-10 09:25:50 | 2025-07-10 09:25:50 |  |
| dbo | usp_GetBidItemsNeedingAIUpdate | 2025-07-10 09:22:52 | 2025-07-14 16:59:21 |  |
| dbo | usp_GetImageList | 2021-05-03 22:29:23 | 2025-03-21 09:02:46 |  |
| dbo | usp_GetItemAIData | 2025-04-27 18:18:06 | 2025-05-07 16:46:32 |  |
| dbo | usp_GetItemsNeedingAIUpdate | 2025-04-27 18:21:27 | 2025-06-30 14:55:37 |  |
| dbo | usp_GetMSDSSheets | 2017-01-25 06:19:09 | 2017-01-25 06:28:50 |  |
| dbo | usp_getMyLastYearsReqs | 2025-03-26 17:44:57 | 2025-03-26 17:44:57 |  |
| dbo | usp_GetNextPONumber | 2019-04-09 14:29:29 | 2024-04-12 10:46:12 |  |
| dbo | usp_GetPODetail | 2025-06-05 14:22:47 | 2025-08-06 12:31:34 |  |
| dbo | usp_GetPODetail_Test | 2025-06-15 19:24:54 | 2025-06-24 15:35:25 |  |
| dbo | usp_GetPOs | 2019-04-28 12:46:44 | 2025-07-06 19:51:03 |  |
| dbo | usp_GetPOs_Test | 2022-05-18 01:08:58 | 2022-05-18 01:08:58 |  |
| dbo | usp_getSDSDocsAll | 2022-09-14 18:34:46 | 2022-09-14 18:35:26 |  |
| dbo | usp_getSDSDocsDistrict | 2022-09-14 16:57:36 | 2022-09-14 18:35:48 |  |
| dbo | usp_getSDSDocsSchool | 2022-09-14 16:53:18 | 2022-09-14 18:36:37 |  |
| dbo | usp_getSDSDocsUser | 2022-09-14 16:48:46 | 2022-09-14 18:36:11 |  |
| dbo | usp_getSDSheets | 2022-08-08 07:59:20 | 2022-08-08 07:59:48 |  |
| dbo | usp_getSDSItems | 2022-08-03 12:32:01 | 2022-08-08 07:59:48 |  |
| dbo | usp_GetSDSURLs | 2021-06-07 12:38:34 | 2021-07-23 14:19:40 |  |
| dbo | usp_GetVendorPricing | 2021-03-31 09:15:55 | 2021-03-31 09:15:55 |  |
| dbo | usp_ImportUser | 2022-02-17 17:00:24 | 2022-02-26 10:11:50 |  |
| dbo | usp_MakeZ$ | 2022-12-02 15:36:26 | 2023-12-01 08:13:51 |  |
| dbo | usp_MakeZC | 2022-12-02 15:35:16 | 2022-12-03 20:51:20 |  |
| dbo | usp_MissingHeaders | 2019-09-05 09:35:55 | 2019-09-05 09:35:55 |  |
| dbo | usp_mySDS | 2019-03-15 16:05:09 | 2019-03-15 16:05:09 |  |
| dbo | usp_OrderEZVendors | 2019-03-19 13:42:03 | 2021-04-25 21:34:34 |  |
| dbo | usp_POPrintExport | 2019-04-29 14:48:09 | 2019-04-29 14:48:09 |  |
| dbo | usp_POStatusByRep | 2021-04-21 15:27:48 | 2021-04-21 17:44:45 |  |
| dbo | usp_POStatusByState | 2022-05-05 07:31:34 | 2023-05-18 09:57:32 |  |
| dbo | usp_POStatusUpdates | 2019-07-17 15:25:13 | 2023-06-30 13:58:00 |  |
| dbo | usp_QueuePOsToSend | 2019-06-10 11:24:30 | 2025-06-04 15:27:29 |  |
| dbo | usp_RestoreBidHeaderNumber | 2015-12-03 00:16:55 | 2015-12-03 00:41:19 |  |
| dbo | usp_SavePositionData | 2025-04-21 20:52:26 | 2025-04-21 20:52:26 |  |
| dbo | usp_SDSDocs | 2019-02-21 12:45:25 | 2025-07-24 16:03:22 |  |
| dbo | usp_SearchItems_SearchDataDB | 2019-10-16 07:14:11 | 2019-10-16 07:35:16 |  |
| dbo | usp_SearchItemsByReqHKDS | 2018-08-07 23:53:11 | 2022-12-22 15:00:36 |  |
| dbo | usp_SearchItemsByReqHKDS_David | 2020-04-16 11:47:58 | 2020-04-16 11:47:58 |  |
| dbo | usp_SearchItemsByReqHKDSDavid | 2020-06-09 16:03:49 | 2020-06-09 17:20:06 |  |
| dbo | usp_SearchItemsByReqHKDSError | 2020-06-08 12:51:31 | 2020-06-08 12:51:31 |  |
| dbo | usp_SearchItemsByReqHKDSTest | 2018-12-12 10:51:27 | 2019-06-26 14:50:48 |  |
| dbo | usp_SearchVendors | 2019-01-28 08:13:15 | 2022-03-22 10:17:02 |  |
| dbo | usp_SetBidItemAIData | 2025-07-10 10:02:05 | 2025-07-11 15:16:04 |  |
| dbo | usp_SetItemAIData | 2025-04-27 18:21:27 | 2025-07-11 15:08:50 |  |
| dbo | usp_SetPricing | 2018-08-06 23:59:55 | 2025-08-15 20:26:40 |  |
| dbo | usp_SetPricing_SearchDataDB | 2019-10-16 07:17:55 | 2019-11-01 12:45:14 |  |
| dbo | usp_ShowItemURLs | 2019-07-29 15:10:09 | 2019-07-29 15:11:17 |  |
| dbo | usp_StartPOSend | 2019-04-28 12:45:09 | 2023-05-23 10:24:06 |  |
| dbo | usp_StoreImage | 2021-05-03 22:02:21 | 2021-05-03 22:02:21 |  |
| dbo | usp_StoreImageDone | 2021-05-03 22:02:22 | 2021-05-03 22:02:22 |  |
| dbo | usp_StoreImageError | 2021-05-03 22:02:22 | 2021-05-03 22:02:22 |  |
| dbo | usp_StoreVendorOrder | 2025-06-06 19:51:03 | 2025-07-25 11:35:56 |  |
| dbo | usp_TransactionLogMover | 2025-03-09 16:36:24 | 2025-04-06 12:08:31 |  |
| dbo | usp_UpdateBudgets | 2019-09-05 09:27:02 | 2019-09-05 09:29:49 |  |
| dbo | usp_UpdatePONextNumber | 2019-08-08 19:37:13 | 2024-04-11 21:59:10 |  |
| dbo | usp_UpdatePONumbers | 2019-05-01 11:38:14 | 2019-05-01 11:38:14 |  |
| dbo | usp_validateRequisitionStatuses | 2023-09-25 17:22:49 | 2023-09-25 17:22:49 |  |
| dbo | usp_VendorStatsCYvsLY | 2021-04-12 16:26:29 | 2025-05-08 16:15:38 |  |
| dbo | usp_WaitingTasks | 2019-08-14 13:07:26 | 2019-08-16 12:13:35 |  |
| dbo | x_TestErrorHandling | 2016-04-27 22:11:28 | 2016-04-27 22:37:36 |  |
| EDSIQWebUser | sp_CCAddAddendaItem_EDSIQWebuser | 2002-12-12 14:53:59 | 2015-11-24 23:37:39 |  |
| EDSIQWebUser | sp_CCAddAddendaMaint | 2003-05-16 12:59:52 | 2015-11-24 23:37:42 |  |
| EDSIQWebUser | sp_CCUpdateAddendaItem_EDSIQWEBUSER | 2002-12-12 14:54:09 | 2013-02-04 00:18:57 |  |
| EDSIQWebUser | sp_CCUpdateAddendaMaint | 2003-05-16 13:01:59 | 2015-11-24 23:37:29 |  |
| EDSIQWebUser | sp_CombineReqs | 2003-01-08 20:30:11 | 2009-03-25 06:55:28 |  |
| EDSIQWebUser | sp_CombineReqsNoDelete | 2003-06-03 12:45:57 | 2009-03-25 06:55:28 |  |
| EDSIQWebUser | sp_ConvertReadyBatches | 2003-02-11 19:54:47 | 2009-03-25 06:55:28 |  |
| EDSIQWebUser | sp_CopyReq | 2002-11-25 14:06:52 | 2014-10-07 17:53:24 |  |
| EDSIQWebUser | sp_CopyReqs | 2003-06-30 12:55:48 | 2009-03-25 06:55:28 |  |
| EDSIQWebUser | sp_CoverView | 2003-01-09 15:10:55 | 2009-03-25 06:55:28 |  |
| EDSIQWebUser | sp_DeleteDistrictBudgetPOs | 2002-08-14 11:59:37 | 2009-03-25 06:55:28 |  |
| EDSIQWebUser | sp_DeleteEmptyReqs | 2003-01-09 16:38:54 | 2014-01-06 16:40:17 |  |
| EDSIQWebUser | sp_DeletePOList | 2003-05-02 09:50:18 | 2009-03-25 06:55:28 |  |
| EDSIQWebUser | sp_DeleteRequisitionWithItems | 2003-03-13 11:26:51 | 2009-03-25 06:55:28 |  |
| EDSIQWebUser | sp_MultiBatchLoad | 2002-09-23 10:28:01 | 2015-11-24 23:37:34 |  |
| EDSIQWebUser | sp_NightlyGarbageCollection | 2002-11-22 06:50:37 | 2009-03-25 06:55:28 |  |
| EDSIQWebUser | sp_OrderBookCopy | 2002-12-19 16:06:48 | 2015-11-24 23:37:41 |  |
| EDSIQWebUser | sp_SavingsLetter | 2003-06-30 12:55:56 | 2009-03-25 06:55:28 |  |
| EDSIQWebUser | sp_Sys3000ToWinCap | 2002-07-31 10:58:03 | 2002-07-31 10:58:03 |  |
| utility | Log_ProcedureCall | 2016-04-27 23:15:10 | 2016-04-27 23:15:10 |  |


## Functions

| Schema | Function Name | Type | Created | Modified | Description |
|--------|---------------|------|---------|----------|-------------|
| dbo | fn_diagramobjects | SQL_SCALAR_FUNCTION | 2009-03-26 16:18:10 | 2009-03-26 16:18:10 |  |
| dbo | fnParseRTF | SQL_SCALAR_FUNCTION | 2012-02-06 21:21:01 | 2012-02-06 21:29:27 |  |
| dbo | isValidEmail | SQL_SCALAR_FUNCTION | 2011-08-24 14:44:35 | 2012-11-07 13:10:56 |  |
| dbo | RTF2TXT | SQL_SCALAR_FUNCTION | 2012-02-06 20:56:24 | 2012-02-06 21:31:16 |  |
| dbo | uf_ActiveAccountList | SQL_SCALAR_FUNCTION | 2004-10-03 15:09:09 | 2009-03-25 06:55:28 |  |
| dbo | uf_AwardLetter | SQL_TABLE_VALUED_FUNCTION | 2008-05-29 22:42:29 | 2009-03-25 06:55:28 |  |
| dbo | uf_AwardLetter1 | SQL_TABLE_VALUED_FUNCTION | 2008-05-29 22:51:44 | 2009-03-25 06:55:28 |  |
| dbo | uf_AwardLetterBid | SQL_TABLE_VALUED_FUNCTION | 2008-06-06 14:04:15 | 2024-07-25 13:09:39 |  |
| dbo | uf_AwardLetterBid_Orig | SQL_TABLE_VALUED_FUNCTION | 2011-02-25 11:05:29 | 2011-02-25 11:05:29 |  |
| dbo | uf_AwardLetterBid1 | SQL_TABLE_VALUED_FUNCTION | 2011-02-25 11:05:01 | 2011-02-25 11:05:01 |  |
| dbo | uf_BatchChanges | SQL_TABLE_VALUED_FUNCTION | 2002-03-01 01:08:49 | 2009-03-25 06:55:28 |  |
| dbo | uf_BidAnalysisDetail | SQL_INLINE_TABLE_VALUED_FUNCTION | 2004-02-18 22:32:39 | 2015-08-05 15:03:20 |  |
| dbo | uf_BidAnalysisDetailItem | SQL_INLINE_TABLE_VALUED_FUNCTION | 2005-01-31 20:53:48 | 2013-08-08 23:34:51 |  |
| dbo | uf_BidAnalysisDetailReq | SQL_INLINE_TABLE_VALUED_FUNCTION | 2004-02-18 22:36:45 | 2013-04-22 11:10:57 |  |
| dbo | uf_BidAnalysisDetailReqComb | SQL_INLINE_TABLE_VALUED_FUNCTION | 2006-05-30 23:45:30 | 2014-03-07 20:35:40 |  |
| dbo | uf_BidAnalysisDetailRSId | SQL_INLINE_TABLE_VALUED_FUNCTION | 2007-06-26 23:18:07 | 2012-03-12 15:00:43 |  |
| dbo | uf_BidAnalysisDetailTest | SQL_INLINE_TABLE_VALUED_FUNCTION | 2010-03-18 11:33:42 | 2010-03-18 13:56:58 |  |
| dbo | uf_BidAnalysisVendorSummary | SQL_INLINE_TABLE_VALUED_FUNCTION | 2009-08-19 14:01:50 | 2011-11-28 09:46:32 |  |
| dbo | uf_BidAnalysisVendorSummaryByDistrict | SQL_INLINE_TABLE_VALUED_FUNCTION | 2009-08-19 14:36:16 | 2009-08-19 14:36:16 |  |
| dbo | uf_BidItemDescription | SQL_SCALAR_FUNCTION | 2014-01-10 17:14:42 | 2017-03-21 16:49:57 |  |
| dbo | uf_BidItemWinner | SQL_INLINE_TABLE_VALUED_FUNCTION | 2003-07-17 11:10:46 | 2009-03-25 06:55:28 |  |
| dbo | uf_BidItemWinnerReq | SQL_INLINE_TABLE_VALUED_FUNCTION | 2004-02-17 13:15:13 | 2009-03-25 06:55:28 |  |
| dbo | uf_BidMSRPRankedManufacturerProductLinesOrdered | SQL_TABLE_VALUED_FUNCTION | 2013-11-18 23:55:23 | 2013-11-18 23:55:23 |  |
| dbo | uf_BidProjectAveragePO | SQL_INLINE_TABLE_VALUED_FUNCTION | 2003-07-17 11:11:51 | 2022-05-06 11:52:57 |  |
| dbo | uf_BidProjectAveragePODistrict | SQL_INLINE_TABLE_VALUED_FUNCTION | 2004-02-25 00:54:33 | 2022-05-06 11:52:57 |  |
| dbo | uf_BidProjectAveragePOReq | SQL_INLINE_TABLE_VALUED_FUNCTION | 2004-02-17 13:15:35 | 2022-05-06 11:52:56 |  |
| dbo | uf_BidProjectAveragePORSId | SQL_INLINE_TABLE_VALUED_FUNCTION | 2007-06-26 23:17:52 | 2022-05-06 11:52:56 |  |
| dbo | uf_BidSummary | SQL_TABLE_VALUED_FUNCTION | 2004-05-08 12:11:21 | 2009-03-25 06:55:28 |  |
| dbo | uf_BidSummaryVendors | SQL_TABLE_VALUED_FUNCTION | 2004-05-07 18:34:07 | 2009-03-25 06:55:28 |  |
| dbo | uf_BillingMonths | SQL_SCALAR_FUNCTION | 2018-07-09 14:45:56 | 2018-07-09 14:58:51 |  |
| dbo | uf_CatalogFtsHighlights | SQL_TABLE_VALUED_FUNCTION | 2012-06-06 23:38:36 | 2017-12-19 12:56:25 |  |
| dbo | uf_CatalogFtsPageHighlights | SQL_TABLE_VALUED_FUNCTION | 2012-07-08 22:57:52 | 2017-12-19 12:55:05 |  |
| dbo | uf_CatalogRefs | SQL_SCALAR_FUNCTION | 2004-10-08 10:57:44 | 2014-01-31 15:34:42 |  |
| dbo | uf_CatalogRefsAsp | SQL_SCALAR_FUNCTION | 2012-09-19 11:38:29 | 2013-01-14 15:56:25 |  |
| dbo | uf_CatalogRefsDetail | SQL_SCALAR_FUNCTION | 2013-01-20 14:33:53 | 2017-04-17 12:29:57 |  |
| dbo | uf_CatalogRefsDetailTest | SQL_SCALAR_FUNCTION | 2017-04-17 12:29:23 | 2017-04-17 12:29:23 |  |
| dbo | uf_CatalogRefsItem | SQL_SCALAR_FUNCTION | 2013-03-13 22:31:29 | 2013-03-13 22:31:29 |  |
| dbo | uf_CleanExtdAsciiChars | SQL_SCALAR_FUNCTION | 2019-11-05 05:34:45 | 2019-11-05 05:34:45 |  |
| dbo | uf_ConfiguredDistricts | SQL_SCALAR_FUNCTION | 2013-12-02 17:32:45 | 2013-12-02 17:38:58 |  |
| dbo | uf_ContactList | SQL_SCALAR_FUNCTION | 2012-01-16 23:42:50 | 2012-01-16 23:59:12 |  |
| dbo | uf_ContactListHtml | SQL_SCALAR_FUNCTION | 2012-01-17 00:22:40 | 2012-01-17 00:22:40 |  |
| dbo | uf_ContactListText | SQL_SCALAR_FUNCTION | 2012-01-17 00:23:25 | 2012-01-17 00:23:25 |  |
| dbo | uf_CrossRefs2Text | SQL_SCALAR_FUNCTION | 2003-05-10 10:34:08 | 2025-07-18 13:52:29 |  |
| dbo | uf_CrossRefs2TextOrig | SQL_SCALAR_FUNCTION | 2010-06-03 14:40:53 | 2017-01-14 20:10:28 |  |
| dbo | uf_DecodeChargeDates | SQL_SCALAR_FUNCTION | 2017-03-01 10:32:36 | 2017-03-01 10:36:37 |  |
| dbo | uf_DetailDescription | SQL_SCALAR_FUNCTION | 2004-09-29 15:53:31 | 2015-09-01 11:56:40 |  |
| dbo | uf_DetailItemDescription | SQL_SCALAR_FUNCTION | 2006-08-07 11:05:00 | 2015-09-01 11:54:21 |  |
| dbo | uf_DetailItemDescriptionNoExtra | SQL_SCALAR_FUNCTION | 2013-06-07 10:50:52 | 2015-09-01 11:53:06 |  |
| dbo | uf_DetailItemDescriptionNoExtraNH | SQL_SCALAR_FUNCTION | 2015-03-06 13:20:20 | 2015-09-01 11:53:30 |  |
| dbo | uf_DistrictBANameAndAddress | SQL_SCALAR_FUNCTION | 2012-02-09 16:03:28 | 2023-12-13 14:02:27 |  |
| dbo | uf_DistrictNameAndAddress | SQL_SCALAR_FUNCTION | 2007-03-21 16:18:18 | 2009-03-25 06:55:28 |  |
| dbo | uf_DistrictPaymentHistory | SQL_TABLE_VALUED_FUNCTION | 2008-06-05 10:32:10 | 2009-03-25 06:55:28 |  |
| dbo | uf_DistrictPaymentHistoryBudget | SQL_TABLE_VALUED_FUNCTION | 2008-06-05 10:35:02 | 2009-03-25 06:55:28 |  |
| dbo | uf_DistrictPaymentSchedule | SQL_TABLE_VALUED_FUNCTION | 2007-04-04 10:21:47 | 2023-01-12 12:09:22 |  |
| dbo | uf_DistrictPaymentScheduleBudget | SQL_TABLE_VALUED_FUNCTION | 2014-03-20 15:54:32 | 2023-01-12 12:08:53 |  |
| dbo | uf_DistrictPaymentScheduleQBO | SQL_TABLE_VALUED_FUNCTION | 2022-11-16 13:39:09 | 2025-05-19 12:55:24 |  |
| dbo | uf_DistrictPaymentScheduleQBOBudget | SQL_TABLE_VALUED_FUNCTION | 2024-07-08 19:07:58 | 2025-03-19 10:58:49 |  |
| dbo | uf_DistrictPaymentScheduleQBOTest | SQL_TABLE_VALUED_FUNCTION | 2024-11-20 11:50:22 | 2024-11-20 11:50:22 |  |
| dbo | uf_DistrictProposedFees | SQL_TABLE_VALUED_FUNCTION | 2016-01-12 23:16:10 | 2023-01-12 12:07:36 |  |
| dbo | uf_DistrictSummary | SQL_TABLE_VALUED_FUNCTION | 2002-06-26 22:30:07 | 2009-03-25 06:55:28 |  |
| dbo | uf_DistrictSummary1 | SQL_TABLE_VALUED_FUNCTION | 2006-05-31 10:27:44 | 2018-05-04 14:19:27 |  |
| dbo | uf_DistrictSummary1_Test | SQL_TABLE_VALUED_FUNCTION | 2022-04-04 10:38:53 | 2022-04-04 10:38:53 |  |
| dbo | uf_DistrictSummary2 | SQL_TABLE_VALUED_FUNCTION | 2003-04-30 13:49:07 | 2009-03-25 06:55:28 |  |
| dbo | uf_DistrictSummary2Off | SQL_TABLE_VALUED_FUNCTION | 2003-04-30 14:06:41 | 2009-03-25 06:55:28 |  |
| dbo | uf_DistrictSummaryBid | SQL_TABLE_VALUED_FUNCTION | 2006-05-31 10:28:37 | 2022-05-19 11:23:11 |  |
| dbo | uf_DistrictSummaryBidHeader | SQL_TABLE_VALUED_FUNCTION | 2016-03-30 23:12:34 | 2016-03-30 23:12:34 |  |
| dbo | uf_DistrictSummaryVendors | SQL_TABLE_VALUED_FUNCTION | 2002-06-26 22:30:05 | 2009-03-25 06:55:28 |  |
| dbo | uf_DistrictSummaryVendors1 | SQL_TABLE_VALUED_FUNCTION | 2004-06-25 11:16:27 | 2009-03-25 06:55:28 |  |
| dbo | uf_DistrictSummaryVendorsBid | SQL_TABLE_VALUED_FUNCTION | 2006-05-18 17:00:24 | 2022-05-19 11:18:15 |  |
| dbo | uf_EncryptPassword | SQL_SCALAR_FUNCTION | 2024-10-18 02:10:25 | 2024-10-18 02:10:25 |  |
| dbo | uf_ExportMSRPBid | SQL_TABLE_VALUED_FUNCTION | 2014-07-16 15:05:03 | 2014-07-16 15:05:03 |  |
| dbo | uf_ExtractListEntry | SQL_SCALAR_FUNCTION | 2007-03-22 12:40:37 | 2007-03-22 12:40:37 |  |
| dbo | uf_FA_ApprovalUserTree | SQL_TABLE_VALUED_FUNCTION | 2012-12-21 00:26:36 | 2020-04-27 16:00:25 |  |
| dbo | uf_FA_Requisitions | SQL_INLINE_TABLE_VALUED_FUNCTION | 2012-06-14 00:05:22 | 2025-06-26 14:28:31 |  |
| dbo | uf_FA_UserApproverTree | SQL_TABLE_VALUED_FUNCTION | 2012-06-13 23:56:34 | 2024-10-22 15:41:28 |  |
| dbo | uf_FirstPhrase | SQL_SCALAR_FUNCTION | 2003-06-17 16:50:49 | 2003-06-17 16:50:49 |  |
| dbo | uf_FirstWord | SQL_SCALAR_FUNCTION | 2011-08-25 11:40:06 | 2011-08-25 11:57:54 |  |
| dbo | uf_FixExtended | SQL_SCALAR_FUNCTION | 2013-01-30 21:26:07 | 2013-01-30 23:20:59 |  |
| dbo | uf_FormatData | SQL_SCALAR_FUNCTION | 2012-03-05 22:37:07 | 2012-03-05 23:36:44 |  |
| dbo | uf_FormatDateDisplay | SQL_SCALAR_FUNCTION | 2024-02-06 15:19:21 | 2024-02-06 15:19:21 |  |
| dbo | uf_GetTrackingA | SQL_SCALAR_FUNCTION | 2025-06-06 14:14:10 | 2025-06-10 10:01:27 |  |
| dbo | uf_IsBid | SQL_SCALAR_FUNCTION | 2013-07-01 16:21:20 | 2014-07-08 10:49:47 |  |
| dbo | uf_IsRequisitionLocked | SQL_SCALAR_FUNCTION | 2004-05-11 09:36:26 | 2023-04-11 15:59:23 |  |
| dbo | uf_ItemDescription | SQL_SCALAR_FUNCTION | 2003-05-10 10:19:41 | 2015-09-01 08:46:32 |  |
| dbo | uf_LineCount | SQL_SCALAR_FUNCTION | 2004-07-07 19:32:04 | 2004-07-07 19:32:04 |  |
| dbo | uf_LookupItemCode | SQL_TABLE_VALUED_FUNCTION | 2004-06-14 15:40:08 | 2009-03-25 06:55:28 |  |
| dbo | uf_LookupItemCodeByBH | SQL_TABLE_VALUED_FUNCTION | 2006-11-13 08:25:09 | 2009-03-25 06:55:28 |  |
| dbo | uf_LookupItemCodeByBH1 | SQL_TABLE_VALUED_FUNCTION | 2006-11-13 08:26:25 | 2009-03-25 06:55:28 |  |
| dbo | uf_LookupItemCodeByReq | SQL_TABLE_VALUED_FUNCTION | 2008-02-05 22:09:52 | 2022-02-17 11:47:07 |  |
| dbo | uf_LookupItemCodeByReq-120912 | SQL_TABLE_VALUED_FUNCTION | 2012-09-12 13:01:06 | 2012-09-12 13:01:06 |  |
| dbo | uf_LookupItemCodeByReqOld120912 | SQL_TABLE_VALUED_FUNCTION | 2012-09-12 13:02:44 | 2012-09-12 13:02:44 |  |
| dbo | uf_LookupItemCodeByReqSaved | SQL_TABLE_VALUED_FUNCTION | 2008-02-05 22:09:28 | 2009-03-25 06:55:28 |  |
| dbo | uf_LookupItemCodeByReqTest | SQL_TABLE_VALUED_FUNCTION | 2012-03-08 21:13:04 | 2012-03-08 21:13:04 |  |
| dbo | uf_LookupItemCodeByReqVendor | SQL_TABLE_VALUED_FUNCTION | 2012-04-11 11:26:20 | 2025-05-27 10:16:09 |  |
| dbo | uf_LookupItemCodeByReqVendor_BK20241205 | SQL_TABLE_VALUED_FUNCTION | 2024-12-05 00:05:47 | 2024-12-05 00:05:47 |  |
| dbo | uf_LookupItemCodeByReqVendor_BK20241227 | SQL_TABLE_VALUED_FUNCTION | 2024-12-27 01:54:30 | 2024-12-27 01:54:30 |  |
| dbo | uf_LookupItemCodeByReqVendorTest | SQL_TABLE_VALUED_FUNCTION | 2017-04-04 11:49:38 | 2017-04-04 12:36:49 |  |
| dbo | uf_LookupItemCodeReq | SQL_TABLE_VALUED_FUNCTION | 2003-06-27 18:39:40 | 2009-03-25 06:55:28 |  |
| dbo | uf_LookupItems | SQL_TABLE_VALUED_FUNCTION | 2004-05-05 14:23:16 | 2009-03-25 06:55:28 |  |
| dbo | uf_LookupPrice | SQL_TABLE_VALUED_FUNCTION | 2004-05-27 15:10:26 | 2009-03-25 06:55:28 |  |
| dbo | uf_LookupPriceByBH | SQL_TABLE_VALUED_FUNCTION | 2006-09-16 14:16:12 | 2019-05-02 20:17:32 |  |
| dbo | uf_LookupPriceByBHLong | SQL_TABLE_VALUED_FUNCTION | 2020-12-23 19:13:05 | 2024-12-11 16:36:03 |  |
| dbo | uf_LookupPricesAlt | SQL_TABLE_VALUED_FUNCTION | 2008-12-12 15:00:01 | 2009-03-25 06:55:28 |  |
| dbo | uf_lower | SQL_SCALAR_FUNCTION | 2001-08-24 14:40:45 | 2001-08-24 14:40:45 |  |
| dbo | uf_LowestPrice | SQL_SCALAR_FUNCTION | 2003-07-16 17:12:42 | 2009-03-25 06:55:28 |  |
| dbo | uf_LowestPriceId | SQL_SCALAR_FUNCTION | 2003-07-16 17:12:42 | 2009-09-02 15:26:53 |  |
| dbo | uf_MSRPCheckManufacturerAndNumber | SQL_TABLE_VALUED_FUNCTION | 2013-05-21 15:17:46 | 2013-05-21 15:17:46 |  |
| dbo | uf_MyUserTree | SQL_TABLE_VALUED_FUNCTION | 2012-12-17 18:51:56 | 2012-12-17 19:00:03 |  |
| dbo | uf_NameParser | SQL_TABLE_VALUED_FUNCTION | 2011-08-29 15:24:36 | 2011-08-29 17:42:51 |  |
| dbo | uf_NewSavingsLetter | SQL_TABLE_VALUED_FUNCTION | 2004-03-05 12:44:47 | 2009-03-25 06:55:28 |  |
| dbo | uf_NextCometId | SQL_SCALAR_FUNCTION | 2008-01-23 11:05:50 | 2009-03-25 06:55:28 |  |
| dbo | uf_NextLowestPrice | SQL_SCALAR_FUNCTION | 2003-07-16 17:12:42 | 2009-03-25 06:55:28 |  |
| dbo | uf_NextLowestPriceId | SQL_SCALAR_FUNCTION | 2003-07-16 17:12:42 | 2009-03-25 06:55:28 |  |
| dbo | uf_OrderBook | SQL_TABLE_VALUED_FUNCTION | 2008-09-22 13:31:20 | 2016-07-28 11:22:10 |  |
| dbo | uf_OrderBook03 | SQL_TABLE_VALUED_FUNCTION | 2006-11-13 08:30:08 | 2009-03-25 06:55:28 |  |
| dbo | uf_OrderBookNew | SQL_TABLE_VALUED_FUNCTION | 2009-09-25 13:28:49 | 2009-09-25 15:21:06 |  |
| dbo | uf_OrderBookSaved | SQL_TABLE_VALUED_FUNCTION | 2009-09-25 15:29:38 | 2009-09-25 15:29:38 |  |
| dbo | uf_OrderBookTest | SQL_TABLE_VALUED_FUNCTION | 2008-10-07 15:00:55 | 2009-03-25 06:55:28 |  |
| dbo | uf_OrderBookTest1 | SQL_TABLE_VALUED_FUNCTION | 2010-11-24 14:33:56 | 2010-11-24 16:05:18 |  |
| dbo | uf_OrderOrBudgetBook | SQL_TABLE_VALUED_FUNCTION | 2017-10-23 07:24:32 | 2018-12-14 11:51:31 |  |
| dbo | uf_PackCode | SQL_SCALAR_FUNCTION | 2002-06-26 19:59:18 | 2011-11-14 18:16:25 |  |
| dbo | uf_PackCode_New | SQL_SCALAR_FUNCTION | 2011-11-10 22:17:36 | 2011-11-10 22:17:36 |  |
| dbo | uf_PackCode_Old | SQL_SCALAR_FUNCTION | 2011-11-10 22:00:11 | 2011-11-10 22:00:11 |  |
| dbo | uf_PackCodeCatalog | SQL_SCALAR_FUNCTION | 2002-12-12 10:09:14 | 2013-02-26 17:41:25 |  |
| dbo | uf_PackCodeCatalog_Old | SQL_SCALAR_FUNCTION | 2011-11-10 21:54:48 | 2011-11-10 21:54:48 |  |
| dbo | uf_PackCodeCatalogTest | SQL_SCALAR_FUNCTION | 2019-03-13 12:26:08 | 2019-03-13 12:26:08 |  |
| dbo | uf_PackCodeExport | SQL_SCALAR_FUNCTION | 2010-03-30 15:56:38 | 2011-11-14 12:19:30 |  |
| dbo | uf_PackCodeExport_Old | SQL_SCALAR_FUNCTION | 2011-11-10 22:03:47 | 2011-11-10 22:14:10 |  |
| dbo | uf_PARequisitions | SQL_TABLE_VALUED_FUNCTION | 2006-06-27 12:53:53 | 2011-11-22 14:01:59 |  |
| dbo | uf_PARequisitionsTest | SQL_TABLE_VALUED_FUNCTION | 2006-06-26 16:49:15 | 2009-03-25 06:55:28 |  |
| dbo | uf_POAccountList | SQL_TABLE_VALUED_FUNCTION | 2006-06-15 15:48:42 | 2009-05-05 14:58:45 |  |
| dbo | uf_POAccountsUsed | SQL_TABLE_VALUED_FUNCTION | 2003-04-03 16:32:54 | 2009-05-05 15:01:14 |  |
| dbo | uf_POAttentionList | SQL_TABLE_VALUED_FUNCTION | 2007-04-16 14:21:06 | 2009-05-05 14:24:33 |  |
| dbo | uf_POAttentionListCount | SQL_SCALAR_FUNCTION | 2007-05-01 12:40:26 | 2009-05-05 13:56:20 |  |
| dbo | uf_PODetail | SQL_TABLE_VALUED_FUNCTION | 2004-09-30 10:04:33 | 2009-03-25 06:55:28 |  |
| dbo | uf_PODetailSummary | SQL_TABLE_VALUED_FUNCTION | 2004-09-30 10:03:48 | 2009-03-25 06:55:28 |  |
| dbo | uf_PODetailSummary1 | SQL_TABLE_VALUED_FUNCTION | 2004-09-30 10:04:10 | 2018-08-27 14:10:59 |  |
| dbo | uf_POHeader | SQL_TABLE_VALUED_FUNCTION | 2003-05-15 15:12:58 | 2009-03-25 06:55:28 |  |
| dbo | uf_PricePlanSummary | SQL_TABLE_VALUED_FUNCTION | 2003-06-30 12:55:44 | 2009-03-25 06:55:28 |  |
| dbo | uf_ProposedDistrictPaymentSchedule | SQL_TABLE_VALUED_FUNCTION | 2017-10-27 11:45:00 | 2024-03-13 11:07:50 |  |
| dbo | uf_RemoveHighOrder | SQL_SCALAR_FUNCTION | 2009-05-12 14:31:54 | 2009-05-12 14:31:54 |  |
| dbo | uf_RemoveLeadingZeros | SQL_SCALAR_FUNCTION | 2001-11-02 13:16:30 | 2001-11-02 13:16:30 |  |
| dbo | uf_RemoveTrailingCRs | SQL_SCALAR_FUNCTION | 2003-08-27 14:47:07 | 2010-05-05 13:56:10 |  |
| dbo | uf_RequisitionCategories | SQL_INLINE_TABLE_VALUED_FUNCTION | 2014-03-13 23:58:42 | 2025-01-12 19:21:58 |  |
| dbo | uf_RequisitionCategoriesTest | SQL_INLINE_TABLE_VALUED_FUNCTION | 2016-03-09 10:15:59 | 2016-03-09 10:17:54 |  |
| dbo | uf_RequisitionData | SQL_INLINE_TABLE_VALUED_FUNCTION | 2003-03-12 14:54:20 | 2009-03-25 06:55:28 |  |
| dbo | uf_RequisitionIsVisible | SQL_SCALAR_FUNCTION | 2003-03-13 14:20:02 | 2020-09-02 11:53:28 |  |
| dbo | uf_RequisitionList | SQL_TABLE_VALUED_FUNCTION | 2009-01-06 15:54:14 | 2013-05-22 19:03:44 |  |
| dbo | uf_RequisitionListSelective | SQL_TABLE_VALUED_FUNCTION | 2009-01-06 15:54:52 | 2011-11-22 14:21:02 |  |
| dbo | uf_RequisitionListTest | SQL_TABLE_VALUED_FUNCTION | 2008-06-20 11:36:39 | 2009-03-25 06:55:28 |  |
| dbo | uf_RequisitionStatus | SQL_SCALAR_FUNCTION | 2003-03-13 14:01:08 | 2022-06-22 14:42:09 |  |
| dbo | uf_RTKItems | SQL_INLINE_TABLE_VALUED_FUNCTION | 2005-02-17 15:56:58 | 2012-05-17 16:26:37 |  |
| dbo | uf_RTKItemsRev2 | SQL_INLINE_TABLE_VALUED_FUNCTION | 2013-07-26 16:55:38 | 2015-01-15 14:11:41 |  |
| dbo | uf_RTKUnassignedShipLocations | SQL_INLINE_TABLE_VALUED_FUNCTION | 2005-07-07 19:00:31 | 2009-03-25 06:55:28 |  |
| dbo | uf_SavingsLetter | SQL_TABLE_VALUED_FUNCTION | 2007-04-16 14:57:50 | 2012-02-09 15:32:37 |  |
| dbo | uf_SavingsLetter2 | SQL_TABLE_VALUED_FUNCTION | 2009-03-09 00:03:50 | 2009-03-25 06:55:28 |  |
| dbo | uf_SavingsLetterCounty | SQL_TABLE_VALUED_FUNCTION | 2008-10-31 12:24:25 | 2009-03-25 06:55:28 |  |
| dbo | uf_SavingsLetterCounty1 | SQL_TABLE_VALUED_FUNCTION | 2008-11-13 00:18:14 | 2009-03-25 06:55:28 |  |
| dbo | uf_SavingsLetterCountyNew | SQL_TABLE_VALUED_FUNCTION | 2008-11-12 11:16:51 | 2009-03-25 06:55:28 |  |
| dbo | uf_SavingsLetterOld | SQL_TABLE_VALUED_FUNCTION | 2004-03-05 13:06:04 | 2009-03-25 06:55:28 |  |
| dbo | uf_SavingsLetterState | SQL_TABLE_VALUED_FUNCTION | 2007-12-03 09:31:30 | 2009-03-25 06:55:28 |  |
| dbo | uf_SavingsLetterSummary | SQL_TABLE_VALUED_FUNCTION | 2009-03-08 23:14:35 | 2009-03-25 06:55:28 |  |
| dbo | uf_ScanDocSelectFields | SQL_SCALAR_FUNCTION | 2014-06-10 14:40:13 | 2014-06-10 15:25:31 |  |
| dbo | uf_ScanDocSelectStatement | SQL_SCALAR_FUNCTION | 2014-06-10 15:34:43 | 2014-06-11 15:30:19 |  |
| dbo | uf_ScanDocWhereFields | SQL_SCALAR_FUNCTION | 2014-06-10 14:54:48 | 2014-06-11 14:37:42 |  |
| dbo | uf_SchoolNameAndAddress | SQL_SCALAR_FUNCTION | 2022-04-25 13:15:22 | 2022-04-25 13:15:22 |  |
| dbo | uf_SearchDistrictDetail | SQL_TABLE_VALUED_FUNCTION | 2008-02-26 20:32:44 | 2011-07-13 13:03:23 |  |
| dbo | uf_SearchDistrictDetail_Orig | SQL_TABLE_VALUED_FUNCTION | 2008-02-26 19:40:47 | 2009-03-25 06:55:28 |  |
| dbo | uf_SearchDistrictDetailNew | SQL_TABLE_VALUED_FUNCTION | 2008-02-26 20:22:23 | 2009-03-25 06:55:28 |  |
| dbo | uf_SearchItemsDetail | SQL_INLINE_TABLE_VALUED_FUNCTION | 2004-12-02 23:03:24 | 2012-01-06 11:38:27 |  |
| dbo | uf_SearchItemsHeadings | SQL_INLINE_TABLE_VALUED_FUNCTION | 2004-12-02 21:55:48 | 2009-03-25 06:55:28 |  |
| dbo | uf_SearchKeywords | SQL_SCALAR_FUNCTION | 2004-10-27 09:31:08 | 2009-03-25 06:55:28 |  |
| dbo | uf_SecondPhrase | SQL_SCALAR_FUNCTION | 2003-06-18 01:35:35 | 2003-06-18 01:35:35 |  |
| dbo | uf_SecondWord | SQL_SCALAR_FUNCTION | 2011-08-25 11:45:03 | 2011-08-25 12:53:23 |  |
| dbo | uf_SetSortSeq | SQL_SCALAR_FUNCTION | 2002-02-18 17:28:04 | 2014-09-02 17:01:38 |  |
| dbo | uf_SetSortSeq1 | SQL_SCALAR_FUNCTION | 2006-11-14 21:11:44 | 2006-11-14 21:11:44 |  |
| dbo | uf_SetSortSeq2 | SQL_SCALAR_FUNCTION | 2011-11-28 10:22:37 | 2011-11-28 10:34:52 |  |
| dbo | uf_SetSortSeq3 | SQL_SCALAR_FUNCTION | 2011-11-28 10:22:57 | 2011-11-28 10:22:57 |  |
| dbo | uf_SetSortSeqTest | SQL_SCALAR_FUNCTION | 2014-09-02 16:25:21 | 2014-09-02 16:53:51 |  |
| dbo | uf_SetupSearch | SQL_SCALAR_FUNCTION | 2013-02-13 13:40:00 | 2019-09-26 08:47:39 |  |
| dbo | uf_ShippingNameAndAddress | SQL_SCALAR_FUNCTION | 2009-03-06 14:58:57 | 2009-03-25 06:55:28 |  |
| dbo | uf_ShowDistribution | SQL_TABLE_VALUED_FUNCTION | 2002-06-11 13:27:45 | 2009-03-25 06:55:28 |  |
| dbo | uf_Status | SQL_TABLE_VALUED_FUNCTION | 2007-06-20 09:51:23 | 2009-03-25 06:55:28 |  |
| dbo | uf_TMTradeVendorSummary | SQL_SCALAR_FUNCTION | 2014-05-19 22:46:05 | 2014-05-19 23:06:03 |  |
| dbo | uf_TotalSavings | SQL_TABLE_VALUED_FUNCTION | 2007-07-05 12:09:22 | 2009-03-25 06:55:28 |  |
| dbo | uf_Trim | SQL_SCALAR_FUNCTION | 2004-09-30 14:22:14 | 2004-09-30 14:22:14 |  |
| dbo | uf_UserEmailTree | SQL_TABLE_VALUED_FUNCTION | 2012-03-02 15:25:24 | 2024-09-19 12:38:16 |  |
| dbo | uf_UserInApprovalChain | SQL_SCALAR_FUNCTION | 2003-12-17 02:07:12 | 2009-03-25 06:55:28 |  |
| dbo | uf_UserTree | SQL_TABLE_VALUED_FUNCTION | 2005-11-14 18:26:17 | 2013-11-07 12:28:41 |  |
| dbo | uf_UserTreeApprover | SQL_TABLE_VALUED_FUNCTION | 2013-04-05 12:40:10 | 2013-04-05 12:40:10 |  |
| dbo | uf_UserTreeBudget | SQL_TABLE_VALUED_FUNCTION | 2013-11-06 15:53:10 | 2013-11-07 12:28:44 |  |
| dbo | uf_UserTreeBudgetFiltered | SQL_TABLE_VALUED_FUNCTION | 2013-11-07 13:18:06 | 2022-02-10 11:16:34 |  |
| dbo | uf_UserTreeBudgetWork | SQL_TABLE_VALUED_FUNCTION | 2013-11-07 12:49:41 | 2013-11-07 13:15:52 |  |
| dbo | uf_UserTrees | SQL_TABLE_VALUED_FUNCTION | 2004-11-22 14:54:11 | 2009-03-25 06:55:28 |  |
| dbo | uf_UserTreesDistrict | SQL_TABLE_VALUED_FUNCTION | 2005-08-31 23:52:22 | 2009-03-25 06:55:28 |  |
| dbo | uf_VendorBidContactAddress | SQL_SCALAR_FUNCTION | 2011-09-01 11:51:17 | 2011-09-01 11:51:17 |  |
| dbo | uf_VendorBidContacts | SQL_SCALAR_FUNCTION | 2011-08-25 14:13:23 | 2011-08-25 14:13:23 |  |
| dbo | uf_VendorBidNumbers | SQL_SCALAR_FUNCTION | 2014-04-01 12:52:43 | 2014-04-01 12:52:43 |  |
| dbo | uf_VendorContacts | SQL_SCALAR_FUNCTION | 2011-08-25 11:28:19 | 2011-08-25 14:04:06 |  |
| dbo | uf_VendorEmails | SQL_SCALAR_FUNCTION | 2011-09-19 10:25:40 | 2018-03-19 19:59:58 |  |
| dbo | uf_VendorPhones | SQL_SCALAR_FUNCTION | 2011-09-19 10:26:09 | 2018-03-19 20:00:49 |  |
| dbo | uf_VendorPOContactAddress | SQL_SCALAR_FUNCTION | 2014-01-23 20:11:44 | 2014-01-23 20:11:44 |  |
| dbo | uf_VendorSummary | SQL_TABLE_VALUED_FUNCTION | 2008-07-17 11:59:27 | 2015-03-27 11:47:52 |  |
| dbo | ufn_CatalogRefsDetail | SQL_TABLE_VALUED_FUNCTION | 2018-02-11 20:38:50 | 2018-05-20 23:07:31 |  |
| dbo | ufn_CatalogRefsItem | SQL_TABLE_VALUED_FUNCTION | 2018-02-11 20:42:10 | 2018-05-20 23:07:30 |  |
| dbo | ufn_DistrictInvoiceAddress | SQL_SCALAR_FUNCTION | 2022-11-16 19:18:25 | 2022-11-16 19:18:48 |  |
| dbo | ufn_GetHazardsDescription | SQL_SCALAR_FUNCTION | 2017-03-17 16:37:09 | 2017-03-17 16:39:50 |  |
| dbo | ufn_GetMSDSSheet | SQL_TABLE_VALUED_FUNCTION | 2017-03-16 13:28:51 | 2017-03-16 13:28:51 |  |
| dbo | ufn_GetMSDSSheets | SQL_TABLE_VALUED_FUNCTION | 2017-01-25 06:32:42 | 2017-03-02 08:31:25 |  |
| dbo | ufn_GetMSDSSheetsNonHazardous | SQL_TABLE_VALUED_FUNCTION | 2017-04-19 15:26:11 | 2017-04-19 15:59:23 |  |
| dbo | ufn_GetMSDSSheetsNotScanned | SQL_TABLE_VALUED_FUNCTION | 2017-04-19 16:00:36 | 2017-04-19 16:00:36 |  |
| dbo | ufn_GoogleToFTS_2 | CLR_SCALAR_FUNCTION | 2018-10-10 11:41:57 | 2018-10-10 11:41:57 |  |
| dbo | ufn_MSDSItems | SQL_SCALAR_FUNCTION | 2017-08-17 16:29:57 | 2017-08-17 16:29:57 |  |
| dbo | ufn_MSDSManufacturers | SQL_SCALAR_FUNCTION | 2017-08-17 16:50:38 | 2017-08-17 16:50:38 |  |
| dbo | ufn_MSDSMPNs | SQL_SCALAR_FUNCTION | 2017-08-17 16:44:55 | 2017-08-17 16:44:55 |  |
| dbo | ufn_VerifyForPO | SQL_TABLE_VALUED_FUNCTION | 2015-03-23 22:06:45 | 2015-03-23 22:06:45 |  |
| dbo | UrlDecode | SQL_SCALAR_FUNCTION | 2020-11-03 14:51:07 | 2020-11-03 14:51:07 |  |
| EDSIQWebUser | uf_CoverPages | SQL_INLINE_TABLE_VALUED_FUNCTION | 2002-09-09 16:57:59 | 2009-03-25 06:55:28 |  |
| EDSIQWebUser | uf_IsRequisitionLocked | SQL_SCALAR_FUNCTION | 2003-01-20 15:53:52 | 2009-03-25 06:55:28 |  |
| EDSIQWebUser | uf_LookupItemCode | SQL_TABLE_VALUED_FUNCTION | 2003-11-21 03:05:10 | 2009-03-25 06:55:28 |  |
| EDSIQWebUser | uf_LookupItems | SQL_TABLE_VALUED_FUNCTION | 2003-11-05 19:17:42 | 2009-03-25 06:55:28 |  |
| EDSIQWebUser | uf_LookupItemsByCatalog | SQL_TABLE_VALUED_FUNCTION | 2003-06-27 19:06:07 | 2009-03-25 06:55:28 |  |
| EDSIQWebUser | uf_LookupItemsForBatch | SQL_TABLE_VALUED_FUNCTION | 2003-06-27 19:06:07 | 2009-03-25 06:55:28 |  |
| EDSIQWebUser | uf_LookupItemsForBatch1 | SQL_INLINE_TABLE_VALUED_FUNCTION | 2002-12-30 17:22:59 | 2009-03-25 06:55:28 |  |
| EDSIQWebUser | uf_LookupItemsForBook | SQL_TABLE_VALUED_FUNCTION | 2003-06-27 19:06:07 | 2009-03-25 06:55:28 |  |
| EDSIQWebUser | uf_LookupItemsForBook1 | SQL_INLINE_TABLE_VALUED_FUNCTION | 2002-12-30 17:48:20 | 2009-03-25 06:55:28 |  |
| EDSIQWebUser | uf_LookupPrice | SQL_TABLE_VALUED_FUNCTION | 2003-07-02 01:43:17 | 2009-03-25 06:55:28 |  |
| EDSIQWebUser | uf_LookupPrice1 | SQL_INLINE_TABLE_VALUED_FUNCTION | 2002-10-06 15:23:03 | 2009-03-25 06:55:28 |  |
| EDSIQWebUser | uf_LookupPrices | SQL_TABLE_VALUED_FUNCTION | 2003-06-27 19:06:07 | 2009-03-25 06:55:28 |  |
| EDSIQWebUser | uf_OrderBook | SQL_TABLE_VALUED_FUNCTION | 2003-06-27 19:03:37 | 2009-03-25 06:55:28 |  |
| EDSIQWebUser | uf_Sys3000ToWinCap | SQL_TABLE_VALUED_FUNCTION | 2003-06-27 19:04:01 | 2003-06-27 19:04:01 |  |
| EDSIQWebUser | uf_TopOrderBook | SQL_INLINE_TABLE_VALUED_FUNCTION | 2002-08-14 21:46:24 | 2009-03-25 06:55:28 |  |


## Relationships

**Total Foreign Key Relationships:** 31

| Foreign Key | Parent Table | Parent Column | Referenced Table | Referenced Column | On Delete | On Update |
|-------------|--------------|---------------|------------------|-------------------|-----------|-----------|
| Catalog Request Header/Detail | dbo.CatalogRequestDetail | CatalogRequestId | dbo.CatalogRequest | CatalogRequestId | CASCADE | NO_ACTION |
| Catalog Request Header/Status | dbo.CatalogRequestStatus | CatalogRequestId | dbo.CatalogRequest | CatalogRequestId | CASCADE | NO_ACTION |
| FK_Accounts_District | dbo.Accounts | DistrictId | dbo.District | DistrictId | NO_ACTION | NO_ACTION |
| FK_Accounts_School | dbo.Accounts | SchoolId | dbo.School | SchoolId | NO_ACTION | NO_ACTION |
| FK_BidAnswersJournal_BidAnswers | dbo.BidAnswersJournal | BidAnswerId | dbo.BidAnswers | BidAnswerId | CASCADE | CASCADE |
| FK_BidQuestions_BidTrades | dbo.BidQuestions | BidTradeId | dbo.BidTrades | BidTradeId | CASCADE | NO_ACTION |
| FK_BidRequestManufacturer_BidHeaders | dbo.BidRequestManufacturer | BidHeaderId | dbo.BidHeaders | BidHeaderId | CASCADE | CASCADE |
| FK_BudgetAccounts_Accounts | dbo.BudgetAccounts | AccountId | dbo.Accounts | AccountId | NO_ACTION | NO_ACTION |
| FK_BudgetAccounts_Budgets | dbo.BudgetAccounts | BudgetId | dbo.Budgets | BudgetId | NO_ACTION | NO_ACTION |
| FK_Budgets_District | dbo.Budgets | DistrictId | dbo.District | DistrictId | NO_ACTION | CASCADE |
| FK_Catalog_Category | dbo.Catalog | CategoryId | dbo.Category | CategoryId | NO_ACTION | CASCADE |
| FK_Catalog_Vendors | dbo.Catalog | VendorId | dbo.Vendors | VendorId | NO_ACTION | CASCADE |
| FK_DistrictPP_PricePlans | dbo.DistrictPP | PricePlanId | dbo.PricePlans | PricePlanId | NO_ACTION | NO_ACTION |
| FK_DistrictVendor_District | dbo.DistrictVendor | DistrictId | dbo.District | DistrictId | NO_ACTION | CASCADE |
| FK_DistrictVendor_Vendors | dbo.DistrictVendor | VendorId | dbo.Vendors | VendorId | NO_ACTION | CASCADE |
| FK_MSDSDetail_MSDS | dbo.MSDSDetail | MSDSID | dbo.MSDS | MSDSId | CASCADE | NO_ACTION |
| FK_PO_Requisitions | dbo.PO | RequisitionId | dbo.Requisitions | RequisitionId | NO_ACTION | NO_ACTION |
| FK_PO_Vendors | dbo.PO | VendorId | dbo.Vendors | VendorId | CASCADE | CASCADE |
| FK_PODetailItems_Detail | dbo.PODetailItems | DetailId | dbo.Detail | DetailId | NO_ACTION | NO_ACTION |
| FK_PODetailItems_PO | dbo.PODetailItems | POId | dbo.PO | POId | NO_ACTION | NO_ACTION |
| FK_prices_BidItems | dbo.Prices | BidItemId | dbo.BidItems_Old | BidItemId | CASCADE | CASCADE |
| FK_Requisitions_Budgets | dbo.Requisitions | BudgetId | dbo.Budgets | BudgetId | NO_ACTION | NO_ACTION |
| FK_Requisitions_Category | dbo.Requisitions | CategoryId | dbo.Category | CategoryId | NO_ACTION | NO_ACTION |
| FK_School_District | dbo.School | DistrictId | dbo.District | DistrictId | NO_ACTION | NO_ACTION |
| FK_UserAccounts_Accounts | dbo.UserAccounts | AccountId | dbo.Accounts | AccountId | NO_ACTION | CASCADE |
| FK_UserAccounts_BudgetAccounts | dbo.UserAccounts | BudgetAccountId | dbo.BudgetAccounts | BudgetAccountId | NO_ACTION | CASCADE |
| FK_UserAccounts_Budgets | dbo.UserAccounts | BudgetId | dbo.Budgets | BudgetId | NO_ACTION | CASCADE |
| MSRP Vendor Query Header/Detail | dbo.VendorQueryMSRPDetail | VendorQueryMSRPId | dbo.VendorQueryMSRP | VendorQueryMSRPId | CASCADE | NO_ACTION |
| MSRP Vendor Query Header/Status | dbo.VendorQueryMSRPStatus | VendorQueryMSRPId | dbo.VendorQueryMSRP | VendorQueryMSRPId | CASCADE | NO_ACTION |
| T&M Vendor Query Header/Detail | dbo.VendorQueryTandMDetail | VendorQueryTandMId | dbo.VendorQueryTandM | VendorQueryTandMId | CASCADE | NO_ACTION |
| T&M Vendor Query Header/Status | dbo.VendorQueryTandMStatus | VendorQueryTandMId | dbo.VendorQueryTandM | VendorQueryTandMId | CASCADE | NO_ACTION |


---
*Generated on 2025-08-27 09:31:32 using Azure SQL Database Documentation Tool*